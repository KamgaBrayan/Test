# Migration CCA sans VPN : ETL en local, rejeu SQL par l'éditeur

## Principe

1. DHI exécute les ETL Talend sur une **copie locale** des bases Fluxoon (même schéma, mêmes seeders que la production).
2. `export_migration.py` extrait des bases locales **uniquement les données CCA écrites par les ETL** et produit un script SQL par base.
3. L'éditeur rejoue ces scripts sur la production, dans son réseau. Ils sont transactionnels et rejouables (`ON CONFLICT … DO UPDATE`).

## Prérequis

- Bases locales identiques à la production : obtenir de l'éditeur un dump récent (schéma + configuration) ou, au minimum, l'historique Flyway de chaque base pour vérifier les versions ; restaurer, puis passer les seeders 01 à 06.
- Aucune modification de configuration en production entre le passage des seeders et le rejeu (postes, unités, sites…) : `job_positions` est réexporté en entier et écraserait une modification faite entre-temps.
- Rémunération : le catalogue CM version 3 doit être créé en production (manuellement) avec les **mêmes numéros** que ceux utilisés localement, avant le rejeu de `04_data_compensation_db.sql`.
- Python 3 et `pip install psycopg2-binary` sur le poste DHI.

## Étapes côté DHI

```bash
# 1. ETL en local (contexte Talend LOCAL), puis le script 07 de recalage de séquence (chargement complet uniquement)
# 2. Export
python export_migration.py --host localhost --port 5432 --user postgres --password '***' --out ./export
#    essai sur quelques salariés : même liste que la variable de contexte TEST_KEYS
python export_migration.py --password '***' --out ./export_test --keys "001|00960;001|01283;002|01500"
```

Le dossier `export` contient `01_data_employee_db.sql`, `02_data_employment_db.sql`, `03_data_career_db.sql`,
`04_data_compensation_db.sql` et `MANIFEST.txt` (volumes par table et empreinte SHA-256 de chaque fichier).

## Étapes côté éditeur (production)

```bash
# sauvegarde préalable des quatre bases, puis :
psql -v ON_ERROR_STOP=1 -d employee_db     -f 01_data_employee_db.sql
psql -v ON_ERROR_STOP=1 -d employment_db   -f 02_data_employment_db.sql
psql -v ON_ERROR_STOP=1 -d career_db       -f 03_data_career_db.sql
psql -v ON_ERROR_STOP=1 -d compensation_db -f 04_data_compensation_db.sql
```

Chaque fichier se termine par une requête de contrôle (volumes en base / volumes exportés) : l'éditeur renvoie la sortie
à DHI. En cas d'erreur, la transaction du fichier est annulée en entier ; il suffit de corriger et de rejouer.
Après le rejeu, l'éditeur indique si l'application doit être réindexée ou redémarrée pour prendre en compte les données.

## Protection des données

Les fichiers contiennent des données personnelles et sensibles (identité, pièces d'identité, comptes bancaires, salaires,
sanctions). Les transmettre chiffrés (archive protégée par mot de passe communiqué par un autre canal, ou espace de dépôt
sécurisé de l'éditeur), vérifier les empreintes SHA-256 du MANIFEST à réception, puis supprimer les copies intermédiaires.
