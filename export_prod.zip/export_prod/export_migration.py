#!/usr/bin/env python3
"""
Export des données CCA chargées par les ETL dans les bases Fluxoon LOCALES,
sous forme de scripts SQL rejouables par l'éditeur sur les bases de PRODUCTION.

- Une seule entreprise exportée : COMPANY_ID (CCA).
- Uniquement les tables alimentées par les ETL (les seeders sont déjà passés en prod).
- Chaque INSERT se termine par ON CONFLICT (clé primaire) DO UPDATE : rejouable sans doublon.
- Un fichier par base, une transaction par fichier, ordre compatible avec les clés étrangères,
  et une requête de contrôle des volumes en fin de fichier.

Usage :
  pip install psycopg2-binary
  python export_migration.py --host localhost --port 5432 --user postgres --password xxx --out ./export
  (option --keys "001|00960;001|01283" pour n'exporter que les salariés du test : voir README)
"""
import argparse, json, datetime, decimal, os, uuid, hashlib
import psycopg2, psycopg2.extras

COMPANY_ID = '0a2cc461-2674-4861-912a-0c624953ef64'
BATCH = 500

# base -> tables dans l'ordre d'écriture (parents avant enfants)
PLAN = {
    'employee_db': ['employees', 'registration_number_assignments', 'secondary_identifiers', 'employee_identities',
                    'dependents', 'employee_payment_accounts', 'employee_career_records', 'employee_affiliations',
                    'registration_number_sequences'],
    'employment_db': ['job_positions', 'employee_engagements', 'employments', 'employment_movements'],
    'career_db': ['career_incidents', 'incident_members', 'incident_actions', 'trainings', 'training_sessions',
                  'training_participants'],
    'compensation_db': ['employee_compensations', 'employee_benefit_assignments'],
}
# tables liées au salarié : filtrables par la liste de test (--keys)
EMPLOYEE_COL = {'employees', 'registration_number_assignments', 'secondary_identifiers', 'employee_identities', 'dependents',
                'employee_payment_accounts', 'employee_career_records', 'employee_affiliations', 'employee_engagements',
                'employments', 'employment_movements', 'incident_members', 'training_participants',
                'employee_compensations', 'employee_benefit_assignments'}

def emp_id(cdos, nmat):   # identique à MigUtils.employeeId (UUID v3 de "EMP|CDOS|NMAT")
    return str(uuid.UUID(bytes=_v3(('EMP|' + cdos.strip() + '|' + nmat.strip()).encode('utf-8'))))
def _v3(b):
    h = bytearray(hashlib.md5(b).digest()); h[6] = (h[6] & 0x0f) | 0x30; h[8] = (h[8] & 0x3f) | 0x80; return bytes(h)

def js(v):
    if isinstance(v, (datetime.datetime, datetime.date, datetime.time)): return v.isoformat()
    if isinstance(v, decimal.Decimal): return str(v)
    if isinstance(v, uuid.UUID): return str(v)
    raise TypeError(type(v))

def table_meta(cur, t):
    cur.execute("""select a.attname from pg_attribute a join pg_class c on c.oid=a.attrelid join pg_namespace n on n.oid=c.relnamespace
                   where n.nspname='public' and c.relname=%s and a.attnum>0 and not a.attisdropped order by a.attnum""", (t,))
    cols = [r[0] for r in cur.fetchall()]
    cur.execute("""select a.attname from pg_index i join pg_class c on c.oid=i.indrelid join pg_namespace n on n.oid=c.relnamespace
                   join pg_attribute a on a.attrelid=c.oid and a.attnum=any(i.indkey) where n.nspname='public' and c.relname=%s and i.indisprimary""", (t,))
    pk = [r[0] for r in cur.fetchall()]
    return cols, pk

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--host', default='localhost'); ap.add_argument('--port', default='5432')
    ap.add_argument('--user', default='postgres'); ap.add_argument('--password', default='')
    ap.add_argument('--out', default='./export'); ap.add_argument('--keys', default='')
    ap.add_argument('--db-suffix', default='', help='suffixe éventuel des noms de bases locales')
    ap.add_argument('--dbs', default='', help='bases à exporter, séparées par des virgules (défaut : toutes). Ex. : employee_db')
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    ids = [emp_id(*k.split('|')) for k in a.keys.replace(',', ';').split(';') if '|' in k]
    stamp = datetime.datetime.now().strftime('%Y-%m-%d %H:%M')
    summary = []
    wanted = [d.strip() for d in a.dbs.split(',') if d.strip()]
    for i, (db, tables) in enumerate(PLAN.items(), 1):
        if wanted and db not in wanted:
            continue
        try:
            conn = psycopg2.connect(host=a.host, port=a.port, user=a.user, password=a.password, dbname=db + a.db_suffix)
        except Exception as e:
            print(f"!! {db} : connexion impossible, base ignorée ({str(e).strip().splitlines()[0]})")
            continue
        cur = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
        fname = os.path.join(a.out, f'{i:02d}_data_{db}.sql')
        counts = []
        with open(fname, 'w', encoding='utf-8') as f:
            f.write(f"-- Données CCA migrées depuis Amplitude : {db}\n-- Généré le {stamp} à partir des bases locales.\n"
                    f"-- Exécution : psql -v ON_ERROR_STOP=1 -d {db} -f {os.path.basename(fname)}\n"
                    + (f"-- Périmètre de test : {len(ids)} salarié(s)\n" if ids else "") +
                    "SET client_encoding = 'UTF8';\nSET client_min_messages = warning;\nBEGIN;\n")
            for t in tables:
                cols, pk = table_meta(conn.cursor(), t)
                if not cols:
                    f.write(f"-- {t} : table absente de la base locale\n"); continue
                where, args = "company_id = %s", [COMPANY_ID]
                if ids:
                    if t in EMPLOYEE_COL: where += " and employee_id = any(%s)"; args.append(ids)
                    elif t == 'incident_actions': where += " and target_employee_id = any(%s)"; args.append(ids)
                    elif t == 'career_incidents':
                        where += " and incident_id in (select incident_id from incident_members where company_id=%s and employee_id = any(%s))"; args += [COMPANY_ID, ids]
                    elif t in ('registration_number_sequences', 'job_positions', 'trainings', 'training_sessions'):
                        pass  # référentiels : exportés en entier (petits, rejouables)
                cur.execute(f'select * from public."{t}" where {where} order by {", ".join(chr(34)+c+chr(34) for c in pk)}', args)
                rows = cur.fetchall()
                counts.append((t, len(rows), where.split(' and ')[0]))
                f.write(f"\n-- {t} : {len(rows)} ligne(s)\n")
                q = lambda c: '"' + c + '"'
                upd = [c for c in cols if c not in pk and c != 'created_at']
                for s in range(0, len(rows), BATCH):
                    chunk = rows[s:s + BATCH]
                    body = ',\n'.join(json.dumps(r, ensure_ascii=False, default=js) for r in chunk)
                    f.write(f"INSERT INTO public.{q(t)} ({', '.join(map(q, cols))})\nSELECT {', '.join(map(q, cols))} FROM "
                            f"jsonb_populate_recordset(NULL::public.{q(t)}, $JSON$[\n{body}\n]$JSON$::jsonb)\n"
                            f"ON CONFLICT ({', '.join(map(q, pk))}) DO UPDATE SET "
                            + ', '.join(f'{q(c)} = EXCLUDED.{q(c)}' for c in upd) + ";\n")
            f.write("\nCOMMIT;\n\n-- Contrôle : volumes CCA après rejeu (doivent être >= aux volumes exportés ci-dessous)\n")
            f.write('\nUNION ALL '.join(f"SELECT '{t}' AS table_name, count(*) AS en_base, {n} AS exportees FROM public.\"{t}\" WHERE company_id = '{COMPANY_ID}'" for t, n, _ in counts) + ';\n')
        conn.close()
        sha = hashlib.sha256(open(fname, 'rb').read()).hexdigest()
        summary.append((os.path.basename(fname), counts, sha))
    with open(os.path.join(a.out, 'MANIFEST.txt'), 'w', encoding='utf-8') as m:
        m.write(f"Export CCA du {stamp}\n" + (f"Périmètre de test : {a.keys}\n" if ids else "Périmètre : complet\n"))
        for fn, counts, sha in summary:
            m.write(f"\n{fn}  sha256={sha}\n" + ''.join(f"  {t:35s} {n:>8d}\n" for t, n, _ in counts))
    print(open(os.path.join(a.out, 'MANIFEST.txt'), encoding='utf-8').read())

if __name__ == '__main__':
    main()
