--
-- PostgreSQL database dump
--

\restrict GwxxJWH3yOBW7uxzwi357NcD8mWZ0nLBSj1vzlgxa7ZOjx9Yd1aCpMW0zgGhjdq

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: prevent_campaign_configuration_refreeze(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.prevent_campaign_configuration_refreeze() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    PERFORM 1 FROM payroll_campaigns
      WHERE company_id = NEW.company_id AND payroll_id = NEW.run_id FOR UPDATE;
    IF EXISTS (SELECT 1 FROM payroll_run_configurations WHERE company_id = NEW.company_id AND run_id = NEW.run_id) THEN
        RAISE EXCEPTION 'Campaign configuration is immutable after startup';
    END IF;
    RETURN NEW;
END $$;


ALTER FUNCTION public.prevent_campaign_configuration_refreeze() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: campaign_payment_exports; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.campaign_payment_exports (
    cancelled_amount numeric(38,2),
    confirmed_amount numeric(38,2),
    pending_amount numeric(38,2),
    total_amount numeric(38,2),
    cancelled_payments bigint NOT NULL,
    confirmed_payments bigint NOT NULL,
    exported_at timestamp(6) with time zone,
    pending_payments bigint NOT NULL,
    total_payments bigint NOT NULL,
    campaign_id character varying(255) NOT NULL,
    campaign_reference character varying(255),
    company_id character varying(255) NOT NULL,
    export_format character varying(255),
    file text,
    CONSTRAINT campaign_payment_exports_export_format_check CHECK (((export_format)::text = ANY (ARRAY[('EXCEL'::character varying)::text, ('CSV'::character varying)::text])))
);


ALTER TABLE public.campaign_payment_exports OWNER TO postgres;

--
-- Name: cumulative_balances; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cumulative_balances (
    fiscal_window_end date NOT NULL,
    fiscal_window_start date NOT NULL,
    total numeric(24,6) NOT NULL,
    last_entry_sequence bigint NOT NULL,
    lock_version bigint NOT NULL,
    updated_at timestamp(6) with time zone,
    accumulator_code character varying(255) NOT NULL,
    company_id character varying(255) NOT NULL,
    employee_id character varying(255) NOT NULL,
    jurisdiction character varying(255) NOT NULL,
    legal_entity_id character varying(255) NOT NULL
);


ALTER TABLE public.cumulative_balances OWNER TO postgres;

--
-- Name: cumulative_entries; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cumulative_entries (
    amount numeric(24,6) NOT NULL,
    fiscal_window_end date NOT NULL,
    fiscal_window_start date NOT NULL,
    source_bulletin_version integer NOT NULL,
    entry_sequence bigint NOT NULL,
    occurred_at timestamp(6) with time zone NOT NULL,
    accumulator_code character varying(255) NOT NULL,
    company_id character varying(255) NOT NULL,
    employee_id character varying(255) NOT NULL,
    id character varying(255) NOT NULL,
    idempotency_key character varying(255) NOT NULL,
    jurisdiction character varying(255) NOT NULL,
    legal_entity_id character varying(255) NOT NULL,
    operation character varying(255) NOT NULL,
    payroll_period_id character varying(255) NOT NULL,
    reason character varying(255),
    reverted_entry_id character varying(255),
    source_bulletin_id character varying(255) NOT NULL,
    CONSTRAINT cumulative_entries_operation_check CHECK (((operation)::text = ANY (ARRAY[('APPLY'::character varying)::text, ('REVERT'::character varying)::text, ('ADJUST'::character varying)::text])))
);


ALTER TABLE public.cumulative_entries OWNER TO postgres;

--
-- Name: cumulative_entry_sequence; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cumulative_entry_sequence
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cumulative_entry_sequence OWNER TO postgres;

--
-- Name: cumulative_rules; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cumulative_rules (
    id character varying(255) NOT NULL,
    country_code character varying(255) NOT NULL,
    accumulator_code character varying(255) NOT NULL,
    label character varying(255) NOT NULL,
    status character varying(32) NOT NULL,
    scope character varying(255) NOT NULL,
    start_month integer,
    end_month integer,
    rolling_months_window integer,
    include_current_pay_period boolean NOT NULL,
    aggregation character varying(255) NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    activated_at timestamp with time zone,
    archived_at timestamp with time zone,
    CONSTRAINT cumulative_rules_aggregation_check CHECK (((aggregation)::text = ANY ((ARRAY['SUM'::character varying, 'AVERAGE'::character varying, 'LAST_VALUE'::character varying])::text[]))),
    CONSTRAINT cumulative_rules_scope_check CHECK (((scope)::text = ANY ((ARRAY['CALENDAR_YEAR'::character varying, 'FISCAL_YEAR'::character varying, 'ROLLING_WINDOW'::character varying])::text[]))),
    CONSTRAINT cumulative_rules_status_check CHECK (((status)::text = ANY ((ARRAY['DRAFT'::character varying, 'ACTIVE'::character varying, 'ARCHIVED'::character varying])::text[]))),
    CONSTRAINT cumulative_rules_status_dates_check CHECK (((((status)::text <> 'ACTIVE'::text) OR (activated_at IS NOT NULL)) AND (((status)::text <> 'ARCHIVED'::text) OR (archived_at IS NOT NULL))))
);


ALTER TABLE public.cumulative_rules OWNER TO postgres;

--
-- Name: documents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.documents (
    "timestamp" timestamp(6) without time zone NOT NULL,
    format character varying(255) NOT NULL,
    id character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    data oid NOT NULL,
    CONSTRAINT documents_format_check CHECK (((format)::text = ANY (ARRAY[('PNG'::character varying)::text, ('JPEG'::character varying)::text, ('CSV'::character varying)::text, ('XLS'::character varying)::text, ('PDF'::character varying)::text])))
);


ALTER TABLE public.documents OWNER TO postgres;

--
-- Name: employee_engine_inputs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employee_engine_inputs (
    version integer NOT NULL,
    captured_at timestamp(6) with time zone NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    lock_version bigint,
    updated_at timestamp(6) with time zone NOT NULL,
    captured_by character varying(255),
    code character varying(255) NOT NULL,
    display_name character varying(255),
    employee_id character varying(255) NOT NULL,
    id character varying(255) NOT NULL,
    legal_entity_id character varying(255) NOT NULL,
    occurrence character varying(255) NOT NULL,
    org_id character varying(255) NOT NULL,
    period_id character varying(255) NOT NULL,
    previous_version_id character varying(255),
    source character varying(255) NOT NULL,
    source_aggregate_id character varying(255),
    source_domain character varying(255),
    source_event_id character varying(255),
    source_label character varying(255),
    status character varying(255) NOT NULL,
    value text NOT NULL,
    value_type character varying(255) NOT NULL,
    CONSTRAINT employee_engine_inputs_source_check CHECK (((source)::text = ANY (ARRAY[('MANUAL'::character varying)::text, ('IMPORT'::character varying)::text, ('SYSTEM'::character varying)::text, ('INTEGRATION'::character varying)::text]))),
    CONSTRAINT employee_engine_inputs_status_check CHECK (((status)::text = ANY (ARRAY[('DRAFT'::character varying)::text, ('VALIDATED'::character varying)::text, ('SUPERSEDED'::character varying)::text, ('CANCELLED'::character varying)::text]))),
    CONSTRAINT employee_engine_inputs_value_type_check CHECK (((value_type)::text = ANY (ARRAY[('MONEY'::character varying)::text, ('DECIMAL'::character varying)::text, ('RATE'::character varying)::text, ('QUANTITY'::character varying)::text, ('BOOLEAN'::character varying)::text, ('DATE'::character varying)::text, ('TEXT'::character varying)::text])))
);


ALTER TABLE public.employee_engine_inputs OWNER TO postgres;

--
-- Name: employee_payroll_preparation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employee_payroll_preparation (
    id character varying(255) NOT NULL,
    company_id character varying(255) NOT NULL,
    legal_entity_id character varying(255) NOT NULL,
    period_id character varying(255) NOT NULL,
    employee_id character varying(255) NOT NULL,
    status character varying(32) NOT NULL,
    generation bigint DEFAULT 0 NOT NULL,
    lock_version bigint DEFAULT 0 NOT NULL,
    last_attempt_at timestamp with time zone,
    last_successful_refresh_at timestamp with time zone,
    compensation_snapshot_id character varying(255),
    prepared_revision_id character varying(255),
    issues jsonb DEFAULT '[]'::jsonb NOT NULL,
    requirements jsonb DEFAULT '[]'::jsonb NOT NULL,
    invalidated_at timestamp with time zone,
    invalidation_reasons jsonb,
    excluded_by character varying(255),
    excluded_at timestamp with time zone,
    exclusion_reason text,
    CONSTRAINT employee_preparation_exclusion CHECK ((((excluded_at IS NULL) AND (excluded_by IS NULL) AND (exclusion_reason IS NULL)) OR ((excluded_at IS NOT NULL) AND (excluded_by IS NOT NULL) AND (exclusion_reason IS NOT NULL))))
);


ALTER TABLE public.employee_payroll_preparation OWNER TO postgres;

--
-- Name: engine_bases; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.engine_bases (
    optional boolean,
    code character varying(255) NOT NULL,
    description text NOT NULL,
    display_name character varying(255) NOT NULL,
    engine_id character varying(255) NOT NULL,
    formular jsonb NOT NULL,
    rounding_rule character varying(255) NOT NULL,
    type character varying(255) NOT NULL,
    CONSTRAINT engine_bases_rounding_rule_check CHECK (((rounding_rule)::text = ANY (ARRAY[('NONE'::character varying)::text, ('UP'::character varying)::text, ('DOWN'::character varying)::text, ('HALF_UP'::character varying)::text, ('HALF_DOWN'::character varying)::text]))),
    CONSTRAINT engine_bases_type_check CHECK (((type)::text = ANY (ARRAY[('REMUNERATION'::character varying)::text, ('INTERMEDIATE'::character varying)::text, ('SUMMARY'::character varying)::text])))
);


ALTER TABLE public.engine_bases OWNER TO postgres;

--
-- Name: engine_benefits; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.engine_benefits (
    code character varying(255) NOT NULL,
    engine_id character varying(255) NOT NULL,
    country_code character varying(255) NOT NULL,
    catalog_number character varying(255) NOT NULL,
    catalog_version bigint NOT NULL,
    catalog_valid_from date,
    catalog_valid_to date,
    display_name character varying(255) NOT NULL,
    legal_ref character varying(255),
    allowed_supply_modes character varying(255) NOT NULL,
    characteristics jsonb DEFAULT '[]'::jsonb NOT NULL,
    status character varying(20) NOT NULL,
    justification text,
    valuation_scope character varying(20),
    aggregates jsonb DEFAULT '[]'::jsonb NOT NULL,
    in_kind_formula text,
    cash_formula text,
    rounding_rule character varying(20) NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    CONSTRAINT engine_benefits_aggregates_check CHECK ((jsonb_typeof(aggregates) = 'array'::text)),
    CONSTRAINT engine_benefits_catalog_version_check CHECK ((catalog_version > 0)),
    CONSTRAINT engine_benefits_characteristics_check CHECK ((jsonb_typeof(characteristics) = 'array'::text)),
    CONSTRAINT engine_benefits_rounding_rule_check CHECK (((rounding_rule)::text = ANY ((ARRAY['NONE'::character varying, 'UP'::character varying, 'DOWN'::character varying, 'HALF_UP'::character varying, 'HALF_DOWN'::character varying])::text[]))),
    CONSTRAINT engine_benefits_status_check CHECK (((status)::text = ANY ((ARRAY['TO_CONFIGURE'::character varying, 'VALUED'::character varying, 'NOT_VALUED'::character varying])::text[]))),
    CONSTRAINT engine_benefits_valuation_scope_check CHECK (((valuation_scope)::text = ANY ((ARRAY['GROUPED'::character varying, 'INDIVIDUAL'::character varying])::text[])))
);


ALTER TABLE public.engine_benefits OWNER TO postgres;

--
-- Name: engine_constants; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.engine_constants (
    value numeric(19,6) NOT NULL,
    code character varying(255) NOT NULL,
    description character varying(255) NOT NULL,
    engine_id character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    override_input_code character varying(255),
    resolution_policy character varying(255) NOT NULL,
    value_type character varying(255) NOT NULL,
    CONSTRAINT engine_constants_resolution_policy_check CHECK (((resolution_policy)::text = ANY (ARRAY[('REJECT_OVERRIDE'::character varying)::text, ('ENGINE_ONLY'::character varying)::text, ('INPUT_OVERRIDE'::character varying)::text, ('MAXIMUM'::character varying)::text, ('MINIMUM'::character varying)::text]))),
    CONSTRAINT engine_constants_value_type_check CHECK (((value_type)::text = ANY (ARRAY[('HOURS'::character varying)::text, ('DAYS'::character varying)::text, ('YEARS'::character varying)::text, ('MONTHS'::character varying)::text, ('AMOUNT'::character varying)::text, ('COUNT'::character varying)::text, ('PERCENT'::character varying)::text, ('NUMBER'::character varying)::text, ('RATE'::character varying)::text, ('PERCENTAGE'::character varying)::text, ('QUANTITY'::character varying)::text, ('BOOLEAN'::character varying)::text, ('ENUM'::character varying)::text, ('STRING'::character varying)::text])))
);


ALTER TABLE public.engine_constants OWNER TO postgres;

--
-- Name: engine_cumulative_bindings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.engine_cumulative_bindings (
    engine_id character varying(255) NOT NULL,
    accumulator_code character varying(255) NOT NULL,
    source_code character varying(255) NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.engine_cumulative_bindings OWNER TO postgres;

--
-- Name: engine_functions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.engine_functions (
    description character varying(255) NOT NULL,
    engine_id character varying(255) NOT NULL,
    fnc jsonb NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE public.engine_functions OWNER TO postgres;

--
-- Name: engine_inputs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.engine_inputs (
    catalog_valid_from date,
    catalog_valid_to date,
    integral boolean NOT NULL,
    maximum numeric(38,2),
    minimum numeric(38,2),
    overridable boolean NOT NULL,
    required boolean NOT NULL,
    system_defined boolean NOT NULL,
    catalog_version bigint,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    aggregation character varying(255),
    allowed_sources character varying(255) NOT NULL,
    code character varying(255) NOT NULL,
    color character varying(255),
    country_code character varying(255) NOT NULL,
    currency character varying(255),
    display_name character varying(255) NOT NULL,
    engine_id character varying(255) NOT NULL,
    frequency character varying(255) NOT NULL,
    icon character varying(255),
    input_value_type character varying(255),
    legal_ref character varying(255),
    localized_display_names jsonb,
    possible_values character varying(255),
    reference_value character varying(255),
    resolution_policy character varying(255),
    unit character varying(255),
    value_type character varying(255) NOT NULL,
    CONSTRAINT engine_inputs_aggregation_check CHECK (((aggregation)::text = ANY (ARRAY[('SINGLE'::character varying)::text, ('SUM'::character varying)::text]))),
    CONSTRAINT engine_inputs_frequency_check CHECK (((frequency)::text = ANY (ARRAY[('PERMANENT'::character varying)::text, ('CAMPAIGN'::character varying)::text]))),
    CONSTRAINT engine_inputs_input_value_type_check CHECK (((input_value_type)::text = ANY (ARRAY[('MONEY'::character varying)::text, ('DECIMAL'::character varying)::text, ('RATE'::character varying)::text, ('QUANTITY'::character varying)::text, ('BOOLEAN'::character varying)::text, ('DATE'::character varying)::text, ('TEXT'::character varying)::text]))),
    CONSTRAINT engine_inputs_resolution_policy_check CHECK (((resolution_policy)::text = ANY (ARRAY[('REFERENCE_ONLY'::character varying)::text, ('EXTERNAL_OVERRIDE'::character varying)::text, ('MAXIMUM'::character varying)::text, ('MINIMUM'::character varying)::text]))),
    CONSTRAINT engine_inputs_unit_check CHECK (((unit)::text = ANY ((ARRAY['HOURS'::character varying, 'DAYS'::character varying, 'MONTHS'::character varying, 'YEARS'::character varying, 'UNITS'::character varying, 'KILOMETERS'::character varying])::text[]))),
    CONSTRAINT engine_inputs_value_type_check CHECK (((value_type)::text = ANY (ARRAY[('HOURS'::character varying)::text, ('DAYS'::character varying)::text, ('YEARS'::character varying)::text, ('MONTHS'::character varying)::text, ('AMOUNT'::character varying)::text, ('COUNT'::character varying)::text, ('PERCENT'::character varying)::text, ('NUMBER'::character varying)::text, ('RATE'::character varying)::text, ('PERCENTAGE'::character varying)::text, ('QUANTITY'::character varying)::text, ('BOOLEAN'::character varying)::text, ('ENUM'::character varying)::text, ('STRING'::character varying)::text])))
);


ALTER TABLE public.engine_inputs OWNER TO postgres;

--
-- Name: engine_payslip_contracts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.engine_payslip_contracts (
    engine_id character varying(255) NOT NULL,
    country_code character varying(255) NOT NULL,
    engine_version character varying(255) NOT NULL,
    lines jsonb DEFAULT '[]'::jsonb NOT NULL,
    totals jsonb DEFAULT '[]'::jsonb NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    cumulatives jsonb DEFAULT '[]'::jsonb NOT NULL,
    CONSTRAINT engine_payslip_contracts_cumulatives_check CHECK ((jsonb_typeof(cumulatives) = 'array'::text)),
    CONSTRAINT engine_payslip_contracts_lines_check CHECK ((jsonb_typeof(lines) = 'array'::text)),
    CONSTRAINT engine_payslip_contracts_totals_check CHECK ((jsonb_typeof(totals) = 'array'::text))
);


ALTER TABLE public.engine_payslip_contracts OWNER TO postgres;

--
-- Name: engine_remuneration_rules; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.engine_remuneration_rules (
    catalog_valid_from date,
    catalog_valid_to date,
    contributive boolean NOT NULL,
    overridable boolean NOT NULL,
    taxable boolean NOT NULL,
    catalog_version bigint,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    calculation jsonb,
    catalog_number character varying(16),
    catalog_type character varying(255),
    catalog_value_type character varying(255),
    category character varying(255),
    code character varying(255) NOT NULL,
    color character varying(255),
    contribution_treatment_display jsonb,
    contribution_treatment_explanation text,
    contribution_treatment_formula text,
    contribution_treatment_mode character varying(255),
    contribution_treatment_visibility character varying(255),
    country_code character varying(255) NOT NULL,
    display_name character varying(255) NOT NULL,
    engine_id character varying(255) NOT NULL,
    icon character varying(255),
    legal_ref character varying(255),
    localized_display_names jsonb,
    nature character varying(255),
    output_bindings jsonb NOT NULL,
    proration_policy jsonb,
    resolution_policy character varying(255),
    tax_treatment_display jsonb,
    tax_treatment_explanation text,
    tax_treatment_formula text,
    tax_treatment_mode character varying(255),
    tax_treatment_visibility character varying(255),
    CONSTRAINT engine_remuneration_rules_category_check CHECK (((category)::text = ANY (ARRAY[('BASE_SALARY'::character varying)::text, ('OVERTIME'::character varying)::text, ('ALLOWANCE'::character varying)::text, ('BONUS'::character varying)::text, ('BENEFIT'::character varying)::text, ('DEDUCTION'::character varying)::text]))),
    CONSTRAINT engine_remuneration_rules_contribution_treatment_mode_check CHECK (((contribution_treatment_mode)::text = ANY (ARRAY[('EXCLUDED'::character varying)::text, ('INCLUDED'::character varying)::text, ('FORMULA'::character varying)::text]))),
    CONSTRAINT engine_remuneration_rules_contribution_treatment_visibili_check CHECK (((contribution_treatment_visibility)::text = ANY (ARRAY[('PAYSLIP'::character varying)::text, ('DETAIL_ONLY'::character varying)::text, ('INTERNAL'::character varying)::text]))),
    CONSTRAINT engine_remuneration_rules_nature_check CHECK (((nature)::text = ANY (ARRAY[('FINAL'::character varying)::text, ('INTERMEDIATE'::character varying)::text]))),
    CONSTRAINT engine_remuneration_rules_resolution_policy_check CHECK (((resolution_policy)::text = ANY (ARRAY[('ENGINE_ONLY'::character varying)::text, ('ACCEPT_AMOUNT'::character varying)::text, ('ACCEPT_CALCULATION'::character varying)::text]))),
    CONSTRAINT engine_remuneration_rules_tax_treatment_mode_check CHECK (((tax_treatment_mode)::text = ANY (ARRAY[('EXCLUDED'::character varying)::text, ('INCLUDED'::character varying)::text, ('FORMULA'::character varying)::text]))),
    CONSTRAINT engine_remuneration_rules_tax_treatment_visibility_check CHECK (((tax_treatment_visibility)::text = ANY (ARRAY[('PAYSLIP'::character varying)::text, ('DETAIL_ONLY'::character varying)::text, ('INTERNAL'::character varying)::text])))
);


ALTER TABLE public.engine_remuneration_rules OWNER TO postgres;

--
-- Name: engines; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.engines (
    deprecated boolean,
    retroactive_from date,
    valid_from date,
    valid_to date,
    created_at timestamp(6) with time zone,
    published_at timestamp(6) with time zone,
    updated_at timestamp(6) with time zone,
    country_code character varying(255) NOT NULL,
    description character varying(255),
    display_name character varying(255) NOT NULL,
    id character varying(255) NOT NULL,
    legal_reference jsonb NOT NULL,
    localized_descriptions jsonb,
    localized_display_names jsonb,
    status character varying(255),
    version character varying(255) NOT NULL,
    CONSTRAINT engines_status_check CHECK (((status)::text = ANY (ARRAY[('DRAFT'::character varying)::text, ('ENABLED'::character varying)::text, ('DISABLED'::character varying)::text, ('ARCHIVED'::character varying)::text])))
);


ALTER TABLE public.engines OWNER TO postgres;

--
-- Name: flyway_schema_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.flyway_schema_history (
    installed_rank integer NOT NULL,
    version character varying(50),
    description character varying(200) NOT NULL,
    type character varying(20) NOT NULL,
    script character varying(1000) NOT NULL,
    checksum integer,
    installed_by character varying(100) NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


ALTER TABLE public.flyway_schema_history OWNER TO postgres;

--
-- Name: input_window_audit; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.input_window_audit (
    cut_off_after timestamp(6) with time zone,
    cut_off_before timestamp(6) with time zone,
    occurred_at timestamp(6) with time zone NOT NULL,
    action character varying(255) NOT NULL,
    actor character varying(255) NOT NULL,
    company_id character varying(255) NOT NULL,
    id character varying(255) NOT NULL,
    period_id character varying(255) NOT NULL,
    reason text,
    status_after character varying(255) NOT NULL,
    status_before character varying(255) NOT NULL,
    window_id character varying(255) NOT NULL,
    CONSTRAINT input_window_audit_action_check CHECK (((action)::text = ANY (ARRAY[('OPENED'::character varying)::text, ('OPENED_ON_SCHEDULE'::character varying)::text, ('EXTENDED'::character varying)::text, ('REOPENED'::character varying)::text, ('CLOSED'::character varying)::text, ('CLOSED_AT_CUT_OFF'::character varying)::text]))),
    CONSTRAINT input_window_audit_status_after_check CHECK (((status_after)::text = ANY (ARRAY[('SCHEDULED'::character varying)::text, ('OPEN'::character varying)::text, ('REOPENED'::character varying)::text, ('CLOSED'::character varying)::text]))),
    CONSTRAINT input_window_audit_status_before_check CHECK (((status_before)::text = ANY (ARRAY[('SCHEDULED'::character varying)::text, ('OPEN'::character varying)::text, ('REOPENED'::character varying)::text, ('CLOSED'::character varying)::text])))
);


ALTER TABLE public.input_window_audit OWNER TO postgres;

--
-- Name: input_windows; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.input_windows (
    opens_automatically boolean DEFAULT true NOT NULL,
    closed_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone NOT NULL,
    cut_off_at timestamp(6) with time zone NOT NULL,
    extended_until timestamp(6) with time zone,
    lock_version bigint NOT NULL,
    opened_at timestamp(6) with time zone,
    opens_at timestamp(6) with time zone NOT NULL,
    population_prepared_at timestamp(6) with time zone,
    updated_at timestamp(6) with time zone NOT NULL,
    calendar_version_id character varying(255) NOT NULL,
    closed_by character varying(255),
    company_id character varying(255) NOT NULL,
    id character varying(255) NOT NULL,
    legal_entity_id character varying(255) NOT NULL,
    opened_by character varying(255),
    period_id character varying(255) NOT NULL,
    reason text,
    status character varying(255) NOT NULL,
    CONSTRAINT input_windows_status_check CHECK (((status)::text = ANY (ARRAY[('SCHEDULED'::character varying)::text, ('OPEN'::character varying)::text, ('REOPENED'::character varying)::text, ('CLOSED'::character varying)::text])))
);


ALTER TABLE public.input_windows OWNER TO postgres;

--
-- Name: legal_entity_payroll_configs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.legal_entity_payroll_configs (
    effective_from date NOT NULL,
    effective_to date,
    created_at timestamp(6) with time zone NOT NULL,
    lock_version bigint NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    company_id character varying(255) NOT NULL,
    country_code character varying(255) NOT NULL,
    default_cycle_id character varying(255),
    id character varying(255) NOT NULL,
    legal_entity_id character varying(255) NOT NULL,
    payroll_currency character varying(255) NOT NULL,
    status character varying(255) NOT NULL,
    time_zone character varying(255) NOT NULL,
    CONSTRAINT legal_entity_payroll_configs_status_check CHECK (((status)::text = ANY (ARRAY[('DRAFT'::character varying)::text, ('ACTIVE'::character varying)::text, ('SUSPENDED'::character varying)::text, ('CLOSED'::character varying)::text])))
);


ALTER TABLE public.legal_entity_payroll_configs OWNER TO postgres;

--
-- Name: manual_remunerations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.manual_remunerations (
    version integer NOT NULL,
    captured_at timestamp(6) with time zone NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    lock_version bigint,
    updated_at timestamp(6) with time zone NOT NULL,
    captured_by character varying(255) NOT NULL,
    category character varying(255) NOT NULL,
    code character varying(255) NOT NULL,
    country_code character varying(255) NOT NULL,
    display_name character varying(255) NOT NULL,
    employee_id character varying(255) NOT NULL,
    id character varying(255) NOT NULL,
    legal_entity_id character varying(255) NOT NULL,
    nature character varying(255) NOT NULL,
    occurrence character varying(255) NOT NULL,
    org_id character varying(255) NOT NULL,
    override_strategy character varying(255) NOT NULL,
    period_id character varying(255) NOT NULL,
    previous_version_id character varying(255),
    status character varying(255) NOT NULL,
    calculation text NOT NULL,
    source_label text,
    CONSTRAINT manual_remunerations_override_check CHECK (((override_strategy)::text = ANY ((ARRAY['KEEP'::character varying, 'OVERRIDE'::character varying])::text[]))),
    CONSTRAINT manual_remunerations_status_check CHECK (((status)::text = ANY ((ARRAY['DRAFT'::character varying, 'VALIDATED'::character varying, 'SUPERSEDED'::character varying, 'CANCELLED'::character varying])::text[])))
);


ALTER TABLE public.manual_remunerations OWNER TO postgres;

--
-- Name: payroll_bulletin_issuances; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payroll_bulletin_issuances (
    issue_sequence integer NOT NULL,
    issued_at timestamp(6) with time zone,
    started_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    company_id character varying(255) NOT NULL,
    effects jsonb NOT NULL,
    employee_id character varying(255) NOT NULL,
    failure_code character varying(255),
    id character varying(255) NOT NULL,
    idempotency_key character varying(255) NOT NULL,
    participant_id character varying(255) NOT NULL,
    payload_hash character varying(255),
    run_id character varying(255) NOT NULL,
    status character varying(255) NOT NULL,
    CONSTRAINT payroll_bulletin_issuances_status_check CHECK (((status)::text = ANY (ARRAY[('IN_PROGRESS'::character varying)::text, ('ISSUED'::character varying)::text, ('FAILED'::character varying)::text])))
);


ALTER TABLE public.payroll_bulletin_issuances OWNER TO postgres;

--
-- Name: payroll_calculation_results; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payroll_calculation_results (
    id character varying(255) NOT NULL,
    sequence bigint NOT NULL,
    company_id character varying(255) NOT NULL,
    campaign_id character varying(255) NOT NULL,
    participant_id character varying(255) NOT NULL,
    employee_id character varying(255) NOT NULL,
    preparation_id character varying(255) NOT NULL,
    preparation_revision bigint NOT NULL,
    configuration_version integer NOT NULL,
    configuration_hash character varying(64) NOT NULL,
    engine_id character varying(255) NOT NULL,
    engine_version character varying(255) NOT NULL,
    input_hash character varying(64) NOT NULL,
    status character varying(255) NOT NULL,
    result_hash character varying(64),
    error_code character varying(255),
    error_message text,
    started_at timestamp(6) with time zone NOT NULL,
    completed_at timestamp(6) with time zone NOT NULL,
    engine_status smallint,
    duration bigint,
    context jsonb,
    constant_resolutions jsonb,
    step_results jsonb,
    CONSTRAINT calculation_outcome_check CHECK (((((status)::text = 'SUCCEEDED'::text) AND (result_hash IS NOT NULL) AND (engine_status IS NOT NULL) AND (engine_status = 0) AND (error_code IS NULL) AND (error_message IS NULL)) OR (((status)::text = 'FAILED'::text) AND (error_code IS NOT NULL) AND (result_hash IS NULL) AND ((engine_status IS NULL) OR (engine_status = 1))))),
    CONSTRAINT calculation_output_check CHECK (((engine_status IS NULL) OR ((duration IS NOT NULL) AND (context IS NOT NULL) AND (step_results IS NOT NULL)))),
    CONSTRAINT payroll_calculation_results_check CHECK ((completed_at >= started_at)),
    CONSTRAINT payroll_calculation_results_engine_status_check CHECK ((engine_status = ANY (ARRAY[0, 1]))),
    CONSTRAINT payroll_calculation_results_preparation_revision_check CHECK ((preparation_revision > 0)),
    CONSTRAINT payroll_calculation_results_status_check CHECK (((status)::text = ANY ((ARRAY['SUCCEEDED'::character varying, 'FAILED'::character varying])::text[])))
);


ALTER TABLE public.payroll_calculation_results OWNER TO postgres;

--
-- Name: payroll_calculation_results_sequence_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.payroll_calculation_results ALTER COLUMN sequence ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.payroll_calculation_results_sequence_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: payroll_calendars; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payroll_calendars (
    effective_from date NOT NULL,
    effective_to date,
    opens_automatically boolean NOT NULL,
    version integer NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    lock_version bigint NOT NULL,
    published_at timestamp(6) with time zone,
    updated_at timestamp(6) with time zone NOT NULL,
    company_id character varying(255) NOT NULL,
    cut_off_rule character varying(255) NOT NULL,
    cycle_id character varying(255) NOT NULL,
    id character varying(255) NOT NULL,
    opening_rule character varying(255) NOT NULL,
    payment_rule character varying(255) NOT NULL,
    previous_version_id character varying(255),
    status character varying(255) NOT NULL,
    CONSTRAINT payroll_calendars_status_check CHECK (((status)::text = ANY (ARRAY[('DRAFT'::character varying)::text, ('PUBLISHED'::character varying)::text, ('ARCHIVED'::character varying)::text])))
);


ALTER TABLE public.payroll_calendars OWNER TO postgres;

--
-- Name: payroll_campaign_errors; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payroll_campaign_errors (
    resolved boolean NOT NULL,
    occurred_at timestamp(6) with time zone,
    resolved_at timestamp(6) with time zone,
    campaign_id character varying(255) NOT NULL,
    company_id character varying(255) NOT NULL,
    error_code character varying(255) NOT NULL,
    error_id character varying(255) NOT NULL,
    message text,
    participant_id character varying(255),
    phase character varying(255) NOT NULL,
    resolution_note text,
    severity character varying(255) NOT NULL,
    technical_details text,
    type character varying(255) NOT NULL,
    context jsonb,
    CONSTRAINT payroll_campaign_errors_phase_check CHECK (((phase)::text = ANY (ARRAY[('LOADING'::character varying)::text, ('COMPUTATION'::character varying)::text, ('GENERATION'::character varying)::text]))),
    CONSTRAINT payroll_campaign_errors_severity_check CHECK (((severity)::text = ANY (ARRAY[('INFO'::character varying)::text, ('WARNING'::character varying)::text, ('ERROR'::character varying)::text, ('CRITICAL'::character varying)::text]))),
    CONSTRAINT payroll_campaign_errors_type_check CHECK (((type)::text = ANY (ARRAY[('DATA_NOT_FOUND'::character varying)::text, ('DATA_INCOMPLETE'::character varying)::text, ('DATA_INVALID'::character varying)::text, ('TIME_SHEET_NOT_FOUND'::character varying)::text, ('EMPLOYEE_NOT_FOUND'::character varying)::text, ('REMUNERATION_NOT_FOUND'::character varying)::text, ('CALCULATION_ERROR'::character varying)::text, ('SYSTEM_ERROR'::character varying)::text, ('TIMEOUT'::character varying)::text, ('UNKNOWN'::character varying)::text])))
);


ALTER TABLE public.payroll_campaign_errors OWNER TO postgres;

--
-- Name: payroll_campaign_financial_summary_chunk_entity; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payroll_campaign_financial_summary_chunk_entity (
    campaign_id character varying(255) NOT NULL,
    chunk_id character varying(255) NOT NULL,
    company_id character varying(255) NOT NULL,
    financial_summary jsonb NOT NULL
);


ALTER TABLE public.payroll_campaign_financial_summary_chunk_entity OWNER TO postgres;

--
-- Name: payroll_campaign_ledgers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payroll_campaign_ledgers (
    participant_count integer NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    campaign_id character varying(255) NOT NULL,
    company_id character varying(255) NOT NULL,
    document jsonb NOT NULL,
    id character varying(255) NOT NULL,
    reference character varying(255) NOT NULL
);


ALTER TABLE public.payroll_campaign_ledgers OWNER TO postgres;

--
-- Name: payroll_campaign_participant_bulletins; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payroll_campaign_participant_bulletins (
    gross_salary numeric(38,2) NOT NULL,
    net_salary numeric(38,2) NOT NULL,
    employee_deductions numeric(38,2),
    employer_deductions numeric(38,2),
    net_to_pay numeric(38,2),
    campaign_end_date timestamp(6) with time zone,
    campaign_start_date timestamp(6) with time zone,
    created_at timestamp(6) with time zone NOT NULL,
    payment_date timestamp(6) with time zone,
    updated_at timestamp(6) with time zone,
    campaign_id character varying(255) NOT NULL,
    company_id character varying(255) NOT NULL,
    content jsonb,
    document jsonb,
    employee_id character varying(255),
    participant_id character varying(255) NOT NULL,
    period_id character varying(255) NOT NULL,
    reference character varying(255) NOT NULL,
    status character varying(255),
    legal_entity_id character varying(255),
    engine_id character varying(255) NOT NULL,
    engine_version character varying(255) NOT NULL,
    country_code character varying(255) NOT NULL,
    sequence integer NOT NULL,
    kind character varying(20) NOT NULL,
    period character varying(255) NOT NULL,
    calculated_by character varying(255),
    calculated_at timestamp with time zone,
    validated_at timestamp with time zone,
    hiring boolean DEFAULT false NOT NULL,
    departure boolean DEFAULT false NOT NULL,
    CONSTRAINT payroll_campaign_participant_bulletins_kind_check CHECK (((kind)::text = ANY ((ARRAY['NORMAL'::character varying, 'OFF_CYCLE'::character varying, 'TERMINATION'::character varying, 'CORRECTIVE'::character varying, 'FICTIVE'::character varying])::text[]))),
    CONSTRAINT payroll_campaign_participant_bulletins_sequence_check CHECK ((sequence > 0)),
    CONSTRAINT payroll_campaign_participant_bulletins_status_check CHECK (((status)::text = ANY (ARRAY[('DRAFT'::character varying)::text, ('INVALIDATED'::character varying)::text, ('VALIDATED'::character varying)::text, ('CANCELLED'::character varying)::text, ('CALCULATED'::character varying)::text, ('PUBLISHED'::character varying)::text])))
);


ALTER TABLE public.payroll_campaign_participant_bulletins OWNER TO postgres;

--
-- Name: payroll_campaign_participants; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payroll_campaign_participants (
    dirty boolean,
    expected_amount numeric(38,2),
    payment_count integer,
    total_paid numeric(38,2),
    total_pending numeric(38,2),
    calculated_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone NOT NULL,
    enrolled_at timestamp(6) with time zone,
    last_payment_at timestamp(6) with time zone,
    pay_slip_generated_at timestamp(6) with time zone,
    preparation_revision bigint,
    updated_at timestamp(6) with time zone NOT NULL,
    validated_at timestamp(6) with time zone,
    campaign_id character varying(255) NOT NULL,
    company_id character varying(255) NOT NULL,
    employee_id character varying(255) NOT NULL,
    exclusion_reason text,
    last_payment_method character varying(255),
    participant_id character varying(255) NOT NULL,
    payment_status character varying(255),
    period character varying(255),
    period_id character varying(255) NOT NULL,
    preparation_id character varying(255),
    status character varying(255) NOT NULL,
    net_salary numeric(38,10),
    CONSTRAINT payroll_campaign_participants_last_payment_method_check CHECK (((last_payment_method)::text = ANY (ARRAY[('MOBILE_MONEY'::character varying)::text, ('MASTER'::character varying)::text, ('VISA'::character varying)::text, ('CASH'::character varying)::text, ('DIGITAL_WALLET'::character varying)::text, ('CHECK'::character varying)::text, ('BANK_TRANSFERT'::character varying)::text]))),
    CONSTRAINT payroll_campaign_participants_payment_status_check CHECK (((payment_status)::text = ANY (ARRAY[('UNPAID'::character varying)::text, ('PARTIALLY_PAID'::character varying)::text, ('FULLY_PAID'::character varying)::text]))),
    CONSTRAINT payroll_campaign_participants_status_check CHECK (((status)::text = ANY (ARRAY[('ENROLLED'::character varying)::text, ('VALIDATED'::character varying)::text, ('CALCULATED'::character varying)::text, ('BULLETIN_GENERATED'::character varying)::text, ('LOADING_ERROR'::character varying)::text, ('COMPUTATION_ERROR'::character varying)::text, ('GENERATION_ERROR'::character varying)::text, ('EXCLUDED'::character varying)::text])))
);


ALTER TABLE public.payroll_campaign_participants OWNER TO postgres;

--
-- Name: payroll_campaigns; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payroll_campaigns (
    calculation_count integer,
    load_count integer,
    payslip_generation_count integer,
    bulletins_generated_at timestamp(6) with time zone,
    closed_at timestamp(6) with time zone,
    computed_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone NOT NULL,
    employees_loaded_at timestamp(6) with time zone,
    end_date timestamp(6) with time zone NOT NULL,
    payment_completed_at timestamp(6) with time zone,
    payment_started_at timestamp(6) with time zone,
    start_date timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    validated_at timestamp(6) with time zone,
    company_id character varying(255) NOT NULL,
    country character varying(255) NOT NULL,
    engine_id character varying(255) NOT NULL,
    legal_entity_id character varying(255),
    payment_status character varying(255),
    payroll_id character varying(255) NOT NULL,
    period character varying(255) NOT NULL,
    period_id character varying(255),
    reference character varying(255) NOT NULL,
    run_type character varying(255) NOT NULL,
    scope jsonb,
    status character varying(255) NOT NULL,
    summary jsonb,
    CONSTRAINT payroll_campaigns_payment_status_check CHECK (((payment_status)::text = ANY (ARRAY[('NOT_STARTED'::character varying)::text, ('STARTING'::character varying)::text, ('STARTED_ERROR'::character varying)::text, ('PENDING'::character varying)::text, ('PAID'::character varying)::text]))),
    CONSTRAINT payroll_campaigns_run_type_check CHECK (((run_type)::text = ANY (ARRAY[('MAIN'::character varying)::text, ('OFF_CYCLE'::character varying)::text, ('TERMINATION'::character varying)::text, ('ADJUSTMENT'::character varying)::text]))),
    CONSTRAINT payroll_campaigns_status_check CHECK (((status)::text = ANY (ARRAY[('DRAFT'::character varying)::text, ('READY_FOR_LOADING'::character varying)::text, ('LOADING_IN_PROGRESS'::character varying)::text, ('EMPLOYEES_LOADED'::character varying)::text, ('LOADING_FAILED'::character varying)::text, ('READY_FOR_COMPUTATION'::character varying)::text, ('COMPUTING'::character varying)::text, ('COMPUTED'::character varying)::text, ('COMPUTATION_FAILED'::character varying)::text, ('VALIDATED'::character varying)::text, ('READY_FOR_BULLETINS'::character varying)::text, ('GENERATING_BULLETINS'::character varying)::text, ('BULLETINS_GENERATED'::character varying)::text, ('BULLETINS_FAILED'::character varying)::text, ('CLOSED'::character varying)::text, ('ARCHIVED'::character varying)::text])))
);


ALTER TABLE public.payroll_campaigns OWNER TO postgres;

--
-- Name: payroll_compensation_snapshot; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payroll_compensation_snapshot (
    id character varying(255) NOT NULL,
    dossier_id character varying(255) NOT NULL,
    fingerprint character varying(64) NOT NULL,
    content jsonb NOT NULL,
    received_at timestamp with time zone NOT NULL
);


ALTER TABLE public.payroll_compensation_snapshot OWNER TO postgres;

--
-- Name: payroll_cycles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payroll_cycles (
    anchor_date date NOT NULL,
    effective_from date NOT NULL,
    effective_to date,
    created_at timestamp(6) with time zone NOT NULL,
    lock_version bigint NOT NULL,
    published_at timestamp(6) with time zone,
    updated_at timestamp(6) with time zone NOT NULL,
    company_id character varying(255) NOT NULL,
    frequency character varying(255) NOT NULL,
    id character varying(255) NOT NULL,
    label character varying(255) NOT NULL,
    legal_entity_id character varying(255) NOT NULL,
    status character varying(255) NOT NULL,
    timezone character varying(255) NOT NULL,
    CONSTRAINT payroll_cycles_frequency_check CHECK (((frequency)::text = ANY (ARRAY[('WEEKLY'::character varying)::text, ('BIWEEKLY'::character varying)::text, ('SEMI_MONTHLY'::character varying)::text, ('MONTHLY'::character varying)::text, ('QUARTERLY'::character varying)::text, ('SEMI_ANNUAL'::character varying)::text, ('ANNUAL'::character varying)::text]))),
    CONSTRAINT payroll_cycles_status_check CHECK (((status)::text = ANY (ARRAY[('DRAFT'::character varying)::text, ('PUBLISHED'::character varying)::text, ('ARCHIVED'::character varying)::text])))
);


ALTER TABLE public.payroll_cycles OWNER TO postgres;

--
-- Name: payroll_engine_assignments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payroll_engine_assignments (
    effective_from date NOT NULL,
    effective_to date,
    assigned_at timestamp(6) with time zone NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    lock_version bigint NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    assigned_by character varying(255),
    company_id character varying(255) NOT NULL,
    engine_id character varying(255) NOT NULL,
    id character varying(255) NOT NULL,
    legal_entity_id character varying(255) NOT NULL,
    status character varying(255) NOT NULL,
    CONSTRAINT payroll_engine_assignments_status_check CHECK (((status)::text = ANY (ARRAY[('PLANNED'::character varying)::text, ('ACTIVE'::character varying)::text, ('ENDED'::character varying)::text])))
);


ALTER TABLE public.payroll_engine_assignments OWNER TO postgres;

--
-- Name: payroll_input_evidences; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payroll_input_evidences (
    id character varying(255) NOT NULL,
    company_id character varying(255) NOT NULL,
    period_id character varying(255) NOT NULL,
    employee_id character varying(255) NOT NULL,
    input_id character varying(255) NOT NULL,
    kind character varying(32) NOT NULL,
    file_name character varying(255) NOT NULL,
    content_type character varying(255),
    size_bytes bigint NOT NULL,
    sha256 character varying(64) NOT NULL,
    storage_ref character varying(1024) NOT NULL,
    note character varying(1000),
    attached_by character varying(255) NOT NULL,
    attached_at timestamp(6) with time zone NOT NULL,
    CONSTRAINT ck_input_evidence_sha256 CHECK (((sha256)::text ~ '^[0-9a-f]{64}$'::text)),
    CONSTRAINT ck_input_evidence_size CHECK ((size_bytes >= 0))
);


ALTER TABLE public.payroll_input_evidences OWNER TO postgres;

--
-- Name: payroll_one_time_element_payments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payroll_one_time_element_payments (
    id character varying(255) NOT NULL,
    company_id character varying(255) NOT NULL,
    employee_id character varying(255) NOT NULL,
    reference character varying(255) NOT NULL,
    campaign_id character varying(255) NOT NULL,
    participant_id character varying(255) NOT NULL,
    bulletin_sequence integer NOT NULL,
    amount numeric(38,10) NOT NULL,
    issued_at timestamp(6) with time zone NOT NULL,
    CONSTRAINT payroll_one_time_element_payments_amount_check CHECK ((amount > (0)::numeric)),
    CONSTRAINT payroll_one_time_element_payments_bulletin_sequence_check CHECK ((bulletin_sequence > 0))
);


ALTER TABLE public.payroll_one_time_element_payments OWNER TO postgres;

--
-- Name: payroll_payments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payroll_payments (
    amount numeric(19,4) NOT NULL,
    cancelled_at timestamp(6) with time zone,
    confirmed_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone NOT NULL,
    paid_at timestamp(6) with time zone,
    updated_at timestamp(6) with time zone NOT NULL,
    method_type character varying(30) NOT NULL,
    status character varying(30) NOT NULL,
    campaign_id character varying(255) NOT NULL,
    company_id character varying(255) NOT NULL,
    employee_id character varying(255) NOT NULL,
    employee_name character varying(255),
    note text,
    participant_id character varying(255) NOT NULL,
    payment_id character varying(255) NOT NULL,
    CONSTRAINT payroll_payments_method_type_check CHECK (((method_type)::text = ANY (ARRAY[('MOBILE_MONEY'::character varying)::text, ('MASTER'::character varying)::text, ('VISA'::character varying)::text, ('CASH'::character varying)::text, ('DIGITAL_WALLET'::character varying)::text, ('CHECK'::character varying)::text, ('BANK_TRANSFERT'::character varying)::text]))),
    CONSTRAINT payroll_payments_status_check CHECK (((status)::text = ANY (ARRAY[('PENDING'::character varying)::text, ('CONFIRMED'::character varying)::text, ('CANCELLED'::character varying)::text])))
);


ALTER TABLE public.payroll_payments OWNER TO postgres;

--
-- Name: payroll_periods; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payroll_periods (
    end_date date NOT NULL,
    payment_date date NOT NULL,
    start_date date NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    cut_off_at timestamp(6) with time zone NOT NULL,
    lock_version bigint NOT NULL,
    opening_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    attachment_month character varying(255) NOT NULL,
    calendar_version_id character varying(255) NOT NULL,
    company_id character varying(255) NOT NULL,
    cycle_id character varying(255) NOT NULL,
    id character varying(255) NOT NULL,
    label character varying(255) NOT NULL,
    legal_entity_id character varying(255) NOT NULL,
    status character varying(255) NOT NULL,
    timezone character varying(255) NOT NULL,
    population_snapshot jsonb NOT NULL,
    CONSTRAINT payroll_periods_status_check CHECK (((status)::text = ANY (ARRAY[('SCHEDULED'::character varying)::text, ('IN_PROGRESS'::character varying)::text, ('CLOSED'::character varying)::text])))
);


ALTER TABLE public.payroll_periods OWNER TO postgres;

--
-- Name: payroll_population_assignments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payroll_population_assignments (
    effective_from date NOT NULL,
    effective_to date,
    created_at timestamp(6) with time zone NOT NULL,
    lock_version bigint NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    company_id character varying(255) NOT NULL,
    cycle_id character varying(255) NOT NULL,
    id character varying(255) NOT NULL,
    legal_entity_id character varying(255) NOT NULL,
    population_id character varying(255) NOT NULL
);


ALTER TABLE public.payroll_population_assignments OWNER TO postgres;

--
-- Name: payroll_populations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payroll_populations (
    created_at timestamp(6) with time zone NOT NULL,
    lock_version bigint NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    company_id character varying(255) NOT NULL,
    definition jsonb NOT NULL,
    id character varying(255) NOT NULL,
    label character varying(255) NOT NULL,
    legal_entity_id character varying(255) NOT NULL,
    parent_id character varying(255)
);


ALTER TABLE public.payroll_populations OWNER TO postgres;

--
-- Name: payroll_run_configurations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payroll_run_configurations (
    version integer NOT NULL,
    frozen_at timestamp(6) with time zone NOT NULL,
    hash character varying(64) NOT NULL,
    company_id character varying(255) NOT NULL,
    engine_id character varying(255) NOT NULL,
    engine_version character varying(255) NOT NULL,
    id character varying(255) NOT NULL,
    period_id character varying(255) NOT NULL,
    run_id character varying(255) NOT NULL,
    content jsonb NOT NULL
);


ALTER TABLE public.payroll_run_configurations OWNER TO postgres;

--
-- Name: payroll_run_control_reports; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payroll_run_control_reports (
    blocking_count integer NOT NULL,
    employer_cost numeric(19,4),
    gross numeric(19,4),
    net numeric(19,4),
    patronal_deductions numeric(19,4),
    salarial_deductions numeric(19,4),
    headcount bigint NOT NULL,
    produced_at timestamp(6) with time zone NOT NULL,
    calculation_hash character varying(255),
    company_id character varying(255) NOT NULL,
    configuration_hash character varying(255),
    findings jsonb NOT NULL,
    id character varying(255) NOT NULL,
    reference_run_id character varying(255),
    reference_totals jsonb,
    run_id character varying(255) NOT NULL,
    rubric_totals jsonb,
    reference_rubric_totals jsonb
);


ALTER TABLE public.payroll_run_control_reports OWNER TO postgres;

--
-- Name: payroll_simulations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payroll_simulations (
    run_count integer NOT NULL,
    completed_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone,
    started_at timestamp(6) with time zone,
    updated_at timestamp(6) with time zone,
    company_id character varying(255) NOT NULL,
    employees jsonb NOT NULL,
    engine_id character varying(255),
    errors jsonb NOT NULL,
    name character varying(255),
    simulation_id character varying(255) NOT NULL,
    status character varying(255),
    summary jsonb NOT NULL,
    CONSTRAINT payroll_simulations_status_check CHECK (((status)::text = ANY (ARRAY[('DRAFT'::character varying)::text, ('RUNNING'::character varying)::text, ('COMPLETED'::character varying)::text, ('FAILED'::character varying)::text])))
);


ALTER TABLE public.payroll_simulations OWNER TO postgres;

--
-- Name: payslip_template_versions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payslip_template_versions (
    version integer NOT NULL,
    published_at timestamp(6) with time zone NOT NULL,
    company_id character varying(255) NOT NULL,
    html_template text NOT NULL,
    id character varying(255) NOT NULL,
    published_by character varying(255),
    template_id character varying(255) NOT NULL,
    payroll_engine_id character varying(255) NOT NULL
);


ALTER TABLE public.payslip_template_versions OWNER TO postgres;

--
-- Name: payslip_templates; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payslip_templates (
    latest_published_version integer NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    published_at timestamp(6) with time zone,
    updated_at timestamp(6) with time zone,
    company_id character varying(255) NOT NULL,
    content_type character varying(255) NOT NULL,
    created_by character varying(255),
    description text,
    engine character varying(255) NOT NULL,
    html_template text NOT NULL,
    id character varying(255) NOT NULL,
    language character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    status character varying(255) NOT NULL,
    updated_by character varying(255),
    payroll_engine_id character varying(255) NOT NULL,
    CONSTRAINT payslip_templates_status_check CHECK (((status)::text = ANY (ARRAY[('DRAFT'::character varying)::text, ('PUBLISHED'::character varying)::text, ('ARCHIVED'::character varying)::text])))
);


ALTER TABLE public.payslip_templates OWNER TO postgres;

--
-- Name: preparation_alert; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.preparation_alert (
    id character varying(255) NOT NULL,
    company_id character varying(255) NOT NULL,
    legal_entity_id character varying(255) NOT NULL,
    period_id character varying(255) NOT NULL,
    employee_id character varying(255) NOT NULL,
    dossier_id character varying(255) NOT NULL,
    code character varying(64) NOT NULL,
    reference character varying(512) NOT NULL,
    severity character varying(16) NOT NULL,
    message text,
    opened_at timestamp with time zone NOT NULL,
    last_seen_at timestamp with time zone NOT NULL,
    last_reminded_at timestamp with time zone,
    reminder_count integer DEFAULT 0 NOT NULL,
    resolved_at timestamp with time zone,
    lock_version bigint DEFAULT 0 NOT NULL,
    CONSTRAINT preparation_alert_severity CHECK (((severity)::text = ANY ((ARRAY['WAITING'::character varying, 'BLOCKING'::character varying])::text[])))
);


ALTER TABLE public.preparation_alert OWNER TO postgres;

--
-- Name: prepared_employee_payroll; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.prepared_employee_payroll (
    prepared_at timestamp(6) with time zone NOT NULL,
    revision bigint NOT NULL,
    company_id character varying(255) NOT NULL,
    content text NOT NULL,
    content_hash character varying(255) NOT NULL,
    employee_id character varying(255) NOT NULL,
    id character varying(255) NOT NULL,
    period_id character varying(255) NOT NULL
);


ALTER TABLE public.prepared_employee_payroll OWNER TO postgres;

--
-- Name: campaign_payment_exports campaign_payment_exports_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.campaign_payment_exports
    ADD CONSTRAINT campaign_payment_exports_pkey PRIMARY KEY (campaign_id, company_id);


--
-- Name: cumulative_balances cumulative_balances_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cumulative_balances
    ADD CONSTRAINT cumulative_balances_pkey PRIMARY KEY (fiscal_window_end, fiscal_window_start, accumulator_code, company_id, employee_id, jurisdiction, legal_entity_id);


--
-- Name: cumulative_entries cumulative_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cumulative_entries
    ADD CONSTRAINT cumulative_entries_pkey PRIMARY KEY (id);


--
-- Name: cumulative_rules cumulative_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cumulative_rules
    ADD CONSTRAINT cumulative_rules_pkey PRIMARY KEY (id);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: employee_engine_inputs employee_engine_inputs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_engine_inputs
    ADD CONSTRAINT employee_engine_inputs_pkey PRIMARY KEY (id);


--
-- Name: employee_payroll_preparation employee_payroll_preparation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_payroll_preparation
    ADD CONSTRAINT employee_payroll_preparation_pkey PRIMARY KEY (id);


--
-- Name: employee_payroll_preparation employee_preparation_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_payroll_preparation
    ADD CONSTRAINT employee_preparation_key UNIQUE (company_id, legal_entity_id, period_id, employee_id);


--
-- Name: engine_bases engine_bases_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.engine_bases
    ADD CONSTRAINT engine_bases_pkey PRIMARY KEY (code, engine_id);


--
-- Name: engine_benefits engine_benefits_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.engine_benefits
    ADD CONSTRAINT engine_benefits_pkey PRIMARY KEY (code, engine_id);


--
-- Name: engine_constants engine_constants_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.engine_constants
    ADD CONSTRAINT engine_constants_pkey PRIMARY KEY (code, engine_id);


--
-- Name: engine_cumulative_bindings engine_cumulative_bindings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.engine_cumulative_bindings
    ADD CONSTRAINT engine_cumulative_bindings_pkey PRIMARY KEY (engine_id, accumulator_code);


--
-- Name: engine_functions engine_functions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.engine_functions
    ADD CONSTRAINT engine_functions_pkey PRIMARY KEY (engine_id, name);


--
-- Name: engine_inputs engine_inputs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.engine_inputs
    ADD CONSTRAINT engine_inputs_pkey PRIMARY KEY (code, engine_id);


--
-- Name: engine_payslip_contracts engine_payslip_contracts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.engine_payslip_contracts
    ADD CONSTRAINT engine_payslip_contracts_pkey PRIMARY KEY (engine_id);


--
-- Name: engine_remuneration_rules engine_remuneration_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.engine_remuneration_rules
    ADD CONSTRAINT engine_remuneration_rules_pkey PRIMARY KEY (code, engine_id);


--
-- Name: engines engines_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.engines
    ADD CONSTRAINT engines_pkey PRIMARY KEY (id);


--
-- Name: flyway_schema_history flyway_schema_history_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flyway_schema_history
    ADD CONSTRAINT flyway_schema_history_pk PRIMARY KEY (installed_rank);


--
-- Name: input_window_audit input_window_audit_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.input_window_audit
    ADD CONSTRAINT input_window_audit_pkey PRIMARY KEY (id);


--
-- Name: input_windows input_windows_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.input_windows
    ADD CONSTRAINT input_windows_pkey PRIMARY KEY (id);


--
-- Name: legal_entity_payroll_configs legal_entity_payroll_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.legal_entity_payroll_configs
    ADD CONSTRAINT legal_entity_payroll_configs_pkey PRIMARY KEY (id);


--
-- Name: manual_remunerations manual_remunerations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.manual_remunerations
    ADD CONSTRAINT manual_remunerations_pkey PRIMARY KEY (id);


--
-- Name: payroll_bulletin_issuances payroll_bulletin_issuances_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payroll_bulletin_issuances
    ADD CONSTRAINT payroll_bulletin_issuances_pkey PRIMARY KEY (id);


--
-- Name: payroll_calculation_results payroll_calculation_results_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payroll_calculation_results
    ADD CONSTRAINT payroll_calculation_results_pkey PRIMARY KEY (id);


--
-- Name: payroll_calculation_results payroll_calculation_results_sequence_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payroll_calculation_results
    ADD CONSTRAINT payroll_calculation_results_sequence_key UNIQUE (sequence);


--
-- Name: payroll_calendars payroll_calendars_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payroll_calendars
    ADD CONSTRAINT payroll_calendars_pkey PRIMARY KEY (id);


--
-- Name: payroll_campaign_errors payroll_campaign_errors_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payroll_campaign_errors
    ADD CONSTRAINT payroll_campaign_errors_pkey PRIMARY KEY (campaign_id, company_id, error_id);


--
-- Name: payroll_campaign_financial_summary_chunk_entity payroll_campaign_financial_summary_chunk_entity_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payroll_campaign_financial_summary_chunk_entity
    ADD CONSTRAINT payroll_campaign_financial_summary_chunk_entity_pkey PRIMARY KEY (campaign_id, chunk_id, company_id);


--
-- Name: payroll_campaign_ledgers payroll_campaign_ledgers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payroll_campaign_ledgers
    ADD CONSTRAINT payroll_campaign_ledgers_pkey PRIMARY KEY (id);


--
-- Name: payroll_campaign_participant_bulletins payroll_campaign_participant_bulletins_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payroll_campaign_participant_bulletins
    ADD CONSTRAINT payroll_campaign_participant_bulletins_pkey PRIMARY KEY (campaign_id, company_id, participant_id, reference);


--
-- Name: payroll_campaign_participants payroll_campaign_participants_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payroll_campaign_participants
    ADD CONSTRAINT payroll_campaign_participants_pkey PRIMARY KEY (campaign_id, company_id, participant_id);


--
-- Name: payroll_campaigns payroll_campaigns_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payroll_campaigns
    ADD CONSTRAINT payroll_campaigns_pkey PRIMARY KEY (company_id, payroll_id);


--
-- Name: payroll_compensation_snapshot payroll_compensation_snapshot_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payroll_compensation_snapshot
    ADD CONSTRAINT payroll_compensation_snapshot_pkey PRIMARY KEY (id);


--
-- Name: payroll_cycles payroll_cycles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payroll_cycles
    ADD CONSTRAINT payroll_cycles_pkey PRIMARY KEY (id);


--
-- Name: payroll_engine_assignments payroll_engine_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payroll_engine_assignments
    ADD CONSTRAINT payroll_engine_assignments_pkey PRIMARY KEY (id);


--
-- Name: payroll_input_evidences payroll_input_evidences_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payroll_input_evidences
    ADD CONSTRAINT payroll_input_evidences_pkey PRIMARY KEY (id);


--
-- Name: payroll_one_time_element_payments payroll_one_time_element_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payroll_one_time_element_payments
    ADD CONSTRAINT payroll_one_time_element_payments_pkey PRIMARY KEY (id);


--
-- Name: payroll_payments payroll_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payroll_payments
    ADD CONSTRAINT payroll_payments_pkey PRIMARY KEY (campaign_id, company_id, payment_id);


--
-- Name: payroll_periods payroll_periods_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payroll_periods
    ADD CONSTRAINT payroll_periods_pkey PRIMARY KEY (id);


--
-- Name: payroll_population_assignments payroll_population_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payroll_population_assignments
    ADD CONSTRAINT payroll_population_assignments_pkey PRIMARY KEY (id);


--
-- Name: payroll_populations payroll_populations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payroll_populations
    ADD CONSTRAINT payroll_populations_pkey PRIMARY KEY (id);


--
-- Name: payroll_run_configurations payroll_run_configurations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payroll_run_configurations
    ADD CONSTRAINT payroll_run_configurations_pkey PRIMARY KEY (id);


--
-- Name: payroll_run_control_reports payroll_run_control_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payroll_run_control_reports
    ADD CONSTRAINT payroll_run_control_reports_pkey PRIMARY KEY (id);


--
-- Name: payroll_simulations payroll_simulations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payroll_simulations
    ADD CONSTRAINT payroll_simulations_pkey PRIMARY KEY (company_id, simulation_id);


--
-- Name: payslip_template_versions payslip_template_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payslip_template_versions
    ADD CONSTRAINT payslip_template_versions_pkey PRIMARY KEY (id);


--
-- Name: payslip_templates payslip_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payslip_templates
    ADD CONSTRAINT payslip_templates_pkey PRIMARY KEY (id);


--
-- Name: preparation_alert preparation_alert_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.preparation_alert
    ADD CONSTRAINT preparation_alert_pkey PRIMARY KEY (id);


--
-- Name: prepared_employee_payroll prepared_employee_payroll_company_id_period_id_employee_id__key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.prepared_employee_payroll
    ADD CONSTRAINT prepared_employee_payroll_company_id_period_id_employee_id__key UNIQUE (company_id, period_id, employee_id, revision);


--
-- Name: prepared_employee_payroll prepared_employee_payroll_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.prepared_employee_payroll
    ADD CONSTRAINT prepared_employee_payroll_pkey PRIMARY KEY (id);


--
-- Name: cumulative_rules uc_cumulative_rule_country_code; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cumulative_rules
    ADD CONSTRAINT uc_cumulative_rule_country_code UNIQUE (country_code, accumulator_code);


--
-- Name: engines uc_engineentity_version; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.engines
    ADD CONSTRAINT uc_engineentity_version UNIQUE (version, country_code);


--
-- Name: input_windows uc_input_window_period; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.input_windows
    ADD CONSTRAINT uc_input_window_period UNIQUE (period_id);


--
-- Name: legal_entity_payroll_configs uc_legal_entity_payroll_config; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.legal_entity_payroll_configs
    ADD CONSTRAINT uc_legal_entity_payroll_config UNIQUE (company_id, legal_entity_id);


--
-- Name: payroll_calendars uc_payroll_calendar_cycle_version; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payroll_calendars
    ADD CONSTRAINT uc_payroll_calendar_cycle_version UNIQUE (cycle_id, version);


--
-- Name: payroll_campaign_participants uc_payroll_campaign_participant_empl; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payroll_campaign_participants
    ADD CONSTRAINT uc_payroll_campaign_participant_empl UNIQUE (company_id, campaign_id, participant_id, employee_id);


--
-- Name: payroll_cycles uc_payroll_cycle_label; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payroll_cycles
    ADD CONSTRAINT uc_payroll_cycle_label UNIQUE (company_id, legal_entity_id, label);


--
-- Name: payroll_periods uc_payroll_period_cycle_start; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payroll_periods
    ADD CONSTRAINT uc_payroll_period_cycle_start UNIQUE (company_id, cycle_id, start_date);


--
-- Name: payroll_run_configurations uc_run_configuration_version; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payroll_run_configurations
    ADD CONSTRAINT uc_run_configuration_version UNIQUE (company_id, run_id, version);


--
-- Name: cumulative_entries uk_cumulative_entry_idempotency; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cumulative_entries
    ADD CONSTRAINT uk_cumulative_entry_idempotency UNIQUE (idempotency_key);


--
-- Name: cumulative_entries uk_cumulative_entry_sequence; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cumulative_entries
    ADD CONSTRAINT uk_cumulative_entry_sequence UNIQUE (entry_sequence);


--
-- Name: payroll_one_time_element_payments uk_one_time_element_payment; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payroll_one_time_element_payments
    ADD CONSTRAINT uk_one_time_element_payment UNIQUE (company_id, employee_id, reference);


--
-- Name: payroll_bulletin_issuances uq_bulletin_issuance_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payroll_bulletin_issuances
    ADD CONSTRAINT uq_bulletin_issuance_key UNIQUE (company_id, idempotency_key);


--
-- Name: compensation_snapshot_dossier; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX compensation_snapshot_dossier ON public.payroll_compensation_snapshot USING btree (dossier_id, received_at);


--
-- Name: employee_preparation_dashboard; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX employee_preparation_dashboard ON public.employee_payroll_preparation USING btree (company_id, period_id, status);


--
-- Name: engine_benefit_catalog_number; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX engine_benefit_catalog_number ON public.engine_benefits USING btree (engine_id, catalog_number);


--
-- Name: engine_remuneration_catalog_number; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX engine_remuneration_catalog_number ON public.engine_remuneration_rules USING btree (engine_id, catalog_number) WHERE (catalog_number IS NOT NULL);


--
-- Name: flyway_schema_history_s_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX flyway_schema_history_s_idx ON public.flyway_schema_history USING btree (success);


--
-- Name: idx_bulletin_issuance_run; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_bulletin_issuance_run ON public.payroll_bulletin_issuances USING btree (company_id, run_id, status);


--
-- Name: idx_calculation_result_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_calculation_result_key ON public.payroll_calculation_results USING btree (participant_id, configuration_hash, input_hash);


--
-- Name: idx_calculation_result_participant; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_calculation_result_participant ON public.payroll_calculation_results USING btree (company_id, campaign_id, participant_id, completed_at DESC, sequence DESC);


--
-- Name: idx_cumulative_balance_employee; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_cumulative_balance_employee ON public.cumulative_balances USING btree (company_id, employee_id);


--
-- Name: idx_cumulative_entry_employee; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_cumulative_entry_employee ON public.cumulative_entries USING btree (company_id, employee_id, accumulator_code);


--
-- Name: idx_employee_payroll_input_lookup; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_employee_payroll_input_lookup ON public.employee_engine_inputs USING btree (org_id, period_id, employee_id, code, occurrence);


--
-- Name: idx_employee_payroll_input_previous; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_employee_payroll_input_previous ON public.employee_engine_inputs USING btree (previous_version_id);


--
-- Name: idx_engine_assignment_engine; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_engine_assignment_engine ON public.payroll_engine_assignments USING btree (company_id, engine_id);


--
-- Name: idx_engine_assignment_legal_entity; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_engine_assignment_legal_entity ON public.payroll_engine_assignments USING btree (company_id, legal_entity_id, effective_from);


--
-- Name: idx_engine_benefit_engine; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_engine_benefit_engine ON public.engine_benefits USING btree (engine_id);


--
-- Name: idx_engine_cumulative_binding_accumulator; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_engine_cumulative_binding_accumulator ON public.engine_cumulative_bindings USING btree (accumulator_code);


--
-- Name: idx_engine_input_country; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_engine_input_country ON public.engine_inputs USING btree (country_code);


--
-- Name: idx_engine_input_engine; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_engine_input_engine ON public.engine_inputs USING btree (engine_id);


--
-- Name: idx_engine_remuneration_rule_country; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_engine_remuneration_rule_country ON public.engine_remuneration_rules USING btree (country_code);


--
-- Name: idx_engine_remuneration_rule_engine; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_engine_remuneration_rule_engine ON public.engine_remuneration_rules USING btree (engine_id);


--
-- Name: idx_input_evidence_employee; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_input_evidence_employee ON public.payroll_input_evidences USING btree (company_id, period_id, employee_id);


--
-- Name: idx_input_evidence_input; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_input_evidence_input ON public.payroll_input_evidences USING btree (company_id, input_id);


--
-- Name: idx_input_window_audit_window; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_input_window_audit_window ON public.input_window_audit USING btree (company_id, window_id, occurred_at);


--
-- Name: idx_input_window_company; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_input_window_company ON public.input_windows USING btree (company_id, period_id);


--
-- Name: idx_legal_entity_payroll_config_company; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_legal_entity_payroll_config_company ON public.legal_entity_payroll_configs USING btree (company_id, status);


--
-- Name: idx_manual_remuneration_lookup; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_manual_remuneration_lookup ON public.manual_remunerations USING btree (org_id, period_id, employee_id, code, occurrence);


--
-- Name: idx_one_time_payment_bulletin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_one_time_payment_bulletin ON public.payroll_one_time_element_payments USING btree (company_id, campaign_id, participant_id, bulletin_sequence);


--
-- Name: idx_participant_preparation; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_participant_preparation ON public.payroll_campaign_participants USING btree (preparation_id);


--
-- Name: idx_payroll_calendar_governing; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_payroll_calendar_governing ON public.payroll_calendars USING btree (company_id, cycle_id, status, effective_from);


--
-- Name: idx_payroll_campaign_company; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_payroll_campaign_company ON public.payroll_campaigns USING btree (company_id);


--
-- Name: idx_payroll_campaign_participant_company; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_payroll_campaign_participant_company ON public.payroll_campaign_participants USING btree (company_id);


--
-- Name: idx_payroll_cycle_governing; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_payroll_cycle_governing ON public.payroll_cycles USING btree (company_id, status, effective_from);


--
-- Name: idx_payroll_cycle_legal_entity; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_payroll_cycle_legal_entity ON public.payroll_cycles USING btree (company_id, legal_entity_id);


--
-- Name: idx_payroll_payment_campaign; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_payroll_payment_campaign ON public.payroll_payments USING btree (company_id, campaign_id);


--
-- Name: idx_payroll_payment_company; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_payroll_payment_company ON public.payroll_payments USING btree (company_id);


--
-- Name: idx_payroll_payment_employee; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_payroll_payment_employee ON public.payroll_payments USING btree (company_id, employee_id);


--
-- Name: idx_payroll_payment_participant; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_payroll_payment_participant ON public.payroll_payments USING btree (company_id, campaign_id, participant_id);


--
-- Name: idx_payroll_payment_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_payroll_payment_status ON public.payroll_payments USING btree (status);


--
-- Name: idx_payroll_period_attachment; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_payroll_period_attachment ON public.payroll_periods USING btree (company_id, attachment_month);


--
-- Name: idx_payroll_period_range; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_payroll_period_range ON public.payroll_periods USING btree (company_id, cycle_id, start_date, end_date);


--
-- Name: idx_payroll_population_company; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_payroll_population_company ON public.payroll_populations USING btree (company_id, legal_entity_id);


--
-- Name: idx_payroll_population_parent; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_payroll_population_parent ON public.payroll_populations USING btree (parent_id);


--
-- Name: idx_payroll_simulation_company; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_payroll_simulation_company ON public.payroll_simulations USING btree (company_id);


--
-- Name: idx_payrollbulletin_campaign; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_payrollbulletin_campaign ON public.payroll_campaign_participant_bulletins USING btree (company_id, campaign_id);


--
-- Name: idx_payrollbulletin_company; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_payrollbulletin_company ON public.payroll_campaign_participant_bulletins USING btree (company_id);


--
-- Name: idx_payrollbulletin_company_period; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_payrollbulletin_company_period ON public.payroll_campaign_participant_bulletins USING btree (company_id, period);


--
-- Name: idx_payrollbulletin_employee; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_payrollbulletin_employee ON public.payroll_campaign_participant_bulletins USING btree (company_id, employee_id);


--
-- Name: idx_payrollcampaignerror_participant; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_payrollcampaignerror_participant ON public.payroll_campaign_errors USING btree (company_id, campaign_id, participant_id);


--
-- Name: idx_payrollcampaignfinancialsummarychunkentity; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_payrollcampaignfinancialsummarychunkentity ON public.payroll_campaign_financial_summary_chunk_entity USING btree (company_id, campaign_id);


--
-- Name: idx_payrollledger_campaign; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_payrollledger_campaign ON public.payroll_campaign_ledgers USING btree (company_id, campaign_id);


--
-- Name: idx_payrollledger_company; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_payrollledger_company ON public.payroll_campaign_ledgers USING btree (company_id);


--
-- Name: idx_payslip_template_company; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_payslip_template_company ON public.payslip_templates USING btree (company_id);


--
-- Name: idx_payslip_template_engine; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_payslip_template_engine ON public.payslip_templates USING btree (company_id, payroll_engine_id);


--
-- Name: idx_payslip_template_version_company; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_payslip_template_version_company ON public.payslip_template_versions USING btree (company_id);


--
-- Name: idx_payslip_template_version_template; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_payslip_template_version_template ON public.payslip_template_versions USING btree (company_id, template_id);


--
-- Name: idx_population_assignment_cycle; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_population_assignment_cycle ON public.payroll_population_assignments USING btree (company_id, cycle_id, effective_from);


--
-- Name: idx_population_assignment_population; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_population_assignment_population ON public.payroll_population_assignments USING btree (company_id, population_id);


--
-- Name: idx_run_configuration_run; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_run_configuration_run ON public.payroll_run_configurations USING btree (company_id, run_id, version);


--
-- Name: idx_run_control_report_run; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_run_control_report_run ON public.payroll_run_control_reports USING btree (company_id, run_id, produced_at);


--
-- Name: preparation_alert_open_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX preparation_alert_open_key ON public.preparation_alert USING btree (dossier_id, code, reference) WHERE (resolved_at IS NULL);


--
-- Name: preparation_alert_period; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX preparation_alert_period ON public.preparation_alert USING btree (company_id, period_id, resolved_at);


--
-- Name: uq_input_evidence_content; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX uq_input_evidence_content ON public.payroll_input_evidences USING btree (company_id, input_id, sha256);


--
-- Name: uq_manual_remuneration_current; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX uq_manual_remuneration_current ON public.manual_remunerations USING btree (org_id, period_id, employee_id, code, occurrence) WHERE ((status)::text = ANY ((ARRAY['DRAFT'::character varying, 'VALIDATED'::character varying])::text[]));


--
-- Name: payroll_run_configurations immutable_campaign_configuration; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER immutable_campaign_configuration BEFORE INSERT ON public.payroll_run_configurations FOR EACH ROW EXECUTE FUNCTION public.prevent_campaign_configuration_refreeze();


--
-- Name: engine_benefits engine_benefits_engine_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.engine_benefits
    ADD CONSTRAINT engine_benefits_engine_id_fkey FOREIGN KEY (engine_id) REFERENCES public.engines(id);


--
-- Name: engine_cumulative_bindings engine_cumulative_bindings_engine_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.engine_cumulative_bindings
    ADD CONSTRAINT engine_cumulative_bindings_engine_id_fkey FOREIGN KEY (engine_id) REFERENCES public.engines(id);


--
-- Name: engine_payslip_contracts engine_payslip_contracts_engine_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.engine_payslip_contracts
    ADD CONSTRAINT engine_payslip_contracts_engine_id_fkey FOREIGN KEY (engine_id) REFERENCES public.engines(id) ON DELETE CASCADE;


--
-- Name: engine_constants fk37v3a0tdvc6bi692f9ue8bnmw; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.engine_constants
    ADD CONSTRAINT fk37v3a0tdvc6bi692f9ue8bnmw FOREIGN KEY (engine_id) REFERENCES public.engines(id);


--
-- Name: engine_functions fk9wtjj3jeetmvbpuuhakwi51gw; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.engine_functions
    ADD CONSTRAINT fk9wtjj3jeetmvbpuuhakwi51gw FOREIGN KEY (engine_id) REFERENCES public.engines(id);


--
-- Name: engine_bases fkn9ct8w1txd32qxw24c0ojopkt; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.engine_bases
    ADD CONSTRAINT fkn9ct8w1txd32qxw24c0ojopkt FOREIGN KEY (engine_id) REFERENCES public.engines(id);


--
-- Name: payroll_campaign_participant_bulletins payroll_campaign_participant_bulletins_engine_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payroll_campaign_participant_bulletins
    ADD CONSTRAINT payroll_campaign_participant_bulletins_engine_id_fkey FOREIGN KEY (engine_id) REFERENCES public.engines(id);


--
-- Name: payroll_compensation_snapshot payroll_compensation_snapshot_dossier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payroll_compensation_snapshot
    ADD CONSTRAINT payroll_compensation_snapshot_dossier_id_fkey FOREIGN KEY (dossier_id) REFERENCES public.employee_payroll_preparation(id);


--
-- Name: payslip_template_versions payslip_template_versions_payroll_engine_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payslip_template_versions
    ADD CONSTRAINT payslip_template_versions_payroll_engine_id_fkey FOREIGN KEY (payroll_engine_id) REFERENCES public.engines(id);


--
-- Name: payslip_templates payslip_templates_payroll_engine_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payslip_templates
    ADD CONSTRAINT payslip_templates_payroll_engine_id_fkey FOREIGN KEY (payroll_engine_id) REFERENCES public.engines(id);


--
-- Name: preparation_alert preparation_alert_dossier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.preparation_alert
    ADD CONSTRAINT preparation_alert_dossier_id_fkey FOREIGN KEY (dossier_id) REFERENCES public.employee_payroll_preparation(id);


--
-- PostgreSQL database dump complete
--

\unrestrict GwxxJWH3yOBW7uxzwi357NcD8mWZ0nLBSj1vzlgxa7ZOjx9Yd1aCpMW0zgGhjdq

