--
-- PostgreSQL database dump
--

\restrict BCEsaK7hVrGYCn5DOwElNYV8alqEenfMNUksh8c4btgXdzUjDxqOjsk8u4hzvXK

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: benefit_asset_kind; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.benefit_asset_kind (
    country_code character varying(8) NOT NULL,
    catalog_version integer NOT NULL,
    number character varying(3) NOT NULL,
    code character varying(64) NOT NULL,
    label character varying(255) NOT NULL,
    presentation jsonb DEFAULT '{}'::jsonb NOT NULL,
    allowed_frequencies character varying(40)[] NOT NULL,
    status character varying(20) NOT NULL,
    valid_from date NOT NULL,
    valid_to date,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    revision bigint DEFAULT 0 NOT NULL,
    allowed_supply_modes character varying(20)[] DEFAULT '{IN_KIND}'::character varying[] NOT NULL,
    characteristics jsonb DEFAULT '[]'::jsonb NOT NULL,
    CONSTRAINT benefit_asset_kind_allowed_frequencies_check CHECK ((cardinality(allowed_frequencies) > 0)),
    CONSTRAINT benefit_asset_kind_allowed_supply_modes_check CHECK (((cardinality(allowed_supply_modes) > 0) AND (allowed_supply_modes <@ ARRAY['IN_KIND'::character varying, 'CASH'::character varying]))),
    CONSTRAINT benefit_asset_kind_characteristics_check CHECK ((jsonb_typeof(characteristics) = 'array'::text)),
    CONSTRAINT benefit_asset_kind_check CHECK (((valid_to IS NULL) OR (valid_to >= valid_from))),
    CONSTRAINT benefit_asset_kind_check1 CHECK ((((status)::text <> 'DEACTIVATED'::text) OR (valid_to IS NOT NULL))),
    CONSTRAINT benefit_asset_kind_check2 CHECK ((updated_at >= created_at)),
    CONSTRAINT benefit_asset_kind_code_check CHECK (((code)::text ~ '^[A-Z][A-Z0-9_]*$'::text)),
    CONSTRAINT benefit_asset_kind_label_check CHECK ((btrim((label)::text) <> ''::text)),
    CONSTRAINT benefit_asset_kind_number_check CHECK ((((number)::text ~ '^6[0-9]{2}$'::text) AND ((number)::text !~ '00$'::text))),
    CONSTRAINT benefit_asset_kind_presentation_check CHECK ((jsonb_typeof(presentation) = 'object'::text)),
    CONSTRAINT benefit_asset_kind_status_check CHECK (((status)::text = ANY ((ARRAY['DRAFT'::character varying, 'ACTIVE'::character varying, 'DEACTIVATED'::character varying])::text[])))
);


ALTER TABLE public.benefit_asset_kind OWNER TO postgres;

--
-- Name: benefit_asset_rule; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.benefit_asset_rule (
    id character varying(64) NOT NULL,
    country_code character varying(8) NOT NULL,
    rule_code character varying(128) NOT NULL,
    rule_version bigint NOT NULL,
    scope_level character varying(40) NOT NULL,
    company_id character varying(64),
    employee_id character varying(64),
    collective_agreement character varying(128),
    label character varying(255) NOT NULL,
    valid_from date NOT NULL,
    valid_to date,
    status character varying(40) NOT NULL,
    identity jsonb NOT NULL,
    publication jsonb NOT NULL,
    scope jsonb NOT NULL,
    legal_reference jsonb NOT NULL,
    rule_target jsonb NOT NULL,
    rule_constraint jsonb NOT NULL,
    severity character varying(40) NOT NULL,
    resolution_policy jsonb NOT NULL,
    revision bigint DEFAULT 0 NOT NULL,
    CONSTRAINT benefit_asset_rule_check CHECK (((valid_to IS NULL) OR (valid_to >= valid_from))),
    CONSTRAINT benefit_asset_rule_check1 CHECK ((((scope_level)::text <> 'EMPLOYEE'::text) OR ((company_id IS NOT NULL) AND (employee_id IS NOT NULL)))),
    CONSTRAINT benefit_asset_rule_check2 CHECK ((((scope_level)::text <> 'COMPANY'::text) OR ((company_id IS NOT NULL) AND (employee_id IS NULL)))),
    CONSTRAINT benefit_asset_rule_check3 CHECK ((((scope_level)::text <> 'COLLECTIVE_AGREEMENT'::text) OR ((collective_agreement IS NOT NULL) AND (company_id IS NULL) AND (employee_id IS NULL)))),
    CONSTRAINT benefit_asset_rule_check4 CHECK ((((scope_level)::text <> 'COUNTRY'::text) OR ((collective_agreement IS NULL) AND (company_id IS NULL) AND (employee_id IS NULL)))),
    CONSTRAINT benefit_asset_rule_rule_version_check CHECK ((rule_version > 0)),
    CONSTRAINT benefit_asset_rule_scope_level_check CHECK (((scope_level)::text = ANY ((ARRAY['COUNTRY'::character varying, 'COLLECTIVE_AGREEMENT'::character varying, 'COMPANY'::character varying, 'EMPLOYEE'::character varying])::text[]))),
    CONSTRAINT benefit_asset_rule_status_check CHECK (((status)::text = ANY ((ARRAY['DRAFT'::character varying, 'ACTIVE'::character varying, 'RETIRED'::character varying])::text[])))
);


ALTER TABLE public.benefit_asset_rule OWNER TO postgres;

--
-- Name: compensation_awards; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.compensation_awards (
    id character varying(255) NOT NULL,
    company_id character varying(255) NOT NULL,
    legal_entity_id character varying(255) NOT NULL,
    employee_id character varying(255) NOT NULL,
    assignment_id character varying(255) NOT NULL,
    plan_version_id character varying(255) NOT NULL,
    plan_code character varying(64) NOT NULL,
    plan_version integer NOT NULL,
    plan_type character varying(20) NOT NULL,
    country_code character varying(8) NOT NULL,
    payout_number character varying(3) NOT NULL,
    period_start date NOT NULL,
    period_end date NOT NULL,
    figures jsonb NOT NULL,
    currency character varying(3) NOT NULL,
    calculated_amount numeric(19,4) NOT NULL,
    validated_amount numeric(19,4),
    adjustment_reason text,
    payable_on date,
    compensation_id character varying(255),
    status character varying(20) NOT NULL,
    award_version bigint NOT NULL,
    decided_by character varying(255),
    decided_at timestamp with time zone,
    rejection_reason text,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    revision bigint DEFAULT 0 NOT NULL,
    CONSTRAINT compensation_awards_award_version_check CHECK ((award_version > 0)),
    CONSTRAINT compensation_awards_calculated_amount_check CHECK ((calculated_amount >= (0)::numeric)),
    CONSTRAINT compensation_awards_check CHECK ((period_end >= period_start)),
    CONSTRAINT compensation_awards_check1 CHECK ((((status)::text = 'VALIDATED'::text) = ((validated_amount IS NOT NULL) AND (payable_on IS NOT NULL)))),
    CONSTRAINT compensation_awards_check2 CHECK (((payable_on IS NULL) OR (payable_on >= period_end))),
    CONSTRAINT compensation_awards_check3 CHECK ((((status)::text = 'VALIDATED'::text) OR ((compensation_id IS NULL) AND (adjustment_reason IS NULL)))),
    CONSTRAINT compensation_awards_check4 CHECK ((((status)::text = 'REJECTED'::text) = (rejection_reason IS NOT NULL))),
    CONSTRAINT compensation_awards_check5 CHECK ((((status)::text = 'CALCULATED'::text) = ((decided_by IS NULL) AND (decided_at IS NULL)))),
    CONSTRAINT compensation_awards_check6 CHECK ((updated_at >= created_at)),
    CONSTRAINT compensation_awards_figures_check CHECK ((jsonb_typeof(figures) = 'object'::text)),
    CONSTRAINT compensation_awards_plan_type_check CHECK (((plan_type)::text = ANY ((ARRAY['BONUS'::character varying, 'COMMISSION'::character varying])::text[]))),
    CONSTRAINT compensation_awards_plan_version_check CHECK ((plan_version > 0)),
    CONSTRAINT compensation_awards_status_check CHECK (((status)::text = ANY ((ARRAY['CALCULATED'::character varying, 'VALIDATED'::character varying, 'REJECTED'::character varying])::text[]))),
    CONSTRAINT compensation_awards_validated_amount_check CHECK (((validated_amount IS NULL) OR (validated_amount >= (0)::numeric)))
);


ALTER TABLE public.compensation_awards OWNER TO postgres;

--
-- Name: compensation_catalog; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.compensation_catalog (
    country_code character varying(8) NOT NULL,
    catalog_version integer NOT NULL,
    purpose text,
    status character varying(20) NOT NULL,
    published_at timestamp with time zone,
    deprecated_at timestamp with time zone,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    revision bigint DEFAULT 0 NOT NULL,
    CONSTRAINT compensation_catalog_catalog_version_check CHECK ((catalog_version > 0)),
    CONSTRAINT compensation_catalog_check CHECK ((updated_at >= created_at)),
    CONSTRAINT compensation_catalog_check1 CHECK ((((status)::text <> 'DRAFT'::text) OR ((published_at IS NULL) AND (deprecated_at IS NULL)))),
    CONSTRAINT compensation_catalog_check2 CHECK ((((status)::text = 'DRAFT'::text) OR (published_at IS NOT NULL))),
    CONSTRAINT compensation_catalog_check3 CHECK ((((status)::text <> 'PUBLISHED'::text) OR (deprecated_at IS NULL))),
    CONSTRAINT compensation_catalog_check4 CHECK ((((status)::text <> 'DEPRECATED'::text) OR (deprecated_at IS NOT NULL))),
    CONSTRAINT compensation_catalog_status_check CHECK (((status)::text = ANY ((ARRAY['DRAFT'::character varying, 'PUBLISHED'::character varying, 'DEPRECATED'::character varying])::text[])))
);


ALTER TABLE public.compensation_catalog OWNER TO postgres;

--
-- Name: compensation_events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.compensation_events (
    sequence bigint NOT NULL,
    event_id uuid NOT NULL,
    event_name character varying(255) NOT NULL,
    occurred_at timestamp with time zone NOT NULL,
    company_id character varying(255),
    country_code character varying(2),
    payload jsonb NOT NULL
);


ALTER TABLE public.compensation_events OWNER TO postgres;

--
-- Name: compensation_events_sequence_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.compensation_events ALTER COLUMN sequence ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.compensation_events_sequence_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: compensation_packages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.compensation_packages (
    id character varying(255) NOT NULL,
    company_id character varying(255) NOT NULL,
    legal_entity_id character varying(255) NOT NULL,
    country_code character varying(8) NOT NULL,
    currency character varying(3) NOT NULL,
    code character varying(64) NOT NULL,
    label character varying(255) NOT NULL,
    package_version integer NOT NULL,
    remunerations jsonb NOT NULL,
    benefits jsonb NOT NULL,
    inputs jsonb NOT NULL,
    valid_from date NOT NULL,
    valid_to date,
    status character varying(20) NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    revision bigint DEFAULT 0 NOT NULL,
    CONSTRAINT compensation_packages_benefits_check CHECK ((jsonb_typeof(benefits) = 'array'::text)),
    CONSTRAINT compensation_packages_check CHECK (((valid_to IS NULL) OR (valid_to >= valid_from))),
    CONSTRAINT compensation_packages_check1 CHECK ((((status)::text <> ALL ((ARRAY['SUPERSEDED'::character varying, 'RETIRED'::character varying])::text[])) OR (valid_to IS NOT NULL))),
    CONSTRAINT compensation_packages_check2 CHECK ((((status)::text = 'DRAFT'::text) OR (((jsonb_array_length(remunerations) + jsonb_array_length(benefits)) + jsonb_array_length(inputs)) > 0))),
    CONSTRAINT compensation_packages_check3 CHECK ((updated_at >= created_at)),
    CONSTRAINT compensation_packages_code_check CHECK (((code)::text ~ '^[A-Z][A-Z0-9_]*$'::text)),
    CONSTRAINT compensation_packages_inputs_check CHECK ((jsonb_typeof(inputs) = 'array'::text)),
    CONSTRAINT compensation_packages_label_check CHECK ((btrim((label)::text) <> ''::text)),
    CONSTRAINT compensation_packages_package_version_check CHECK ((package_version > 0)),
    CONSTRAINT compensation_packages_remunerations_check CHECK ((jsonb_typeof(remunerations) = 'array'::text)),
    CONSTRAINT compensation_packages_status_check CHECK (((status)::text = ANY ((ARRAY['DRAFT'::character varying, 'PUBLISHED'::character varying, 'SUPERSEDED'::character varying, 'RETIRED'::character varying])::text[])))
);


ALTER TABLE public.compensation_packages OWNER TO postgres;

--
-- Name: compensation_requirement; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.compensation_requirement (
    id character varying(255) NOT NULL,
    company_id character varying(255) NOT NULL,
    legal_entity_id character varying(255) NOT NULL,
    employee_id character varying(255) NOT NULL,
    policy_id character varying(255) NOT NULL,
    policy_code character varying(64) NOT NULL,
    policy_version integer NOT NULL,
    priority integer NOT NULL,
    country_code character varying(8) NOT NULL,
    number character varying(3) NOT NULL,
    frequency character varying(20) NOT NULL,
    currency character varying(3) NOT NULL,
    value jsonb,
    override_strategy character varying(20) NOT NULL,
    assignment_mode character varying(40) NOT NULL,
    approval_required boolean NOT NULL,
    contract_amendment_required boolean NOT NULL,
    employee_acceptance_required boolean NOT NULL,
    occurrence_start date NOT NULL,
    occurrence_end date NOT NULL,
    due_start date NOT NULL,
    due_end date NOT NULL,
    status character varying(20) NOT NULL,
    satisfied_by character varying(255),
    replaced_remunerations character varying(255)[] DEFAULT '{}'::character varying[] NOT NULL,
    note text,
    decided_by character varying(255),
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    revision bigint DEFAULT 0 NOT NULL,
    CONSTRAINT compensation_requirement_check CHECK ((occurrence_end >= occurrence_start)),
    CONSTRAINT compensation_requirement_check1 CHECK (((due_start >= occurrence_start) AND (due_end <= occurrence_end) AND (due_end >= due_start))),
    CONSTRAINT compensation_requirement_check2 CHECK ((((status)::text = ANY ((ARRAY['FULFILLED'::character varying, 'COVERED'::character varying])::text[])) = (satisfied_by IS NOT NULL))),
    CONSTRAINT compensation_requirement_check3 CHECK ((((status)::text <> 'FULFILLED'::text) OR (value IS NOT NULL))),
    CONSTRAINT compensation_requirement_check4 CHECK ((((status)::text = 'FULFILLED'::text) OR (cardinality(replaced_remunerations) = 0))),
    CONSTRAINT compensation_requirement_check5 CHECK ((updated_at >= created_at)),
    CONSTRAINT compensation_requirement_override_strategy_check CHECK (((override_strategy)::text = ANY ((ARRAY['KEEP'::character varying, 'REPLACE'::character varying, 'ADD'::character varying, 'HIGHEST'::character varying])::text[]))),
    CONSTRAINT compensation_requirement_policy_version_check CHECK ((policy_version > 0)),
    CONSTRAINT compensation_requirement_priority_check CHECK ((priority >= 0)),
    CONSTRAINT compensation_requirement_status_check CHECK (((status)::text = ANY ((ARRAY['PENDING'::character varying, 'CONFLICT'::character varying, 'FULFILLED'::character varying, 'COVERED'::character varying, 'WAIVED'::character varying, 'CANCELLED'::character varying])::text[]))),
    CONSTRAINT compensation_requirement_value_check CHECK (((value IS NULL) OR (jsonb_typeof(value) = 'object'::text)))
);


ALTER TABLE public.compensation_requirement OWNER TO postgres;

--
-- Name: eligibility_policy; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.eligibility_policy (
    id character varying(255) NOT NULL,
    company_id character varying(255) NOT NULL,
    legal_entity_id character varying(255) NOT NULL,
    country_code character varying(8) NOT NULL,
    currency character varying(3) NOT NULL,
    code character varying(64) NOT NULL,
    label character varying(255) NOT NULL,
    policy_version integer NOT NULL,
    population jsonb NOT NULL,
    remunerations jsonb NOT NULL,
    frequency character varying(20) NOT NULL,
    anchor date,
    assignment_mode character varying(40) NOT NULL,
    approval_required boolean NOT NULL,
    contract_amendment_required boolean NOT NULL,
    employee_acceptance_required boolean NOT NULL,
    priority integer NOT NULL,
    valid_from date NOT NULL,
    valid_to date,
    status character varying(20) NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    revision bigint DEFAULT 0 NOT NULL,
    CONSTRAINT eligibility_policy_check CHECK (((valid_to IS NULL) OR (valid_to >= valid_from))),
    CONSTRAINT eligibility_policy_check1 CHECK ((((status)::text <> ALL ((ARRAY['SUPERSEDED'::character varying, 'RETIRED'::character varying])::text[])) OR (valid_to IS NOT NULL))),
    CONSTRAINT eligibility_policy_check2 CHECK ((((frequency)::text = 'ONE_TIME'::text) = (anchor IS NULL))),
    CONSTRAINT eligibility_policy_check3 CHECK ((((frequency)::text <> 'ONE_TIME'::text) OR (valid_to IS NOT NULL))),
    CONSTRAINT eligibility_policy_check4 CHECK ((((status)::text = 'DRAFT'::text) OR (jsonb_array_length(remunerations) > 0))),
    CONSTRAINT eligibility_policy_check5 CHECK ((updated_at >= created_at)),
    CONSTRAINT eligibility_policy_code_check CHECK (((code)::text ~ '^[A-Z][A-Z0-9_]*$'::text)),
    CONSTRAINT eligibility_policy_frequency_check CHECK (((frequency)::text <> 'HOURLY'::text)),
    CONSTRAINT eligibility_policy_label_check CHECK ((btrim((label)::text) <> ''::text)),
    CONSTRAINT eligibility_policy_policy_version_check CHECK ((policy_version > 0)),
    CONSTRAINT eligibility_policy_population_check CHECK ((jsonb_typeof(population) = 'object'::text)),
    CONSTRAINT eligibility_policy_priority_check CHECK ((priority >= 0)),
    CONSTRAINT eligibility_policy_remunerations_check CHECK ((jsonb_typeof(remunerations) = 'array'::text)),
    CONSTRAINT eligibility_policy_status_check CHECK (((status)::text = ANY ((ARRAY['DRAFT'::character varying, 'ACTIVE'::character varying, 'SUPERSEDED'::character varying, 'RETIRED'::character varying])::text[])))
);


ALTER TABLE public.eligibility_policy OWNER TO postgres;

--
-- Name: employee_benefit_assignments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employee_benefit_assignments (
    id character varying(255) NOT NULL,
    company_id character varying(255) NOT NULL,
    legal_entity_id character varying(255) NOT NULL,
    employee_id character varying(255) NOT NULL,
    country_code character varying(8) NOT NULL,
    number character varying(3) NOT NULL,
    description character varying(255),
    quantity numeric(19,4),
    unit character varying(40),
    effective_from date NOT NULL,
    effective_to date,
    package_assignment_id character varying(255),
    assignment_version bigint NOT NULL,
    status character varying(20) NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    revision bigint DEFAULT 0 NOT NULL,
    catalog_version integer NOT NULL,
    supply_mode character varying(20) DEFAULT 'IN_KIND'::character varying NOT NULL,
    characteristics jsonb DEFAULT '[]'::jsonb NOT NULL,
    cash_amount numeric(19,4),
    cash_currency character varying(3),
    cash_frequency character varying(20),
    CONSTRAINT employee_benefit_assignments_assignment_version_check CHECK ((assignment_version > 0)),
    CONSTRAINT employee_benefit_assignments_cash_amount_check CHECK (((cash_amount IS NULL) OR (cash_amount > (0)::numeric))),
    CONSTRAINT employee_benefit_assignments_catalog_version_check CHECK ((catalog_version > 0)),
    CONSTRAINT employee_benefit_assignments_characteristics_check CHECK ((jsonb_typeof(characteristics) = 'array'::text)),
    CONSTRAINT employee_benefit_assignments_check3 CHECK (((unit IS NULL) OR (quantity IS NOT NULL))),
    CONSTRAINT employee_benefit_assignments_check4 CHECK (((effective_to IS NULL) OR (effective_to >= effective_from))),
    CONSTRAINT employee_benefit_assignments_check5 CHECK ((((status)::text <> 'ENDED'::text) OR (effective_to IS NOT NULL))),
    CONSTRAINT employee_benefit_assignments_check6 CHECK ((updated_at >= created_at)),
    CONSTRAINT employee_benefit_assignments_check7 CHECK ((((supply_mode)::text = 'IN_KIND'::text) = (cash_amount IS NULL))),
    CONSTRAINT employee_benefit_assignments_check8 CHECK ((((cash_amount IS NULL) = (cash_currency IS NULL)) AND ((cash_amount IS NULL) = (cash_frequency IS NULL)))),
    CONSTRAINT employee_benefit_assignments_description_check CHECK (((description IS NULL) OR (btrim((description)::text) <> ''::text))),
    CONSTRAINT employee_benefit_assignments_quantity_check CHECK (((quantity IS NULL) OR (quantity >= (0)::numeric))),
    CONSTRAINT employee_benefit_assignments_status_check CHECK (((status)::text = ANY ((ARRAY['PROPOSED'::character varying, 'ACTIVE'::character varying, 'ENDED'::character varying, 'CANCELLED'::character varying])::text[]))),
    CONSTRAINT employee_benefit_assignments_supply_mode_check CHECK (((supply_mode)::text = ANY ((ARRAY['IN_KIND'::character varying, 'CASH'::character varying])::text[])))
);


ALTER TABLE public.employee_benefit_assignments OWNER TO postgres;

--
-- Name: employee_compensation_suspensions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employee_compensation_suspensions (
    id character varying(255) NOT NULL,
    company_id character varying(255) NOT NULL,
    legal_entity_id character varying(255) NOT NULL,
    employee_id character varying(255) NOT NULL,
    country_code character varying(8) NOT NULL,
    number character varying(3) NOT NULL,
    effective_from date NOT NULL,
    effective_to date,
    reason character varying(40) NOT NULL,
    comment text,
    source_reference character varying(255),
    status character varying(20) NOT NULL,
    recorded_by character varying(255) NOT NULL,
    recorded_at timestamp with time zone NOT NULL,
    cancelled_by character varying(255),
    cancelled_at timestamp with time zone,
    cancellation_reason text,
    updated_by character varying(255) NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    suspension_version bigint NOT NULL,
    revision bigint DEFAULT 0 NOT NULL,
    CONSTRAINT employee_compensation_suspensions_check CHECK (((effective_to IS NULL) OR (effective_to >= effective_from))),
    CONSTRAINT employee_compensation_suspensions_check1 CHECK ((updated_at >= recorded_at)),
    CONSTRAINT employee_compensation_suspensions_check2 CHECK ((((status)::text = 'CANCELLED'::text) = ((cancelled_at IS NOT NULL) AND (cancelled_by IS NOT NULL) AND (cancellation_reason IS NOT NULL)))),
    CONSTRAINT employee_compensation_suspensions_check3 CHECK ((((status)::text = 'CANCELLED'::text) OR ((cancelled_at IS NULL) AND (cancelled_by IS NULL) AND (cancellation_reason IS NULL)))),
    CONSTRAINT employee_compensation_suspensions_reason_check CHECK (((reason)::text = ANY ((ARRAY['UNPAID_LEAVE'::character varying, 'DISCIPLINARY'::character varying, 'REPLACED_BY_REQUIREMENT'::character varying, 'OTHER'::character varying])::text[]))),
    CONSTRAINT employee_compensation_suspensions_status_check CHECK (((status)::text = ANY ((ARRAY['RECORDED'::character varying, 'CANCELLED'::character varying])::text[]))),
    CONSTRAINT employee_compensation_suspensions_suspension_version_check CHECK ((suspension_version > 0))
);


ALTER TABLE public.employee_compensation_suspensions OWNER TO postgres;

--
-- Name: employee_compensations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employee_compensations (
    id character varying(255) NOT NULL,
    company_id character varying(255) NOT NULL,
    legal_entity_id character varying(255) NOT NULL,
    employee_id character varying(255) NOT NULL,
    country_code character varying(8) NOT NULL,
    number character varying(3) NOT NULL,
    display_label character varying(255),
    value jsonb NOT NULL,
    calculation_method character varying(40),
    execution character varying(20) NOT NULL,
    frequency character varying(20) NOT NULL,
    currency character varying(3) NOT NULL,
    effective_from date NOT NULL,
    effective_to date,
    source character varying(40) NOT NULL,
    source_reference character varying(255),
    package_assignment_id character varying(255),
    requirement_id character varying(255),
    status character varying(20) NOT NULL,
    compensation_version bigint NOT NULL,
    previous_version_id character varying(255),
    approved_at timestamp with time zone,
    approved_by character varying(255),
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    revision bigint DEFAULT 0 NOT NULL,
    award_id character varying(255),
    payable_on date,
    CONSTRAINT ck_employee_compensation_award CHECK ((((source)::text = 'INCENTIVE_AWARD'::text) = (award_id IS NOT NULL))),
    CONSTRAINT ck_employee_compensation_award_once CHECK (((award_id IS NULL) OR ((frequency)::text = 'ONE_TIME'::text))),
    CONSTRAINT ck_employee_compensation_payable_on CHECK (((payable_on IS NULL) OR (((frequency)::text = 'ONE_TIME'::text) AND ((effective_to IS NULL) OR (payable_on >= effective_to))))),
    CONSTRAINT employee_compensations_check CHECK (((effective_to IS NULL) OR (effective_to >= effective_from))),
    CONSTRAINT employee_compensations_check1 CHECK ((((frequency)::text <> 'ONE_TIME'::text) OR (effective_to IS NOT NULL))),
    CONSTRAINT employee_compensations_check2 CHECK ((((source)::text = 'COMPENSATION_PACKAGE'::text) = (package_assignment_id IS NOT NULL))),
    CONSTRAINT employee_compensations_check3 CHECK (((requirement_id IS NULL) OR ((source)::text = 'COMPANY_POLICY'::text))),
    CONSTRAINT employee_compensations_check4 CHECK ((((status)::text <> ALL ((ARRAY['ACTIVE'::character varying, 'ENDED'::character varying])::text[])) OR ((approved_at IS NOT NULL) AND (approved_by IS NOT NULL)))),
    CONSTRAINT employee_compensations_check5 CHECK ((((status)::text <> 'ENDED'::text) OR (effective_to IS NOT NULL))),
    CONSTRAINT employee_compensations_check6 CHECK (((compensation_version = 1) OR (previous_version_id IS NOT NULL))),
    CONSTRAINT employee_compensations_check7 CHECK ((updated_at >= created_at)),
    CONSTRAINT employee_compensations_compensation_version_check CHECK ((compensation_version > 0)),
    CONSTRAINT employee_compensations_status_check CHECK (((status)::text = ANY ((ARRAY['DRAFT'::character varying, 'PENDING_APPROVAL'::character varying, 'ACTIVE'::character varying, 'ENDED'::character varying, 'CANCELLED'::character varying])::text[]))),
    CONSTRAINT employee_compensations_value_check CHECK ((jsonb_typeof(value) = 'object'::text))
);


ALTER TABLE public.employee_compensations OWNER TO postgres;

--
-- Name: employee_incentive_assignments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employee_incentive_assignments (
    id character varying(255) NOT NULL,
    company_id character varying(255) NOT NULL,
    legal_entity_id character varying(255) NOT NULL,
    employee_id character varying(255) NOT NULL,
    plan_code character varying(64) NOT NULL,
    target_amount numeric(19,4),
    target_currency character varying(3),
    target_percentage numeric(9,4),
    valid_from date NOT NULL,
    valid_to date,
    status character varying(20) NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    revision bigint DEFAULT 0 NOT NULL,
    CONSTRAINT employee_incentive_assignments_check CHECK (((target_amount IS NULL) = (target_currency IS NULL))),
    CONSTRAINT employee_incentive_assignments_check1 CHECK (((target_amount IS NULL) OR (target_percentage IS NULL))),
    CONSTRAINT employee_incentive_assignments_check2 CHECK (((valid_to IS NULL) OR (valid_to >= valid_from))),
    CONSTRAINT employee_incentive_assignments_check3 CHECK ((((status)::text <> 'ENDED'::text) OR (valid_to IS NOT NULL))),
    CONSTRAINT employee_incentive_assignments_check4 CHECK ((updated_at >= created_at)),
    CONSTRAINT employee_incentive_assignments_status_check CHECK (((status)::text = ANY ((ARRAY['ACTIVE'::character varying, 'ENDED'::character varying, 'CANCELLED'::character varying])::text[]))),
    CONSTRAINT employee_incentive_assignments_target_amount_check CHECK (((target_amount IS NULL) OR (target_amount >= (0)::numeric))),
    CONSTRAINT employee_incentive_assignments_target_percentage_check CHECK (((target_percentage IS NULL) OR (target_percentage >= (0)::numeric)))
);


ALTER TABLE public.employee_incentive_assignments OWNER TO postgres;

--
-- Name: employee_package_assignment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employee_package_assignment (
    id character varying(255) NOT NULL,
    company_id character varying(255) NOT NULL,
    legal_entity_id character varying(255) NOT NULL,
    employee_id character varying(255) NOT NULL,
    package_version_id character varying(255) NOT NULL,
    package_code character varying(64) NOT NULL,
    package_version integer NOT NULL,
    valid_from date NOT NULL,
    valid_to date,
    adjustments jsonb NOT NULL,
    status character varying(20) NOT NULL,
    successor_id character varying(255),
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    revision bigint DEFAULT 0 NOT NULL,
    CONSTRAINT employee_package_assignment_adjustments_check CHECK ((jsonb_typeof(adjustments) = 'object'::text)),
    CONSTRAINT employee_package_assignment_check CHECK (((valid_to IS NULL) OR (valid_to >= valid_from))),
    CONSTRAINT employee_package_assignment_check1 CHECK ((((status)::text = 'ACTIVE'::text) OR (valid_to IS NOT NULL))),
    CONSTRAINT employee_package_assignment_check2 CHECK ((((status)::text = 'MIGRATED'::text) = (successor_id IS NOT NULL))),
    CONSTRAINT employee_package_assignment_check3 CHECK ((updated_at >= created_at)),
    CONSTRAINT employee_package_assignment_package_version_check CHECK ((package_version > 0)),
    CONSTRAINT employee_package_assignment_status_check CHECK (((status)::text = ANY ((ARRAY['ACTIVE'::character varying, 'ENDED'::character varying, 'MIGRATED'::character varying])::text[])))
);


ALTER TABLE public.employee_package_assignment OWNER TO postgres;

--
-- Name: employee_parameter_assignments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employee_parameter_assignments (
    id character varying(255) NOT NULL,
    company_id character varying(255) NOT NULL,
    legal_entity_id character varying(255) NOT NULL,
    employee_id character varying(255) NOT NULL,
    country_code character varying(8) NOT NULL,
    code character varying(64) NOT NULL,
    definition_version bigint NOT NULL,
    value jsonb NOT NULL,
    effective_from date NOT NULL,
    effective_to date,
    package_assignment_id character varying(255),
    assignment_version bigint NOT NULL,
    status character varying(20) NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    revision bigint DEFAULT 0 NOT NULL,
    CONSTRAINT employee_parameter_assignments_assignment_version_check CHECK ((assignment_version > 0)),
    CONSTRAINT employee_parameter_assignments_check CHECK (((effective_to IS NULL) OR (effective_to >= effective_from))),
    CONSTRAINT employee_parameter_assignments_check1 CHECK ((((status)::text <> 'ENDED'::text) OR (effective_to IS NOT NULL))),
    CONSTRAINT employee_parameter_assignments_check2 CHECK ((updated_at >= created_at)),
    CONSTRAINT employee_parameter_assignments_definition_version_check CHECK ((definition_version > 0)),
    CONSTRAINT employee_parameter_assignments_status_check CHECK (((status)::text = ANY ((ARRAY['PROPOSED'::character varying, 'ACTIVE'::character varying, 'ENDED'::character varying, 'CANCELLED'::character varying])::text[]))),
    CONSTRAINT employee_parameter_assignments_value_check CHECK ((jsonb_typeof(value) = 'object'::text))
);


ALTER TABLE public.employee_parameter_assignments OWNER TO postgres;

--
-- Name: flyway_schema_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.flyway_schema_history (
    installed_rank integer NOT NULL,
    version character varying(50),
    description character varying(200) NOT NULL,
    type character varying(20) NOT NULL,
    script character varying(1000) NOT NULL,
    checksum integer,
    installed_by character varying(100) NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


ALTER TABLE public.flyway_schema_history OWNER TO postgres;

--
-- Name: incentive_plans; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.incentive_plans (
    id character varying(255) NOT NULL,
    company_id character varying(255) NOT NULL,
    legal_entity_id character varying(255) NOT NULL,
    country_code character varying(8) NOT NULL,
    currency character varying(3) NOT NULL,
    code character varying(64) NOT NULL,
    label character varying(255) NOT NULL,
    plan_version integer NOT NULL,
    type character varying(20) NOT NULL,
    payout_number character varying(3) NOT NULL,
    period_type character varying(20) NOT NULL,
    fiscal_year_start smallint NOT NULL,
    kpis jsonb NOT NULL,
    formula jsonb,
    minimum_payout numeric(19,6),
    maximum_payout numeric(19,6),
    valid_from date NOT NULL,
    valid_to date,
    status character varying(20) NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    revision bigint DEFAULT 0 NOT NULL,
    CONSTRAINT incentive_plans_check CHECK (((valid_to IS NULL) OR (valid_to >= valid_from))),
    CONSTRAINT incentive_plans_check1 CHECK (((minimum_payout IS NULL) OR (maximum_payout IS NULL) OR (minimum_payout <= maximum_payout))),
    CONSTRAINT incentive_plans_check2 CHECK ((((status)::text <> ALL ((ARRAY['SUPERSEDED'::character varying, 'RETIRED'::character varying])::text[])) OR (valid_to IS NOT NULL))),
    CONSTRAINT incentive_plans_check3 CHECK ((((status)::text = 'DRAFT'::text) OR ((formula IS NOT NULL) AND (jsonb_array_length(kpis) > 0)))),
    CONSTRAINT incentive_plans_check4 CHECK ((updated_at >= created_at)),
    CONSTRAINT incentive_plans_code_check CHECK (((code)::text ~ '^[A-Z][A-Z0-9_]*$'::text)),
    CONSTRAINT incentive_plans_fiscal_year_start_check CHECK (((fiscal_year_start >= 1) AND (fiscal_year_start <= 12))),
    CONSTRAINT incentive_plans_formula_check CHECK (((formula IS NULL) OR (jsonb_typeof(formula) = 'object'::text))),
    CONSTRAINT incentive_plans_kpis_check CHECK ((jsonb_typeof(kpis) = 'array'::text)),
    CONSTRAINT incentive_plans_label_check CHECK ((btrim((label)::text) <> ''::text)),
    CONSTRAINT incentive_plans_maximum_payout_check CHECK (((maximum_payout IS NULL) OR (maximum_payout > (0)::numeric))),
    CONSTRAINT incentive_plans_minimum_payout_check CHECK (((minimum_payout IS NULL) OR (minimum_payout >= (0)::numeric))),
    CONSTRAINT incentive_plans_period_type_check CHECK (((period_type)::text = ANY ((ARRAY['MONTHLY'::character varying, 'QUARTERLY'::character varying, 'SEMI_ANNUAL'::character varying, 'ANNUAL'::character varying])::text[]))),
    CONSTRAINT incentive_plans_plan_version_check CHECK ((plan_version > 0)),
    CONSTRAINT incentive_plans_status_check CHECK (((status)::text = ANY ((ARRAY['DRAFT'::character varying, 'ACTIVE'::character varying, 'SUPERSEDED'::character varying, 'RETIRED'::character varying])::text[]))),
    CONSTRAINT incentive_plans_type_check CHECK (((type)::text = ANY ((ARRAY['BONUS'::character varying, 'COMMISSION'::character varying])::text[])))
);


ALTER TABLE public.incentive_plans OWNER TO postgres;

--
-- Name: input_definition; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.input_definition (
    country_code character varying(8) NOT NULL,
    catalog_version integer NOT NULL,
    code character varying(64) NOT NULL,
    label character varying(255) NOT NULL,
    presentation jsonb DEFAULT '{}'::jsonb NOT NULL,
    value_type character varying(20) NOT NULL,
    unit character varying(20),
    minimum numeric(38,12),
    maximum numeric(38,12),
    allowed_values character varying(255)[] DEFAULT '{}'::character varying[] NOT NULL,
    binding character varying(20) NOT NULL,
    allowed_sources character varying(20)[] NOT NULL,
    status character varying(20) NOT NULL,
    valid_from date NOT NULL,
    valid_to date,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    revision bigint DEFAULT 0 NOT NULL,
    CONSTRAINT input_definition_allowed_sources_check CHECK ((cardinality(allowed_sources) > 0)),
    CONSTRAINT input_definition_binding_check CHECK (((binding)::text = ANY ((ARRAY['ASSIGNED'::character varying, 'PERIODIC'::character varying])::text[]))),
    CONSTRAINT input_definition_check CHECK (((unit IS NOT NULL) = ((value_type)::text = ANY ((ARRAY['MONEY'::character varying, 'QUANTITY'::character varying, 'RATE'::character varying, 'INTEGER'::character varying])::text[])))),
    CONSTRAINT input_definition_check1 CHECK (((minimum IS NULL) OR (maximum IS NULL) OR (minimum <= maximum))),
    CONSTRAINT input_definition_check2 CHECK ((((minimum IS NULL) AND (maximum IS NULL)) OR ((value_type)::text = ANY ((ARRAY['MONEY'::character varying, 'QUANTITY'::character varying, 'RATE'::character varying, 'INTEGER'::character varying])::text[])))),
    CONSTRAINT input_definition_check3 CHECK (((cardinality(allowed_values) = 0) OR ((value_type)::text = 'TEXT'::text))),
    CONSTRAINT input_definition_check4 CHECK (((valid_to IS NULL) OR (valid_to >= valid_from))),
    CONSTRAINT input_definition_check5 CHECK ((((status)::text <> 'DEACTIVATED'::text) OR (valid_to IS NOT NULL))),
    CONSTRAINT input_definition_check6 CHECK ((updated_at >= created_at)),
    CONSTRAINT input_definition_code_check CHECK (((code)::text ~ '^[A-Z][A-Z0-9_]*$'::text)),
    CONSTRAINT input_definition_label_check CHECK ((btrim((label)::text) <> ''::text)),
    CONSTRAINT input_definition_presentation_check CHECK ((jsonb_typeof(presentation) = 'object'::text)),
    CONSTRAINT input_definition_status_check CHECK (((status)::text = ANY ((ARRAY['DRAFT'::character varying, 'ACTIVE'::character varying, 'DEACTIVATED'::character varying])::text[]))),
    CONSTRAINT input_definition_value_type_check CHECK (((value_type)::text = ANY ((ARRAY['MONEY'::character varying, 'QUANTITY'::character varying, 'RATE'::character varying, 'INTEGER'::character varying, 'BOOLEAN'::character varying, 'TEXT'::character varying, 'DATE'::character varying])::text[])))
);


ALTER TABLE public.input_definition OWNER TO postgres;

--
-- Name: input_rule; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.input_rule (
    id character varying(64) NOT NULL,
    country_code character varying(8) NOT NULL,
    rule_code character varying(128) NOT NULL,
    rule_version bigint NOT NULL,
    scope_level character varying(40) NOT NULL,
    company_id character varying(64),
    employee_id character varying(64),
    collective_agreement character varying(128),
    label character varying(255) NOT NULL,
    valid_from date NOT NULL,
    valid_to date,
    status character varying(40) NOT NULL,
    identity jsonb NOT NULL,
    publication jsonb NOT NULL,
    scope jsonb NOT NULL,
    legal_reference jsonb NOT NULL,
    rule_target jsonb NOT NULL,
    rule_constraint jsonb NOT NULL,
    severity character varying(40) NOT NULL,
    resolution_policy jsonb NOT NULL,
    revision bigint DEFAULT 0 NOT NULL,
    CONSTRAINT input_rule_check CHECK (((valid_to IS NULL) OR (valid_to >= valid_from))),
    CONSTRAINT input_rule_check1 CHECK ((((scope_level)::text <> 'EMPLOYEE'::text) OR ((company_id IS NOT NULL) AND (employee_id IS NOT NULL)))),
    CONSTRAINT input_rule_check2 CHECK ((((scope_level)::text <> 'COMPANY'::text) OR ((company_id IS NOT NULL) AND (employee_id IS NULL)))),
    CONSTRAINT input_rule_check3 CHECK ((((scope_level)::text <> 'COLLECTIVE_AGREEMENT'::text) OR ((collective_agreement IS NOT NULL) AND (company_id IS NULL) AND (employee_id IS NULL)))),
    CONSTRAINT input_rule_check4 CHECK ((((scope_level)::text <> 'COUNTRY'::text) OR ((collective_agreement IS NULL) AND (company_id IS NULL) AND (employee_id IS NULL)))),
    CONSTRAINT input_rule_rule_version_check CHECK ((rule_version > 0)),
    CONSTRAINT input_rule_scope_level_check CHECK (((scope_level)::text = ANY ((ARRAY['COUNTRY'::character varying, 'COLLECTIVE_AGREEMENT'::character varying, 'COMPANY'::character varying, 'EMPLOYEE'::character varying])::text[]))),
    CONSTRAINT input_rule_status_check CHECK (((status)::text = ANY ((ARRAY['DRAFT'::character varying, 'ACTIVE'::character varying, 'RETIRED'::character varying])::text[])))
);


ALTER TABLE public.input_rule OWNER TO postgres;

--
-- Name: kpi_measurements; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.kpi_measurements (
    id character varying(255) NOT NULL,
    company_id character varying(255) NOT NULL,
    legal_entity_id character varying(255) NOT NULL,
    employee_id character varying(255) NOT NULL,
    kpi_code character varying(64) NOT NULL,
    period_start date NOT NULL,
    period_end date NOT NULL,
    value numeric(24,6) NOT NULL,
    unit character varying(40),
    source character varying(20) NOT NULL,
    source_reference character varying(255),
    note text,
    status character varying(20) NOT NULL,
    superseded_by character varying(255),
    recorded_by character varying(255) NOT NULL,
    recorded_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    revision bigint DEFAULT 0 NOT NULL,
    CONSTRAINT kpi_measurements_check CHECK ((period_end >= period_start)),
    CONSTRAINT kpi_measurements_check1 CHECK ((((source)::text = 'MANUAL'::text) OR (source_reference IS NOT NULL))),
    CONSTRAINT kpi_measurements_check2 CHECK ((((status)::text = 'SUPERSEDED'::text) = (superseded_by IS NOT NULL))),
    CONSTRAINT kpi_measurements_check3 CHECK ((updated_at >= recorded_at)),
    CONSTRAINT kpi_measurements_kpi_code_check CHECK (((kpi_code)::text ~ '^[A-Z][A-Z0-9_]*$'::text)),
    CONSTRAINT kpi_measurements_source_check CHECK (((source)::text = ANY ((ARRAY['PERFORMANCE'::character varying, 'MANUAL'::character varying, 'INTEGRATION'::character varying])::text[]))),
    CONSTRAINT kpi_measurements_status_check CHECK (((status)::text = ANY ((ARRAY['CURRENT'::character varying, 'SUPERSEDED'::character varying])::text[])))
);


ALTER TABLE public.kpi_measurements OWNER TO postgres;

--
-- Name: proration_policies; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.proration_policies (
    id uuid NOT NULL,
    country_code character varying(8) NOT NULL,
    lineage uuid NOT NULL,
    policy_version bigint NOT NULL,
    label character varying(255) NOT NULL,
    scope jsonb NOT NULL,
    target jsonb NOT NULL,
    source_reference jsonb,
    temporal_rule jsonb,
    absence_rules jsonb NOT NULL,
    status character varying(20) NOT NULL,
    valid_from date NOT NULL,
    valid_to date,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    revision bigint DEFAULT 0 NOT NULL,
    CONSTRAINT ck_proration_closed CHECK ((((status)::text <> ALL ((ARRAY['SUPERSEDED'::character varying, 'RETIRED'::character varying])::text[])) OR (valid_to IS NOT NULL))),
    CONSTRAINT ck_proration_dates CHECK (((valid_to IS NULL) OR (valid_to >= valid_from))),
    CONSTRAINT proration_policies_policy_version_check CHECK ((policy_version > 0)),
    CONSTRAINT proration_policies_status_check CHECK (((status)::text = ANY ((ARRAY['DRAFT'::character varying, 'ACTIVE'::character varying, 'SUPERSEDED'::character varying, 'RETIRED'::character varying])::text[])))
);


ALTER TABLE public.proration_policies OWNER TO postgres;

--
-- Name: remuneration_element; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.remuneration_element (
    country_code character varying(8) NOT NULL,
    catalog_version integer NOT NULL,
    number character varying(3) NOT NULL,
    code character varying(64) NOT NULL,
    label character varying(255) NOT NULL,
    type character varying(40) NOT NULL,
    presentation jsonb DEFAULT '{}'::jsonb NOT NULL,
    proration_category character varying(40) NOT NULL,
    absence_sensitivity character varying(40) NOT NULL,
    allowed_frequencies character varying(40)[] NOT NULL,
    allowed_calculation_methods character varying(40)[] DEFAULT '{}'::character varying[] NOT NULL,
    allowed_executions character varying(40)[] DEFAULT '{}'::character varying[] NOT NULL,
    status character varying(20) NOT NULL,
    valid_from date NOT NULL,
    valid_to date,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    revision bigint DEFAULT 0 NOT NULL,
    CONSTRAINT remuneration_element_allowed_frequencies_check CHECK ((cardinality(allowed_frequencies) > 0)),
    CONSTRAINT remuneration_element_check CHECK (((valid_to IS NULL) OR (valid_to >= valid_from))),
    CONSTRAINT remuneration_element_check1 CHECK ((((status)::text <> 'DEACTIVATED'::text) OR (valid_to IS NOT NULL))),
    CONSTRAINT remuneration_element_check2 CHECK ((((status)::text = 'DRAFT'::text) OR ((cardinality(allowed_calculation_methods) > 0) AND (cardinality(allowed_executions) > 0)))),
    CONSTRAINT remuneration_element_check3 CHECK ((updated_at >= created_at)),
    CONSTRAINT remuneration_element_code_check CHECK (((code)::text ~ '^[A-Z][A-Z0-9_]*$'::text)),
    CONSTRAINT remuneration_element_label_check CHECK ((btrim((label)::text) <> ''::text)),
    CONSTRAINT remuneration_element_number_check CHECK ((((number)::text ~ '^[1-5][0-9]{2}$'::text) AND ((number)::text !~ '00$'::text))),
    CONSTRAINT remuneration_element_presentation_check CHECK ((jsonb_typeof(presentation) = 'object'::text)),
    CONSTRAINT remuneration_element_status_check CHECK (((status)::text = ANY ((ARRAY['DRAFT'::character varying, 'ACTIVE'::character varying, 'DEACTIVATED'::character varying])::text[])))
);


ALTER TABLE public.remuneration_element OWNER TO postgres;

--
-- Name: remuneration_rule; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.remuneration_rule (
    id character varying(64) NOT NULL,
    country_code character varying(8) NOT NULL,
    rule_code character varying(128) NOT NULL,
    rule_version bigint NOT NULL,
    scope_level character varying(40) NOT NULL,
    company_id character varying(64),
    employee_id character varying(64),
    collective_agreement character varying(128),
    label character varying(255) NOT NULL,
    valid_from date NOT NULL,
    valid_to date,
    status character varying(40) NOT NULL,
    identity jsonb NOT NULL,
    publication jsonb NOT NULL,
    scope jsonb NOT NULL,
    legal_reference jsonb NOT NULL,
    rule_target jsonb NOT NULL,
    rule_constraint jsonb NOT NULL,
    severity character varying(40) NOT NULL,
    resolution_policy jsonb NOT NULL,
    revision bigint DEFAULT 0 NOT NULL,
    CONSTRAINT remuneration_rule_check CHECK (((valid_to IS NULL) OR (valid_to >= valid_from))),
    CONSTRAINT remuneration_rule_check1 CHECK ((((scope_level)::text <> 'EMPLOYEE'::text) OR ((company_id IS NOT NULL) AND (employee_id IS NOT NULL)))),
    CONSTRAINT remuneration_rule_check2 CHECK ((((scope_level)::text <> 'COMPANY'::text) OR ((company_id IS NOT NULL) AND (employee_id IS NULL)))),
    CONSTRAINT remuneration_rule_check3 CHECK ((((scope_level)::text <> 'COLLECTIVE_AGREEMENT'::text) OR ((collective_agreement IS NOT NULL) AND (company_id IS NULL) AND (employee_id IS NULL)))),
    CONSTRAINT remuneration_rule_check4 CHECK ((((scope_level)::text <> 'COUNTRY'::text) OR ((collective_agreement IS NULL) AND (company_id IS NULL) AND (employee_id IS NULL)))),
    CONSTRAINT remuneration_rule_rule_version_check CHECK ((rule_version > 0)),
    CONSTRAINT remuneration_rule_scope_level_check CHECK (((scope_level)::text = ANY ((ARRAY['COUNTRY'::character varying, 'COLLECTIVE_AGREEMENT'::character varying, 'COMPANY'::character varying, 'EMPLOYEE'::character varying])::text[]))),
    CONSTRAINT remuneration_rule_status_check CHECK (((status)::text = ANY ((ARRAY['DRAFT'::character varying, 'ACTIVE'::character varying, 'RETIRED'::character varying])::text[])))
);


ALTER TABLE public.remuneration_rule OWNER TO postgres;

--
-- Name: resolution_alerts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.resolution_alerts (
    id character varying(255) NOT NULL,
    company_id character varying(255) NOT NULL,
    legal_entity_id character varying(255),
    employee_id character varying(255) NOT NULL,
    period_start date NOT NULL,
    period_end date NOT NULL,
    subject character varying(512) NOT NULL,
    family character varying(40),
    state character varying(20),
    reason character varying(40),
    issue character varying(40),
    element_code character varying(80),
    source_kind character varying(40),
    source_id character varying(255),
    message text,
    status character varying(20) NOT NULL,
    first_raised_at timestamp with time zone NOT NULL,
    last_seen_at timestamp with time zone NOT NULL,
    acknowledged_by character varying(255),
    acknowledged_at timestamp with time zone,
    cleared_at timestamp with time zone,
    revision bigint DEFAULT 0 NOT NULL,
    CONSTRAINT ck_resolution_alert_acknowledged CHECK ((((acknowledged_by IS NULL) = (acknowledged_at IS NULL)) AND (((status)::text <> 'ACKNOWLEDGED'::text) OR (acknowledged_at IS NOT NULL)))),
    CONSTRAINT ck_resolution_alert_cleared CHECK ((((status)::text = 'CLEARED'::text) = (cleared_at IS NOT NULL))),
    CONSTRAINT ck_resolution_alert_line CHECK (((family IS NULL) OR ((state IS NOT NULL) AND (source_kind IS NOT NULL) AND (source_id IS NOT NULL)))),
    CONSTRAINT ck_resolution_alert_origin CHECK (((family IS NULL) <> (issue IS NULL))),
    CONSTRAINT ck_resolution_alert_period CHECK ((period_end >= period_start)),
    CONSTRAINT resolution_alerts_family_check CHECK (((family)::text = ANY ((ARRAY['RECURRING_REMUNERATION'::character varying, 'ONE_TIME_REMUNERATION'::character varying, 'REQUIREMENT'::character varying, 'BENEFIT'::character varying, 'PARAMETER'::character varying, 'AWARD'::character varying])::text[]))),
    CONSTRAINT resolution_alerts_state_check CHECK (((state)::text = ANY ((ARRAY['DUE'::character varying, 'REQUIRED'::character varying, 'CONFLICT'::character varying, 'EXCLUDED'::character varying])::text[]))),
    CONSTRAINT resolution_alerts_status_check CHECK (((status)::text = ANY ((ARRAY['OPEN'::character varying, 'ACKNOWLEDGED'::character varying, 'CLEARED'::character varying])::text[])))
);


ALTER TABLE public.resolution_alerts OWNER TO postgres;

--
-- Name: resolution_reminder_schedules; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.resolution_reminder_schedules (
    id character varying(255) NOT NULL,
    company_id character varying(255) NOT NULL,
    legal_entity_id character varying(255),
    lead_days integer NOT NULL,
    families character varying(255) NOT NULL,
    active boolean NOT NULL,
    schedule_version bigint NOT NULL,
    created_by character varying(255) NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    revision bigint DEFAULT 0 NOT NULL,
    CONSTRAINT resolution_reminder_schedules_families_check CHECK (((families)::text <> ''::text)),
    CONSTRAINT resolution_reminder_schedules_lead_days_check CHECK (((lead_days >= 0) AND (lead_days <= 27))),
    CONSTRAINT resolution_reminder_schedules_schedule_version_check CHECK ((schedule_version > 0))
);


ALTER TABLE public.resolution_reminder_schedules OWNER TO postgres;

--
-- Data for Name: benefit_asset_kind; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.benefit_asset_kind (country_code, catalog_version, number, code, label, presentation, allowed_frequencies, status, valid_from, valid_to, created_at, updated_at, revision, allowed_supply_modes, characteristics) FROM stdin;
CM	1	650	CAR	Car	{"description": "N'importe quelle vehicule", "localizedLabels": {}, "localizedDescriptions": {}}	{MONTHLY}	ACTIVE	2026-10-01	\N	2026-10-01 10:27:32.370245+00	2026-10-01 10:29:33.029031+00	1	{IN_KIND}	[{"code": "PROFESSIONAL_USE", "label": "Usage professionnel", "valueType": "BOOLEAN", "obligation": "OPTIONAL", "evidenceRequired": false}, {"code": "PRIVATE_USE", "label": "Usage privé", "valueType": "BOOLEAN", "obligation": "OPTIONAL", "evidenceRequired": false}, {"code": "FUEL_PROVIDED", "label": "Carburant fourni par l'employeur", "valueType": "BOOLEAN", "obligation": "OPTIONAL", "evidenceRequired": false}, {"code": "EMPLOYEE_CONTRIBUTION", "unit": "CURRENCY", "label": "Participation périodique du salarié", "minimum": 0, "valueType": "MONEY", "obligation": "OPTIONAL", "evidenceRequired": false}, {"code": "DECLARED_VALUE", "unit": "CURRENCY", "label": "Coût de l'avantage déclaré par l'employeur", "minimum": 0, "valueType": "MONEY", "obligation": "OPTIONAL", "evidenceRequired": false}]
CM	2	650	CAR	Car	{"description": "N'importe quelle vehicule", "localizedLabels": {}, "localizedDescriptions": {}}	{MONTHLY}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0	{IN_KIND}	[{"code": "PROFESSIONAL_USE", "label": "Usage professionnel", "valueType": "BOOLEAN", "obligation": "OPTIONAL", "evidenceRequired": false}, {"code": "PRIVATE_USE", "label": "Usage privé", "valueType": "BOOLEAN", "obligation": "OPTIONAL", "evidenceRequired": false}, {"code": "FUEL_PROVIDED", "label": "Carburant fourni par l'employeur", "valueType": "BOOLEAN", "obligation": "OPTIONAL", "evidenceRequired": false}, {"code": "EMPLOYEE_CONTRIBUTION", "unit": "CURRENCY", "label": "Participation périodique du salarié", "minimum": 0, "valueType": "MONEY", "obligation": "OPTIONAL", "evidenceRequired": false}, {"code": "DECLARED_VALUE", "unit": "CURRENCY", "label": "Coût de l'avantage déclaré par l'employeur", "minimum": 0, "valueType": "MONEY", "obligation": "OPTIONAL", "evidenceRequired": false}]
\.


--
-- Data for Name: benefit_asset_rule; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.benefit_asset_rule (id, country_code, rule_code, rule_version, scope_level, company_id, employee_id, collective_agreement, label, valid_from, valid_to, status, identity, publication, scope, legal_reference, rule_target, rule_constraint, severity, resolution_policy, revision) FROM stdin;
\.


--
-- Data for Name: compensation_awards; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.compensation_awards (id, company_id, legal_entity_id, employee_id, assignment_id, plan_version_id, plan_code, plan_version, plan_type, country_code, payout_number, period_start, period_end, figures, currency, calculated_amount, validated_amount, adjustment_reason, payable_on, compensation_id, status, award_version, decided_by, decided_at, rejection_reason, created_at, updated_at, revision) FROM stdin;
\.


--
-- Data for Name: compensation_catalog; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.compensation_catalog (country_code, catalog_version, purpose, status, published_at, deprecated_at, created_at, updated_at, revision) FROM stdin;
CM	2	Les heures supps tout confondues doivent accepter les montants fixes	PUBLISHED	2026-10-01 11:53:31.510195+00	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:53:31.510195+00	1
CM	1	\N	DEPRECATED	2026-10-01 10:42:57.469539+00	2026-10-01 11:53:31.510195+00	2026-10-01 08:13:19.749433+00	2026-10-01 11:53:31.510195+00	2
\.


--
-- Data for Name: compensation_events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.compensation_events (sequence, event_id, event_name, occurred_at, company_id, country_code, payload) FROM stdin;
1	9dab6fb0-7a4a-42e8-b80c-4142c76223ef	compensation.catalog.published	2026-10-01 10:42:57.514764+00	\N	CM	{"id": "9dab6fb0-7a4a-42e8-b80c-4142c76223ef", "name": "compensation.catalog.published", "realm": "master", "details": {"inputs": [{"entry": {"unit": "DAY", "draft": false, "label": "Jours d'absence", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "ABSENCE_DAYS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "INTEGER", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre total de jours d'absence reconnus pendant la période.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "HOUR", "draft": false, "label": "Heures d'absence à déduire", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "ABSENCE_DEDUCTIBLE_HOURS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "QUANTITY", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Volume d'absence restant à déduire de la rémunération après neutralisation de la part déjà prise en compte par le prorata. Une correction manuelle est possible.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["MANUAL", "SYSTEM"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "HOUR", "draft": false, "label": "Heures d'absence", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "ABSENCE_HOURS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "QUANTITY", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Volume total d'heures d'absence constatées sur la période.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["IMPORT", "MANUAL", "INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "HOUR", "draft": false, "label": "Heures d'absence rémunérées", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "ABSENCE_PAID_HOURS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "QUANTITY", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Volume d'heures d'absence conservant une rémunération.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["IMPORT", "MANUAL", "INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "HOUR", "draft": false, "label": "Heures d'absence non rémunérées", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "ABSENCE_UNPAID_HOURS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "QUANTITY", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Volume d'heures d'absence ne conservant pas de rémunération.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["IMPORT", "MANUAL", "INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "UNIT", "draft": false, "label": "Unités produites acceptées", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "ACCEPTED_PRODUCTION_UNITS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "INTEGER", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre d'unités produites et acceptées après contrôle.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "UNIT", "draft": false, "label": "Correction d'unités acceptées", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "ACCEPTED_UNITS_CORRECTION"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "INTEGER", "constraint": {"max": null, "min": null, "none": true, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Différence signée d'unités de production acceptées pour une période antérieure.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["INTEGRATION", "SYSTEM"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "HOUR", "draft": false, "label": "Heures d'absence autorisée", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "AUTHORIZED_ABSENCE_HOURS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "QUANTITY", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Volume d'heures d'absence autorisées.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["IMPORT", "MANUAL", "INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "KILOMETER", "draft": false, "label": "Distance professionnelle parcourue", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "BUSINESS_DISTANCE_KM"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "QUANTITY", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Distance parcourue et validée pour l'activité professionnelle.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "DAY", "draft": false, "label": "Jours calendaires de la période", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "CALENDAR_DAYS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "INTEGER", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre de jours calendaires de la période de rémunération.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["SYSTEM"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "CURRENCY", "draft": false, "label": "Ventes annulées", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "CANCELLED_SALES_AMOUNT"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "MONEY", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Montant des ventes annulées à prendre en compte dans l'assiette commerciale.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "CURRENCY", "draft": false, "label": "Ventes encaissées", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "COLLECTED_SALES_AMOUNT"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "MONEY", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Montant des ventes effectivement encaissées pendant la période.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "UNIT", "draft": false, "label": "Livraisons achevées", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "COMPLETED_DELIVERIES"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "INTEGER", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre de livraisons achevées et validées pendant la période.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "UNIT", "draft": false, "label": "Missions achevées", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "COMPLETED_MISSIONS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "INTEGER", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre de missions achevées et validées pendant la période.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "UNIT", "draft": false, "label": "Tâches achevées", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "COMPLETED_TASKS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "INTEGER", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre de tâches achevées et validées pendant la période.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "RATIO", "draft": false, "label": "Quotité contractuelle de travail", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "CONTRACT_WORK_RATIO"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "RATE", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Part du temps plein prévue par le contrat sur la période ; 1 représente un temps plein.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "UNIT", "draft": false, "label": "Contrats commerciaux éligibles", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "ELIGIBLE_CONTRACTS_COUNT"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "INTEGER", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre de contrats commerciaux validés et éligibles à rémunération variable.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "CURRENCY", "draft": false, "label": "Marge éligible à commission", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "ELIGIBLE_MARGIN_AMOUNT"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "MONEY", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Montant de marge validée servant éventuellement de base à une commission.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "CURRENCY", "draft": false, "label": "Ventes éligibles à commission", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "ELIGIBLE_SALES_AMOUNT"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "MONEY", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Montant des ventes validées et éligibles à commission sur la période.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "DAY", "draft": false, "label": "Jours calendaires sous contrat", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "EMPLOYED_CALENDAR_DAYS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "INTEGER", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre de jours calendaires pendant lesquels le contrat était en vigueur sur la période.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["INTEGRATION", "SYSTEM"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "DAY", "draft": false, "label": "Jours prévus sous contrat", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "EMPLOYED_SCHEDULED_DAYS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "INTEGER", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre de jours de travail prévus pendant lesquels le contrat était en vigueur.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["INTEGRATION", "SYSTEM"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "DAY", "draft": false, "label": "Jours de mission sur le terrain", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "FIELD_ASSIGNMENT_DAYS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "INTEGER", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre de jours reconnus comme mission sur le terrain.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "HOUR", "draft": false, "label": "Heures normales de jour férié", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "HOLIDAY_HOURS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "QUANTITY", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre d'heures de travail non supplémentaires effectuées un jour férié sur la période. Les majorations éventuelles sont déterminées par les règles de rémunération.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["IMPORT", "MANUAL", "INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "UNIT", "draft": false, "label": "Score de performance validé", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "INTEGRATION_SCORE"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "INTEGER", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Score final validé pour un dispositif de performance identifié.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "RATIO", "draft": false, "label": "Taux d'atteinte de l'indicateur", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "KPI_ACHIEVEMENT_RATIO"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "RATE", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Rapport validé entre résultat et cible de l'indicateur identifié ; 1 signifie 100 %.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["INTEGRATION", "SYSTEM"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "UNIT", "draft": false, "label": "Résultat de l'indicateur de performance", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "KPI_ACTUAL"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "INTEGER", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Valeur réalisée et validée de l'indicateur identifié pour la période.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "UNIT", "draft": false, "label": "Cible de l'indicateur de performance", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "KPI_TARGET"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "INTEGER", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Valeur cible de l'indicateur identifié pour la période.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "RATIO", "draft": false, "label": "Pondération de l'indicateur", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "KPI_WEIGHT"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "RATE", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Poids attribué à l'indicateur identifié dans le calcul de la performance.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "HOUR", "draft": false, "label": "Absence à examiner manuellement", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "MANUAL_REVIEW_ABSENCE_HOURS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "QUANTITY", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Heures d'absence dont le traitement de rémunération nécessite une décision humaine.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["IMPORT", "MANUAL", "INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "DAY", "draft": false, "label": "Jours éligibles à l'indemnité de repas", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "MEAL_ELIGIBLE_DAYS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "INTEGER", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre de jours remplissant les conditions de l'indemnité de repas.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "HOUR", "draft": false, "label": "Heures normales de nuit et jour férié", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "NIGHT_HOLIDAY_HOURS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "QUANTITY", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre d'heures de travail non supplémentaires qualifiées comme nuit et jour férié sur la période. Les majorations éventuelles sont déterminées par les règles de rémunération.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["IMPORT", "MANUAL", "INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "HOUR", "draft": false, "label": "Heures normales de nuit", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "NIGHT_HOURS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "QUANTITY", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre d'heures de travail non supplémentaires effectuées de nuit sur la période. Les majorations éventuelles sont déterminées par les règles de rémunération.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["IMPORT", "MANUAL", "INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "UNIT", "draft": false, "label": "Postes de nuit", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "NIGHT_SHIFTS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "INTEGER", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre de postes de nuit réalisés et reconnus.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "HOUR", "draft": false, "label": "Heures normales de nuit, dimanche et jour férié", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "NIGHT_SUNDAY_HOLIDAY_HOURS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "QUANTITY", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre d'heures de travail non supplémentaires qualifiées comme nuit, dimanche et jour férié sur la période. Les majorations éventuelles sont déterminées par les règles de rémunération.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["IMPORT", "MANUAL", "INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "HOUR", "draft": false, "label": "Heures normales de nuit et dimanche", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "NIGHT_SUNDAY_HOURS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "QUANTITY", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre d'heures de travail non supplémentaires qualifiées comme nuit et dimanche sur la période. Les majorations éventuelles sont déterminées par les règles de rémunération.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["IMPORT", "MANUAL", "INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "HOUR", "draft": false, "label": "Heures normales de nuit, week-end et jour férié", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "NIGHT_WEEKEND_HOLIDAY_HOURS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "QUANTITY", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre d'heures de travail non supplémentaires qualifiées comme nuit, week-end et jour férié sur la période. Les majorations éventuelles sont déterminées par les règles de rémunération.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["IMPORT", "MANUAL", "INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "HOUR", "draft": false, "label": "Heures normales de nuit et week-end", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "NIGHT_WEEKEND_HOURS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "QUANTITY", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre d'heures de travail non supplémentaires qualifiées comme nuit et week-end sur la période. Les majorations éventuelles sont déterminées par les règles de rémunération.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["IMPORT", "MANUAL", "INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "HOUR", "draft": false, "label": "Heures normales de nuit, week-end, dimanche et jour férié", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "NIGHT_WEEKEND_SUNDAY_HOLIDAY_HOURS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "QUANTITY", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre d'heures de travail non supplémentaires qualifiées comme nuit, week-end, dimanche et jour férié sur la période. Les majorations éventuelles sont déterminées par les règles de rémunération.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["IMPORT", "MANUAL", "INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "HOUR", "draft": false, "label": "Heures normales de nuit, week-end et dimanche", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "NIGHT_WEEKEND_SUNDAY_HOURS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "QUANTITY", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre d'heures de travail non supplémentaires qualifiées comme nuit, week-end et dimanche sur la période. Les majorations éventuelles sont déterminées par les règles de rémunération.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["IMPORT", "MANUAL", "INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "HOUR", "draft": false, "label": "Heures normales théoriques", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "NORMAL_HOURS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "QUANTITY", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre d'heures normalement prévues pour l'employé sur la période, avant prise en compte des absences.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["IMPORT", "MANUAL", "INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "DAY", "draft": false, "label": "Jours d'astreinte", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "ON_CALL_DAYS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "INTEGER", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre de jours d'astreinte reconnus sur la période.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "HOUR", "draft": false, "label": "Heures d'astreinte", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "ON_CALL_HOURS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "QUANTITY", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Heures d'astreinte hors interventions comptées séparément.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["IMPORT", "MANUAL", "INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "UNIT", "draft": false, "label": "Interventions pendant astreinte", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "ON_CALL_INTERVENTIONS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "INTEGER", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre d'interventions réalisées pendant une astreinte.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "UNIT", "draft": false, "label": "Nuitées professionnelles", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "OVERNIGHT_STAYS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "INTEGER", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre de nuitées professionnelles éligibles à une indemnité.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "HOUR", "draft": false, "label": "Heures supplémentaires de jour férié", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "OVERTIME_HOLIDAY_HOURS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "QUANTITY", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre d'heures supplémentaires effectuées un jour férié sur la période. Les majorations applicables sont déterminées par les règles de rémunération.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["IMPORT", "MANUAL", "INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "HOUR", "draft": false, "label": "Heures supplémentaires", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "OVERTIME_HOURS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "QUANTITY", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre d'heures supplémentaires toutes catégories confondues sur la période. Les majorations applicables sont déterminées par les règles de rémunération.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["IMPORT", "MANUAL", "INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "HOUR", "draft": false, "label": "Heures supplémentaires de nuit et jour férié", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "OVERTIME_NIGHT_HOLIDAY_HOURS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "QUANTITY", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre d'heures supplémentaires effectuées de nuit un jour férié sur la période. Les majorations applicables sont déterminées par les règles de rémunération.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["IMPORT", "MANUAL", "INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "HOUR", "draft": false, "label": "Heures supplémentaires de nuit", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "OVERTIME_NIGHT_HOURS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "QUANTITY", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre d'heures supplémentaires effectuées de nuit sur la période. Les majorations applicables sont déterminées par les règles de rémunération.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["IMPORT", "MANUAL", "INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "HOUR", "draft": false, "label": "Heures supplémentaires de nuit, dimanche et jour férié", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "OVERTIME_NIGHT_SUNDAY_HOLIDAY_HOURS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "QUANTITY", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre d'heures supplémentaires qualifiées comme nuit, dimanche et jour férié sur la période. Les majorations applicables sont déterminées par les règles de rémunération.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["IMPORT", "MANUAL", "INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "HOUR", "draft": false, "label": "Heures supplémentaires de nuit et dimanche", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "OVERTIME_NIGHT_SUNDAY_HOURS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "QUANTITY", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre d'heures supplémentaires effectuées de nuit un dimanche sur la période. Les majorations applicables sont déterminées par les règles de rémunération.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["IMPORT", "MANUAL", "INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "HOUR", "draft": false, "label": "Heures supplémentaires de nuit, week-end et jour férié", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "OVERTIME_NIGHT_WEEKEND_HOLIDAY_HOURS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "QUANTITY", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre d'heures supplémentaires qualifiées comme nuit, week-end et jour férié sur la période. Les majorations applicables sont déterminées par les règles de rémunération.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["IMPORT", "MANUAL", "INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "HOUR", "draft": false, "label": "Heures supplémentaires de nuit et week-end", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "OVERTIME_NIGHT_WEEKEND_HOURS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "QUANTITY", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre d'heures supplémentaires effectuées de nuit pendant le week-end sur la période. Les majorations applicables sont déterminées par les règles de rémunération.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["IMPORT", "MANUAL", "INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "HOUR", "draft": false, "label": "Heures supplémentaires de nuit, week-end, dimanche et jour férié", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "OVERTIME_NIGHT_WEEKEND_SUNDAY_HOLIDAY_HOURS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "QUANTITY", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre d'heures supplémentaires qualifiées comme nuit, week-end, dimanche et jour férié sur la période. Les majorations applicables sont déterminées par les règles de rémunération.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["IMPORT", "MANUAL", "INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "HOUR", "draft": false, "label": "Heures supplémentaires de nuit, week-end et dimanche", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "OVERTIME_NIGHT_WEEKEND_SUNDAY_HOURS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "QUANTITY", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre d'heures supplémentaires qualifiées comme nuit, week-end et dimanche sur la période. Les majorations applicables sont déterminées par les règles de rémunération.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["IMPORT", "MANUAL", "INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "HOUR", "draft": false, "label": "Heures supplémentaires du dimanche et jour férié", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "OVERTIME_SUNDAY_HOLIDAY_HOURS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "QUANTITY", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre d'heures supplémentaires qualifiées à la fois comme dimanche et jour férié sur la période. Les majorations applicables sont déterminées par les règles de rémunération.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["IMPORT", "MANUAL", "INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "HOUR", "draft": false, "label": "Heures supplémentaires du dimanche", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "OVERTIME_SUNDAY_HOURS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "QUANTITY", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre d'heures supplémentaires effectuées un dimanche sur la période. Les majorations applicables sont déterminées par les règles de rémunération.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["IMPORT", "MANUAL", "INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "HOUR", "draft": false, "label": "Heures supplémentaires de week-end et jour férié", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "OVERTIME_WEEKEND_HOLIDAY_HOURS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "QUANTITY", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre d'heures supplémentaires qualifiées à la fois comme week-end et jour férié sur la période. Les majorations applicables sont déterminées par les règles de rémunération.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["IMPORT", "MANUAL", "INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "HOUR", "draft": false, "label": "Heures supplémentaires de week-end", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "OVERTIME_WEEKEND_HOURS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "QUANTITY", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre d'heures supplémentaires effectuées pendant le week-end sur la période. Les majorations applicables sont déterminées par les règles de rémunération.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["IMPORT", "MANUAL", "INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "HOUR", "draft": false, "label": "Heures supplémentaires de week-end, dimanche et jour férié", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "OVERTIME_WEEKEND_SUNDAY_HOLIDAY_HOURS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "QUANTITY", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre d'heures supplémentaires qualifiées comme week-end, dimanche et jour férié sur la période. Les majorations applicables sont déterminées par les règles de rémunération.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["IMPORT", "MANUAL", "INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "HOUR", "draft": false, "label": "Heures supplémentaires de week-end et dimanche", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "OVERTIME_WEEKEND_SUNDAY_HOURS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "QUANTITY", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre d'heures supplémentaires qualifiées à la fois comme week-end et dimanche sur la période. Les majorations applicables sont déterminées par les règles de rémunération.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["IMPORT", "MANUAL", "INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "DAY", "draft": false, "label": "Jours d'absence rémunérée", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "PAID_ABSENCE_DAYS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "INTEGER", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre de jours d'absence pour lesquels une rémunération est maintenue.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "DAY", "draft": false, "label": "Jours de congé payé", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "PAID_LEAVE_DAYS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "INTEGER", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre de jours de congé payé pris pendant la période.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "HOUR", "draft": false, "label": "Heures de congé payé", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "PAID_LEAVE_HOURS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "QUANTITY", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Volume d'heures d'absence correspondant à des congés payés.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["IMPORT", "MANUAL", "INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "HOUR", "draft": false, "label": "Absence rémunérée sans impact paie", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "PAID_NO_PAYROLL_IMPACT_ABSENCE_HOURS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "QUANTITY", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Heures d'absence rémunérées qualifiées par la gestion du temps comme sans impact sur la paie.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["IMPORT", "MANUAL", "INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "HOUR", "draft": false, "label": "Absence rémunérée avec marqueur paie", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "PAID_WITH_PAYROLL_MARKER_ABSENCE_HOURS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "QUANTITY", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Heures d'absence rémunérées nécessitant une présentation ou un traitement explicite sur la paie.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["IMPORT", "MANUAL", "INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "HOUR", "draft": false, "label": "Absence partiellement rémunérée", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "PARTIALLY_PAID_ABSENCE_HOURS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "QUANTITY", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Heures d'absence dont la rémunération n'est maintenue qu'en partie.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["IMPORT", "MANUAL", "INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "DAY", "draft": false, "label": "Jours rémunérables", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "PAYABLE_DAYS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "INTEGER", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre de jours retenus pour le paiement après application des règles de présence et de proratisation.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["SYSTEM"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "HOUR", "draft": false, "label": "Absence ayant un impact sur la paie", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "PAYROLL_IMPACT_ABSENCE_HOURS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "QUANTITY", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Heures d'absence qualifiées comme ayant un impact sur la rémunération ou sa présentation.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["IMPORT", "MANUAL", "INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "RATIO", "draft": false, "label": "Coefficient de proratisation", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "PAY_PRORATION_RATIO"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "RATE", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Coefficient retenu pour proratiser la rémunération de la période ; 1 signifie aucune réduction.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["SYSTEM"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "DAY", "draft": false, "label": "Jours de présence reconnus", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "PRESENT_DAYS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "INTEGER", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre de jours reconnus comme jours de présence pour les règles de rémunération.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["INTEGRATION", "SYSTEM"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "UNIT", "draft": false, "label": "Unités produites", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "PRODUCED_UNITS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "INTEGER", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre d'unités produites pendant la période.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "RATIO", "draft": false, "label": "Taux d'acceptation qualité", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "QUALITY_ACCEPTANCE_RATE"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "RATE", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Part des réalisations acceptées après contrôle ; 1 signifie 100 %.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "CURRENCY", "draft": false, "label": "Ventes remboursées", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "REFUNDED_SALES_AMOUNT"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "MONEY", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Montant des ventes remboursées à prendre en compte dans l'assiette commerciale.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "UNIT", "draft": false, "label": "Unités produites rejetées", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "REJECTED_PRODUCTION_UNITS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "INTEGER", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre d'unités produites rejetées après contrôle.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "RATIO", "draft": false, "label": "Taux d'atteinte de l'objectif de ventes", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "SALES_ACHIEVEMENT_RATIO"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "RATE", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Rapport entre ventes retenues et objectif de ventes ; 1 signifie 100 %.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["INTEGRATION", "SYSTEM"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "CURRENCY", "draft": false, "label": "Objectif de ventes", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "SALES_TARGET_AMOUNT"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "MONEY", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Montant cible des ventes pour la période et le périmètre applicables.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "DAY", "draft": false, "label": "Jours de travail prévus", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "SCHEDULED_DAYS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "INTEGER", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre de jours que l'employé devait travailler selon son calendrier applicable.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "MONTH", "draft": false, "label": "Ancienneté dans la catégorie — mois", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "SENIORITY_CATEGORY_MONTHS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "INTEGER", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre de mois d'ancienneté dans la catégorie professionnelle applicable.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["IMPORT", "MANUAL", "INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "DAY", "draft": false, "label": "Ancienneté continue dans l'entreprise — jours", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "SENIORITY_CONTINUOUS_DAYS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "INTEGER", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre de jours d'ancienneté dans la relation d'emploi continue courante ; repart à zéro après une rupture.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["IMPORT", "MANUAL", "INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "MONTH", "draft": false, "label": "Ancienneté continue dans l'entreprise — mois", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "SENIORITY_CONTINUOUS_MONTHS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "INTEGER", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre de mois d'ancienneté dans la relation d'emploi continue courante ; repart à zéro après une rupture.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["IMPORT", "MANUAL", "INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "DAY", "draft": false, "label": "Ancienneté cumulée dans l'entreprise — jours", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "SENIORITY_DAYS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "INTEGER", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre de jours d'ancienneté cumulée dans l'entreprise, selon les règles de prise en compte des périodes de service et des suspensions.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["IMPORT", "MANUAL", "INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "MONTH", "draft": false, "label": "Ancienneté dans le grade — mois", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "SENIORITY_GRADE_MONTHS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "INTEGER", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre de mois d'ancienneté dans le grade applicable.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["IMPORT", "MANUAL", "INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "MONTH", "draft": false, "label": "Ancienneté cumulée dans l'entreprise — mois", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "SENIORITY_MONTHS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "INTEGER", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre de mois d'ancienneté cumulée dans l'entreprise, selon les règles de prise en compte des périodes de service et des suspensions.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["IMPORT", "MANUAL", "INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "MONTH", "draft": false, "label": "Ancienneté dans le poste — mois", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "SENIORITY_POSITION_MONTHS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "INTEGER", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre de mois d'ancienneté dans le poste applicable.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["IMPORT", "MANUAL", "INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "MONTH", "draft": false, "label": "Ancienneté sur le site — mois", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "SENIORITY_SITE_MONTHS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "INTEGER", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre de mois d'ancienneté sur le site d'affectation applicable.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["IMPORT", "MANUAL", "INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "MONTH", "draft": false, "label": "Ancienneté dans l'intitulé de fonction — mois", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "SENIORITY_TITLE_MONTHS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "INTEGER", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre de mois d'ancienneté dans l'intitulé de fonction applicable.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["IMPORT", "MANUAL", "INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "MONTH", "draft": false, "label": "Ancienneté dans l'unité — mois", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "SENIORITY_UNIT_MONTHS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "INTEGER", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre de mois d'ancienneté dans l'unité organisationnelle applicable.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["IMPORT", "MANUAL", "INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "YEAR", "draft": false, "label": "Ancienneté cumulée dans l'entreprise — années", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "SENIORITY_YEARS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "INTEGER", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre d'années révolues d'ancienneté cumulée dans l'entreprise.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["IMPORT", "MANUAL", "INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "DAY", "draft": false, "label": "Jours d'arrêt maladie", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "SICK_LEAVE_DAYS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "INTEGER", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre de jours d'absence liés à un arrêt maladie reconnu.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "HOUR", "draft": false, "label": "Heures d'arrêt maladie", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "SICK_LEAVE_HOURS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "QUANTITY", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Volume d'heures d'absence liées à un arrêt maladie.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["IMPORT", "MANUAL", "INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "HOUR", "draft": false, "label": "Heures normales du dimanche et jour férié", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "SUNDAY_HOLIDAY_HOURS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "QUANTITY", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre d'heures de travail non supplémentaires qualifiées comme dimanche et jour férié sur la période. Les majorations éventuelles sont déterminées par les règles de rémunération.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["IMPORT", "MANUAL", "INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "HOUR", "draft": false, "label": "Heures normales du dimanche", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "SUNDAY_HOURS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "QUANTITY", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre d'heures de travail non supplémentaires effectuées un dimanche sur la période. Les majorations éventuelles sont déterminées par les règles de rémunération.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["IMPORT", "MANUAL", "INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "DAY", "draft": false, "label": "Jours éligibles à l'indemnité de transport", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "TRANSPORT_ELIGIBLE_DAYS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "INTEGER", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre de jours remplissant les conditions de l'indemnité de transport.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "DAY", "draft": false, "label": "Jours de déplacement professionnel", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "TRAVEL_DAYS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "INTEGER", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre de jours de déplacement professionnel reconnus.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "DAY", "draft": false, "label": "Jours de déplacement éligibles", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "TRAVEL_ELIGIBLE_DAYS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "INTEGER", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Jours de déplacement validés pour une indemnité.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["IMPORT", "MANUAL", "INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "HOUR", "draft": false, "label": "Heures d'absence non autorisée", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "UNAUTHORIZED_ABSENCE_HOURS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "QUANTITY", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Volume d'heures d'absence non autorisées.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["IMPORT", "MANUAL", "INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "DAY", "draft": false, "label": "Jours d'absence non rémunérée", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "UNPAID_ABSENCE_DAYS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "INTEGER", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre de jours d'absence sans maintien de rémunération.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "HOUR", "draft": false, "label": "Absence autorisée non rémunérée", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "UNPAID_AUTHORIZED_ABSENCE_HOURS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "QUANTITY", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Heures d'absence autorisées ne conservant pas de rémunération.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["IMPORT", "MANUAL", "INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "HOUR", "draft": false, "label": "Absence non rémunérée déjà déduite", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "UNPAID_DEDUCTED_ABSENCE_HOURS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "QUANTITY", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Heures d'absence non rémunérées pour lesquelles une déduction a déjà été prise en compte en amont.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["IMPORT", "MANUAL", "INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "DAY", "draft": false, "label": "Jours de congé sans solde", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "UNPAID_LEAVE_DAYS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "INTEGER", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre de jours de congé sans solde pris pendant la période.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "HOUR", "draft": false, "label": "Heures de congé sans solde", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "UNPAID_LEAVE_HOURS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "QUANTITY", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Volume d'heures d'absence correspondant à des congés sans solde.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["IMPORT", "MANUAL", "INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "HOUR", "draft": false, "label": "Heures normales de week-end et jour férié", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "WEEKEND_HOLIDAY_HOURS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "QUANTITY", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre d'heures de travail non supplémentaires qualifiées comme week-end et jour férié sur la période. Les majorations éventuelles sont déterminées par les règles de rémunération.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["IMPORT", "MANUAL", "INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "HOUR", "draft": false, "label": "Heures normales de week-end", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "WEEKEND_HOURS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "QUANTITY", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre d'heures de travail non supplémentaires effectuées pendant le week-end sur la période. Les majorations éventuelles sont déterminées par les règles de rémunération.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["IMPORT", "MANUAL", "INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "HOUR", "draft": false, "label": "Heures normales de week-end, dimanche et jour férié", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "WEEKEND_SUNDAY_HOLIDAY_HOURS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "QUANTITY", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre d'heures de travail non supplémentaires qualifiées comme week-end, dimanche et jour férié sur la période. Les majorations éventuelles sont déterminées par les règles de rémunération.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["IMPORT", "MANUAL", "INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "HOUR", "draft": false, "label": "Heures normales de week-end et dimanche", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "WEEKEND_SUNDAY_HOURS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "QUANTITY", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre d'heures de travail non supplémentaires qualifiées comme week-end et dimanche sur la période. Les majorations éventuelles sont déterminées par les règles de rémunération.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["IMPORT", "MANUAL", "INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "DAY", "draft": false, "label": "Jours effectivement travaillés", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "WORKED_DAYS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "INTEGER", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre de jours pendant lesquels un travail effectif a été constaté.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "DAY", "draft": false, "label": "Correction de jours travaillés", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "WORKED_DAYS_CORRECTION"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "INTEGER", "constraint": {"max": null, "min": null, "none": true, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Différence signée de jours travaillés reconnue pour une période antérieure.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["INTEGRATION", "SYSTEM"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "HOUR", "draft": false, "label": "Absence assimilée à du temps travaillé", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "WORKED_EQUIVALENT_ABSENCE_HOURS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "QUANTITY", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Heures d'absence reconnues comme équivalentes à des heures travaillées pour certains calculs.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["IMPORT", "MANUAL", "INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "DAY", "draft": false, "label": "Jours assimilés à du travail", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "WORKED_EQUIVALENT_DAYS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "INTEGER", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre de jours non travaillés mais assimilés à du travail pour certaines règles de rémunération.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["INTEGRATION", "SYSTEM"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "HOUR", "draft": false, "label": "Heures effectivement travaillées", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "WORKED_HOURS"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "QUANTITY", "constraint": {"max": null, "min": 0.000000000000, "none": false, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Nombre d'heures de travail effectivement réalisées sur la période, hors heures supplémentaires si celles-ci sont collectées séparément.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["IMPORT", "MANUAL", "INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}, {"entry": {"unit": "HOUR", "draft": false, "label": "Correction d'heures travaillées", "active": true, "common": true, "status": "ACTIVE", "binding": "PERIODIC", "validTo": null, "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "createdAt": "2026-10-01T08:13:19.749433Z", "inputCode": {"code": {"value": "WORKED_HOURS_CORRECTION"}, "countryCode": {"value": "CM"}}, "lifecycle": {"draft": false, "active": true, "status": "ACTIVE", "validity": {"to": null, "from": "2026-10-01", "openEnded": true}, "deactivated": false}, "updatedAt": "2026-10-01T08:13:19.749433Z", "validFrom": "2026-10-01", "valueType": "QUANTITY", "constraint": {"max": null, "min": null, "none": true, "allowedValues": []}, "countryCode": {"value": "CM"}, "deactivated": false, "presentation": {"icon": null, "color": null, "description": "Différence signée d'heures reconnues pour une période antérieure.", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "allowedSources": ["SYSTEM", "MANUAL", "INTEGRATION"], "catalogVersion": {"value": 1}, "parameterizable": false}, "change": "CREATED"}], "elements": [{"entry": {"code": "BASE_SALARY", "type": "BASE_SALARY", "label": "Salaire de base", "active": true, "validTo": null, "validFrom": "2026-10-01", "catalogVersion": 1, "compensationCode": {"number": {"value": "101"}, "countryCode": {"value": "CM"}, "inCommonRange": true}, "prorationCategory": "TIME_BASED", "absenceSensitivity": "SENSITIVE"}, "change": "CREATED"}, {"entry": {"code": "OVERTIME", "type": "OVERTIME", "label": "Heures supplémentaires", "active": true, "validTo": null, "validFrom": "2026-10-01", "catalogVersion": 1, "compensationCode": {"number": {"value": "201"}, "countryCode": {"value": "CM"}, "inCommonRange": true}, "prorationCategory": "QUANTITY_BASED", "absenceSensitivity": "NOT_SENSITIVE"}, "change": "CREATED"}, {"entry": {"code": "NIGHT_WORK_PREMIUM", "type": "PREMIUM", "label": "Majoration pour travail de nuit", "active": true, "validTo": null, "validFrom": "2026-10-01", "catalogVersion": 1, "compensationCode": {"number": {"value": "202"}, "countryCode": {"value": "CM"}, "inCommonRange": true}, "prorationCategory": "QUANTITY_BASED", "absenceSensitivity": "NOT_SENSITIVE"}, "change": "CREATED"}, {"entry": {"code": "HS20", "type": "OVERTIME", "label": "Heures supps. 20%", "active": true, "validTo": null, "validFrom": "2026-10-01", "catalogVersion": 1, "compensationCode": {"number": {"value": "250"}, "countryCode": {"value": "CM"}, "inCommonRange": false}, "prorationCategory": "NOT_APPLICABLE", "absenceSensitivity": "NOT_SENSITIVE"}, "change": "CREATED"}, {"entry": {"code": "SENIORITY_BONUS", "type": "PREMIUM", "label": "Prime d'ancienneté", "active": true, "validTo": null, "validFrom": "2026-10-01", "catalogVersion": 1, "compensationCode": {"number": {"value": "301"}, "countryCode": {"value": "CM"}, "inCommonRange": true}, "prorationCategory": "TIME_BASED", "absenceSensitivity": "RULE_DRIVEN"}, "change": "CREATED"}, {"entry": {"code": "PERFORMANCE_BONUS", "type": "BONUS", "label": "Prime de performance", "active": true, "validTo": null, "validFrom": "2026-10-01", "catalogVersion": 1, "compensationCode": {"number": {"value": "302"}, "countryCode": {"value": "CM"}, "inCommonRange": true}, "prorationCategory": "NOT_APPLICABLE", "absenceSensitivity": "RULE_DRIVEN"}, "change": "CREATED"}, {"entry": {"code": "THIRTEENTH_MONTH", "type": "BONUS", "label": "Treizième mois", "active": true, "validTo": null, "validFrom": "2026-10-01", "catalogVersion": 1, "compensationCode": {"number": {"value": "303"}, "countryCode": {"value": "CM"}, "inCommonRange": true}, "prorationCategory": "TIME_BASED", "absenceSensitivity": "RULE_DRIVEN"}, "change": "CREATED"}, {"entry": {"code": "EXCEPTIONAL_BONUS", "type": "BONUS", "label": "Prime exceptionnelle", "active": true, "validTo": null, "validFrom": "2026-10-01", "catalogVersion": 1, "compensationCode": {"number": {"value": "304"}, "countryCode": {"value": "CM"}, "inCommonRange": true}, "prorationCategory": "NOT_APPLICABLE", "absenceSensitivity": "NOT_SENSITIVE"}, "change": "CREATED"}, {"entry": {"code": "SALES_COMMISSION", "type": "COMMISSION", "label": "Commission sur ventes", "active": true, "validTo": null, "validFrom": "2026-10-01", "catalogVersion": 1, "compensationCode": {"number": {"value": "401"}, "countryCode": {"value": "CM"}, "inCommonRange": true}, "prorationCategory": "QUANTITY_BASED", "absenceSensitivity": "NOT_SENSITIVE"}, "change": "CREATED"}, {"entry": {"code": "TRANSPORT_ALLOWANCE", "type": "ALLOWANCE", "label": "Indemnité de transport", "active": true, "validTo": null, "validFrom": "2026-10-01", "catalogVersion": 1, "compensationCode": {"number": {"value": "501"}, "countryCode": {"value": "CM"}, "inCommonRange": true}, "prorationCategory": "TIME_BASED", "absenceSensitivity": "SENSITIVE"}, "change": "CREATED"}, {"entry": {"code": "HOUSING_ALLOWANCE", "type": "ALLOWANCE", "label": "Indemnité de logement", "active": true, "validTo": null, "validFrom": "2026-10-01", "catalogVersion": 1, "compensationCode": {"number": {"value": "502"}, "countryCode": {"value": "CM"}, "inCommonRange": true}, "prorationCategory": "TIME_BASED", "absenceSensitivity": "RULE_DRIVEN"}, "change": "CREATED"}, {"entry": {"code": "MEAL_ALLOWANCE", "type": "ALLOWANCE", "label": "Indemnité de repas", "active": true, "validTo": null, "validFrom": "2026-10-01", "catalogVersion": 1, "compensationCode": {"number": {"value": "503"}, "countryCode": {"value": "CM"}, "inCommonRange": true}, "prorationCategory": "QUANTITY_BASED", "absenceSensitivity": "NOT_SENSITIVE"}, "change": "CREATED"}, {"entry": {"code": "ON_CALL_ALLOWANCE", "type": "ALLOWANCE", "label": "Indemnité d'astreinte", "active": true, "validTo": null, "validFrom": "2026-10-01", "catalogVersion": 1, "compensationCode": {"number": {"value": "504"}, "countryCode": {"value": "CM"}, "inCommonRange": true}, "prorationCategory": "QUANTITY_BASED", "absenceSensitivity": "NOT_SENSITIVE"}, "change": "CREATED"}], "countryCode": "CM", "publishedAt": "2026-10-01T10:42:57.469539135Z", "catalogVersion": 1, "benefitAssetKinds": [{"entry": {"code": "CAR", "label": "Car", "number": "650", "status": "ACTIVE", "validTo": null, "createdAt": "2026-10-01T10:27:32.370245Z", "updatedAt": "2026-10-01T10:29:33.029031Z", "validFrom": "2026-10-01", "countryCode": "CM", "presentation": {"icon": null, "color": null, "description": "N'importe quelle vehicule", "legalReference": null, "localizedLabels": {}, "localizedDescriptions": {}}, "catalogVersion": 1, "allowedFrequencies": ["MONTHLY"]}, "change": "CREATED"}]}, "metadata": {"actor": "UserId[value=1234567890]", "client": null, "device": "device-id", "locale": "en", "actor_type": "user", "request_id": "36f7f6f9-dc1b-41b5-b460-38d931273bb6", "actor_realm": "master", "device_info": {"proxy": [], "location": {}, "ipAddress": "0.0.0.0", "userAgent": "unknown", "appVersion": "unknown", "deviceName": "unknown"}, "actor_session": null}, "timestamp": "2026-10-01T10:42:57.509342355Z", "application": "compensation"}
2	d8c9827d-2e64-400f-aa74-1ca3ca445196	compensation.catalog.published	2026-10-01 11:53:31.528996+00	\N	CM	{"id": "d8c9827d-2e64-400f-aa74-1ca3ca445196", "name": "compensation.catalog.published", "realm": "master", "details": {"inputs": [], "elements": [], "countryCode": "CM", "publishedAt": "2026-10-01T11:53:31.510195211Z", "catalogVersion": 2, "benefitAssetKinds": []}, "metadata": {"actor": "UserId[value=1234567890]", "client": null, "device": "device-id", "locale": "en", "actor_type": "user", "request_id": "b6181d54-8280-4add-bae5-7d50eb08b453", "actor_realm": "master", "device_info": {"proxy": [], "location": {}, "ipAddress": "0.0.0.0", "userAgent": "unknown", "appVersion": "unknown", "deviceName": "unknown"}, "actor_session": null}, "timestamp": "2026-10-01T11:53:31.527877935Z", "application": "compensation"}
\.


--
-- Data for Name: compensation_packages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.compensation_packages (id, company_id, legal_entity_id, country_code, currency, code, label, package_version, remunerations, benefits, inputs, valid_from, valid_to, status, created_at, updated_at, revision) FROM stdin;
61542bde-39a0-43bd-b5fa-05f154d7e8d8	96101814-b255-4348-bb24-d5a963439148	9ae734b6-ae8f-4f87-a103-44ba78f70d04	CM	XAF	MACON	Macons Qualifiés	1	[{"max": 300000, "min": 200000, "mode": "DEFAULT", "value": {"rounding": null, "execution": "COMPENSATION", "calculation": {"method": "FIXED", "execution": "COMPENSATION", "calculationJson": {"base": null, "grid": null, "rate": null, "amount": 200000, "formula": null, "currency": "XAF", "rounding": null, "hourlyBase": null}}}, "number": "101", "frequency": "MONTHLY", "mandatory": true}, {"max": 40000, "min": 10000, "mode": "INDIVIDUAL", "value": null, "number": "201", "frequency": "MONTHLY", "mandatory": true}]	[{"number": "650", "frequency": "MONTHLY", "mandatory": true}]	[]	2026-10-01	2026-10-01	SUPERSEDED	2026-10-01 07:55:58.615348+00	2026-10-01 11:02:31.406833+00	5
7e583367-3346-4e31-8543-f6f4238bb9a0	96101814-b255-4348-bb24-d5a963439148	9ae734b6-ae8f-4f87-a103-44ba78f70d04	CM	XAF	MACON	Macons Qualifiés	2	[{"max": 300000, "min": 200000, "mode": "DEFAULT", "value": {"rounding": null, "execution": "COMPENSATION", "calculation": {"method": "FIXED", "execution": "COMPENSATION", "calculationJson": {"base": null, "grid": null, "rate": null, "amount": 200000, "formula": null, "currency": "XAF", "rounding": null, "hourlyBase": null}}}, "number": "101", "frequency": "MONTHLY", "mandatory": true}]	[{"number": "650", "frequency": "MONTHLY", "mandatory": true}]	[]	2026-10-02	\N	PUBLISHED	2026-10-01 10:59:02.340994+00	2026-10-01 11:02:31.406833+00	2
\.


--
-- Data for Name: compensation_requirement; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.compensation_requirement (id, company_id, legal_entity_id, employee_id, policy_id, policy_code, policy_version, priority, country_code, number, frequency, currency, value, override_strategy, assignment_mode, approval_required, contract_amendment_required, employee_acceptance_required, occurrence_start, occurrence_end, due_start, due_end, status, satisfied_by, replaced_remunerations, note, decided_by, created_at, updated_at, revision) FROM stdin;
968b1381-a51f-3d6b-945b-192e4e1b9586	96101814-b255-4348-bb24-d5a963439148	9ae734b6-ae8f-4f87-a103-44ba78f70d04	be359e18-b877-4ef8-b3b4-af1450ce2f14	27c0cd99-30b7-4d23-8231-1d4bfc918d05	PRIME_EXCEPT	1	2	CM	302	MONTHLY	XAF	{"rounding": null, "execution": "COMPENSATION", "calculation": {"method": "FIXED", "execution": "COMPENSATION", "calculationJson": {"base": null, "grid": null, "rate": null, "amount": 20000, "formula": null, "currency": "XAF", "rounding": null, "hourlyBase": null}}}	ADD	HR_DECISION	f	f	f	2026-10-01	2026-10-31	2026-10-01	2026-10-31	FULFILLED	c101459b-3a61-3323-ba26-3a258b9ca618	{}	\N	1234567890	2026-10-01 13:55:02.617913+00	2026-10-01 14:34:46.602593+00	1
f425463f-d658-3ca8-bd09-8aeabbeb0d54	96101814-b255-4348-bb24-d5a963439148	9ae734b6-ae8f-4f87-a103-44ba78f70d04	2c99dcac-8793-4032-a34b-af88f7cc12a1	27c0cd99-30b7-4d23-8231-1d4bfc918d05	PRIME_EXCEPT	1	2	CM	302	MONTHLY	XAF	{"rounding": null, "execution": "COMPENSATION", "calculation": {"method": "FIXED", "execution": "COMPENSATION", "calculationJson": {"base": null, "grid": null, "rate": null, "amount": 20000, "formula": null, "currency": "XAF", "rounding": null, "hourlyBase": null}}}	ADD	HR_DECISION	f	f	f	2026-10-01	2026-10-31	2026-10-01	2026-10-31	FULFILLED	2cb17e34-5265-3391-9e3c-02aa35da7035	{}	\N	1234567890	2026-10-01 13:55:02.503875+00	2026-10-02 10:41:15.670284+00	9
2b60c0d4-610d-318c-8bb2-664707be0a35	96101814-b255-4348-bb24-d5a963439148	9ae734b6-ae8f-4f87-a103-44ba78f70d04	c3e1cf30-c450-49ed-9b31-dc6408516405	27c0cd99-30b7-4d23-8231-1d4bfc918d05	PRIME_EXCEPT	1	2	CM	302	MONTHLY	XAF	{"rounding": null, "execution": "COMPENSATION", "calculation": {"method": "FIXED", "execution": "COMPENSATION", "calculationJson": {"base": null, "grid": null, "rate": null, "amount": 24000, "formula": null, "currency": "XAF", "rounding": null, "hourlyBase": null}}}	ADD	HR_DECISION	f	f	f	2026-10-01	2026-10-31	2026-10-01	2026-10-31	FULFILLED	7d376f1b-5cca-329e-917f-a206730643a7	{}	\N	1234567890	2026-10-02 12:27:15.024388+00	2026-10-02 12:27:41.026194+00	1
\.


--
-- Data for Name: eligibility_policy; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.eligibility_policy (id, company_id, legal_entity_id, country_code, currency, code, label, policy_version, population, remunerations, frequency, anchor, assignment_mode, approval_required, contract_amendment_required, employee_acceptance_required, priority, valid_from, valid_to, status, created_at, updated_at, revision) FROM stdin;
27c0cd99-30b7-4d23-8231-1d4bfc918d05	96101814-b255-4348-bb24-d5a963439148	9ae734b6-ae8f-4f87-a103-44ba78f70d04	CM	XAF	PRIME_EXCEPT	Variable Bonus	1	{"sites": [], "grades": [], "positions": [], "categories": [], "companyUnits": ["direction-des-ressources-humaines", "equipe-fiscalite", "service-paie"]}	[{"value": null, "number": "302", "overrideStrategy": "ADD"}]	MONTHLY	2026-10-01	HR_DECISION	f	f	f	2	2026-10-01	\N	ACTIVE	2026-10-01 11:19:05.69157+00	2026-10-01 11:22:19.092484+00	3
\.


--
-- Data for Name: employee_benefit_assignments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employee_benefit_assignments (id, company_id, legal_entity_id, employee_id, country_code, number, description, quantity, unit, effective_from, effective_to, package_assignment_id, assignment_version, status, created_at, updated_at, revision, catalog_version, supply_mode, characteristics, cash_amount, cash_currency, cash_frequency) FROM stdin;
5c519862-df6e-4781-b6f9-84f220e64827	96101814-b255-4348-bb24-d5a963439148	9ae734b6-ae8f-4f87-a103-44ba78f70d04	2c99dcac-8793-4032-a34b-af88f7cc12a1	CM	650	Toyota Corolla LT 260 X	\N	\N	2026-10-02	\N	207b98f1-0907-4d63-b1fa-b05a3637cacc	2	ACTIVE	2026-10-01 11:08:11.947353+00	2026-10-01 11:08:11.947353+00	0	2	IN_KIND	[{"code": "PROFESSIONAL_USE", "value": {"type": "BOOLEAN", "booleanValue": true}}, {"code": "PRIVATE_USE", "value": {"type": "BOOLEAN", "booleanValue": false}}, {"code": "FUEL_PROVIDED", "value": {"type": "BOOLEAN", "booleanValue": false}}]	\N	\N	\N
9e9e4479-bcf6-4853-925d-8ca4efa47575	96101814-b255-4348-bb24-d5a963439148	9ae734b6-ae8f-4f87-a103-44ba78f70d04	be359e18-b877-4ef8-b3b4-af1450ce2f14	CM	650	Toyota Fantasy	\N	\N	2026-10-02	\N	9be4f516-2b6c-4e95-a800-5ca486427a3f	2	ACTIVE	2026-10-02 12:18:00.238133+00	2026-10-02 12:18:00.238133+00	0	2	IN_KIND	[{"code": "PROFESSIONAL_USE", "unit": null, "value": {"date": null, "text": null, "type": "BOOLEAN", "number": null, "booleanValue": true}, "evidence": null}, {"code": "PRIVATE_USE", "unit": null, "value": {"date": null, "text": null, "type": "BOOLEAN", "number": null, "booleanValue": true}, "evidence": null}, {"code": "FUEL_PROVIDED", "unit": null, "value": {"date": null, "text": null, "type": "BOOLEAN", "number": null, "booleanValue": true}, "evidence": null}]	\N	\N	\N
\.


--
-- Data for Name: employee_compensation_suspensions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employee_compensation_suspensions (id, company_id, legal_entity_id, employee_id, country_code, number, effective_from, effective_to, reason, comment, source_reference, status, recorded_by, recorded_at, cancelled_by, cancelled_at, cancellation_reason, updated_by, updated_at, suspension_version, revision) FROM stdin;
\.


--
-- Data for Name: employee_compensations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employee_compensations (id, company_id, legal_entity_id, employee_id, country_code, number, display_label, value, calculation_method, execution, frequency, currency, effective_from, effective_to, source, source_reference, package_assignment_id, requirement_id, status, compensation_version, previous_version_id, approved_at, approved_by, created_at, updated_at, revision, award_id, payable_on) FROM stdin;
8cb21880-f59f-4cae-91ec-cf62e5decabe	96101814-b255-4348-bb24-d5a963439148	9ae734b6-ae8f-4f87-a103-44ba78f70d04	2c99dcac-8793-4032-a34b-af88f7cc12a1	CM	101	\N	{"rounding": null, "execution": "COMPENSATION", "calculation": {"method": "FIXED", "execution": "COMPENSATION", "calculationJson": {"base": null, "grid": null, "rate": null, "amount": 200000, "formula": null, "currency": "XAF", "rounding": null, "hourlyBase": null}}}	FIXED	COMPENSATION	MONTHLY	XAF	2026-10-02	\N	COMPENSATION_PACKAGE	MACON v2	207b98f1-0907-4d63-b1fa-b05a3637cacc	\N	ACTIVE	1	\N	2026-10-01 11:03:08.907948+00	1234567890	2026-10-01 11:03:08.907948+00	2026-10-01 11:03:08.907948+00	0	\N	\N
c101459b-3a61-3323-ba26-3a258b9ca618	96101814-b255-4348-bb24-d5a963439148	9ae734b6-ae8f-4f87-a103-44ba78f70d04	be359e18-b877-4ef8-b3b4-af1450ce2f14	CM	302	\N	{"rounding": null, "execution": "COMPENSATION", "calculation": {"method": "FIXED", "execution": "COMPENSATION", "calculationJson": {"base": null, "grid": null, "rate": null, "amount": 20000, "formula": null, "currency": "XAF", "rounding": null, "hourlyBase": null}}}	FIXED	COMPENSATION	MONTHLY	XAF	2026-10-01	2026-10-31	COMPANY_POLICY	PRIME_EXCEPT v1	\N	968b1381-a51f-3d6b-945b-192e4e1b9586	ACTIVE	1	\N	2026-10-01 14:34:46.602604+00	1234567890	2026-10-01 14:34:46.602604+00	2026-10-01 14:34:46.602604+00	0	\N	\N
1d336361-ff17-44df-9ffb-c501b2afb7bc	96101814-b255-4348-bb24-d5a963439148	9ae734b6-ae8f-4f87-a103-44ba78f70d04	be359e18-b877-4ef8-b3b4-af1450ce2f14	CM	101	\N	{"rounding": null, "execution": "COMPENSATION", "calculation": {"method": "FIXED", "execution": "COMPENSATION", "calculationJson": {"base": null, "grid": null, "rate": null, "amount": 240000, "formula": null, "currency": "XAF", "rounding": null, "hourlyBase": null}}}	FIXED	COMPENSATION	MONTHLY	XAF	2026-10-02	\N	COMPENSATION_PACKAGE	MACON v2	9be4f516-2b6c-4e95-a800-5ca486427a3f	\N	ACTIVE	1	\N	2026-10-01 21:50:55.01083+00	1234567890	2026-10-01 21:50:55.01083+00	2026-10-01 21:50:55.01083+00	0	\N	\N
2cb17e34-5265-3391-9e3c-02aa35da7035	96101814-b255-4348-bb24-d5a963439148	9ae734b6-ae8f-4f87-a103-44ba78f70d04	2c99dcac-8793-4032-a34b-af88f7cc12a1	CM	302	\N	{"rounding": null, "execution": "COMPENSATION", "calculation": {"method": "FIXED", "execution": "COMPENSATION", "calculationJson": {"base": null, "grid": null, "rate": null, "amount": 20000, "formula": null, "currency": "XAF", "rounding": null, "hourlyBase": null}}}	FIXED	COMPENSATION	ONE_TIME	XAF	2026-10-01	2026-10-31	COMPANY_POLICY	PRIME_EXCEPT v1	\N	f425463f-d658-3ca8-bd09-8aeabbeb0d54	ACTIVE	1	\N	2026-10-02 10:41:15.670299+00	1234567890	2026-10-02 10:41:15.670299+00	2026-10-02 10:41:15.670299+00	0	\N	\N
7d376f1b-5cca-329e-917f-a206730643a7	96101814-b255-4348-bb24-d5a963439148	9ae734b6-ae8f-4f87-a103-44ba78f70d04	c3e1cf30-c450-49ed-9b31-dc6408516405	CM	302	\N	{"rounding": null, "execution": "COMPENSATION", "calculation": {"method": "FIXED", "execution": "COMPENSATION", "calculationJson": {"base": null, "grid": null, "rate": null, "amount": 24000, "formula": null, "currency": "XAF", "rounding": null, "hourlyBase": null}}}	FIXED	COMPENSATION	ONE_TIME	XAF	2026-10-01	2026-10-31	COMPANY_POLICY	PRIME_EXCEPT v1	\N	2b60c0d4-610d-318c-8bb2-664707be0a35	ACTIVE	1	\N	2026-10-02 12:27:41.026212+00	1234567890	2026-10-02 12:27:41.026212+00	2026-10-02 12:27:41.026212+00	0	\N	\N
b51915ed-3c7f-4700-a892-e62fcee38e52	96101814-b255-4348-bb24-d5a963439148	9ae734b6-ae8f-4f87-a103-44ba78f70d04	2c99dcac-8793-4032-a34b-af88f7cc12a1	CM	501	\N	{"rounding": null, "execution": "COMPENSATION", "calculation": {"method": "FIXED", "execution": "COMPENSATION", "calculationJson": {"base": null, "grid": null, "rate": null, "amount": 30000, "formula": null, "currency": "XAF", "rounding": null, "hourlyBase": null}}}	FIXED	COMPENSATION	MONTHLY	XAF	2026-10-04	\N	INDIVIDUAL_DECISION	dfdfdggdg	\N	\N	ACTIVE	1	\N	2026-10-04 10:31:40.02755+00	1234567890	2026-10-04 10:31:40.02755+00	2026-10-04 10:31:40.02755+00	0	\N	\N
\.


--
-- Data for Name: employee_incentive_assignments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employee_incentive_assignments (id, company_id, legal_entity_id, employee_id, plan_code, target_amount, target_currency, target_percentage, valid_from, valid_to, status, created_at, updated_at, revision) FROM stdin;
\.


--
-- Data for Name: employee_package_assignment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employee_package_assignment (id, company_id, legal_entity_id, employee_id, package_version_id, package_code, package_version, valid_from, valid_to, adjustments, status, successor_id, created_at, updated_at, revision) FROM stdin;
207b98f1-0907-4d63-b1fa-b05a3637cacc	96101814-b255-4348-bb24-d5a963439148	9ae734b6-ae8f-4f87-a103-44ba78f70d04	2c99dcac-8793-4032-a34b-af88f7cc12a1	7e583367-3346-4e31-8543-f6f4238bb9a0	MACON	2	2026-10-02	\N	{"inputs": [], "remunerations": [], "excludedInputs": [], "excludedBenefits": [], "excludedRemunerations": []}	ACTIVE	\N	2026-10-01 11:03:08.891075+00	2026-10-01 11:03:08.891075+00	0
9be4f516-2b6c-4e95-a800-5ca486427a3f	96101814-b255-4348-bb24-d5a963439148	9ae734b6-ae8f-4f87-a103-44ba78f70d04	be359e18-b877-4ef8-b3b4-af1450ce2f14	7e583367-3346-4e31-8543-f6f4238bb9a0	MACON	2	2026-10-02	\N	{"inputs": [], "remunerations": [{"key": {"code": "101", "country": "CM"}, "value": {"rounding": null, "execution": "COMPENSATION", "calculation": {"method": "FIXED", "execution": "COMPENSATION", "calculationJson": {"base": null, "grid": null, "rate": null, "amount": 240000, "formula": null, "currency": "XAF", "rounding": null, "hourlyBase": null}}}}], "excludedInputs": [], "excludedBenefits": [], "excludedRemunerations": []}	ACTIVE	\N	2026-10-01 21:50:54.965387+00	2026-10-01 21:50:54.965387+00	0
\.


--
-- Data for Name: employee_parameter_assignments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employee_parameter_assignments (id, company_id, legal_entity_id, employee_id, country_code, code, definition_version, value, effective_from, effective_to, package_assignment_id, assignment_version, status, created_at, updated_at, revision) FROM stdin;
\.


--
-- Data for Name: flyway_schema_history; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.flyway_schema_history (installed_rank, version, description, type, script, checksum, installed_by, installed_on, execution_time, success) FROM stdin;
1	1	catalog	SQL	V1__catalog.sql	283818753	postgres	2026-09-30 11:55:56.7064	99	t
2	2	rules	SQL	V2__rules.sql	2098225772	postgres	2026-09-30 11:55:56.845777	158	t
3	3	packages and eligibility	SQL	V3__packages_and_eligibility.sql	1435656880	postgres	2026-09-30 11:55:57.01775	118	t
4	4	employee compensation	SQL	V4__employee_compensation.sql	-2022488293	postgres	2026-09-30 11:55:57.147954	99	t
5	5	incentive plans	SQL	V5__incentive_plans.sql	446129627	postgres	2026-09-30 11:55:57.261853	121	t
6	6	proration policies	SQL	V6__proration_policies.sql	-1804137823	postgres	2026-09-30 11:55:57.393984	32	t
7	7	resolution reminders	SQL	V7__resolution_reminders.sql	-1560954342	postgres	2026-09-30 11:55:57.431999	51	t
8	8	transactional event feed	SQL	V8__transactional_event_feed.sql	1169349743	postgres	2026-10-01 10:39:57.521132	41	t
9	9	element types aligned on payroll	SQL	V9__element_types_aligned_on_payroll.sql	1262349396	postgres	2026-10-01 18:14:34.226114	16	t
10	10	benefit supply and characteristics	SQL	V10__benefit_supply_and_characteristics.sql	-262823236	postgres	2026-10-01 23:03:26.871082	36	t
\.


--
-- Data for Name: incentive_plans; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.incentive_plans (id, company_id, legal_entity_id, country_code, currency, code, label, plan_version, type, payout_number, period_type, fiscal_year_start, kpis, formula, minimum_payout, maximum_payout, valid_from, valid_to, status, created_at, updated_at, revision) FROM stdin;
dfefff98-e919-4d73-acf0-2e4719b99e03	96101814-b255-4348-bb24-d5a963439148	9ae734b6-ae8f-4f87-a103-44ba78f70d04	CM	XAF	COMM_CAISSE	Commisions pour les caissière	1	COMMISSION	401	QUARTERLY	1	[{"code": "NOMBRE_CLIENT", "unit": null, "label": "Nombres de clients", "direction": "HIGHER_IS_BETTER"}]	{"rules": [], "expression": "NOMBRE_CLIENT * 0.3 * 1000"}	10000.000000	20000.000000	2027-01-01	\N	ACTIVE	2026-10-01 11:12:03.089917+00	2026-10-01 11:14:15.259527+00	3
\.


--
-- Data for Name: input_definition; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.input_definition (country_code, catalog_version, code, label, presentation, value_type, unit, minimum, maximum, allowed_values, binding, allowed_sources, status, valid_from, valid_to, created_at, updated_at, revision) FROM stdin;
CM	1	CALENDAR_DAYS	Jours calendaires de la période	{"description": "Nombre de jours calendaires de la période de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	DAY	0.000000000000	\N	{}	PERIODIC	{SYSTEM}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	SCHEDULED_DAYS	Jours de travail prévus	{"description": "Nombre de jours que l'employé devait travailler selon son calendrier applicable.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	DAY	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	WORKED_DAYS	Jours effectivement travaillés	{"description": "Nombre de jours pendant lesquels un travail effectif a été constaté.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	DAY	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	PRESENT_DAYS	Jours de présence reconnus	{"description": "Nombre de jours reconnus comme jours de présence pour les règles de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	DAY	0.000000000000	\N	{}	PERIODIC	{INTEGRATION,SYSTEM}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	PAYABLE_DAYS	Jours rémunérables	{"description": "Nombre de jours retenus pour le paiement après application des règles de présence et de proratisation.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	DAY	0.000000000000	\N	{}	PERIODIC	{SYSTEM}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	WORKED_EQUIVALENT_DAYS	Jours assimilés à du travail	{"description": "Nombre de jours non travaillés mais assimilés à du travail pour certaines règles de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	DAY	0.000000000000	\N	{}	PERIODIC	{INTEGRATION,SYSTEM}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	ABSENCE_DAYS	Jours d'absence	{"description": "Nombre total de jours d'absence reconnus pendant la période.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	DAY	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	PAID_ABSENCE_DAYS	Jours d'absence rémunérée	{"description": "Nombre de jours d'absence pour lesquels une rémunération est maintenue.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	DAY	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	UNPAID_ABSENCE_DAYS	Jours d'absence non rémunérée	{"description": "Nombre de jours d'absence sans maintien de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	DAY	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	SICK_LEAVE_DAYS	Jours d'arrêt maladie	{"description": "Nombre de jours d'absence liés à un arrêt maladie reconnu.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	DAY	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	PAID_LEAVE_DAYS	Jours de congé payé	{"description": "Nombre de jours de congé payé pris pendant la période.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	DAY	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	UNPAID_LEAVE_DAYS	Jours de congé sans solde	{"description": "Nombre de jours de congé sans solde pris pendant la période.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	DAY	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	EMPLOYED_CALENDAR_DAYS	Jours calendaires sous contrat	{"description": "Nombre de jours calendaires pendant lesquels le contrat était en vigueur sur la période.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	DAY	0.000000000000	\N	{}	PERIODIC	{INTEGRATION,SYSTEM}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	EMPLOYED_SCHEDULED_DAYS	Jours prévus sous contrat	{"description": "Nombre de jours de travail prévus pendant lesquels le contrat était en vigueur.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	DAY	0.000000000000	\N	{}	PERIODIC	{INTEGRATION,SYSTEM}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	CONTRACT_WORK_RATIO	Quotité contractuelle de travail	{"description": "Part du temps plein prévue par le contrat sur la période ; 1 représente un temps plein.", "localizedLabels": {}, "localizedDescriptions": {}}	RATE	RATIO	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	PAY_PRORATION_RATIO	Coefficient de proratisation	{"description": "Coefficient retenu pour proratiser la rémunération de la période ; 1 signifie aucune réduction.", "localizedLabels": {}, "localizedDescriptions": {}}	RATE	RATIO	0.000000000000	\N	{}	PERIODIC	{SYSTEM}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	ON_CALL_DAYS	Jours d'astreinte	{"description": "Nombre de jours d'astreinte reconnus sur la période.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	DAY	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	ON_CALL_INTERVENTIONS	Interventions pendant astreinte	{"description": "Nombre d'interventions réalisées pendant une astreinte.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	UNIT	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	NIGHT_SHIFTS	Postes de nuit	{"description": "Nombre de postes de nuit réalisés et reconnus.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	UNIT	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	FIELD_ASSIGNMENT_DAYS	Jours de mission sur le terrain	{"description": "Nombre de jours reconnus comme mission sur le terrain.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	DAY	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	TRAVEL_ELIGIBLE_DAYS	Jours de déplacement éligibles	{"description": "Jours de déplacement validés pour une indemnité.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	DAY	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	TRAVEL_DAYS	Jours de déplacement professionnel	{"description": "Nombre de jours de déplacement professionnel reconnus.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	DAY	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	OVERNIGHT_STAYS	Nuitées professionnelles	{"description": "Nombre de nuitées professionnelles éligibles à une indemnité.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	UNIT	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	BUSINESS_DISTANCE_KM	Distance professionnelle parcourue	{"description": "Distance parcourue et validée pour l'activité professionnelle.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	KILOMETER	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	MEAL_ELIGIBLE_DAYS	Jours éligibles à l'indemnité de repas	{"description": "Nombre de jours remplissant les conditions de l'indemnité de repas.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	DAY	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	TRANSPORT_ELIGIBLE_DAYS	Jours éligibles à l'indemnité de transport	{"description": "Nombre de jours remplissant les conditions de l'indemnité de transport.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	DAY	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	PRODUCED_UNITS	Unités produites	{"description": "Nombre d'unités produites pendant la période.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	UNIT	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	ACCEPTED_PRODUCTION_UNITS	Unités produites acceptées	{"description": "Nombre d'unités produites et acceptées après contrôle.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	UNIT	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	REJECTED_PRODUCTION_UNITS	Unités produites rejetées	{"description": "Nombre d'unités produites rejetées après contrôle.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	UNIT	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	COMPLETED_TASKS	Tâches achevées	{"description": "Nombre de tâches achevées et validées pendant la période.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	UNIT	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	COMPLETED_MISSIONS	Missions achevées	{"description": "Nombre de missions achevées et validées pendant la période.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	UNIT	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	COMPLETED_DELIVERIES	Livraisons achevées	{"description": "Nombre de livraisons achevées et validées pendant la période.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	UNIT	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	QUALITY_ACCEPTANCE_RATE	Taux d'acceptation qualité	{"description": "Part des réalisations acceptées après contrôle ; 1 signifie 100 %.", "localizedLabels": {}, "localizedDescriptions": {}}	RATE	RATIO	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	ELIGIBLE_SALES_AMOUNT	Ventes éligibles à commission	{"description": "Montant des ventes validées et éligibles à commission sur la période.", "localizedLabels": {}, "localizedDescriptions": {}}	MONEY	CURRENCY	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	COLLECTED_SALES_AMOUNT	Ventes encaissées	{"description": "Montant des ventes effectivement encaissées pendant la période.", "localizedLabels": {}, "localizedDescriptions": {}}	MONEY	CURRENCY	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	CANCELLED_SALES_AMOUNT	Ventes annulées	{"description": "Montant des ventes annulées à prendre en compte dans l'assiette commerciale.", "localizedLabels": {}, "localizedDescriptions": {}}	MONEY	CURRENCY	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	REFUNDED_SALES_AMOUNT	Ventes remboursées	{"description": "Montant des ventes remboursées à prendre en compte dans l'assiette commerciale.", "localizedLabels": {}, "localizedDescriptions": {}}	MONEY	CURRENCY	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	ELIGIBLE_MARGIN_AMOUNT	Marge éligible à commission	{"description": "Montant de marge validée servant éventuellement de base à une commission.", "localizedLabels": {}, "localizedDescriptions": {}}	MONEY	CURRENCY	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	ELIGIBLE_CONTRACTS_COUNT	Contrats commerciaux éligibles	{"description": "Nombre de contrats commerciaux validés et éligibles à rémunération variable.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	UNIT	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	SALES_TARGET_AMOUNT	Objectif de ventes	{"description": "Montant cible des ventes pour la période et le périmètre applicables.", "localizedLabels": {}, "localizedDescriptions": {}}	MONEY	CURRENCY	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	SALES_ACHIEVEMENT_RATIO	Taux d'atteinte de l'objectif de ventes	{"description": "Rapport entre ventes retenues et objectif de ventes ; 1 signifie 100 %.", "localizedLabels": {}, "localizedDescriptions": {}}	RATE	RATIO	0.000000000000	\N	{}	PERIODIC	{INTEGRATION,SYSTEM}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	KPI_TARGET	Cible de l'indicateur de performance	{"description": "Valeur cible de l'indicateur identifié pour la période.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	UNIT	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	KPI_ACTUAL	Résultat de l'indicateur de performance	{"description": "Valeur réalisée et validée de l'indicateur identifié pour la période.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	UNIT	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	KPI_ACHIEVEMENT_RATIO	Taux d'atteinte de l'indicateur	{"description": "Rapport validé entre résultat et cible de l'indicateur identifié ; 1 signifie 100 %.", "localizedLabels": {}, "localizedDescriptions": {}}	RATE	RATIO	0.000000000000	\N	{}	PERIODIC	{INTEGRATION,SYSTEM}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	KPI_WEIGHT	Pondération de l'indicateur	{"description": "Poids attribué à l'indicateur identifié dans le calcul de la performance.", "localizedLabels": {}, "localizedDescriptions": {}}	RATE	RATIO	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	INTEGRATION_SCORE	Score de performance validé	{"description": "Score final validé pour un dispositif de performance identifié.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	UNIT	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	WORKED_DAYS_CORRECTION	Correction de jours travaillés	{"description": "Différence signée de jours travaillés reconnue pour une période antérieure.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	DAY	\N	\N	{}	PERIODIC	{INTEGRATION,SYSTEM}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	ACCEPTED_UNITS_CORRECTION	Correction d'unités acceptées	{"description": "Différence signée d'unités de production acceptées pour une période antérieure.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	UNIT	\N	\N	{}	PERIODIC	{INTEGRATION,SYSTEM}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	NORMAL_HOURS	Heures normales théoriques	{"description": "Nombre d'heures normalement prévues pour l'employé sur la période, avant prise en compte des absences.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	WORKED_HOURS	Heures effectivement travaillées	{"description": "Nombre d'heures de travail effectivement réalisées sur la période, hors heures supplémentaires si celles-ci sont collectées séparément.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	ON_CALL_HOURS	Heures d'astreinte	{"description": "Heures d'astreinte hors interventions comptées séparément.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	WORKED_HOURS_CORRECTION	Correction d'heures travaillées	{"description": "Différence signée d'heures reconnues pour une période antérieure.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	\N	\N	{}	PERIODIC	{INTEGRATION,MANUAL,SYSTEM}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	OVERTIME_HOURS	Heures supplémentaires	{"description": "Nombre d'heures supplémentaires toutes catégories confondues sur la période. Les majorations applicables sont déterminées par les règles de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	OVERTIME_NIGHT_HOURS	Heures supplémentaires de nuit	{"description": "Nombre d'heures supplémentaires effectuées de nuit sur la période. Les majorations applicables sont déterminées par les règles de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	OVERTIME_WEEKEND_HOURS	Heures supplémentaires de week-end	{"description": "Nombre d'heures supplémentaires effectuées pendant le week-end sur la période. Les majorations applicables sont déterminées par les règles de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	OVERTIME_SUNDAY_HOURS	Heures supplémentaires du dimanche	{"description": "Nombre d'heures supplémentaires effectuées un dimanche sur la période. Les majorations applicables sont déterminées par les règles de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	OVERTIME_HOLIDAY_HOURS	Heures supplémentaires de jour férié	{"description": "Nombre d'heures supplémentaires effectuées un jour férié sur la période. Les majorations applicables sont déterminées par les règles de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	OVERTIME_NIGHT_WEEKEND_HOURS	Heures supplémentaires de nuit et week-end	{"description": "Nombre d'heures supplémentaires effectuées de nuit pendant le week-end sur la période. Les majorations applicables sont déterminées par les règles de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	OVERTIME_NIGHT_SUNDAY_HOURS	Heures supplémentaires de nuit et dimanche	{"description": "Nombre d'heures supplémentaires effectuées de nuit un dimanche sur la période. Les majorations applicables sont déterminées par les règles de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	OVERTIME_NIGHT_HOLIDAY_HOURS	Heures supplémentaires de nuit et jour férié	{"description": "Nombre d'heures supplémentaires effectuées de nuit un jour férié sur la période. Les majorations applicables sont déterminées par les règles de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	OVERTIME_WEEKEND_SUNDAY_HOURS	Heures supplémentaires de week-end et dimanche	{"description": "Nombre d'heures supplémentaires qualifiées à la fois comme week-end et dimanche sur la période. Les majorations applicables sont déterminées par les règles de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	OVERTIME_WEEKEND_HOLIDAY_HOURS	Heures supplémentaires de week-end et jour férié	{"description": "Nombre d'heures supplémentaires qualifiées à la fois comme week-end et jour férié sur la période. Les majorations applicables sont déterminées par les règles de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	OVERTIME_SUNDAY_HOLIDAY_HOURS	Heures supplémentaires du dimanche et jour férié	{"description": "Nombre d'heures supplémentaires qualifiées à la fois comme dimanche et jour férié sur la période. Les majorations applicables sont déterminées par les règles de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	OVERTIME_NIGHT_WEEKEND_SUNDAY_HOURS	Heures supplémentaires de nuit, week-end et dimanche	{"description": "Nombre d'heures supplémentaires qualifiées comme nuit, week-end et dimanche sur la période. Les majorations applicables sont déterminées par les règles de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	OVERTIME_NIGHT_WEEKEND_HOLIDAY_HOURS	Heures supplémentaires de nuit, week-end et jour férié	{"description": "Nombre d'heures supplémentaires qualifiées comme nuit, week-end et jour férié sur la période. Les majorations applicables sont déterminées par les règles de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	OVERTIME_NIGHT_SUNDAY_HOLIDAY_HOURS	Heures supplémentaires de nuit, dimanche et jour férié	{"description": "Nombre d'heures supplémentaires qualifiées comme nuit, dimanche et jour férié sur la période. Les majorations applicables sont déterminées par les règles de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	OVERTIME_WEEKEND_SUNDAY_HOLIDAY_HOURS	Heures supplémentaires de week-end, dimanche et jour férié	{"description": "Nombre d'heures supplémentaires qualifiées comme week-end, dimanche et jour férié sur la période. Les majorations applicables sont déterminées par les règles de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	OVERTIME_NIGHT_WEEKEND_SUNDAY_HOLIDAY_HOURS	Heures supplémentaires de nuit, week-end, dimanche et jour férié	{"description": "Nombre d'heures supplémentaires qualifiées comme nuit, week-end, dimanche et jour férié sur la période. Les majorations applicables sont déterminées par les règles de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	NIGHT_HOURS	Heures normales de nuit	{"description": "Nombre d'heures de travail non supplémentaires effectuées de nuit sur la période. Les majorations éventuelles sont déterminées par les règles de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	WEEKEND_HOURS	Heures normales de week-end	{"description": "Nombre d'heures de travail non supplémentaires effectuées pendant le week-end sur la période. Les majorations éventuelles sont déterminées par les règles de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	SUNDAY_HOURS	Heures normales du dimanche	{"description": "Nombre d'heures de travail non supplémentaires effectuées un dimanche sur la période. Les majorations éventuelles sont déterminées par les règles de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	HOLIDAY_HOURS	Heures normales de jour férié	{"description": "Nombre d'heures de travail non supplémentaires effectuées un jour férié sur la période. Les majorations éventuelles sont déterminées par les règles de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	NIGHT_WEEKEND_HOURS	Heures normales de nuit et week-end	{"description": "Nombre d'heures de travail non supplémentaires qualifiées comme nuit et week-end sur la période. Les majorations éventuelles sont déterminées par les règles de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	NIGHT_SUNDAY_HOURS	Heures normales de nuit et dimanche	{"description": "Nombre d'heures de travail non supplémentaires qualifiées comme nuit et dimanche sur la période. Les majorations éventuelles sont déterminées par les règles de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	NIGHT_HOLIDAY_HOURS	Heures normales de nuit et jour férié	{"description": "Nombre d'heures de travail non supplémentaires qualifiées comme nuit et jour férié sur la période. Les majorations éventuelles sont déterminées par les règles de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	WEEKEND_SUNDAY_HOURS	Heures normales de week-end et dimanche	{"description": "Nombre d'heures de travail non supplémentaires qualifiées comme week-end et dimanche sur la période. Les majorations éventuelles sont déterminées par les règles de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	WEEKEND_HOLIDAY_HOURS	Heures normales de week-end et jour férié	{"description": "Nombre d'heures de travail non supplémentaires qualifiées comme week-end et jour férié sur la période. Les majorations éventuelles sont déterminées par les règles de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	SUNDAY_HOLIDAY_HOURS	Heures normales du dimanche et jour férié	{"description": "Nombre d'heures de travail non supplémentaires qualifiées comme dimanche et jour férié sur la période. Les majorations éventuelles sont déterminées par les règles de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	NIGHT_WEEKEND_SUNDAY_HOURS	Heures normales de nuit, week-end et dimanche	{"description": "Nombre d'heures de travail non supplémentaires qualifiées comme nuit, week-end et dimanche sur la période. Les majorations éventuelles sont déterminées par les règles de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	NIGHT_WEEKEND_HOLIDAY_HOURS	Heures normales de nuit, week-end et jour férié	{"description": "Nombre d'heures de travail non supplémentaires qualifiées comme nuit, week-end et jour férié sur la période. Les majorations éventuelles sont déterminées par les règles de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	NIGHT_SUNDAY_HOLIDAY_HOURS	Heures normales de nuit, dimanche et jour férié	{"description": "Nombre d'heures de travail non supplémentaires qualifiées comme nuit, dimanche et jour férié sur la période. Les majorations éventuelles sont déterminées par les règles de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	WEEKEND_SUNDAY_HOLIDAY_HOURS	Heures normales de week-end, dimanche et jour férié	{"description": "Nombre d'heures de travail non supplémentaires qualifiées comme week-end, dimanche et jour férié sur la période. Les majorations éventuelles sont déterminées par les règles de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	NIGHT_WEEKEND_SUNDAY_HOLIDAY_HOURS	Heures normales de nuit, week-end, dimanche et jour férié	{"description": "Nombre d'heures de travail non supplémentaires qualifiées comme nuit, week-end, dimanche et jour férié sur la période. Les majorations éventuelles sont déterminées par les règles de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	ABSENCE_HOURS	Heures d'absence	{"description": "Volume total d'heures d'absence constatées sur la période.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	ABSENCE_PAID_HOURS	Heures d'absence rémunérées	{"description": "Volume d'heures d'absence conservant une rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	ABSENCE_UNPAID_HOURS	Heures d'absence non rémunérées	{"description": "Volume d'heures d'absence ne conservant pas de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	ABSENCE_DEDUCTIBLE_HOURS	Heures d'absence à déduire	{"description": "Volume d'absence restant à déduire de la rémunération après neutralisation de la part déjà prise en compte par le prorata. Une correction manuelle est possible.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{MANUAL,SYSTEM}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	AUTHORIZED_ABSENCE_HOURS	Heures d'absence autorisée	{"description": "Volume d'heures d'absence autorisées.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	UNAUTHORIZED_ABSENCE_HOURS	Heures d'absence non autorisée	{"description": "Volume d'heures d'absence non autorisées.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	SICK_LEAVE_HOURS	Heures d'arrêt maladie	{"description": "Volume d'heures d'absence liées à un arrêt maladie.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	PAID_LEAVE_HOURS	Heures de congé payé	{"description": "Volume d'heures d'absence correspondant à des congés payés.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	UNPAID_LEAVE_HOURS	Heures de congé sans solde	{"description": "Volume d'heures d'absence correspondant à des congés sans solde.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	PAID_NO_PAYROLL_IMPACT_ABSENCE_HOURS	Absence rémunérée sans impact paie	{"description": "Heures d'absence rémunérées qualifiées par la gestion du temps comme sans impact sur la paie.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	PAID_WITH_PAYROLL_MARKER_ABSENCE_HOURS	Absence rémunérée avec marqueur paie	{"description": "Heures d'absence rémunérées nécessitant une présentation ou un traitement explicite sur la paie.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	PARTIALLY_PAID_ABSENCE_HOURS	Absence partiellement rémunérée	{"description": "Heures d'absence dont la rémunération n'est maintenue qu'en partie.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	UNPAID_DEDUCTED_ABSENCE_HOURS	Absence non rémunérée déjà déduite	{"description": "Heures d'absence non rémunérées pour lesquelles une déduction a déjà été prise en compte en amont.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	UNPAID_AUTHORIZED_ABSENCE_HOURS	Absence autorisée non rémunérée	{"description": "Heures d'absence autorisées ne conservant pas de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	MANUAL_REVIEW_ABSENCE_HOURS	Absence à examiner manuellement	{"description": "Heures d'absence dont le traitement de rémunération nécessite une décision humaine.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	WORKED_EQUIVALENT_ABSENCE_HOURS	Absence assimilée à du temps travaillé	{"description": "Heures d'absence reconnues comme équivalentes à des heures travaillées pour certains calculs.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	PAYROLL_IMPACT_ABSENCE_HOURS	Absence ayant un impact sur la paie	{"description": "Heures d'absence qualifiées comme ayant un impact sur la rémunération ou sa présentation.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	SENIORITY_MONTHS	Ancienneté cumulée dans l'entreprise — mois	{"description": "Nombre de mois d'ancienneté cumulée dans l'entreprise, selon les règles de prise en compte des périodes de service et des suspensions.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	MONTH	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	SENIORITY_DAYS	Ancienneté cumulée dans l'entreprise — jours	{"description": "Nombre de jours d'ancienneté cumulée dans l'entreprise, selon les règles de prise en compte des périodes de service et des suspensions.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	DAY	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	SENIORITY_YEARS	Ancienneté cumulée dans l'entreprise — années	{"description": "Nombre d'années révolues d'ancienneté cumulée dans l'entreprise.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	YEAR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	SENIORITY_CONTINUOUS_MONTHS	Ancienneté continue dans l'entreprise — mois	{"description": "Nombre de mois d'ancienneté dans la relation d'emploi continue courante ; repart à zéro après une rupture.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	MONTH	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	SENIORITY_CONTINUOUS_DAYS	Ancienneté continue dans l'entreprise — jours	{"description": "Nombre de jours d'ancienneté dans la relation d'emploi continue courante ; repart à zéro après une rupture.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	DAY	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	SENIORITY_GRADE_MONTHS	Ancienneté dans le grade — mois	{"description": "Nombre de mois d'ancienneté dans le grade applicable.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	MONTH	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	SENIORITY_POSITION_MONTHS	Ancienneté dans le poste — mois	{"description": "Nombre de mois d'ancienneté dans le poste applicable.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	MONTH	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	SENIORITY_CATEGORY_MONTHS	Ancienneté dans la catégorie — mois	{"description": "Nombre de mois d'ancienneté dans la catégorie professionnelle applicable.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	MONTH	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	SENIORITY_TITLE_MONTHS	Ancienneté dans l'intitulé de fonction — mois	{"description": "Nombre de mois d'ancienneté dans l'intitulé de fonction applicable.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	MONTH	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	SENIORITY_UNIT_MONTHS	Ancienneté dans l'unité — mois	{"description": "Nombre de mois d'ancienneté dans l'unité organisationnelle applicable.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	MONTH	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	SENIORITY_SITE_MONTHS	Ancienneté sur le site — mois	{"description": "Nombre de mois d'ancienneté sur le site d'affectation applicable.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	MONTH	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	2	ABSENCE_DAYS	Jours d'absence	{"description": "Nombre total de jours d'absence reconnus pendant la période.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	DAY	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	ABSENCE_DEDUCTIBLE_HOURS	Heures d'absence à déduire	{"description": "Volume d'absence restant à déduire de la rémunération après neutralisation de la part déjà prise en compte par le prorata. Une correction manuelle est possible.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{MANUAL,SYSTEM}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	ABSENCE_HOURS	Heures d'absence	{"description": "Volume total d'heures d'absence constatées sur la période.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	ABSENCE_PAID_HOURS	Heures d'absence rémunérées	{"description": "Volume d'heures d'absence conservant une rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	ABSENCE_UNPAID_HOURS	Heures d'absence non rémunérées	{"description": "Volume d'heures d'absence ne conservant pas de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	ACCEPTED_PRODUCTION_UNITS	Unités produites acceptées	{"description": "Nombre d'unités produites et acceptées après contrôle.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	UNIT	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	ACCEPTED_UNITS_CORRECTION	Correction d'unités acceptées	{"description": "Différence signée d'unités de production acceptées pour une période antérieure.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	UNIT	\N	\N	{}	PERIODIC	{INTEGRATION,SYSTEM}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	AUTHORIZED_ABSENCE_HOURS	Heures d'absence autorisée	{"description": "Volume d'heures d'absence autorisées.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	BUSINESS_DISTANCE_KM	Distance professionnelle parcourue	{"description": "Distance parcourue et validée pour l'activité professionnelle.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	KILOMETER	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	CALENDAR_DAYS	Jours calendaires de la période	{"description": "Nombre de jours calendaires de la période de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	DAY	0.000000000000	\N	{}	PERIODIC	{SYSTEM}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	CANCELLED_SALES_AMOUNT	Ventes annulées	{"description": "Montant des ventes annulées à prendre en compte dans l'assiette commerciale.", "localizedLabels": {}, "localizedDescriptions": {}}	MONEY	CURRENCY	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	COLLECTED_SALES_AMOUNT	Ventes encaissées	{"description": "Montant des ventes effectivement encaissées pendant la période.", "localizedLabels": {}, "localizedDescriptions": {}}	MONEY	CURRENCY	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	COMPLETED_DELIVERIES	Livraisons achevées	{"description": "Nombre de livraisons achevées et validées pendant la période.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	UNIT	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	COMPLETED_MISSIONS	Missions achevées	{"description": "Nombre de missions achevées et validées pendant la période.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	UNIT	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	COMPLETED_TASKS	Tâches achevées	{"description": "Nombre de tâches achevées et validées pendant la période.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	UNIT	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	CONTRACT_WORK_RATIO	Quotité contractuelle de travail	{"description": "Part du temps plein prévue par le contrat sur la période ; 1 représente un temps plein.", "localizedLabels": {}, "localizedDescriptions": {}}	RATE	RATIO	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	ELIGIBLE_CONTRACTS_COUNT	Contrats commerciaux éligibles	{"description": "Nombre de contrats commerciaux validés et éligibles à rémunération variable.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	UNIT	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	ELIGIBLE_MARGIN_AMOUNT	Marge éligible à commission	{"description": "Montant de marge validée servant éventuellement de base à une commission.", "localizedLabels": {}, "localizedDescriptions": {}}	MONEY	CURRENCY	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	ELIGIBLE_SALES_AMOUNT	Ventes éligibles à commission	{"description": "Montant des ventes validées et éligibles à commission sur la période.", "localizedLabels": {}, "localizedDescriptions": {}}	MONEY	CURRENCY	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	EMPLOYED_CALENDAR_DAYS	Jours calendaires sous contrat	{"description": "Nombre de jours calendaires pendant lesquels le contrat était en vigueur sur la période.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	DAY	0.000000000000	\N	{}	PERIODIC	{INTEGRATION,SYSTEM}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	EMPLOYED_SCHEDULED_DAYS	Jours prévus sous contrat	{"description": "Nombre de jours de travail prévus pendant lesquels le contrat était en vigueur.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	DAY	0.000000000000	\N	{}	PERIODIC	{INTEGRATION,SYSTEM}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	FIELD_ASSIGNMENT_DAYS	Jours de mission sur le terrain	{"description": "Nombre de jours reconnus comme mission sur le terrain.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	DAY	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	HOLIDAY_HOURS	Heures normales de jour férié	{"description": "Nombre d'heures de travail non supplémentaires effectuées un jour férié sur la période. Les majorations éventuelles sont déterminées par les règles de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	INTEGRATION_SCORE	Score de performance validé	{"description": "Score final validé pour un dispositif de performance identifié.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	UNIT	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	KPI_ACHIEVEMENT_RATIO	Taux d'atteinte de l'indicateur	{"description": "Rapport validé entre résultat et cible de l'indicateur identifié ; 1 signifie 100 %.", "localizedLabels": {}, "localizedDescriptions": {}}	RATE	RATIO	0.000000000000	\N	{}	PERIODIC	{INTEGRATION,SYSTEM}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	KPI_ACTUAL	Résultat de l'indicateur de performance	{"description": "Valeur réalisée et validée de l'indicateur identifié pour la période.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	UNIT	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	KPI_TARGET	Cible de l'indicateur de performance	{"description": "Valeur cible de l'indicateur identifié pour la période.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	UNIT	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	KPI_WEIGHT	Pondération de l'indicateur	{"description": "Poids attribué à l'indicateur identifié dans le calcul de la performance.", "localizedLabels": {}, "localizedDescriptions": {}}	RATE	RATIO	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	MANUAL_REVIEW_ABSENCE_HOURS	Absence à examiner manuellement	{"description": "Heures d'absence dont le traitement de rémunération nécessite une décision humaine.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	MEAL_ELIGIBLE_DAYS	Jours éligibles à l'indemnité de repas	{"description": "Nombre de jours remplissant les conditions de l'indemnité de repas.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	DAY	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	NIGHT_HOLIDAY_HOURS	Heures normales de nuit et jour férié	{"description": "Nombre d'heures de travail non supplémentaires qualifiées comme nuit et jour férié sur la période. Les majorations éventuelles sont déterminées par les règles de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	NIGHT_HOURS	Heures normales de nuit	{"description": "Nombre d'heures de travail non supplémentaires effectuées de nuit sur la période. Les majorations éventuelles sont déterminées par les règles de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	NIGHT_SHIFTS	Postes de nuit	{"description": "Nombre de postes de nuit réalisés et reconnus.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	UNIT	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	NIGHT_SUNDAY_HOLIDAY_HOURS	Heures normales de nuit, dimanche et jour férié	{"description": "Nombre d'heures de travail non supplémentaires qualifiées comme nuit, dimanche et jour férié sur la période. Les majorations éventuelles sont déterminées par les règles de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	NIGHT_SUNDAY_HOURS	Heures normales de nuit et dimanche	{"description": "Nombre d'heures de travail non supplémentaires qualifiées comme nuit et dimanche sur la période. Les majorations éventuelles sont déterminées par les règles de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	NIGHT_WEEKEND_HOLIDAY_HOURS	Heures normales de nuit, week-end et jour férié	{"description": "Nombre d'heures de travail non supplémentaires qualifiées comme nuit, week-end et jour férié sur la période. Les majorations éventuelles sont déterminées par les règles de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	NIGHT_WEEKEND_HOURS	Heures normales de nuit et week-end	{"description": "Nombre d'heures de travail non supplémentaires qualifiées comme nuit et week-end sur la période. Les majorations éventuelles sont déterminées par les règles de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	NIGHT_WEEKEND_SUNDAY_HOLIDAY_HOURS	Heures normales de nuit, week-end, dimanche et jour férié	{"description": "Nombre d'heures de travail non supplémentaires qualifiées comme nuit, week-end, dimanche et jour férié sur la période. Les majorations éventuelles sont déterminées par les règles de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	NIGHT_WEEKEND_SUNDAY_HOURS	Heures normales de nuit, week-end et dimanche	{"description": "Nombre d'heures de travail non supplémentaires qualifiées comme nuit, week-end et dimanche sur la période. Les majorations éventuelles sont déterminées par les règles de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	NORMAL_HOURS	Heures normales théoriques	{"description": "Nombre d'heures normalement prévues pour l'employé sur la période, avant prise en compte des absences.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	ON_CALL_DAYS	Jours d'astreinte	{"description": "Nombre de jours d'astreinte reconnus sur la période.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	DAY	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	ON_CALL_HOURS	Heures d'astreinte	{"description": "Heures d'astreinte hors interventions comptées séparément.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	ON_CALL_INTERVENTIONS	Interventions pendant astreinte	{"description": "Nombre d'interventions réalisées pendant une astreinte.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	UNIT	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	OVERNIGHT_STAYS	Nuitées professionnelles	{"description": "Nombre de nuitées professionnelles éligibles à une indemnité.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	UNIT	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	OVERTIME_HOLIDAY_HOURS	Heures supplémentaires de jour férié	{"description": "Nombre d'heures supplémentaires effectuées un jour férié sur la période. Les majorations applicables sont déterminées par les règles de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	OVERTIME_HOURS	Heures supplémentaires	{"description": "Nombre d'heures supplémentaires toutes catégories confondues sur la période. Les majorations applicables sont déterminées par les règles de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	OVERTIME_NIGHT_HOLIDAY_HOURS	Heures supplémentaires de nuit et jour férié	{"description": "Nombre d'heures supplémentaires effectuées de nuit un jour férié sur la période. Les majorations applicables sont déterminées par les règles de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	OVERTIME_NIGHT_HOURS	Heures supplémentaires de nuit	{"description": "Nombre d'heures supplémentaires effectuées de nuit sur la période. Les majorations applicables sont déterminées par les règles de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	OVERTIME_NIGHT_SUNDAY_HOLIDAY_HOURS	Heures supplémentaires de nuit, dimanche et jour férié	{"description": "Nombre d'heures supplémentaires qualifiées comme nuit, dimanche et jour férié sur la période. Les majorations applicables sont déterminées par les règles de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	OVERTIME_NIGHT_SUNDAY_HOURS	Heures supplémentaires de nuit et dimanche	{"description": "Nombre d'heures supplémentaires effectuées de nuit un dimanche sur la période. Les majorations applicables sont déterminées par les règles de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	OVERTIME_NIGHT_WEEKEND_HOLIDAY_HOURS	Heures supplémentaires de nuit, week-end et jour férié	{"description": "Nombre d'heures supplémentaires qualifiées comme nuit, week-end et jour férié sur la période. Les majorations applicables sont déterminées par les règles de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	OVERTIME_NIGHT_WEEKEND_HOURS	Heures supplémentaires de nuit et week-end	{"description": "Nombre d'heures supplémentaires effectuées de nuit pendant le week-end sur la période. Les majorations applicables sont déterminées par les règles de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	OVERTIME_NIGHT_WEEKEND_SUNDAY_HOLIDAY_HOURS	Heures supplémentaires de nuit, week-end, dimanche et jour férié	{"description": "Nombre d'heures supplémentaires qualifiées comme nuit, week-end, dimanche et jour férié sur la période. Les majorations applicables sont déterminées par les règles de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	OVERTIME_NIGHT_WEEKEND_SUNDAY_HOURS	Heures supplémentaires de nuit, week-end et dimanche	{"description": "Nombre d'heures supplémentaires qualifiées comme nuit, week-end et dimanche sur la période. Les majorations applicables sont déterminées par les règles de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	OVERTIME_SUNDAY_HOLIDAY_HOURS	Heures supplémentaires du dimanche et jour férié	{"description": "Nombre d'heures supplémentaires qualifiées à la fois comme dimanche et jour férié sur la période. Les majorations applicables sont déterminées par les règles de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	OVERTIME_SUNDAY_HOURS	Heures supplémentaires du dimanche	{"description": "Nombre d'heures supplémentaires effectuées un dimanche sur la période. Les majorations applicables sont déterminées par les règles de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	OVERTIME_WEEKEND_HOLIDAY_HOURS	Heures supplémentaires de week-end et jour férié	{"description": "Nombre d'heures supplémentaires qualifiées à la fois comme week-end et jour férié sur la période. Les majorations applicables sont déterminées par les règles de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	OVERTIME_WEEKEND_HOURS	Heures supplémentaires de week-end	{"description": "Nombre d'heures supplémentaires effectuées pendant le week-end sur la période. Les majorations applicables sont déterminées par les règles de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	OVERTIME_WEEKEND_SUNDAY_HOLIDAY_HOURS	Heures supplémentaires de week-end, dimanche et jour férié	{"description": "Nombre d'heures supplémentaires qualifiées comme week-end, dimanche et jour férié sur la période. Les majorations applicables sont déterminées par les règles de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	OVERTIME_WEEKEND_SUNDAY_HOURS	Heures supplémentaires de week-end et dimanche	{"description": "Nombre d'heures supplémentaires qualifiées à la fois comme week-end et dimanche sur la période. Les majorations applicables sont déterminées par les règles de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	PAID_ABSENCE_DAYS	Jours d'absence rémunérée	{"description": "Nombre de jours d'absence pour lesquels une rémunération est maintenue.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	DAY	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	PAID_LEAVE_DAYS	Jours de congé payé	{"description": "Nombre de jours de congé payé pris pendant la période.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	DAY	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	PAID_LEAVE_HOURS	Heures de congé payé	{"description": "Volume d'heures d'absence correspondant à des congés payés.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	PAID_NO_PAYROLL_IMPACT_ABSENCE_HOURS	Absence rémunérée sans impact paie	{"description": "Heures d'absence rémunérées qualifiées par la gestion du temps comme sans impact sur la paie.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	PAID_WITH_PAYROLL_MARKER_ABSENCE_HOURS	Absence rémunérée avec marqueur paie	{"description": "Heures d'absence rémunérées nécessitant une présentation ou un traitement explicite sur la paie.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	PARTIALLY_PAID_ABSENCE_HOURS	Absence partiellement rémunérée	{"description": "Heures d'absence dont la rémunération n'est maintenue qu'en partie.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	PAYABLE_DAYS	Jours rémunérables	{"description": "Nombre de jours retenus pour le paiement après application des règles de présence et de proratisation.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	DAY	0.000000000000	\N	{}	PERIODIC	{SYSTEM}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	PAYROLL_IMPACT_ABSENCE_HOURS	Absence ayant un impact sur la paie	{"description": "Heures d'absence qualifiées comme ayant un impact sur la rémunération ou sa présentation.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	PAY_PRORATION_RATIO	Coefficient de proratisation	{"description": "Coefficient retenu pour proratiser la rémunération de la période ; 1 signifie aucune réduction.", "localizedLabels": {}, "localizedDescriptions": {}}	RATE	RATIO	0.000000000000	\N	{}	PERIODIC	{SYSTEM}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	PRESENT_DAYS	Jours de présence reconnus	{"description": "Nombre de jours reconnus comme jours de présence pour les règles de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	DAY	0.000000000000	\N	{}	PERIODIC	{INTEGRATION,SYSTEM}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	PRODUCED_UNITS	Unités produites	{"description": "Nombre d'unités produites pendant la période.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	UNIT	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	QUALITY_ACCEPTANCE_RATE	Taux d'acceptation qualité	{"description": "Part des réalisations acceptées après contrôle ; 1 signifie 100 %.", "localizedLabels": {}, "localizedDescriptions": {}}	RATE	RATIO	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	REFUNDED_SALES_AMOUNT	Ventes remboursées	{"description": "Montant des ventes remboursées à prendre en compte dans l'assiette commerciale.", "localizedLabels": {}, "localizedDescriptions": {}}	MONEY	CURRENCY	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	REJECTED_PRODUCTION_UNITS	Unités produites rejetées	{"description": "Nombre d'unités produites rejetées après contrôle.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	UNIT	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	SALES_ACHIEVEMENT_RATIO	Taux d'atteinte de l'objectif de ventes	{"description": "Rapport entre ventes retenues et objectif de ventes ; 1 signifie 100 %.", "localizedLabels": {}, "localizedDescriptions": {}}	RATE	RATIO	0.000000000000	\N	{}	PERIODIC	{INTEGRATION,SYSTEM}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	SALES_TARGET_AMOUNT	Objectif de ventes	{"description": "Montant cible des ventes pour la période et le périmètre applicables.", "localizedLabels": {}, "localizedDescriptions": {}}	MONEY	CURRENCY	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	SCHEDULED_DAYS	Jours de travail prévus	{"description": "Nombre de jours que l'employé devait travailler selon son calendrier applicable.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	DAY	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	SENIORITY_CATEGORY_MONTHS	Ancienneté dans la catégorie — mois	{"description": "Nombre de mois d'ancienneté dans la catégorie professionnelle applicable.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	MONTH	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	SENIORITY_CONTINUOUS_DAYS	Ancienneté continue dans l'entreprise — jours	{"description": "Nombre de jours d'ancienneté dans la relation d'emploi continue courante ; repart à zéro après une rupture.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	DAY	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	SENIORITY_CONTINUOUS_MONTHS	Ancienneté continue dans l'entreprise — mois	{"description": "Nombre de mois d'ancienneté dans la relation d'emploi continue courante ; repart à zéro après une rupture.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	MONTH	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	SENIORITY_DAYS	Ancienneté cumulée dans l'entreprise — jours	{"description": "Nombre de jours d'ancienneté cumulée dans l'entreprise, selon les règles de prise en compte des périodes de service et des suspensions.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	DAY	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	SENIORITY_GRADE_MONTHS	Ancienneté dans le grade — mois	{"description": "Nombre de mois d'ancienneté dans le grade applicable.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	MONTH	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	SENIORITY_MONTHS	Ancienneté cumulée dans l'entreprise — mois	{"description": "Nombre de mois d'ancienneté cumulée dans l'entreprise, selon les règles de prise en compte des périodes de service et des suspensions.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	MONTH	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	SENIORITY_POSITION_MONTHS	Ancienneté dans le poste — mois	{"description": "Nombre de mois d'ancienneté dans le poste applicable.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	MONTH	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	SENIORITY_SITE_MONTHS	Ancienneté sur le site — mois	{"description": "Nombre de mois d'ancienneté sur le site d'affectation applicable.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	MONTH	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	SENIORITY_TITLE_MONTHS	Ancienneté dans l'intitulé de fonction — mois	{"description": "Nombre de mois d'ancienneté dans l'intitulé de fonction applicable.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	MONTH	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	SENIORITY_UNIT_MONTHS	Ancienneté dans l'unité — mois	{"description": "Nombre de mois d'ancienneté dans l'unité organisationnelle applicable.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	MONTH	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	SENIORITY_YEARS	Ancienneté cumulée dans l'entreprise — années	{"description": "Nombre d'années révolues d'ancienneté cumulée dans l'entreprise.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	YEAR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	SICK_LEAVE_DAYS	Jours d'arrêt maladie	{"description": "Nombre de jours d'absence liés à un arrêt maladie reconnu.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	DAY	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	SICK_LEAVE_HOURS	Heures d'arrêt maladie	{"description": "Volume d'heures d'absence liées à un arrêt maladie.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	SUNDAY_HOLIDAY_HOURS	Heures normales du dimanche et jour férié	{"description": "Nombre d'heures de travail non supplémentaires qualifiées comme dimanche et jour férié sur la période. Les majorations éventuelles sont déterminées par les règles de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	SUNDAY_HOURS	Heures normales du dimanche	{"description": "Nombre d'heures de travail non supplémentaires effectuées un dimanche sur la période. Les majorations éventuelles sont déterminées par les règles de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	TRANSPORT_ELIGIBLE_DAYS	Jours éligibles à l'indemnité de transport	{"description": "Nombre de jours remplissant les conditions de l'indemnité de transport.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	DAY	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	TRAVEL_DAYS	Jours de déplacement professionnel	{"description": "Nombre de jours de déplacement professionnel reconnus.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	DAY	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	TRAVEL_ELIGIBLE_DAYS	Jours de déplacement éligibles	{"description": "Jours de déplacement validés pour une indemnité.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	DAY	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	UNAUTHORIZED_ABSENCE_HOURS	Heures d'absence non autorisée	{"description": "Volume d'heures d'absence non autorisées.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	UNPAID_ABSENCE_DAYS	Jours d'absence non rémunérée	{"description": "Nombre de jours d'absence sans maintien de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	DAY	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	UNPAID_AUTHORIZED_ABSENCE_HOURS	Absence autorisée non rémunérée	{"description": "Heures d'absence autorisées ne conservant pas de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	UNPAID_DEDUCTED_ABSENCE_HOURS	Absence non rémunérée déjà déduite	{"description": "Heures d'absence non rémunérées pour lesquelles une déduction a déjà été prise en compte en amont.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	UNPAID_LEAVE_DAYS	Jours de congé sans solde	{"description": "Nombre de jours de congé sans solde pris pendant la période.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	DAY	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	UNPAID_LEAVE_HOURS	Heures de congé sans solde	{"description": "Volume d'heures d'absence correspondant à des congés sans solde.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	WEEKEND_HOLIDAY_HOURS	Heures normales de week-end et jour férié	{"description": "Nombre d'heures de travail non supplémentaires qualifiées comme week-end et jour férié sur la période. Les majorations éventuelles sont déterminées par les règles de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	WEEKEND_HOURS	Heures normales de week-end	{"description": "Nombre d'heures de travail non supplémentaires effectuées pendant le week-end sur la période. Les majorations éventuelles sont déterminées par les règles de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	WEEKEND_SUNDAY_HOLIDAY_HOURS	Heures normales de week-end, dimanche et jour férié	{"description": "Nombre d'heures de travail non supplémentaires qualifiées comme week-end, dimanche et jour férié sur la période. Les majorations éventuelles sont déterminées par les règles de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	WEEKEND_SUNDAY_HOURS	Heures normales de week-end et dimanche	{"description": "Nombre d'heures de travail non supplémentaires qualifiées comme week-end et dimanche sur la période. Les majorations éventuelles sont déterminées par les règles de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	WORKED_DAYS	Jours effectivement travaillés	{"description": "Nombre de jours pendant lesquels un travail effectif a été constaté.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	DAY	0.000000000000	\N	{}	PERIODIC	{INTEGRATION}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	WORKED_DAYS_CORRECTION	Correction de jours travaillés	{"description": "Différence signée de jours travaillés reconnue pour une période antérieure.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	DAY	\N	\N	{}	PERIODIC	{INTEGRATION,SYSTEM}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	WORKED_EQUIVALENT_ABSENCE_HOURS	Absence assimilée à du temps travaillé	{"description": "Heures d'absence reconnues comme équivalentes à des heures travaillées pour certains calculs.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	WORKED_EQUIVALENT_DAYS	Jours assimilés à du travail	{"description": "Nombre de jours non travaillés mais assimilés à du travail pour certaines règles de rémunération.", "localizedLabels": {}, "localizedDescriptions": {}}	INTEGER	DAY	0.000000000000	\N	{}	PERIODIC	{INTEGRATION,SYSTEM}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	WORKED_HOURS	Heures effectivement travaillées	{"description": "Nombre d'heures de travail effectivement réalisées sur la période, hors heures supplémentaires si celles-ci sont collectées séparément.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	0.000000000000	\N	{}	PERIODIC	{IMPORT,INTEGRATION,MANUAL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	WORKED_HOURS_CORRECTION	Correction d'heures travaillées	{"description": "Différence signée d'heures reconnues pour une période antérieure.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY	HOUR	\N	\N	{}	PERIODIC	{INTEGRATION,MANUAL,SYSTEM}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
\.


--
-- Data for Name: input_rule; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.input_rule (id, country_code, rule_code, rule_version, scope_level, company_id, employee_id, collective_agreement, label, valid_from, valid_to, status, identity, publication, scope, legal_reference, rule_target, rule_constraint, severity, resolution_policy, revision) FROM stdin;
\.


--
-- Data for Name: kpi_measurements; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.kpi_measurements (id, company_id, legal_entity_id, employee_id, kpi_code, period_start, period_end, value, unit, source, source_reference, note, status, superseded_by, recorded_by, recorded_at, updated_at, revision) FROM stdin;
\.


--
-- Data for Name: proration_policies; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.proration_policies (id, country_code, lineage, policy_version, label, scope, target, source_reference, temporal_rule, absence_rules, status, valid_from, valid_to, created_at, updated_at, revision) FROM stdin;
5b33e6a3-22d6-4245-b912-5b1f42f43447	CM	33fa5a77-138d-482f-a13a-11ade36f7faf	1	Prorata Salaire de base	{"level": "COUNTRY", "echelon": null, "category": null, "agreement": null, "companyId": null, "employeeId": null, "minSeniorityMonths": null}	{"type": null, "number": "101"}	{"url": null, "title": "Loi Fantasy 2026", "article": null, "publishedOn": null}	{"basis": "CALENDAR_DAYS", "force": "ALLOWED_OPTIONS", "concrete": true, "rounding": null, "triggers": ["EXIT", "ENTRY"], "allowedBases": ["FIXED_30_DAYS", "WORKING_DAYS", "CALENDAR_DAYS"]}	[]	ACTIVE	2026-01-01	\N	2026-10-01 10:26:26.908171+00	2026-10-02 12:25:00.832291+00	2
\.


--
-- Data for Name: remuneration_element; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.remuneration_element (country_code, catalog_version, number, code, label, type, presentation, proration_category, absence_sensitivity, allowed_frequencies, allowed_calculation_methods, allowed_executions, status, valid_from, valid_to, created_at, updated_at, revision) FROM stdin;
CM	1	101	BASE_SALARY	Salaire de base	BASE_SALARY	{"description": "Rémunération contractuelle de référence, versée pour la durée de travail prévue.", "localizedLabels": {}, "localizedDescriptions": {}}	TIME_BASED	SENSITIVE	{BIWEEKLY,DAILY,HOURLY,MONTHLY,SEMI_MONTHLY,WEEKLY}	{FIXED,GRID,HOURLY_WAGE}	{COMPENSATION}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	201	OVERTIME	Heures supplémentaires	OVERTIME	{"description": "Rémunération des heures effectuées au-delà de la durée de travail de référence, majorations comprises.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY_BASED	NOT_SENSITIVE	{BIWEEKLY,MONTHLY,SEMI_MONTHLY,WEEKLY}	{HOURLY_RATE,HOURLY_RATE_MULTIPLIER}	{PAYROLL}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	302	PERFORMANCE_BONUS	Prime de performance	BONUS	{"description": "Prime variable liée à l'atteinte d'objectifs individuels ou collectifs.", "localizedLabels": {}, "localizedDescriptions": {}}	NOT_APPLICABLE	RULE_DRIVEN	{ANNUAL,MONTHLY,ONE_TIME,QUARTERLY,SEMI_ANNUAL}	{FIXED,GRID,PERCENTAGE}	{COMPENSATION}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	303	THIRTEENTH_MONTH	Treizième mois	BONUS	{"description": "Gratification annuelle équivalente à un mois de salaire, proratisée selon la présence.", "localizedLabels": {}, "localizedDescriptions": {}}	TIME_BASED	RULE_DRIVEN	{ANNUAL,SEMI_ANNUAL}	{FIXED,FORMULA,PERCENTAGE}	{COMPENSATION,PAYROLL}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	304	EXCEPTIONAL_BONUS	Prime exceptionnelle	BONUS	{"description": "Prime ponctuelle, sans périodicité ni proratisation.", "localizedLabels": {}, "localizedDescriptions": {}}	NOT_APPLICABLE	NOT_SENSITIVE	{ONE_TIME}	{FIXED}	{COMPENSATION}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	501	TRANSPORT_ALLOWANCE	Indemnité de transport	ALLOWANCE	{"description": "Indemnité périodique couvrant les frais de déplacement domicile-travail.", "localizedLabels": {}, "localizedDescriptions": {}}	TIME_BASED	SENSITIVE	{MONTHLY}	{FIXED,FORMULA}	{COMPENSATION,PAYROLL}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	502	HOUSING_ALLOWANCE	Indemnité de logement	ALLOWANCE	{"description": "Indemnité périodique de logement, forfaitaire ou en pourcentage du salaire de base.", "localizedLabels": {}, "localizedDescriptions": {}}	TIME_BASED	RULE_DRIVEN	{MONTHLY}	{FIXED,PERCENTAGE}	{COMPENSATION,PAYROLL}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	503	MEAL_ALLOWANCE	Indemnité de repas	ALLOWANCE	{"description": "Indemnité versée par jour éligible ; recomptée sur les faits, jamais proratisée.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY_BASED	NOT_SENSITIVE	{MONTHLY}	{FIXED,FORMULA}	{PAYROLL}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	504	ON_CALL_ALLOWANCE	Indemnité d'astreinte	ALLOWANCE	{"description": "Indemnité rémunérant les périodes d'astreinte et, le cas échéant, les interventions.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY_BASED	NOT_SENSITIVE	{MONTHLY}	{FIXED,FORMULA,HOURLY_RATE}	{PAYROLL}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	202	NIGHT_WORK_PREMIUM	Majoration pour travail de nuit	BONUS	{"description": "Majoration des heures normales effectuées de nuit.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY_BASED	NOT_SENSITIVE	{BIWEEKLY,MONTHLY,SEMI_MONTHLY,WEEKLY}	{FIXED,HOURLY_RATE,HOURLY_RATE_MULTIPLIER}	{PAYROLL}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	250	HS20	Heures supps. 20%	OVERTIME	{"localizedLabels": {}, "localizedDescriptions": {}}	NOT_APPLICABLE	NOT_SENSITIVE	{DAILY,HOURLY,MONTHLY,ONE_TIME,WEEKLY}	{HOURLY_RATE_MULTIPLIER}	{PAYROLL}	ACTIVE	2026-10-01	\N	2026-10-01 10:21:01.490504+00	2026-10-01 10:29:03.779915+00	2
CM	2	101	BASE_SALARY	Salaire de base	BASE_SALARY	{"description": "Rémunération contractuelle de référence, versée pour la durée de travail prévue.", "localizedLabels": {}, "localizedDescriptions": {}}	TIME_BASED	SENSITIVE	{BIWEEKLY,DAILY,HOURLY,MONTHLY,SEMI_MONTHLY,WEEKLY}	{FIXED,GRID,HOURLY_WAGE}	{COMPENSATION}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	201	OVERTIME	Heures supplémentaires	OVERTIME	{"description": "Rémunération des heures effectuées au-delà de la durée de travail de référence, majorations comprises.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY_BASED	NOT_SENSITIVE	{BIWEEKLY,MONTHLY,SEMI_MONTHLY,WEEKLY}	{HOURLY_RATE,HOURLY_RATE_MULTIPLIER}	{PAYROLL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	250	HS20	Heures supps. 20%	OVERTIME	{"localizedLabels": {}, "localizedDescriptions": {}}	NOT_APPLICABLE	NOT_SENSITIVE	{DAILY,HOURLY,MONTHLY,ONE_TIME,WEEKLY}	{HOURLY_RATE_MULTIPLIER}	{PAYROLL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	302	PERFORMANCE_BONUS	Prime de performance	BONUS	{"description": "Prime variable liée à l'atteinte d'objectifs individuels ou collectifs.", "localizedLabels": {}, "localizedDescriptions": {}}	NOT_APPLICABLE	RULE_DRIVEN	{ANNUAL,MONTHLY,ONE_TIME,QUARTERLY,SEMI_ANNUAL}	{FIXED,GRID,PERCENTAGE}	{COMPENSATION}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	303	THIRTEENTH_MONTH	Treizième mois	BONUS	{"description": "Gratification annuelle équivalente à un mois de salaire, proratisée selon la présence.", "localizedLabels": {}, "localizedDescriptions": {}}	TIME_BASED	RULE_DRIVEN	{ANNUAL,SEMI_ANNUAL}	{FIXED,FORMULA,PERCENTAGE}	{COMPENSATION,PAYROLL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	304	EXCEPTIONAL_BONUS	Prime exceptionnelle	BONUS	{"description": "Prime ponctuelle, sans périodicité ni proratisation.", "localizedLabels": {}, "localizedDescriptions": {}}	NOT_APPLICABLE	NOT_SENSITIVE	{ONE_TIME}	{FIXED}	{COMPENSATION}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	501	TRANSPORT_ALLOWANCE	Indemnité de transport	ALLOWANCE	{"description": "Indemnité périodique couvrant les frais de déplacement domicile-travail.", "localizedLabels": {}, "localizedDescriptions": {}}	TIME_BASED	SENSITIVE	{MONTHLY}	{FIXED,FORMULA}	{COMPENSATION,PAYROLL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	502	HOUSING_ALLOWANCE	Indemnité de logement	ALLOWANCE	{"description": "Indemnité périodique de logement, forfaitaire ou en pourcentage du salaire de base.", "localizedLabels": {}, "localizedDescriptions": {}}	TIME_BASED	RULE_DRIVEN	{MONTHLY}	{FIXED,PERCENTAGE}	{COMPENSATION,PAYROLL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	503	MEAL_ALLOWANCE	Indemnité de repas	ALLOWANCE	{"description": "Indemnité versée par jour éligible ; recomptée sur les faits, jamais proratisée.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY_BASED	NOT_SENSITIVE	{MONTHLY}	{FIXED,FORMULA}	{PAYROLL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	504	ON_CALL_ALLOWANCE	Indemnité d'astreinte	ALLOWANCE	{"description": "Indemnité rémunérant les périodes d'astreinte et, le cas échéant, les interventions.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY_BASED	NOT_SENSITIVE	{MONTHLY}	{FIXED,FORMULA,HOURLY_RATE}	{PAYROLL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	1	301	SENIORITY_BONUS	Prime d'ancienneté	BONUS	{"description": "Prime liée à l'ancienneté de l'employé, selon un barème ou un pourcentage du salaire de base.", "localizedLabels": {}, "localizedDescriptions": {}}	TIME_BASED	RULE_DRIVEN	{MONTHLY}	{FIXED,GRID,PERCENTAGE}	{COMPENSATION,PAYROLL}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	1	401	SALES_COMMISSION	Commission sur ventes	BONUS	{"description": "Rémunération variable calculée sur les ventes ou la marge éligibles.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY_BASED	NOT_SENSITIVE	{MONTHLY,ONE_TIME,QUARTERLY}	{FIXED,FORMULA,GRID,PERCENTAGE}	{COMPENSATION,PAYROLL}	ACTIVE	2026-10-01	\N	2026-10-01 08:13:19.749433+00	2026-10-01 08:13:19.749433+00	0
CM	2	202	NIGHT_WORK_PREMIUM	Majoration pour travail de nuit	BONUS	{"description": "Majoration des heures normales effectuées de nuit.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY_BASED	NOT_SENSITIVE	{BIWEEKLY,MONTHLY,SEMI_MONTHLY,WEEKLY}	{FIXED,HOURLY_RATE,HOURLY_RATE_MULTIPLIER}	{PAYROLL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	301	SENIORITY_BONUS	Prime d'ancienneté	BONUS	{"description": "Prime liée à l'ancienneté de l'employé, selon un barème ou un pourcentage du salaire de base.", "localizedLabels": {}, "localizedDescriptions": {}}	TIME_BASED	RULE_DRIVEN	{MONTHLY}	{FIXED,GRID,PERCENTAGE}	{COMPENSATION,PAYROLL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
CM	2	401	SALES_COMMISSION	Commission sur ventes	BONUS	{"description": "Rémunération variable calculée sur les ventes ou la marge éligibles.", "localizedLabels": {}, "localizedDescriptions": {}}	QUANTITY_BASED	NOT_SENSITIVE	{MONTHLY,ONE_TIME,QUARTERLY}	{FIXED,FORMULA,GRID,PERCENTAGE}	{COMPENSATION,PAYROLL}	ACTIVE	2026-10-01	\N	2026-10-01 11:00:26.942368+00	2026-10-01 11:00:26.942368+00	0
\.


--
-- Data for Name: remuneration_rule; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.remuneration_rule (id, country_code, rule_code, rule_version, scope_level, company_id, employee_id, collective_agreement, label, valid_from, valid_to, status, identity, publication, scope, legal_reference, rule_target, rule_constraint, severity, resolution_policy, revision) FROM stdin;
\.


--
-- Data for Name: resolution_alerts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.resolution_alerts (id, company_id, legal_entity_id, employee_id, period_start, period_end, subject, family, state, reason, issue, element_code, source_kind, source_id, message, status, first_raised_at, last_seen_at, acknowledged_by, acknowledged_at, cleared_at, revision) FROM stdin;
240d0888-c826-4421-a5b7-0141f09b05c8	96101814-b255-4348-bb24-d5a963439148	\N	c3e1cf30-c450-49ed-9b31-dc6408516405	2026-10-01	2026-10-31	ISSUE:REFERENCE_DATA_UNAVAILABLE:-	\N	\N	\N	REFERENCE_DATA_UNAVAILABLE	\N	\N	\N	Employment reference data unavailable	OPEN	2026-10-01 13:55:02.146347+00	2026-10-01 13:55:02.146347+00	\N	\N	\N	0
cb3391f0-5a5d-414a-ab34-42a26c44608f	96101814-b255-4348-bb24-d5a963439148	9ae734b6-ae8f-4f87-a103-44ba78f70d04	be359e18-b877-4ef8-b3b4-af1450ce2f14	2026-10-01	2026-10-31	LINE:REQUIREMENT:REQUIREMENT:968b1381-a51f-3d6b-945b-192e4e1b9586:CM:302:2026-10-01	REQUIREMENT	REQUIRED	AWAITING_VALUE	\N	CM:302	REQUIREMENT	968b1381-a51f-3d6b-945b-192e4e1b9586	The policy sets no value: a decision must set it	ACKNOWLEDGED	2026-10-01 13:55:02.146347+00	2026-10-01 13:55:02.146347+00	1234567890	2026-10-01 23:46:45.011484+00	\N	1
c717bc47-5435-47ef-a390-d8100bdedd17	96101814-b255-4348-bb24-d5a963439148	9ae734b6-ae8f-4f87-a103-44ba78f70d04	2c99dcac-8793-4032-a34b-af88f7cc12a1	2026-10-01	2026-10-31	LINE:REQUIREMENT:REQUIREMENT:f425463f-d658-3ca8-bd09-8aeabbeb0d54:CM:302:2026-10-01	REQUIREMENT	REQUIRED	AWAITING_VALUE	\N	CM:302	REQUIREMENT	f425463f-d658-3ca8-bd09-8aeabbeb0d54	The policy sets no value: a decision must set it	ACKNOWLEDGED	2026-10-01 13:55:02.146347+00	2026-10-01 13:55:02.146347+00	1234567890	2026-10-02 16:20:40.671003+00	\N	1
\.


--
-- Data for Name: resolution_reminder_schedules; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.resolution_reminder_schedules (id, company_id, legal_entity_id, lead_days, families, active, schedule_version, created_by, created_at, updated_at, revision) FROM stdin;
69bbe2c5-126b-4968-a40a-b2f5143b66c0	96101814-b255-4348-bb24-d5a963439148	9ae734b6-ae8f-4f87-a103-44ba78f70d04	5	RECURRING_REMUNERATION,ONE_TIME_REMUNERATION,REQUIREMENT,BENEFIT,PARAMETER,AWARD	t	1	1234567890	2026-10-01 13:54:01.168919+00	2026-10-01 13:54:01.168919+00	0
\.


--
-- Name: compensation_events_sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.compensation_events_sequence_seq', 2, true);


--
-- Name: benefit_asset_kind benefit_asset_kind_country_code_catalog_version_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.benefit_asset_kind
    ADD CONSTRAINT benefit_asset_kind_country_code_catalog_version_code_key UNIQUE (country_code, catalog_version, code);


--
-- Name: benefit_asset_kind benefit_asset_kind_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.benefit_asset_kind
    ADD CONSTRAINT benefit_asset_kind_pkey PRIMARY KEY (country_code, catalog_version, number);


--
-- Name: benefit_asset_rule benefit_asset_rule_country_code_rule_code_rule_version_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.benefit_asset_rule
    ADD CONSTRAINT benefit_asset_rule_country_code_rule_code_rule_version_key UNIQUE (country_code, rule_code, rule_version);


--
-- Name: benefit_asset_rule benefit_asset_rule_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.benefit_asset_rule
    ADD CONSTRAINT benefit_asset_rule_pkey PRIMARY KEY (id);


--
-- Name: compensation_awards compensation_awards_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.compensation_awards
    ADD CONSTRAINT compensation_awards_pkey PRIMARY KEY (id);


--
-- Name: compensation_catalog compensation_catalog_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.compensation_catalog
    ADD CONSTRAINT compensation_catalog_pkey PRIMARY KEY (country_code, catalog_version);


--
-- Name: compensation_events compensation_events_event_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.compensation_events
    ADD CONSTRAINT compensation_events_event_id_key UNIQUE (event_id);


--
-- Name: compensation_events compensation_events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.compensation_events
    ADD CONSTRAINT compensation_events_pkey PRIMARY KEY (sequence);


--
-- Name: compensation_packages compensation_packages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.compensation_packages
    ADD CONSTRAINT compensation_packages_pkey PRIMARY KEY (id);


--
-- Name: compensation_requirement compensation_requirement_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.compensation_requirement
    ADD CONSTRAINT compensation_requirement_pkey PRIMARY KEY (id);


--
-- Name: eligibility_policy eligibility_policy_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.eligibility_policy
    ADD CONSTRAINT eligibility_policy_pkey PRIMARY KEY (id);


--
-- Name: employee_benefit_assignments employee_benefit_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_benefit_assignments
    ADD CONSTRAINT employee_benefit_assignments_pkey PRIMARY KEY (id);


--
-- Name: employee_compensation_suspensions employee_compensation_suspensions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_compensation_suspensions
    ADD CONSTRAINT employee_compensation_suspensions_pkey PRIMARY KEY (id);


--
-- Name: employee_compensations employee_compensations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_compensations
    ADD CONSTRAINT employee_compensations_pkey PRIMARY KEY (id);


--
-- Name: employee_incentive_assignments employee_incentive_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_incentive_assignments
    ADD CONSTRAINT employee_incentive_assignments_pkey PRIMARY KEY (id);


--
-- Name: employee_package_assignment employee_package_assignment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_package_assignment
    ADD CONSTRAINT employee_package_assignment_pkey PRIMARY KEY (id);


--
-- Name: employee_parameter_assignments employee_parameter_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_parameter_assignments
    ADD CONSTRAINT employee_parameter_assignments_pkey PRIMARY KEY (id);


--
-- Name: flyway_schema_history flyway_schema_history_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flyway_schema_history
    ADD CONSTRAINT flyway_schema_history_pk PRIMARY KEY (installed_rank);


--
-- Name: incentive_plans incentive_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.incentive_plans
    ADD CONSTRAINT incentive_plans_pkey PRIMARY KEY (id);


--
-- Name: input_definition input_definition_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.input_definition
    ADD CONSTRAINT input_definition_pkey PRIMARY KEY (country_code, catalog_version, code);


--
-- Name: input_rule input_rule_country_code_rule_code_rule_version_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.input_rule
    ADD CONSTRAINT input_rule_country_code_rule_code_rule_version_key UNIQUE (country_code, rule_code, rule_version);


--
-- Name: input_rule input_rule_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.input_rule
    ADD CONSTRAINT input_rule_pkey PRIMARY KEY (id);


--
-- Name: kpi_measurements kpi_measurements_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kpi_measurements
    ADD CONSTRAINT kpi_measurements_pkey PRIMARY KEY (id);


--
-- Name: proration_policies proration_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.proration_policies
    ADD CONSTRAINT proration_policies_pkey PRIMARY KEY (id);


--
-- Name: remuneration_element remuneration_element_country_code_catalog_version_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.remuneration_element
    ADD CONSTRAINT remuneration_element_country_code_catalog_version_code_key UNIQUE (country_code, catalog_version, code);


--
-- Name: remuneration_element remuneration_element_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.remuneration_element
    ADD CONSTRAINT remuneration_element_pkey PRIMARY KEY (country_code, catalog_version, number);


--
-- Name: remuneration_rule remuneration_rule_country_code_rule_code_rule_version_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.remuneration_rule
    ADD CONSTRAINT remuneration_rule_country_code_rule_code_rule_version_key UNIQUE (country_code, rule_code, rule_version);


--
-- Name: remuneration_rule remuneration_rule_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.remuneration_rule
    ADD CONSTRAINT remuneration_rule_pkey PRIMARY KEY (id);


--
-- Name: resolution_alerts resolution_alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.resolution_alerts
    ADD CONSTRAINT resolution_alerts_pkey PRIMARY KEY (id);


--
-- Name: resolution_reminder_schedules resolution_reminder_schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.resolution_reminder_schedules
    ADD CONSTRAINT resolution_reminder_schedules_pkey PRIMARY KEY (id);


--
-- Name: compensation_packages uc_compensation_package_version; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.compensation_packages
    ADD CONSTRAINT uc_compensation_package_version UNIQUE (company_id, legal_entity_id, code, package_version);


--
-- Name: eligibility_policy uc_eligibility_policy_version; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.eligibility_policy
    ADD CONSTRAINT uc_eligibility_policy_version UNIQUE (company_id, legal_entity_id, code, policy_version);


--
-- Name: incentive_plans uc_incentive_plan_version; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.incentive_plans
    ADD CONSTRAINT uc_incentive_plan_version UNIQUE (company_id, legal_entity_id, code, plan_version);


--
-- Name: proration_policies uq_proration_version; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.proration_policies
    ADD CONSTRAINT uq_proration_version UNIQUE (lineage, policy_version);


--
-- Name: resolution_alerts uq_resolution_alert_subject; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.resolution_alerts
    ADD CONSTRAINT uq_resolution_alert_subject UNIQUE (company_id, employee_id, period_start, period_end, subject);


--
-- Name: flyway_schema_history_s_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX flyway_schema_history_s_idx ON public.flyway_schema_history USING btree (success);


--
-- Name: idx_benefit_asset_rule_agreement; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_benefit_asset_rule_agreement ON public.benefit_asset_rule USING btree (country_code, collective_agreement);


--
-- Name: idx_benefit_asset_rule_scope; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_benefit_asset_rule_scope ON public.benefit_asset_rule USING btree (country_code, scope_level, company_id, employee_id);


--
-- Name: idx_benefit_asset_rule_validity; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_benefit_asset_rule_validity ON public.benefit_asset_rule USING btree (country_code, status, valid_from, valid_to);


--
-- Name: idx_benefit_assignment_employee; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_benefit_assignment_employee ON public.employee_benefit_assignments USING btree (company_id, employee_id, effective_from, effective_to);


--
-- Name: idx_benefit_assignment_package; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_benefit_assignment_package ON public.employee_benefit_assignments USING btree (package_assignment_id) WHERE (package_assignment_id IS NOT NULL);


--
-- Name: idx_benefit_kind_code; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_benefit_kind_code ON public.benefit_asset_kind USING btree (country_code, code);


--
-- Name: idx_benefit_kind_number_versions; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_benefit_kind_number_versions ON public.benefit_asset_kind USING btree (country_code, number, catalog_version DESC);


--
-- Name: idx_compensation_award_employee; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_compensation_award_employee ON public.compensation_awards USING btree (company_id, employee_id, period_start);


--
-- Name: idx_compensation_award_pending; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_compensation_award_pending ON public.compensation_awards USING btree (company_id, legal_entity_id, period_start) WHERE ((status)::text = 'CALCULATED'::text);


--
-- Name: idx_compensation_event_company; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_compensation_event_company ON public.compensation_events USING btree (company_id, sequence);


--
-- Name: idx_compensation_event_country; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_compensation_event_country ON public.compensation_events USING btree (country_code, sequence) WHERE (company_id IS NULL);


--
-- Name: idx_eligibility_policy_company; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_eligibility_policy_company ON public.eligibility_policy USING btree (company_id, legal_entity_id, status);


--
-- Name: idx_employee_compensation_in_effect; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_employee_compensation_in_effect ON public.employee_compensations USING btree (company_id, employee_id, effective_from, effective_to);


--
-- Name: idx_employee_compensation_package; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_employee_compensation_package ON public.employee_compensations USING btree (package_assignment_id) WHERE (package_assignment_id IS NOT NULL);


--
-- Name: idx_employee_compensation_payable; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_employee_compensation_payable ON public.employee_compensations USING btree (company_id, employee_id, payable_on) WHERE (payable_on IS NOT NULL);


--
-- Name: idx_employee_compensation_scope; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_employee_compensation_scope ON public.employee_compensations USING btree (company_id, legal_entity_id, employee_id, status);


--
-- Name: idx_incentive_assignment_employee; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_incentive_assignment_employee ON public.employee_incentive_assignments USING btree (company_id, employee_id);


--
-- Name: idx_incentive_assignment_plan; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_incentive_assignment_plan ON public.employee_incentive_assignments USING btree (company_id, legal_entity_id, plan_code);


--
-- Name: idx_incentive_plan_company; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_incentive_plan_company ON public.incentive_plans USING btree (company_id, legal_entity_id, status);


--
-- Name: idx_input_code_versions; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_input_code_versions ON public.input_definition USING btree (country_code, code, catalog_version DESC);


--
-- Name: idx_input_rule_agreement; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_input_rule_agreement ON public.input_rule USING btree (country_code, collective_agreement);


--
-- Name: idx_input_rule_scope; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_input_rule_scope ON public.input_rule USING btree (country_code, scope_level, company_id, employee_id);


--
-- Name: idx_input_rule_validity; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_input_rule_validity ON public.input_rule USING btree (country_code, status, valid_from, valid_to);


--
-- Name: idx_kpi_measurement_employee; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_kpi_measurement_employee ON public.kpi_measurements USING btree (company_id, employee_id, period_start);


--
-- Name: idx_package_assignment_employee; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_package_assignment_employee ON public.employee_package_assignment USING btree (company_id, employee_id);


--
-- Name: idx_package_assignment_package; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_package_assignment_package ON public.employee_package_assignment USING btree (company_id, legal_entity_id, package_code, status);


--
-- Name: idx_package_assignment_version; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_package_assignment_version ON public.employee_package_assignment USING btree (package_version_id);


--
-- Name: idx_package_company; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_package_company ON public.compensation_packages USING btree (company_id, legal_entity_id, status);


--
-- Name: idx_parameter_employee; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_parameter_employee ON public.employee_parameter_assignments USING btree (company_id, employee_id, effective_from);


--
-- Name: idx_parameter_package; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_parameter_package ON public.employee_parameter_assignments USING btree (package_assignment_id) WHERE (package_assignment_id IS NOT NULL);


--
-- Name: idx_proration_country_dates; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_proration_country_dates ON public.proration_policies USING btree (country_code, valid_from, valid_to);


--
-- Name: idx_reminder_schedule_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_reminder_schedule_active ON public.resolution_reminder_schedules USING btree (active);


--
-- Name: idx_remuneration_code; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_remuneration_code ON public.remuneration_element USING btree (country_code, code);


--
-- Name: idx_remuneration_number_versions; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_remuneration_number_versions ON public.remuneration_element USING btree (country_code, number, catalog_version DESC);


--
-- Name: idx_remuneration_rule_agreement; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_remuneration_rule_agreement ON public.remuneration_rule USING btree (country_code, collective_agreement);


--
-- Name: idx_remuneration_rule_scope; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_remuneration_rule_scope ON public.remuneration_rule USING btree (country_code, scope_level, company_id, employee_id);


--
-- Name: idx_remuneration_rule_validity; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_remuneration_rule_validity ON public.remuneration_rule USING btree (country_code, status, valid_from, valid_to);


--
-- Name: idx_requirement_employee; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_requirement_employee ON public.compensation_requirement USING btree (company_id, employee_id, occurrence_end);


--
-- Name: idx_requirement_unresolved; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_requirement_unresolved ON public.compensation_requirement USING btree (company_id, legal_entity_id, occurrence_end) WHERE ((status)::text = ANY ((ARRAY['PENDING'::character varying, 'CONFLICT'::character varying])::text[]));


--
-- Name: idx_resolution_alert_employee; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_resolution_alert_employee ON public.resolution_alerts USING btree (company_id, employee_id, period_start);


--
-- Name: idx_resolution_alert_period; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_resolution_alert_period ON public.resolution_alerts USING btree (company_id, period_start, status);


--
-- Name: idx_suspension_employee; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_suspension_employee ON public.employee_compensation_suspensions USING btree (company_id, employee_id);


--
-- Name: idx_suspension_right; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_suspension_right ON public.employee_compensation_suspensions USING btree (company_id, legal_entity_id, employee_id, effective_from, effective_to);


--
-- Name: uq_catalog_draft; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX uq_catalog_draft ON public.compensation_catalog USING btree (country_code) WHERE ((status)::text = 'DRAFT'::text);


--
-- Name: uq_compensation_award_open; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX uq_compensation_award_open ON public.compensation_awards USING btree (assignment_id, period_start) WHERE ((status)::text <> 'REJECTED'::text);


--
-- Name: uq_compensation_package_draft; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX uq_compensation_package_draft ON public.compensation_packages USING btree (company_id, legal_entity_id, code) WHERE ((status)::text = 'DRAFT'::text);


--
-- Name: uq_compensation_package_published; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX uq_compensation_package_published ON public.compensation_packages USING btree (company_id, legal_entity_id, code) WHERE ((status)::text = 'PUBLISHED'::text);


--
-- Name: uq_eligibility_policy_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX uq_eligibility_policy_active ON public.eligibility_policy USING btree (company_id, legal_entity_id, code) WHERE ((status)::text = 'ACTIVE'::text);


--
-- Name: uq_eligibility_policy_draft; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX uq_eligibility_policy_draft ON public.eligibility_policy USING btree (company_id, legal_entity_id, code) WHERE ((status)::text = 'DRAFT'::text);


--
-- Name: uq_employee_compensation_award; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX uq_employee_compensation_award ON public.employee_compensations USING btree (award_id) WHERE (award_id IS NOT NULL);


--
-- Name: uq_employee_compensation_requirement; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX uq_employee_compensation_requirement ON public.employee_compensations USING btree (requirement_id) WHERE (requirement_id IS NOT NULL);


--
-- Name: uq_incentive_plan_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX uq_incentive_plan_active ON public.incentive_plans USING btree (company_id, legal_entity_id, code) WHERE ((status)::text = 'ACTIVE'::text);


--
-- Name: uq_incentive_plan_draft; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX uq_incentive_plan_draft ON public.incentive_plans USING btree (company_id, legal_entity_id, code) WHERE ((status)::text = 'DRAFT'::text);


--
-- Name: uq_kpi_measurement_current; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX uq_kpi_measurement_current ON public.kpi_measurements USING btree (company_id, employee_id, kpi_code, period_start, period_end) WHERE ((status)::text = 'CURRENT'::text);


--
-- Name: uq_proration_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX uq_proration_active ON public.proration_policies USING btree (lineage) WHERE ((status)::text = 'ACTIVE'::text);


--
-- Name: uq_proration_draft; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX uq_proration_draft ON public.proration_policies USING btree (lineage) WHERE ((status)::text = 'DRAFT'::text);


--
-- Name: uq_reminder_schedule_scope; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX uq_reminder_schedule_scope ON public.resolution_reminder_schedules USING btree (company_id, COALESCE(legal_entity_id, ''::character varying), lead_days);


--
-- Name: benefit_asset_kind benefit_asset_kind_country_code_catalog_version_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.benefit_asset_kind
    ADD CONSTRAINT benefit_asset_kind_country_code_catalog_version_fkey FOREIGN KEY (country_code, catalog_version) REFERENCES public.compensation_catalog(country_code, catalog_version);


--
-- Name: compensation_awards compensation_awards_assignment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.compensation_awards
    ADD CONSTRAINT compensation_awards_assignment_id_fkey FOREIGN KEY (assignment_id) REFERENCES public.employee_incentive_assignments(id);


--
-- Name: compensation_awards compensation_awards_plan_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.compensation_awards
    ADD CONSTRAINT compensation_awards_plan_version_id_fkey FOREIGN KEY (plan_version_id) REFERENCES public.incentive_plans(id);


--
-- Name: compensation_requirement compensation_requirement_policy_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.compensation_requirement
    ADD CONSTRAINT compensation_requirement_policy_id_fkey FOREIGN KEY (policy_id) REFERENCES public.eligibility_policy(id);


--
-- Name: employee_benefit_assignments employee_benefit_assignments_package_assignment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_benefit_assignments
    ADD CONSTRAINT employee_benefit_assignments_package_assignment_id_fkey FOREIGN KEY (package_assignment_id) REFERENCES public.employee_package_assignment(id);


--
-- Name: employee_compensations employee_compensations_award_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_compensations
    ADD CONSTRAINT employee_compensations_award_id_fkey FOREIGN KEY (award_id) REFERENCES public.compensation_awards(id);


--
-- Name: employee_compensations employee_compensations_package_assignment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_compensations
    ADD CONSTRAINT employee_compensations_package_assignment_id_fkey FOREIGN KEY (package_assignment_id) REFERENCES public.employee_package_assignment(id);


--
-- Name: employee_compensations employee_compensations_previous_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_compensations
    ADD CONSTRAINT employee_compensations_previous_version_id_fkey FOREIGN KEY (previous_version_id) REFERENCES public.employee_compensations(id);


--
-- Name: employee_compensations employee_compensations_requirement_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_compensations
    ADD CONSTRAINT employee_compensations_requirement_id_fkey FOREIGN KEY (requirement_id) REFERENCES public.compensation_requirement(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: employee_package_assignment employee_package_assignment_package_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_package_assignment
    ADD CONSTRAINT employee_package_assignment_package_version_id_fkey FOREIGN KEY (package_version_id) REFERENCES public.compensation_packages(id);


--
-- Name: employee_package_assignment employee_package_assignment_successor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_package_assignment
    ADD CONSTRAINT employee_package_assignment_successor_id_fkey FOREIGN KEY (successor_id) REFERENCES public.employee_package_assignment(id);


--
-- Name: employee_parameter_assignments employee_parameter_assignments_package_assignment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_parameter_assignments
    ADD CONSTRAINT employee_parameter_assignments_package_assignment_id_fkey FOREIGN KEY (package_assignment_id) REFERENCES public.employee_package_assignment(id);


--
-- Name: input_definition input_definition_country_code_catalog_version_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.input_definition
    ADD CONSTRAINT input_definition_country_code_catalog_version_fkey FOREIGN KEY (country_code, catalog_version) REFERENCES public.compensation_catalog(country_code, catalog_version);


--
-- Name: kpi_measurements kpi_measurements_superseded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kpi_measurements
    ADD CONSTRAINT kpi_measurements_superseded_by_fkey FOREIGN KEY (superseded_by) REFERENCES public.kpi_measurements(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: remuneration_element remuneration_element_country_code_catalog_version_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.remuneration_element
    ADD CONSTRAINT remuneration_element_country_code_catalog_version_fkey FOREIGN KEY (country_code, catalog_version) REFERENCES public.compensation_catalog(country_code, catalog_version);


--
-- PostgreSQL database dump complete
--

\unrestrict BCEsaK7hVrGYCn5DOwElNYV8alqEenfMNUksh8c4btgXdzUjDxqOjsk8u4hzvXK

