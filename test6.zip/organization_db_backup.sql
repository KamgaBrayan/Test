--
-- PostgreSQL database dump
--

\restrict Zy1bIzFfomojwE0nHyyzfMyBUttGT21enwLiMJCcCGbZK3GZNleBjVRUl1mLOSr

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: companies; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.companies (
    id character varying(255) NOT NULL,
    billing_config jsonb,
    commercial_profile jsonb,
    country_code character varying(255) NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    description text,
    email character varying(255),
    legal_info jsonb,
    location jsonb,
    logo text,
    name character varying(255) NOT NULL,
    org_id character varying(255) NOT NULL,
    phone character varying(255),
    status smallint NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    website_url character varying(255),
    CONSTRAINT companies_status_check CHECK (((status >= 0) AND (status <= 2)))
);


ALTER TABLE public.companies OWNER TO postgres;

--
-- Name: company_unit_managers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.company_unit_managers (
    company_id character varying(255) NOT NULL,
    company_unit_id character varying(255) NOT NULL,
    employee_id character varying(255) NOT NULL,
    priority character varying(255) NOT NULL,
    since timestamp(6) with time zone NOT NULL,
    type character varying(255) NOT NULL,
    CONSTRAINT company_unit_managers_priority_check CHECK (((priority)::text = ANY ((ARRAY['PRIMARY'::character varying, 'SECONDARY'::character varying])::text[]))),
    CONSTRAINT company_unit_managers_type_check CHECK (((type)::text = ANY ((ARRAY['HIERARCHICAL'::character varying, 'FUNCTIONAL'::character varying, 'HR'::character varying, 'PROJECT'::character varying])::text[])))
);


ALTER TABLE public.company_unit_managers OWNER TO postgres;

--
-- Name: company_unit_sites; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.company_unit_sites (
    company_id character varying(255) NOT NULL,
    company_unit_id character varying(255) NOT NULL,
    site_id character varying(255) NOT NULL
);


ALTER TABLE public.company_unit_sites OWNER TO postgres;

--
-- Name: company_units; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.company_units (
    company_id character varying(255) NOT NULL,
    unit_id character varying(255) NOT NULL,
    archived_at timestamp(6) with time zone,
    attributes jsonb,
    change_reason text,
    color character varying(255),
    cost_center_code character varying(255),
    country_code character varying(255),
    created_at timestamp(6) with time zone NOT NULL,
    deprecated_at timestamp(6) with time zone,
    description character varying(1000),
    display_order integer,
    effective_from date,
    effective_to date,
    email character varying(255),
    external_references jsonb,
    icon character varying(255),
    legal_entity_id character varying(255),
    main_site_id character varying(255),
    name character varying(255) NOT NULL,
    parent_unit_id character varying(255),
    path character varying(1024),
    phone character varying(255),
    short_name character varying(100),
    status character varying(255),
    successor_id character varying(255),
    timezone character varying(255),
    type_code character varying(255) NOT NULL,
    updated_at timestamp(6) with time zone,
    CONSTRAINT company_units_status_check CHECK (((status)::text = ANY ((ARRAY['ACTIVE'::character varying, 'OBSOLETE'::character varying, 'ARCHIVED'::character varying])::text[])))
);


ALTER TABLE public.company_units OWNER TO postgres;

--
-- Name: documents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.documents (
    id character varying(255) NOT NULL,
    data oid NOT NULL,
    format character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    "timestamp" timestamp(6) without time zone NOT NULL,
    CONSTRAINT documents_format_check CHECK (((format)::text = ANY ((ARRAY['PNG'::character varying, 'JPEG'::character varying, 'CSV'::character varying, 'XLS'::character varying, 'PDF'::character varying])::text[])))
);


ALTER TABLE public.documents OWNER TO postgres;

--
-- Name: industry_sectors; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.industry_sectors (
    id character varying(255) NOT NULL,
    code character varying(255) NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    description text,
    name character varying(255) NOT NULL,
    parent_code character varying(255),
    status character varying(255) NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    CONSTRAINT industry_sectors_status_check CHECK (((status)::text = ANY ((ARRAY['DRAFT'::character varying, 'ACTIVE'::character varying, 'ARCHIVED'::character varying])::text[])))
);


ALTER TABLE public.industry_sectors OWNER TO postgres;

--
-- Name: legal_entities; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.legal_entities (
    company_id character varying(255) NOT NULL,
    legal_entity_id character varying(255) NOT NULL,
    country_code character varying(255) NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    description text,
    dissolved_at timestamp(6) with time zone,
    external_references jsonb,
    headquarters jsonb,
    incorporated_on date,
    legal_info jsonb,
    name character varying(255) NOT NULL,
    parent_id character varying(255),
    registration_number character varying(255),
    representative jsonb,
    status smallint NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    CONSTRAINT legal_entities_status_check CHECK (((status >= 0) AND (status <= 1)))
);


ALTER TABLE public.legal_entities OWNER TO postgres;

--
-- Name: provider_company_units; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.provider_company_units (
    company_id character varying(255) NOT NULL,
    provider_id character varying(255) NOT NULL,
    company_unit_id character varying(255) NOT NULL
);


ALTER TABLE public.provider_company_units OWNER TO postgres;

--
-- Name: provider_service_domains; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.provider_service_domains (
    company_id character varying(255) NOT NULL,
    provider_id character varying(255) NOT NULL,
    service_domain character varying(255) NOT NULL
);


ALTER TABLE public.provider_service_domains OWNER TO postgres;

--
-- Name: provider_sites; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.provider_sites (
    company_id character varying(255) NOT NULL,
    provider_id character varying(255) NOT NULL,
    site_id character varying(255) NOT NULL
);


ALTER TABLE public.provider_sites OWNER TO postgres;

--
-- Name: providers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.providers (
    company_id character varying(255) NOT NULL,
    provider_id character varying(255) NOT NULL,
    blacklisted_at timestamp(6) with time zone,
    contacts jsonb,
    country_code character varying(255),
    created_at timestamp(6) with time zone NOT NULL,
    description text,
    engaged_from date,
    engaged_until date,
    engagements jsonb,
    insurance_expires_on date,
    kind character varying(255) NOT NULL,
    location jsonb,
    name character varying(255) NOT NULL,
    registration_number character varying(255),
    status character varying(255) NOT NULL,
    status_reason text,
    suspended_at timestamp(6) with time zone,
    tax_identifier character varying(255),
    terminated_at timestamp(6) with time zone,
    updated_at timestamp(6) with time zone,
    vigilance_certificate_expires_on date,
    website_url character varying(255),
    CONSTRAINT providers_kind_check CHECK (((kind)::text = ANY ((ARRAY['COMPANY'::character varying, 'INDEPENDENT'::character varying, 'TEMPORARY_WORK_AGENCY'::character varying, 'TRAINING_ORGANIZATION'::character varying, 'SUBCONTRACTOR'::character varying, 'OTHER'::character varying])::text[]))),
    CONSTRAINT providers_status_check CHECK (((status)::text = ANY ((ARRAY['DRAFT'::character varying, 'ACTIVE'::character varying, 'SUSPENDED'::character varying, 'TERMINATED'::character varying, 'BLACKLISTED'::character varying])::text[])))
);


ALTER TABLE public.providers OWNER TO postgres;

--
-- Name: sites; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sites (
    company_id character varying(255) NOT NULL,
    site_id character varying(255) NOT NULL,
    attributes jsonb,
    capacity jsonb,
    closed_at timestamp(6) with time zone,
    contacts jsonb,
    created_at timestamp(6) with time zone NOT NULL,
    description text,
    external_references jsonb,
    location jsonb,
    name character varying(255) NOT NULL,
    opened_on date,
    parent_id character varying(255),
    remote boolean NOT NULL,
    status smallint NOT NULL,
    timezone character varying(255),
    type_code character varying(255) NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    CONSTRAINT sites_status_check CHECK (((status >= 0) AND (status <= 1)))
);


ALTER TABLE public.sites OWNER TO postgres;

--
-- Name: structure_type_definitions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.structure_type_definitions (
    code character varying(255) NOT NULL,
    company_id character varying(255) NOT NULL,
    scope character varying(255) NOT NULL,
    allowed_child_codes jsonb,
    attributes jsonb,
    color character varying(255),
    created_at timestamp(6) with time zone NOT NULL,
    description text,
    display_order integer,
    icon character varying(255),
    label jsonb,
    type_level integer NOT NULL,
    is_standard boolean NOT NULL,
    status character varying(255) NOT NULL,
    updated_at timestamp(6) with time zone,
    CONSTRAINT structure_type_definitions_scope_check CHECK (((scope)::text = ANY ((ARRAY['UNIT'::character varying, 'SITE'::character varying])::text[]))),
    CONSTRAINT structure_type_definitions_status_check CHECK (((status)::text = ANY ((ARRAY['ACTIVE'::character varying, 'ARCHIVED'::character varying])::text[])))
);


ALTER TABLE public.structure_type_definitions OWNER TO postgres;

--
-- Data for Name: companies; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.companies (id, billing_config, commercial_profile, country_code, created_at, description, email, legal_info, location, logo, name, org_id, phone, status, updated_at, website_url) FROM stdin;
96101814-b255-4348-bb24-d5a963439148	{"currency": "XAF", "billingAddress": "{\\"zipcode\\":\\"9090\\",\\"country\\":\\"Cameroon\\",\\"city\\":\\"Douala\\",\\"countryCode\\":\\"CM\\",\\"street\\":\\"Rue Njoh Njoh\\",\\"state\\":\\"Littoral\\"}", "taxCountryCode": "CM"}	{"revision": 1, "updatedAt": 1789115417.910549017, "companyKind": "PRIVATE_COMPANY", "industryCode": "ESN", "headcountValue": 2, "headcountSource": "DECLARED", "operatingCountries": ["CM"], "headcountObservedAt": 1789115417.910549017}	CM	2026-09-11 08:30:18.294187+00	Opur SAR	\N	\N	{"city": "Douala", "state": "Littoral", "street": "Rue Njoh Njoh", "country": "Cameroon", "zipcode": "9090", "countryCode": "CM"}	\N	Opur SAR	96101814-b255-4348-bb24-d5a963439148	\N	0	2026-09-11 08:30:18.294188+00	\N
\.


--
-- Data for Name: company_unit_managers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.company_unit_managers (company_id, company_unit_id, employee_id, priority, since, type) FROM stdin;
96101814-b255-4348-bb24-d5a963439148	service-paie	bb788d50-f3d8-4b9a-b54e-2fcc530465b2	PRIMARY	2026-09-13 17:11:40.022156+00	HIERARCHICAL
\.


--
-- Data for Name: company_unit_sites; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.company_unit_sites (company_id, company_unit_id, site_id) FROM stdin;
96101814-b255-4348-bb24-d5a963439148	departement-des-ventes	DLA-HQ
96101814-b255-4348-bb24-d5a963439148	direction-des-ressources-humaines	DLA-HQ
96101814-b255-4348-bb24-d5a963439148	service-paie	DLA-HQ
\.


--
-- Data for Name: company_units; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.company_units (company_id, unit_id, archived_at, attributes, change_reason, color, cost_center_code, country_code, created_at, deprecated_at, description, display_order, effective_from, effective_to, email, external_references, icon, legal_entity_id, main_site_id, name, parent_unit_id, path, phone, short_name, status, successor_id, timezone, type_code, updated_at) FROM stdin;
96101814-b255-4348-bb24-d5a963439148	departement-des-ventes	\N	\N	RAS	\N	\N	\N	2026-09-11 13:56:34.901369+00	\N	Département des Ventes	1	2026-09-11	\N	cteuboutonzong@gmail.com	\N	\N	9ae734b6-ae8f-4f87-a103-44ba78f70d04	DLA-HQ	Département des Ventes	\N	/departement-des-ventes/	678252276	DVI	ACTIVE	\N	Africa/Douala	DEPARTMENT	2026-09-11 13:56:34.90137+00
96101814-b255-4348-bb24-d5a963439148	direction-des-ressources-humaines	\N	{"numero_d_urgence": "694567219"}	\N	\N	\N	\N	2026-09-11 21:28:39.525061+00	\N	Direction des ressources humaines	0	2026-09-11	\N	drh@gmail.com	\N	\N	9ae734b6-ae8f-4f87-a103-44ba78f70d04	DLA-HQ	Direction des ressources humaines	\N	/direction-des-ressources-humaines/	\N	DRH	ACTIVE	\N	Africa/Douala	DIRECTION	2026-09-11 21:28:39.525062+00
96101814-b255-4348-bb24-d5a963439148	service-paie	\N	\N	\N	\N	\N	\N	2026-09-11 21:30:43.037692+00	\N	Service Paie	\N	2026-09-11	\N	\N	\N	\N	9ae734b6-ae8f-4f87-a103-44ba78f70d04	DLA-HQ	Service Paie	direction-des-ressources-humaines	/direction-des-ressources-humaines/service-paie/	\N	DRH-PAIE	ACTIVE	\N	\N	SERVICE	2026-09-13 17:11:40.022234+00
\.


--
-- Data for Name: documents; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.documents (id, data, format, name, "timestamp") FROM stdin;
\.


--
-- Data for Name: industry_sectors; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.industry_sectors (id, code, created_at, description, name, parent_code, status, updated_at) FROM stdin;
a7c93c11-794b-4511-bd48-51d071fc0714	COMM	2026-09-10 21:49:55.100543+00	Communication	Communication	\N	ARCHIVED	2026-09-10 22:49:16.128433+00
71941b6a-ef40-4016-86ce-fa78632d70a7	ESN	2026-09-11 07:57:48.455689+00	Entreprise de service numérique	Entreprise de service numérique	\N	ACTIVE	2026-09-11 08:00:29.688838+00
\.


--
-- Data for Name: legal_entities; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.legal_entities (company_id, legal_entity_id, country_code, created_at, description, dissolved_at, external_references, headquarters, incorporated_on, legal_info, name, parent_id, registration_number, representative, status, updated_at) FROM stdin;
96101814-b255-4348-bb24-d5a963439148	9ae734b6-ae8f-4f87-a103-44ba78f70d04	CM	2026-09-11 08:30:18.294592+00	Opur SAR	\N	\N	{"city": "Douala", "state": "Littoral", "street": "Rue Njoh Njoh", "country": "Cameroon", "zipcode": "9090", "countryCode": "CM"}	2026-09-10	{"legalForm": "SARL", "legalName": "Opur SAR", "taxNumber": "1232334322", "registrationNumber": "RCCM/2026/11", "socialSecurityNumber": "23644152"}	Opur SAR	\N	RCCM/2026/11	{"name": "Teubou Christian", "role": "Directeur", "email": "cteuboutonzong@gmail.com", "phone": "678252276"}	0	2026-09-11 08:30:18.294593+00
\.


--
-- Data for Name: provider_company_units; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.provider_company_units (company_id, provider_id, company_unit_id) FROM stdin;
96101814-b255-4348-bb24-d5a963439148	PRV-001	departement-des-ventes
96101814-b255-4348-bb24-d5a963439148	PRV-001	service-paie
\.


--
-- Data for Name: provider_service_domains; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.provider_service_domains (company_id, provider_id, service_domain) FROM stdin;
96101814-b255-4348-bb24-d5a963439148	PRV-001	Security
\.


--
-- Data for Name: provider_sites; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.provider_sites (company_id, provider_id, site_id) FROM stdin;
96101814-b255-4348-bb24-d5a963439148	PRV-001	DLA-HQ
\.


--
-- Data for Name: providers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.providers (company_id, provider_id, blacklisted_at, contacts, country_code, created_at, description, engaged_from, engaged_until, engagements, insurance_expires_on, kind, location, name, registration_number, status, status_reason, suspended_at, tax_identifier, terminated_at, updated_at, vigilance_certificate_expires_on, website_url) FROM stdin;
96101814-b255-4348-bb24-d5a963439148	PRV-001	\N	\N	CM	2026-09-12 16:09:01.112652+00	This is a security company	2026-09-14	2026-09-29	\N	2026-09-08	COMPANY	{"city": "Douala", "state": "Littoral", "street": "Rue Toyota", "country": "Cameroon", "zipcode": "00237", "countryCode": "CM"}	Atlas Security	aegaegaefaefaefaefa54236	ACTIVE	\N	\N	436ergrsgrsg5wg5	\N	2026-09-12 16:27:08.277936+00	2026-09-07	\N
\.


--
-- Data for Name: sites; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sites (company_id, site_id, attributes, capacity, closed_at, contacts, created_at, description, external_references, location, name, opened_on, parent_id, remote, status, timezone, type_code, updated_at) FROM stdin;
96101814-b255-4348-bb24-d5a963439148	DLA-HQ	\N	\N	\N	\N	2026-09-11 13:09:15.345623+00	Batiment principale incluant la direction	\N	{"city": "Douala", "state": "Littoral", "street": "Rue Toyota", "country": "Cameroon", "zipcode": "9090", "countryCode": "CM"}	Siège Douala	2026-09-01	\N	f	0	Africa/Douala	HEADQUARTERS	2026-09-11 13:09:15.345624+00
\.


--
-- Data for Name: structure_type_definitions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.structure_type_definitions (code, company_id, scope, allowed_child_codes, attributes, color, created_at, description, display_order, icon, label, type_level, is_standard, status, updated_at) FROM stdin;
HEADQUARTERS	96101814-b255-4348-bb24-d5a963439148	SITE	["BRANCH", "OFFICE", "PLANT", "STORE", "WAREHOUSE"]	\N	\N	2026-09-11 13:06:45.867685+00	Établissement principal de l'entreprise	10	\N	{"fr": "Siège social"}	0	t	ACTIVE	2026-09-11 13:06:45.867686+00
BRANCH	96101814-b255-4348-bb24-d5a963439148	SITE	["OFFICE", "STORE"]	\N	\N	2026-09-11 13:06:45.867705+00	Agence ou antenne régionale	20	\N	{"fr": "Agence"}	1	t	ACTIVE	2026-09-11 13:06:45.867705+00
WAREHOUSE	96101814-b255-4348-bb24-d5a963439148	SITE	[]	\N	\N	2026-09-11 13:06:45.867721+00	Entrepôt ou centre logistique	40	\N	{"fr": "Entrepôt"}	1	t	ACTIVE	2026-09-11 13:06:45.867721+00
OFFICE	96101814-b255-4348-bb24-d5a963439148	SITE	[]	\N	\N	2026-09-11 13:06:45.867726+00	Bureau administratif	50	\N	{"fr": "Bureau"}	2	t	ACTIVE	2026-09-11 13:06:45.867726+00
STORE	96101814-b255-4348-bb24-d5a963439148	SITE	[]	\N	\N	2026-09-11 13:06:45.867732+00	Boutique ou point de vente	60	\N	{"fr": "Point de vente"}	2	t	ACTIVE	2026-09-11 13:06:45.867732+00
OTHER	96101814-b255-4348-bb24-d5a963439148	SITE	[]	\N	\N	2026-09-11 13:06:45.867734+00	Type non couvert par le catalogue standard	70	\N	{"fr": "Autre"}	2	t	ACTIVE	2026-09-11 13:06:45.867734+00
PLANT	96101814-b255-4348-bb24-d5a963439148	SITE	["OFFICE", "WAREHOUSE"]	\N	\N	2026-09-11 13:06:45.867712+00	Site de production	30	\N	{"en": "Branch", "fr": "Usine"}	1	t	ACTIVE	2026-09-11 21:38:23.32508+00
DIVISION	96101814-b255-4348-bb24-d5a963439148	UNIT	["DEPARTMENT", "DIRECTION", "SERVICE"]	\N	\N	2026-09-11 13:06:45.865617+00	Grande unité au sein d'un groupe ou d'un département	20	\N	{"fr": "Division"}	1	t	ACTIVE	2026-09-11 13:06:45.865617+00
DEPARTMENT	96101814-b255-4348-bb24-d5a963439148	UNIT	["DIRECTION", "SERVICE", "TEAM"]	\N	\N	2026-09-11 13:06:45.865638+00	Unité principale regroupant plusieurs services	40	\N	{"fr": "Département"}	2	t	ACTIVE	2026-09-11 13:06:45.865638+00
SERVICE	96101814-b255-4348-bb24-d5a963439148	UNIT	["SECTION", "TEAM"]	\N	\N	2026-09-11 13:06:45.865648+00	Sous-division fonctionnelle d'un département	50	\N	{"fr": "Service"}	3	t	ACTIVE	2026-09-11 13:06:45.865648+00
SECTION	96101814-b255-4348-bb24-d5a963439148	UNIT	["TEAM"]	\N	\N	2026-09-11 13:06:45.865662+00	Sous-ensemble d'un service	60	\N	{"fr": "Section"}	4	t	ACTIVE	2026-09-11 13:06:45.865662+00
OFFICE	96101814-b255-4348-bb24-d5a963439148	UNIT	["TEAM"]	\N	\N	2026-09-11 13:06:45.86567+00	Bureau rattaché à un service	70	\N	{"fr": "Bureau"}	4	t	ACTIVE	2026-09-11 13:06:45.86567+00
TEAM	96101814-b255-4348-bb24-d5a963439148	UNIT	[]	\N	\N	2026-09-11 13:06:45.865676+00	Plus petite unité opérationnelle	80	\N	{"fr": "Équipe"}	5	t	ACTIVE	2026-09-11 13:06:45.865676+00
OTHER	96101814-b255-4348-bb24-d5a963439148	UNIT	[]	\N	\N	2026-09-11 13:06:45.865682+00	Type non couvert par le catalogue standard	90	\N	{"fr": "Autre"}	5	t	ACTIVE	2026-09-11 13:06:45.865682+00
DIRECTION	96101814-b255-4348-bb24-d5a963439148	UNIT	["DEPARTMENT", "SERVICE", "TEAM"]	[{"key": "numero_d_urgence", "max": null, "min": null, "type": "TEXT", "label": {"fr": "Numéro d'urgence"}, "options": [], "pattern": null, "required": false, "description": null, "defaultValue": null, "displayOrder": 10}]	\N	2026-09-11 13:06:45.86563+00	Direction fonctionnelle ou opérationnelle	30	\N	{"fr": "Direction"}	1	t	ACTIVE	2026-09-11 14:32:14.577443+00
GROUP	96101814-b255-4348-bb24-d5a963439148	UNIT	["DEPARTMENT", "DIRECTION", "DIVISION"]	\N	\N	2026-09-11 13:06:45.865573+00	Regroupe plusieurs divisions ou départements	10	\N	{"fr": "Groupe"}	0	t	ARCHIVED	2026-09-12 08:51:40.444756+00
\.


--
-- Name: companies companies_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_pkey PRIMARY KEY (id);


--
-- Name: company_unit_managers company_unit_managers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.company_unit_managers
    ADD CONSTRAINT company_unit_managers_pkey PRIMARY KEY (company_id, company_unit_id, employee_id, priority, since, type);


--
-- Name: company_unit_sites company_unit_sites_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.company_unit_sites
    ADD CONSTRAINT company_unit_sites_pkey PRIMARY KEY (company_id, company_unit_id, site_id);


--
-- Name: company_units company_units_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.company_units
    ADD CONSTRAINT company_units_pkey PRIMARY KEY (company_id, unit_id);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: industry_sectors industry_sectors_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.industry_sectors
    ADD CONSTRAINT industry_sectors_pkey PRIMARY KEY (id);


--
-- Name: legal_entities legal_entities_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.legal_entities
    ADD CONSTRAINT legal_entities_pkey PRIMARY KEY (company_id, legal_entity_id);


--
-- Name: provider_company_units provider_company_units_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.provider_company_units
    ADD CONSTRAINT provider_company_units_pkey PRIMARY KEY (company_id, provider_id, company_unit_id);


--
-- Name: provider_service_domains provider_service_domains_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.provider_service_domains
    ADD CONSTRAINT provider_service_domains_pkey PRIMARY KEY (company_id, provider_id, service_domain);


--
-- Name: provider_sites provider_sites_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.provider_sites
    ADD CONSTRAINT provider_sites_pkey PRIMARY KEY (company_id, provider_id, site_id);


--
-- Name: providers providers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.providers
    ADD CONSTRAINT providers_pkey PRIMARY KEY (company_id, provider_id);


--
-- Name: sites sites_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sites
    ADD CONSTRAINT sites_pkey PRIMARY KEY (company_id, site_id);


--
-- Name: structure_type_definitions structure_type_definitions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.structure_type_definitions
    ADD CONSTRAINT structure_type_definitions_pkey PRIMARY KEY (code, company_id, scope);


--
-- Name: industry_sectors uk_industry_sector_code; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.industry_sectors
    ADD CONSTRAINT uk_industry_sector_code UNIQUE (code);


--
-- Name: idx_company_org_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_company_org_id ON public.companies USING btree (org_id);


--
-- Name: idx_company_site_company_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_company_site_company_id ON public.sites USING btree (company_id);


--
-- Name: idx_company_site_parent; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_company_site_parent ON public.sites USING btree (company_id, parent_id);


--
-- Name: idx_company_site_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_company_site_type ON public.sites USING btree (company_id, type_code);


--
-- Name: idx_company_unit_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_company_unit_name ON public.company_units USING btree (name);


--
-- Name: idx_company_unit_parent; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_company_unit_parent ON public.company_units USING btree (parent_unit_id, company_id);


--
-- Name: idx_company_unit_path; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_company_unit_path ON public.company_units USING btree (company_id, path);


--
-- Name: idx_company_unit_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_company_unit_type ON public.company_units USING btree (company_id, type_code);


--
-- Name: idx_industry_sector_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_industry_sector_name ON public.industry_sectors USING btree (name);


--
-- Name: idx_industry_sector_parent_code; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_industry_sector_parent_code ON public.industry_sectors USING btree (parent_code);


--
-- Name: idx_industry_sector_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_industry_sector_status ON public.industry_sectors USING btree (status);


--
-- Name: idx_legal_entity_company_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_legal_entity_company_id ON public.legal_entities USING btree (company_id);


--
-- Name: idx_legal_entity_country; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_legal_entity_country ON public.legal_entities USING btree (company_id, country_code);


--
-- Name: idx_legal_entity_parent; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_legal_entity_parent ON public.legal_entities USING btree (company_id, parent_id);


--
-- Name: idx_legal_entity_registration; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_legal_entity_registration ON public.legal_entities USING btree (company_id, registration_number);


--
-- Name: idx_provider_company_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_provider_company_id ON public.providers USING btree (company_id);


--
-- Name: idx_provider_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_provider_name ON public.providers USING btree (company_id, name);


--
-- Name: idx_provider_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_provider_status ON public.providers USING btree (company_id, status);


--
-- Name: idx_structure_type_scope; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_structure_type_scope ON public.structure_type_definitions USING btree (company_id, scope);


--
-- Name: idx_structure_type_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_structure_type_status ON public.structure_type_definitions USING btree (company_id, scope, status);


--
-- Name: provider_service_domains fk2m6p273a8k72oo576jc4yk2cu; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.provider_service_domains
    ADD CONSTRAINT fk2m6p273a8k72oo576jc4yk2cu FOREIGN KEY (company_id, provider_id) REFERENCES public.providers(company_id, provider_id);


--
-- Name: company_unit_sites fk85w5a3rtqn1f6ayuyj604kloc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.company_unit_sites
    ADD CONSTRAINT fk85w5a3rtqn1f6ayuyj604kloc FOREIGN KEY (company_id, company_unit_id) REFERENCES public.company_units(company_id, unit_id);


--
-- Name: provider_sites fkijnsbnbxv8ytwkxte90ij0gxb; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.provider_sites
    ADD CONSTRAINT fkijnsbnbxv8ytwkxte90ij0gxb FOREIGN KEY (company_id, provider_id) REFERENCES public.providers(company_id, provider_id);


--
-- Name: provider_company_units fko3cjp3rfx8nxmcat073efuquw; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.provider_company_units
    ADD CONSTRAINT fko3cjp3rfx8nxmcat073efuquw FOREIGN KEY (company_id, provider_id) REFERENCES public.providers(company_id, provider_id);


--
-- Name: company_unit_managers fkt8tyv8hcii5idyxj2mew5b9tj; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.company_unit_managers
    ADD CONSTRAINT fkt8tyv8hcii5idyxj2mew5b9tj FOREIGN KEY (company_id, company_unit_id) REFERENCES public.company_units(company_id, unit_id);


--
-- PostgreSQL database dump complete
--

\unrestrict Zy1bIzFfomojwE0nHyyzfMyBUttGT21enwLiMJCcCGbZK3GZNleBjVRUl1mLOSr

