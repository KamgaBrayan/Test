--
-- PostgreSQL database dump
--

\restrict d75zRmrYMnds81u67EnonHi29Dnn08ThfONPFozosvok9yHtcTqDspCI2FZnijn

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: activity_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.activity_groups (
    id character varying(255) NOT NULL,
    activities text[] NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    deprecated boolean,
    description text,
    display_name character varying(255) NOT NULL,
    display_order integer NOT NULL,
    localized_descriptions jsonb,
    localized_display_names jsonb,
    name character varying(255) NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


ALTER TABLE public.activity_groups OWNER TO postgres;

--
-- Name: authorization_grants; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.authorization_grants (
    id character varying(255) NOT NULL,
    authorized_client_id character varying(255),
    context jsonb,
    expires_at timestamp(6) with time zone NOT NULL,
    granted_permissions jsonb NOT NULL,
    invalidated_at timestamp(6) with time zone,
    issued_at timestamp(6) with time zone NOT NULL,
    not_before timestamp(6) with time zone NOT NULL,
    permission_hash character varying(255) NOT NULL,
    policy_traces text[] NOT NULL,
    realm character varying(255) NOT NULL,
    resource_owner character varying(255),
    revoked_at timestamp(6) with time zone,
    status character varying(255) NOT NULL,
    subject character varying(255) NOT NULL,
    suspended_at timestamp(6) with time zone
);


ALTER TABLE public.authorization_grants OWNER TO postgres;

--
-- Name: authorization_resource_policies; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.authorization_resource_policies (
    id character varying(255) NOT NULL,
    conditions jsonb NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    decision_strategy character varying(255) NOT NULL,
    duration_in_seconds bigint,
    owner character varying(255) NOT NULL,
    realm character varying(255) NOT NULL,
    related_resource_type character varying(255) NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


ALTER TABLE public.authorization_resource_policies OWNER TO postgres;

--
-- Name: authorization_resources; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.authorization_resources (
    id character varying(255) NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    display_name character varying(255),
    name character varying(255) NOT NULL,
    owner character varying(255) NOT NULL,
    realm character varying(255) NOT NULL,
    resource_type_name character varying(255) NOT NULL,
    server_name character varying(255) NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


ALTER TABLE public.authorization_resources OWNER TO postgres;

--
-- Name: challenge; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.challenge (
    id character varying(255) NOT NULL,
    data jsonb,
    duration_in_seconds bigint,
    id_hash character varying(255) NOT NULL,
    invalidated boolean NOT NULL,
    invalidated_at timestamp(6) with time zone,
    issued_at timestamp(6) with time zone NOT NULL,
    reason character varying(255) NOT NULL
);


ALTER TABLE public.challenge OWNER TO postgres;

--
-- Name: client_entity_scopes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.client_entity_scopes (
    client_entity_id character varying(255) NOT NULL,
    assigned_at timestamp(6) with time zone,
    scope character varying(255)
);


ALTER TABLE public.client_entity_scopes OWNER TO postgres;

--
-- Name: clients; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.clients (
    id character varying(255) NOT NULL,
    client_authentication_methods character varying(255)[],
    client_settings jsonb,
    created_at timestamp(6) with time zone NOT NULL,
    grant_types character varying(255)[],
    ip_access_control_list jsonb,
    name character varying(255) NOT NULL,
    org_id character varying(255),
    status character varying(255) NOT NULL,
    token_settings jsonb,
    type smallint NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    CONSTRAINT clients_status_check CHECK (((status)::text = ANY ((ARRAY['ENABLED'::character varying, 'DISABLED'::character varying, 'ARCHIVED'::character varying])::text[]))),
    CONSTRAINT clients_type_check CHECK (((type >= 0) AND (type <= 5)))
);


ALTER TABLE public.clients OWNER TO postgres;

--
-- Name: documents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.documents (
    id character varying(255) NOT NULL,
    data oid NOT NULL,
    format character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    "timestamp" timestamp(6) without time zone NOT NULL,
    CONSTRAINT documents_format_check CHECK (((format)::text = ANY ((ARRAY['PNG'::character varying, 'JPEG'::character varying, 'CSV'::character varying, 'XLS'::character varying, 'PDF'::character varying])::text[])))
);


ALTER TABLE public.documents OWNER TO postgres;

--
-- Name: images; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.images (
    id character varying(255) NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    data oid NOT NULL,
    image_format smallint NOT NULL,
    CONSTRAINT images_image_format_check CHECK (((image_format >= 0) AND (image_format <= 5)))
);


ALTER TABLE public.images OWNER TO postgres;

--
-- Name: keys; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.keys (
    id character varying(255) NOT NULL,
    algorithm character varying(255) NOT NULL,
    archived_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone,
    curve character varying(255),
    default_client_certificate boolean,
    expires_at timestamp(6) with time zone,
    key_size integer,
    name character varying(255),
    org_id character varying(255),
    origin character varying(255) NOT NULL,
    priority bigint,
    public_key oid,
    status character varying(255) NOT NULL,
    type character varying(255) NOT NULL,
    use character varying(255) NOT NULL,
    version integer NOT NULL,
    CONSTRAINT keys_origin_check CHECK (((origin)::text = ANY ((ARRAY['GENERATED'::character varying, 'IMPORTED'::character varying, 'EXTERNAL'::character varying])::text[]))),
    CONSTRAINT keys_status_check CHECK (((status)::text = ANY ((ARRAY['ACTIVE'::character varying, 'PASSIVE'::character varying, 'DISABLED'::character varying])::text[]))),
    CONSTRAINT keys_type_check CHECK (((type)::text = ANY ((ARRAY['RSA'::character varying, 'EC'::character varying, 'OCT'::character varying, 'OKP'::character varying])::text[]))),
    CONSTRAINT keys_use_check CHECK (((use)::text = ANY ((ARRAY['SIG'::character varying, 'ENC'::character varying])::text[])))
);


ALTER TABLE public.keys OWNER TO postgres;

--
-- Name: login_events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.login_events (
    id character varying(255) NOT NULL,
    occurred_at timestamp(6) with time zone NOT NULL,
    org_id character varying(255),
    user_id character varying(255) NOT NULL
);


ALTER TABLE public.login_events OWNER TO postgres;

--
-- Name: mv_daily_login_counts; Type: MATERIALIZED VIEW; Schema: public; Owner: postgres
--

CREATE MATERIALIZED VIEW public.mv_daily_login_counts AS
 SELECT (date_trunc('day'::text, occurred_at))::date AS day,
    count(*) AS count
   FROM public.login_events
  GROUP BY ((date_trunc('day'::text, occurred_at))::date)
  WITH NO DATA;


ALTER MATERIALIZED VIEW public.mv_daily_login_counts OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id character varying(255) NOT NULL,
    address character varying(255),
    created_at timestamp(6) with time zone NOT NULL,
    email character varying(255),
    email_verified boolean,
    email_verified_at timestamp(6) with time zone,
    first_name character varying(255),
    gender character varying(255),
    last_login text,
    last_name character varying(255),
    org_id character varying(255),
    phone character varying(255),
    phone_verified boolean,
    phone_verified_at timestamp(6) with time zone,
    roles character varying[],
    status character varying(255) NOT NULL,
    type character varying(255),
    updated_at timestamp(6) with time zone,
    user_security jsonb NOT NULL,
    username character varying(255) NOT NULL,
    CONSTRAINT users_gender_check CHECK (((gender)::text = ANY ((ARRAY['MALE'::character varying, 'FEMALE'::character varying])::text[]))),
    CONSTRAINT users_status_check CHECK (((status)::text = ANY ((ARRAY['ENABLED'::character varying, 'DISABLED'::character varying, 'LOCKED'::character varying, 'ARCHIVED'::character varying, 'NOT_VERIFIED'::character varying])::text[]))),
    CONSTRAINT users_type_check CHECK (((type)::text = ANY ((ARRAY['MANAGED'::character varying, 'UNMANAGED'::character varying])::text[])))
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: mv_daily_new_user_counts; Type: MATERIALIZED VIEW; Schema: public; Owner: postgres
--

CREATE MATERIALIZED VIEW public.mv_daily_new_user_counts AS
 SELECT (date_trunc('day'::text, created_at))::date AS day,
    count(*) AS count
   FROM public.users
  GROUP BY ((date_trunc('day'::text, created_at))::date)
  WITH NO DATA;


ALTER MATERIALIZED VIEW public.mv_daily_new_user_counts OWNER TO postgres;

--
-- Name: organization_access_approval_circuits; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.organization_access_approval_circuits (
    circuit_id character varying(255) NOT NULL,
    org_id character varying(255) NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    description text,
    enabled boolean NOT NULL,
    entries text[],
    item_types text[],
    name character varying(255) NOT NULL,
    priority integer NOT NULL,
    risk_levels text[],
    stages jsonb NOT NULL,
    temporary_only boolean,
    updated_at timestamp(6) with time zone NOT NULL
);


ALTER TABLE public.organization_access_approval_circuits OWNER TO postgres;

--
-- Name: organization_access_catalog; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.organization_access_catalog (
    entry_id character varying(255) NOT NULL,
    org_id character varying(255) NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    description text,
    enabled boolean NOT NULL,
    justification_required boolean NOT NULL,
    label character varying(255) NOT NULL,
    max_duration bigint,
    risk_level character varying(255) NOT NULL,
    target_id character varying(255) NOT NULL,
    type character varying(255) NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    CONSTRAINT organization_access_catalog_risk_level_check CHECK (((risk_level)::text = ANY ((ARRAY['LOW'::character varying, 'STANDARD'::character varying, 'HIGH'::character varying, 'CRITICAL'::character varying])::text[]))),
    CONSTRAINT organization_access_catalog_type_check CHECK (((type)::text = ANY ((ARRAY['ROLE'::character varying, 'GROUP'::character varying, 'PROFILE'::character varying])::text[])))
);


ALTER TABLE public.organization_access_catalog OWNER TO postgres;

--
-- Name: organization_access_certification_campaigns; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.organization_access_certification_campaigns (
    campaign_id character varying(255) NOT NULL,
    org_id character varying(255) NOT NULL,
    closed_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone NOT NULL,
    description text,
    due_at timestamp(6) with time zone,
    expiry_policy character varying(255) NOT NULL,
    groups text[],
    name character varying(255) NOT NULL,
    opened_at timestamp(6) with time zone,
    profiles text[],
    reviewer_roles text[],
    status character varying(255) NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    user_ids text[],
    CONSTRAINT organization_access_certification_campaigns_expiry_policy_check CHECK (((expiry_policy)::text = ANY ((ARRAY['REVOKE'::character varying, 'KEEP'::character varying])::text[]))),
    CONSTRAINT organization_access_certification_campaigns_status_check CHECK (((status)::text = ANY ((ARRAY['DRAFT'::character varying, 'RUNNING'::character varying, 'CLOSED'::character varying, 'CANCELLED'::character varying])::text[])))
);


ALTER TABLE public.organization_access_certification_campaigns OWNER TO postgres;

--
-- Name: organization_access_certification_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.organization_access_certification_items (
    item_id character varying(255) NOT NULL,
    access_type character varying(255) NOT NULL,
    application_note text,
    applied_at timestamp(6) with time zone,
    campaign_id character varying(255) NOT NULL,
    comment text,
    created_at timestamp(6) with time zone NOT NULL,
    decided_at timestamp(6) with time zone,
    decided_by character varying(255),
    decision character varying(255) NOT NULL,
    org_id character varying(255) NOT NULL,
    reviewer_id character varying(255),
    sources text[],
    target_id character varying(255) NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    user_id character varying(255) NOT NULL,
    CONSTRAINT organization_access_certification_items_access_type_check CHECK (((access_type)::text = ANY ((ARRAY['ROLE'::character varying, 'GROUP'::character varying, 'PROFILE'::character varying])::text[]))),
    CONSTRAINT organization_access_certification_items_decision_check CHECK (((decision)::text = ANY ((ARRAY['PENDING'::character varying, 'MAINTAIN'::character varying, 'REVOKE'::character varying, 'MODIFY'::character varying])::text[])))
);


ALTER TABLE public.organization_access_certification_items OWNER TO postgres;

--
-- Name: organization_access_request_decisions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.organization_access_request_decisions (
    request_id character varying(255) NOT NULL,
    comment text,
    decided_at timestamp(6) with time zone NOT NULL,
    decided_by character varying(255),
    outcome character varying(255) NOT NULL,
    stage character varying(255),
    decision_order integer NOT NULL,
    CONSTRAINT organization_access_request_decisions_outcome_check CHECK (((outcome)::text = ANY ((ARRAY['APPROVED'::character varying, 'REJECTED'::character varying])::text[])))
);


ALTER TABLE public.organization_access_request_decisions OWNER TO postgres;

--
-- Name: organization_access_request_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.organization_access_request_items (
    request_id character varying(255) NOT NULL,
    entry_id character varying(255) NOT NULL,
    target_id character varying(255) NOT NULL,
    type character varying(255) NOT NULL,
    CONSTRAINT organization_access_request_items_type_check CHECK (((type)::text = ANY ((ARRAY['ROLE'::character varying, 'GROUP'::character varying, 'PROFILE'::character varying])::text[])))
);


ALTER TABLE public.organization_access_request_items OWNER TO postgres;

--
-- Name: organization_access_request_resources; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.organization_access_request_resources (
    request_id character varying(255) NOT NULL,
    resource_name character varying(255),
    resource_type_name character varying(255) NOT NULL
);


ALTER TABLE public.organization_access_request_resources OWNER TO postgres;

--
-- Name: organization_access_requests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.organization_access_requests (
    request_id character varying(255) NOT NULL,
    applied_at timestamp(6) with time zone,
    beneficiary_id character varying(255) NOT NULL,
    circuit_id character varying(255),
    created_at timestamp(6) with time zone NOT NULL,
    current_stage_order integer,
    decided_at timestamp(6) with time zone,
    duration bigint,
    granted_policy_ids text[],
    justification text,
    org_id character varying(255) NOT NULL,
    outcome_reason text,
    requester_id character varying(255) NOT NULL,
    risk_level character varying(255) NOT NULL,
    status character varying(255) NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    warned_activities text[],
    CONSTRAINT organization_access_requests_risk_level_check CHECK (((risk_level)::text = ANY ((ARRAY['LOW'::character varying, 'STANDARD'::character varying, 'HIGH'::character varying, 'CRITICAL'::character varying])::text[]))),
    CONSTRAINT organization_access_requests_status_check CHECK (((status)::text = ANY ((ARRAY['PENDING'::character varying, 'APPROVED'::character varying, 'REJECTED'::character varying, 'CANCELLED'::character varying, 'APPLIED'::character varying, 'FAILED'::character varying])::text[])))
);


ALTER TABLE public.organization_access_requests OWNER TO postgres;

--
-- Name: organization_activities; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.organization_activities (
    id character varying(255) NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    deprecated boolean,
    description text,
    display_name character varying(255) NOT NULL,
    localized_descriptions jsonb,
    localized_display_names jsonb,
    name character varying(255) NOT NULL,
    scopes text[] NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


ALTER TABLE public.organization_activities OWNER TO postgres;

--
-- Name: organization_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.organization_groups (
    group_id character varying(255) NOT NULL,
    org_id character varying(255) NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    description character varying(255),
    external_ref character varying(255),
    external_source character varying(255),
    managed boolean NOT NULL,
    name character varying(255) NOT NULL,
    parent_id character varying(255),
    roles text[],
    status character varying(255) NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    CONSTRAINT organization_groups_status_check CHECK (((status)::text = ANY ((ARRAY['ACTIVE'::character varying, 'ARCHIVED'::character varying])::text[])))
);


ALTER TABLE public.organization_groups OWNER TO postgres;

--
-- Name: organization_invitations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.organization_invitations (
    id character varying(255) NOT NULL,
    approved_at timestamp(6) with time zone,
    email character varying(255) NOT NULL,
    expires_at timestamp(6) with time zone NOT NULL,
    first_name character varying(255),
    gender character varying(255),
    id_hash character varying(255) NOT NULL,
    last_name character varying(255),
    org_id character varying(255) NOT NULL,
    rejected_at timestamp(6) with time zone,
    sent_at timestamp(6) with time zone NOT NULL,
    status character varying(255) NOT NULL,
    CONSTRAINT organization_invitations_gender_check CHECK (((gender)::text = ANY ((ARRAY['MALE'::character varying, 'FEMALE'::character varying])::text[]))),
    CONSTRAINT organization_invitations_status_check CHECK (((status)::text = ANY ((ARRAY['PENDING'::character varying, 'APPROVED'::character varying, 'REJECTED'::character varying])::text[])))
);


ALTER TABLE public.organization_invitations OWNER TO postgres;

--
-- Name: organization_member_group_assignments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.organization_member_group_assignments (
    organization_member_entity_org_id character varying(255) NOT NULL,
    organization_member_entity_user_id character varying(255) NOT NULL,
    assigned_at timestamp(6) with time zone NOT NULL,
    group_id character varying(255) NOT NULL,
    source character varying(255) NOT NULL,
    CONSTRAINT organization_member_group_assignments_source_check CHECK (((source)::text = ANY ((ARRAY['MANUAL'::character varying, 'MANAGED'::character varying])::text[])))
);


ALTER TABLE public.organization_member_group_assignments OWNER TO postgres;

--
-- Name: organization_member_profiles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.organization_member_profiles (
    org_id character varying(255) NOT NULL,
    profile_id character varying(255) NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    default_groups text[],
    default_roles text[],
    description character varying(255),
    name character varying(255) NOT NULL,
    status character varying(255) NOT NULL,
    system boolean NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    CONSTRAINT organization_member_profiles_status_check CHECK (((status)::text = ANY ((ARRAY['ACTIVE'::character varying, 'ARCHIVED'::character varying])::text[])))
);


ALTER TABLE public.organization_member_profiles OWNER TO postgres;

--
-- Name: organization_member_role_assignments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.organization_member_role_assignments (
    organization_member_entity_org_id character varying(255) NOT NULL,
    organization_member_entity_user_id character varying(255) NOT NULL,
    assigned_at timestamp(6) with time zone NOT NULL,
    role_id character varying(255) NOT NULL
);


ALTER TABLE public.organization_member_role_assignments OWNER TO postgres;

--
-- Name: organization_member_roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.organization_member_roles (
    org_id character varying(255) NOT NULL,
    user_id character varying(255) NOT NULL,
    archived_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone NOT NULL,
    member_profiles text[],
    status character varying(255) NOT NULL,
    suspended_at timestamp(6) with time zone,
    updated_at timestamp(6) with time zone NOT NULL,
    CONSTRAINT organization_member_roles_status_check CHECK (((status)::text = ANY ((ARRAY['ACTIVE'::character varying, 'SUSPENDED'::character varying, 'ARCHIVED'::character varying])::text[])))
);


ALTER TABLE public.organization_member_roles OWNER TO postgres;

--
-- Name: organization_permission_usages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.organization_permission_usages (
    org_id character varying(255) NOT NULL,
    permission character varying(255) NOT NULL,
    user_id character varying(255) NOT NULL,
    last_used_at timestamp(6) with time zone NOT NULL
);


ALTER TABLE public.organization_permission_usages OWNER TO postgres;

--
-- Name: organization_role_delegations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.organization_role_delegations (
    delegation_id character varying(255) NOT NULL,
    org_id character varying(255) NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    delegate_id character varying(255) NOT NULL,
    delegator_id character varying(255) NOT NULL,
    groups text[],
    reason character varying(255),
    revoked_at timestamp(6) with time zone,
    revoked_by character varying(255),
    roles text[],
    status character varying(255) NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    valid_from timestamp(6) with time zone NOT NULL,
    valid_until timestamp(6) with time zone NOT NULL,
    CONSTRAINT organization_role_delegations_status_check CHECK (((status)::text = ANY ((ARRAY['ACTIVE'::character varying, 'REVOKED'::character varying, 'EXPIRED'::character varying])::text[])))
);


ALTER TABLE public.organization_role_delegations OWNER TO postgres;

--
-- Name: organization_roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.organization_roles (
    org_id character varying(255) NOT NULL,
    role_id character varying(255) NOT NULL,
    activities text[],
    created_at timestamp(6) with time zone NOT NULL,
    description character varying(255),
    name character varying(255) NOT NULL,
    system boolean NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


ALTER TABLE public.organization_roles OWNER TO postgres;

--
-- Name: organization_security_policies; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.organization_security_policies (
    org_id character varying(255) NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    device_check_enabled boolean,
    ip_access_control_list jsonb,
    lock_duration bigint,
    locked_user_check_enabled boolean,
    max_login_attempts integer,
    multifactorial_required_always boolean,
    multifactorial_required_on_risky_login boolean,
    password_config jsonb,
    updated_at timestamp(6) with time zone NOT NULL,
    updated_by character varying(255)
);


ALTER TABLE public.organization_security_policies OWNER TO postgres;

--
-- Name: organization_segregation_rules; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.organization_segregation_rules (
    org_id character varying(255) NOT NULL,
    rule_id character varying(255) NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    description character varying(255),
    enabled boolean NOT NULL,
    left_activities text[],
    name character varying(255) NOT NULL,
    right_activities text[],
    severity character varying(255) NOT NULL,
    system boolean NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    CONSTRAINT organization_segregation_rules_severity_check CHECK (((severity)::text = ANY ((ARRAY['BLOCKING'::character varying, 'WARNING'::character varying])::text[])))
);


ALTER TABLE public.organization_segregation_rules OWNER TO postgres;

--
-- Name: organization_segregation_violations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.organization_segregation_violations (
    org_id character varying(255) NOT NULL,
    violation_id character varying(255) NOT NULL,
    conflicting_activities text[],
    created_at timestamp(6) with time zone NOT NULL,
    detected_at timestamp(6) with time zone NOT NULL,
    resolved_at timestamp(6) with time zone,
    rule_id character varying(255) NOT NULL,
    severity character varying(255) NOT NULL,
    status character varying(255) NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    user_id character varying(255) NOT NULL,
    waived_at timestamp(6) with time zone,
    waived_by character varying(255),
    waiver_reason character varying(255),
    waiver_until timestamp(6) with time zone,
    CONSTRAINT organization_segregation_violations_severity_check CHECK (((severity)::text = ANY ((ARRAY['BLOCKING'::character varying, 'WARNING'::character varying])::text[]))),
    CONSTRAINT organization_segregation_violations_status_check CHECK (((status)::text = ANY ((ARRAY['OPEN'::character varying, 'WAIVED'::character varying, 'RESOLVED'::character varying])::text[])))
);


ALTER TABLE public.organization_segregation_violations OWNER TO postgres;

--
-- Name: organization_system_role_definitions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.organization_system_role_definitions (
    role_id character varying(255) NOT NULL,
    activities text[],
    created_at timestamp(6) with time zone NOT NULL,
    description text,
    name character varying(255) NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


ALTER TABLE public.organization_system_role_definitions OWNER TO postgres;

--
-- Name: organization_temporary_access_grants; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.organization_temporary_access_grants (
    grant_id character varying(255) NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    emergency boolean NOT NULL,
    expiry_notice_sent_at timestamp(6) with time zone,
    granted_groups text[],
    granted_policy_ids text[],
    granted_profiles text[],
    granted_roles text[],
    org_id character varying(255) NOT NULL,
    reason text,
    request_id character varying(255),
    review_note text,
    reviewed_at timestamp(6) with time zone,
    reviewed_by character varying(255),
    revocation_reason text,
    revoked_at timestamp(6) with time zone,
    revoked_by character varying(255),
    status character varying(255) NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    user_id character varying(255) NOT NULL,
    valid_from timestamp(6) with time zone NOT NULL,
    valid_until timestamp(6) with time zone NOT NULL,
    CONSTRAINT organization_temporary_access_grants_status_check CHECK (((status)::text = ANY ((ARRAY['ACTIVE'::character varying, 'EXPIRED'::character varying, 'REVOKED'::character varying])::text[])))
);


ALTER TABLE public.organization_temporary_access_grants OWNER TO postgres;

--
-- Name: organizations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.organizations (
    id character varying(255) NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    description text,
    login_code character varying(255),
    logo text,
    name character varying(255) NOT NULL,
    rich_description text,
    status character varying(255) NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    website_url character varying(1025),
    CONSTRAINT organizations_status_check CHECK (((status)::text = ANY ((ARRAY['ENABLED'::character varying, 'DISABLED'::character varying, 'ARCHIVED'::character varying])::text[])))
);


ALTER TABLE public.organizations OWNER TO postgres;

--
-- Name: resource_policy_entity_authorized_actions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.resource_policy_entity_authorized_actions (
    resource_policy_entity_id character varying(255) NOT NULL,
    authorized_actions character varying(255) NOT NULL
);


ALTER TABLE public.resource_policy_entity_authorized_actions OWNER TO postgres;

--
-- Name: resource_policy_entity_related_resources; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.resource_policy_entity_related_resources (
    resource_policy_entity_id character varying(255) NOT NULL,
    related_resources character varying(255)
);


ALTER TABLE public.resource_policy_entity_related_resources OWNER TO postgres;

--
-- Name: resource_servers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.resource_servers (
    id character varying(255) NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    description text,
    display_name character varying(255),
    name character varying(255) NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


ALTER TABLE public.resource_servers OWNER TO postgres;

--
-- Name: resource_types; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.resource_types (
    id character varying(255) NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    default_policy_specs jsonb,
    description text,
    display_name character varying(255) NOT NULL,
    localized_descriptions jsonb,
    localized_display_names jsonb,
    realm character varying(255) NOT NULL,
    server_name character varying(255) NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


ALTER TABLE public.resource_types OWNER TO postgres;

--
-- Name: roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.roles (
    id character varying(255) NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    deprecated boolean NOT NULL,
    description text,
    display_name character varying(255) NOT NULL,
    managed boolean NOT NULL,
    parents character varying[],
    updated_at timestamp(6) with time zone NOT NULL
);


ALTER TABLE public.roles OWNER TO postgres;

--
-- Name: scopes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.scopes (
    id character varying(255) NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    deprecated boolean,
    description text,
    display_name character varying(255) NOT NULL,
    localized_descriptions jsonb,
    localized_display_names jsonb,
    managed boolean NOT NULL,
    realm character varying(255) NOT NULL,
    resource_type character varying(255) NOT NULL,
    server_name character varying(255) NOT NULL,
    type character varying(255) NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    CONSTRAINT scopes_type_check CHECK (((type)::text = ANY ((ARRAY['HUMAN'::character varying, 'MACHINE'::character varying, 'ANY'::character varying])::text[])))
);


ALTER TABLE public.scopes OWNER TO postgres;

--
-- Name: tokens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tokens (
    id character varying(255) NOT NULL,
    active boolean NOT NULL,
    claims jsonb NOT NULL,
    expires_at timestamp(6) with time zone NOT NULL,
    issued_at timestamp(6) with time zone NOT NULL,
    metadata jsonb,
    not_before timestamp(6) with time zone NOT NULL,
    token_format character varying(255) NOT NULL,
    type character varying(255) NOT NULL,
    value text NOT NULL,
    CONSTRAINT tokens_token_format_check CHECK (((token_format)::text = ANY ((ARRAY['OPAQUE'::character varying, 'JWT'::character varying, 'PASETO'::character varying, 'SAML'::character varying])::text[]))),
    CONSTRAINT tokens_type_check CHECK (((type)::text = ANY ((ARRAY['API_KEY'::character varying, 'DEVICE_CODE'::character varying, 'SESSION_TOKEN'::character varying, 'AUTHORIZATION_CODE'::character varying, 'ACCESS_TOKEN'::character varying, 'REFRESH_TOKEN'::character varying, 'ID_TOKEN'::character varying, 'SAML1'::character varying, 'SAML2'::character varying, 'DPoP'::character varying])::text[])))
);


ALTER TABLE public.tokens OWNER TO postgres;

--
-- Name: 120705; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('120705');


ALTER LARGE OBJECT 120705 OWNER TO postgres;

--
-- Name: 120746; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('120746');


ALTER LARGE OBJECT 120746 OWNER TO postgres;

--
-- Name: 122547; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('122547');


ALTER LARGE OBJECT 122547 OWNER TO postgres;

--
-- Name: 131648; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('131648');


ALTER LARGE OBJECT 131648 OWNER TO postgres;

--
-- Name: 131649; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('131649');


ALTER LARGE OBJECT 131649 OWNER TO postgres;

--
-- Name: 131670; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('131670');


ALTER LARGE OBJECT 131670 OWNER TO postgres;

--
-- Name: 17577; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('17577');


ALTER LARGE OBJECT 17577 OWNER TO postgres;

--
-- Name: 21378; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('21378');


ALTER LARGE OBJECT 21378 OWNER TO postgres;

--
-- Name: 21379; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('21379');


ALTER LARGE OBJECT 21379 OWNER TO postgres;

--
-- Name: 21380; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('21380');


ALTER LARGE OBJECT 21380 OWNER TO postgres;

--
-- Name: 21401; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('21401');


ALTER LARGE OBJECT 21401 OWNER TO postgres;

--
-- Name: 21402; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('21402');


ALTER LARGE OBJECT 21402 OWNER TO postgres;

--
-- Name: 21543; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('21543');


ALTER LARGE OBJECT 21543 OWNER TO postgres;

--
-- Name: 21564; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('21564');


ALTER LARGE OBJECT 21564 OWNER TO postgres;

--
-- Name: 21585; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('21585');


ALTER LARGE OBJECT 21585 OWNER TO postgres;

--
-- Name: 21586; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('21586');


ALTER LARGE OBJECT 21586 OWNER TO postgres;

--
-- Name: 22128; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('22128');


ALTER LARGE OBJECT 22128 OWNER TO postgres;

--
-- Name: 22546; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('22546');


ALTER LARGE OBJECT 22546 OWNER TO postgres;

--
-- Name: 28167; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('28167');


ALTER LARGE OBJECT 28167 OWNER TO postgres;

--
-- Name: 28208; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('28208');


ALTER LARGE OBJECT 28208 OWNER TO postgres;

--
-- Name: 296182; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('296182');


ALTER LARGE OBJECT 296182 OWNER TO postgres;

--
-- Name: 30638; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('30638');


ALTER LARGE OBJECT 30638 OWNER TO postgres;

--
-- Name: 30940; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('30940');


ALTER LARGE OBJECT 30940 OWNER TO postgres;

--
-- Name: 31021; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('31021');


ALTER LARGE OBJECT 31021 OWNER TO postgres;

--
-- Name: 31062; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('31062');


ALTER LARGE OBJECT 31062 OWNER TO postgres;

--
-- Name: 31483; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('31483');


ALTER LARGE OBJECT 31483 OWNER TO postgres;

--
-- Name: 31524; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('31524');


ALTER LARGE OBJECT 31524 OWNER TO postgres;

--
-- Name: 31585; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('31585');


ALTER LARGE OBJECT 31585 OWNER TO postgres;

--
-- Name: 31966; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('31966');


ALTER LARGE OBJECT 31966 OWNER TO postgres;

--
-- Name: 32187; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('32187');


ALTER LARGE OBJECT 32187 OWNER TO postgres;

--
-- Name: 32428; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('32428');


ALTER LARGE OBJECT 32428 OWNER TO postgres;

--
-- Name: 32989; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('32989');


ALTER LARGE OBJECT 32989 OWNER TO postgres;

--
-- Name: 33750; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('33750');


ALTER LARGE OBJECT 33750 OWNER TO postgres;

--
-- Name: 34631; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('34631');


ALTER LARGE OBJECT 34631 OWNER TO postgres;

--
-- Name: 34912; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('34912');


ALTER LARGE OBJECT 34912 OWNER TO postgres;

--
-- Name: 35473; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('35473');


ALTER LARGE OBJECT 35473 OWNER TO postgres;

--
-- Name: 35734; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('35734');


ALTER LARGE OBJECT 35734 OWNER TO postgres;

--
-- Name: 54935; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('54935');


ALTER LARGE OBJECT 54935 OWNER TO postgres;

--
-- Name: 55296; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('55296');


ALTER LARGE OBJECT 55296 OWNER TO postgres;

--
-- Name: 57922; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('57922');


ALTER LARGE OBJECT 57922 OWNER TO postgres;

--
-- Name: 58443; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('58443');


ALTER LARGE OBJECT 58443 OWNER TO postgres;

--
-- Name: 60804; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('60804');


ALTER LARGE OBJECT 60804 OWNER TO postgres;

--
-- Name: 69805; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('69805');


ALTER LARGE OBJECT 69805 OWNER TO postgres;

--
-- Name: 69909; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('69909');


ALTER LARGE OBJECT 69909 OWNER TO postgres;

--
-- Name: 70670; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('70670');


ALTER LARGE OBJECT 70670 OWNER TO postgres;

--
-- Name: 99240; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('99240');


ALTER LARGE OBJECT 99240 OWNER TO postgres;

--
-- Data for Name: activity_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.activity_groups (id, activities, created_at, deprecated, description, display_name, display_order, localized_descriptions, localized_display_names, name, updated_at) FROM stdin;
30ec24ef-5174-4e3e-b9bf-11a2952f714b	{}	2026-09-11 07:44:24.054844+00	f	Gestion de la Paie	Gestion de la Paie	1	{}	{}	payroll-administration	2026-09-11 07:44:24.054844+00
\.


--
-- Data for Name: authorization_grants; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.authorization_grants (id, authorized_client_id, context, expires_at, granted_permissions, invalidated_at, issued_at, not_before, permission_hash, policy_traces, realm, resource_owner, revoked_at, status, subject, suspended_at) FROM stdin;
\.


--
-- Data for Name: authorization_resource_policies; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.authorization_resource_policies (id, conditions, created_at, decision_strategy, duration_in_seconds, owner, realm, related_resource_type, updated_at) FROM stdin;
\.


--
-- Data for Name: authorization_resources; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.authorization_resources (id, created_at, display_name, name, owner, realm, resource_type_name, server_name, updated_at) FROM stdin;
6f2f770c-1ea1-44d2-8c38-5a6c9c1977b2	2026-09-10 15:56:58.69704+00	OpenID Connect	resource-any-openid-connect	urn:africonnect:system:system	default	openid-connect	default	2026-09-10 15:56:58.69704+00
\.


--
-- Data for Name: challenge; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.challenge (id, data, duration_in_seconds, id_hash, invalidated, invalidated_at, issued_at, reason) FROM stdin;
FWTg8llbWR-k1O2OkJm-1HBqf82LwQPQZjU0NWUyODAtMjU0Ny00MjUwLWI4NTEtY2Y2M2M2ODZiYWYz	{"key": "132adde3-ae34-49a3-a06a-038efe2e12bf", "flow": "LOGIN", "method": "PASSWORD"}	600	wuRUtrCS4NzXR9nC4GWBrlE8FJMPJhyTeEgX0LRpM3o	f	\N	2026-09-10 17:32:48.89255+00	authentication
nglGMM-Q5mvHZT_9XV8tD3bbCYeGoU9AMjdlYTlkNTAtYzBjMS00NWEzLWI0MjctMmVhMzFiOTBmNTBk	{"key": "14f2dcc4-1d0d-43bb-a6d9-aba26762e753", "flow": "LOGIN", "method": "PASSWORD"}	600	o_vOXk8p6_3GesxvtWS2wdPlGYonY9UeTH43L0c9LEc	f	\N	2026-09-10 17:32:53.79344+00	authentication
N_n5Ufh88gG_Wm5ePobIh8GENjZmLHRtYTgwYTQyNTMtMzkyYi00N2FmLTg0Y2UtMzE3NzAwNTk2OGQ4	{"key": "7e60cd54-eddd-4e75-bd21-1cba73803bd9", "flow": "LOGIN", "method": "PASSWORD"}	600	nOcDw-HTknBU0SFWXQ1kjr61c5KmmLsOVSNOml-ITdA	f	\N	2026-09-10 17:32:56.379912+00	authentication
IPDXD2egDQPmiVYTjZdxG4ou7xxtLeFuZTIzZjM5MDctNTEyYi00NjU1LWEwYTktNmMzYzdlMzhhZWUx	{"key": "5f1c7ba3-ea49-4ada-ae0e-f636878c4ee8", "flow": "LOGIN", "method": "PASSWORD"}	600	1XAzQlu0mBrrTzBCh2xbSWz7DeOKCw-HeaTGmx7La08	f	\N	2026-09-10 17:32:59.696203+00	authentication
Rq14N1i74umamCLCfCAifqx5wTkSj32KNDRkMzkyOTItZGE4ZC00NDEwLThmNzctMWFhZmYyNGJmNmI4	{"key": "5f7db64a-5d24-4d4d-aff9-99c3d5951407", "flow": "REGISTER", "method": "PASSWORD"}	600	HiLGmqSnOGnJTTTiTAJIfHQ5TJoEssL5lJ8QoApUwis	f	\N	2026-09-10 17:33:19.152393+00	authentication
zavqAV2msGJRAFkNXJ6LfScWoKdPSp-8MjdiZDcwNTItNWEyNC00MDU0LTkxNzgtYzAxNjM0Y2QwMzVl	{"otp": "825898", "flow": "REQUIRED_ACTIONS", "user": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "action": "VERIFY_EMAIL", "method": "EMAIL", "scopes": ["VERIFY_EMAIL"], "acrLevels": ["BASIC"]}	3000	FNv8R1kp4ob8QoshIm2XzKKJxcb2s0ll9gueBaab-PQ	f	\N	2026-09-10 17:34:04.371524+00	required_action
oa6WDZkoAlWdRGgxHaaqoTvnOaI6-WU1MThhNGEyMmEtZTgyMS00N2Y1LWJkNGEtNTgzNDA2YmU4ZjBh	{"key": "4a6d328d-5aee-4e2a-9d3d-745b102b1c48", "flow": "LOGIN", "method": "PASSWORD"}	600	gAiVR_WSeOdGo_t9iqj45TEfDOr3E9mQaM_qJDkbJYg	f	\N	2026-09-10 17:36:38.581166+00	authentication
I819GNrwYY3O583XIEqhjVUAGPbj2cY2ZDZjNGNlYzEtZTVjOC00YTk0LWI5OWQtY2Y4N2E0YjU5ODcy	{"key": "1229be88-18a9-4113-9ec3-d80c86ab9165", "flow": "LOGIN", "method": "PASSWORD"}	600	t8rXhiMjnvw7_y96CYJDaHI7ERJGwwrGpOGdu-GOzqw	f	\N	2026-09-10 17:37:02.099979+00	authentication
KiFLYkEmWOvNP-rLuEMCOTZ8p4h1cpxMZTQ1MzgzMTQtODc1My00MWVkLWJmYzItMDU3ZGYzZGE0Mjg4	{"key": "def631fb-c339-416e-856b-1c47999935e4", "flow": "LOGIN", "method": "PASSWORD"}	600	z0vYjRjRIObAtXn1_TkKA8MJOo3z8CRv7jIvsnQEbaY	f	\N	2026-09-10 17:37:52.402626+00	authentication
3pgqwdWZ0F7vEaYMC5WCWJm49Ne6UIoBMDQ5OTg2ODMtZDI3Mi00ZDU1LTljN2YtMTU0MGVhYWVkNzk4	{"key": "03ea199f-bbdc-4210-ba98-c3b9f6b7674f", "flow": "LOGIN", "method": "PASSWORD"}	600	iXoTSN4P76lCoVLpyw1pXm62kZNJX9TZX1u5kdXc2MA	f	\N	2026-09-10 17:37:52.416574+00	authentication
ZGLJRuBmc0kfMbOM_1AZO_PEFJX9KojVZGNlN2U2NWUtZGJlNi00MTVhLWI2MTQtZTUxNmMwN2Y5OGJh	{"key": "95a51876-4029-4d5c-8752-d81b8eeeea14", "flow": "LOGIN", "method": "PASSWORD"}	600	thnuEXQ-eG-eq9kuaTJVN4xohfI4i9DTPeaee_y7vQs	f	\N	2026-09-10 17:51:13.193894+00	authentication
ZRgJ3aWXyIjqVzJKbPEWa7M4jBVhl9uIZWZjMGRkMTUtMDYyMC00NjU3LTg0MDktZDJjODcxODRmYTk5	{"key": "36856706-c363-4bee-b7fe-16d47ed8cc57", "flow": "LOGIN", "method": "PASSWORD"}	600	lCXpStuCc-_YglgZg3WUVLDxy6F5GPYd6lqjzKYKHW0	f	\N	2026-09-10 17:57:26.915301+00	authentication
yiwunM8IDrpNiDecTyuOIKajMZwabN2SZWI2M2ZiZDUtYzU5ZS00YWNhLWE3MWUtMzU1NTI0ZWQ0ODFi	{"key": "2e0f2b8a-d626-4e2c-b834-c6fa5654d245", "flow": "LOGIN", "method": "PASSWORD"}	600	ET5zK_Kg3MIIw8zQwZcAC-qGOl9hxae4ll540VFhQf4	f	\N	2026-09-10 20:17:44.032331+00	authentication
bjL4LlW45vTUX_ADrQIx3DR87ux74gwQYmVlZDU4MDAtYzk2Yi00NjYxLTllYmUtNGViZjA2MDU2YjQ4	{"key": "32f33a71-dcd8-448f-b006-9142e44b33ac", "flow": "LOGIN", "method": "PASSWORD"}	600	X8Q8tc_T-QKBewFzsEPO29EcY-ZlP77DQSWdFET3iQ0	f	\N	2026-09-10 20:18:28.554812+00	authentication
UKEYWUtdyNnlHXgISZCnRN9p1Sud6qVoOTRlYWUyZDEtYmIzOS00ZjM4LWIwYzQtNDc0MzczYmMwZWQ3	{"key": "a7621594-12f5-468e-ad7f-ff6ee5f7d4cd", "flow": "LOGIN", "method": "PASSWORD"}	600	Zerd-TFiCkvTK6WdV6Vu01UhGEc7R6LS2ID8hQzeseU	f	\N	2026-09-10 21:05:38.808628+00	authentication
xR6dY8aIYT2emtIPR0jOTLpCcANmzfN8YTQ2NDFkZWItZjg5Yy00ZTk2LWE4MWEtZjFlYjY2OTg3Mjgx	{"key": "edaffe14-435d-4eb4-b022-649e4937daf1", "flow": "LOGIN", "method": "PASSWORD"}	600	u4QotHglYczOJc0uf56qJkkWz-66pn1Fd0tFDqRVjLw	f	\N	2026-09-10 21:13:27.755104+00	authentication
6D61urqKtU0WNP0uCWgrtogjh4I_Ycp9YTA4ZjI0ZjctMWU4Zi00ZWQ4LWFiZjItZTA1OGE2MDY1Nzgz	{"key": "08bbb224-5988-4f5d-aeb3-4a28a7959d51", "flow": "LOGIN", "method": "PASSWORD"}	600	FzYM4Lh4OSuRttRFoZnUCXxFvsv3LL6uNJ0GAyJz_7Y	f	\N	2026-09-10 21:15:14.791431+00	authentication
_LwWaZ33KJ5zGe0xRv0J3Rl8oElbD4b0OTY5ODJlOTgtZWRmMy00NDFhLWI3NzUtYzkwMzc5OGU2MzJl	{"key": "69fa0e9a-8829-45d4-9ee7-086ec4513ceb", "flow": "LOGIN", "method": "PASSWORD"}	600	z6bLvRWoF1NVdkC51iloN7XfeJbUaeMFsaX4uq6pvvE	f	\N	2026-09-10 21:16:26.950194+00	authentication
P9LhnaPtolMwa6p76WTIsC9I0fi-tSSzYTg2YTkzZDktNTc4Mi00YmU1LTgxZDgtNDlmMjBkMWEzZTg0	{"key": "45616785-3557-4eb2-8e9b-fbd6eb6bdec0", "flow": "LOGIN", "method": "PASSWORD"}	600	enGM_aUgds2hWXCcOiqnXNqpTnKB9bZKKhSkWX98qcA	f	\N	2026-09-10 21:27:38.619805+00	authentication
XHzWGvpgSBqWc4dylRpiYBW8dDy-S83ZOTdiNjA0YTQtOTdkNy00MDQ3LWE3ZmEtYzk4NDM0ZTE1OTQw	{"key": "9441a2fe-e87d-4ae7-b135-aedfc0b0cb37", "flow": "LOGIN", "method": "PASSWORD"}	600	i_SZnEdFcwXuF4EvUcwJVOONSA9AoO-beYK92sQSvN8	f	\N	2026-09-10 21:28:34.01378+00	authentication
0Ob6ykNFIDcmAM72TFHCtEy7CgJKs04cZDRiZDAwYjUtY2FmOC00ZWQ3LTgwNDktYWJjNTVjZmIzYWUz	{"key": "2ec60f62-4e8b-456b-a402-44a8f823187d", "flow": "LOGIN", "method": "PASSWORD"}	600	dF6fn-ka6N30XiWw8DtuOrhF4HAEm8gSKJxm0c7ZbWo	f	\N	2026-09-10 21:30:12.13895+00	authentication
iB2JgkNRRLw85FkLivZVZ4gHQbJdzvKZMDk5ZjA5N2UtNTdkNi00NmQ3LWI2ODgtOTkwYTE4Zjc3ZGYy	{"key": "f8ff301f-4f46-4b22-a0ae-8fc547db3cac", "flow": "LOGIN", "method": "PASSWORD"}	600	O5VaRE8ThR93__GOSYMetyGrkWUuOQFOSNGyt2mzX4I	f	\N	2026-09-10 21:39:38.446447+00	authentication
E3jhdZPBIrYS9EVLn7aD5LwNxv4f2BLAMTQ4MzMxY2MtNWVkMC00ODBlLTkzODItNjg3NGZlYzZjY2Fi	{"key": "ecb2c871-95b0-4197-b1c3-f64d0a899760", "flow": "LOGIN", "method": "PASSWORD"}	600	xRrrTrsS7QXBFDv55cxVD9_oCOfEdOnK8uLIfJQdcBE	f	\N	2026-09-10 21:45:28.657745+00	authentication
ldSAmDBn8h0l8T3oAEpXAsOp32FFFtOROGU0NDBkZGQtZThmNy00M2FjLWI5NTctZWYzNDEwYWQ2ZDk3	{"key": "29e90fb6-509b-45c3-afad-0b4dd297f1de", "flow": "LOGIN", "method": "PASSWORD"}	600	HT_Umw04B2yv7zcJkF5u66GZrzkfJEBS6Jcfhxpycd4	f	\N	2026-09-10 21:51:30.445368+00	authentication
K8Suja1VO3gHwKzORT4n_hj3RaqAehXJYTIyMmVhNGMtZGU4My00ODA3LWJlZWItZmY3ODM1NWI3Yzlh	{"key": "7b8c7305-aa92-431b-8147-a4f0a260f1c2", "flow": "LOGIN", "method": "PASSWORD"}	600	5bUMX6dzCSdJ0IPMrpJ_Qx4R7OBbHTZyHKgrLhocNJQ	f	\N	2026-09-10 22:05:24.374938+00	authentication
bHsUOBuCkW7hR1CcHRwdL97lO3G7DsrkZWFmYTcxODMtNmNmOC00OTU1LWI1MDMtMTA0ZWEwYTYxYTU3	{"key": "b87a2fa2-2c0e-4a18-a314-dd108bb80139", "flow": "LOGIN", "method": "PASSWORD"}	600	HS4ux_O45PidHuneKSWMSQaQLVhQSgodIimA-cxypOc	f	\N	2026-09-10 22:24:17.572109+00	authentication
kEnTCbca72KEcf0KHPjh4TvAsZGMpAeeZTJkMDBmYjAtZTdhOS00OGMwLWIwZjEtYTU1ZjBmZDZmMDk5	{"key": "23d55e7c-2ad0-43ec-877b-4b22e6edf00f", "flow": "LOGIN", "method": "PASSWORD"}	600	mJ7rTh-Sdz0rVjiL_QR84Jd9PXhDkga2x3h7s2gjPDU	f	\N	2026-09-10 22:46:27.003858+00	authentication
mgU3qJfDpCgB186x_c6Hxbiar-sd1z-1MWIxMmExZjItMWUzZi00MjlhLThiMWItZGVmZjdkMjA5ZGI3	{"key": "b1a1135b-d287-469c-84a9-6588ac538901", "flow": "LOGIN", "method": "PASSWORD"}	600	7BmZ0goiTWKBtI9C4N9xlf9It0HqBbXy9XOmRuk88co	f	\N	2026-09-10 22:53:21.381342+00	authentication
kDtgu3H4U_fU5s_4p9JNvtJZ1CFLskX6NzE3ZjAzNDAtMmQ5ZC00OGQwLTg3NWItMzFhYjQ4MWM5NTA3	{"key": "ccba68a2-fb8e-48ff-beb8-b6aca491b50c", "flow": "LOGIN", "method": "PASSWORD"}	600	WHvcDh5bVsuRHkXqQdgC_XMekh5oeOi-O-mrVeVH92o	f	\N	2026-09-10 23:07:14.785755+00	authentication
0C0iYB0aOxqzDxsmX41_kXMnaH5UkbQDNjc4ZGU0NzQtODc4OS00YTM2LWEzOTYtYjA5YTZiNDE1NGIx	{"key": "519e7d54-74fd-42c8-a8e1-11f7e4bfe95f", "flow": "LOGIN", "method": "PASSWORD"}	600	mxAD-2-qbnJy36X3QFSiu33XdIAQhnoGtg2dXt91DpI	f	\N	2026-09-10 23:13:51.802955+00	authentication
YcyJlAISDori3kGyejUcI1dibgR4E-zlZTAzZmVkZjQtODRlYy00ZDA4LWJjNmQtMzM0ZDdkOTkxMjNk	{"key": "ff6d8fc8-2cc7-4a98-927f-15e898c5a7f6", "flow": "LOGIN", "method": "PASSWORD"}	600	jishL1YsETXZZwCKgnEfJ5QjlBmzIpt2rTUAMvACqKg	f	\N	2026-09-11 07:13:44.713062+00	authentication
SNPi6hOLUWwPIxJJdqRH0bJqVnHLONAeMzNlNmVjYWYtMWY1Ni00MDZlLTljMzgtMDBhZjFiNWIzMTdl	{"key": "2164e9ae-bf37-4418-9634-5f3428f2d8df", "flow": "LOGIN", "method": "PASSWORD"}	600	cETrBfFPOZ7H-bDRm5vfRqIXpdSjzmt1fH_OQjxc0DQ	f	\N	2026-09-11 07:22:37.319139+00	authentication
NXCiwSfx8Bkwc-X_q1Ejq32C4OQRu6hgZGViN2Q5NDItMWE4OC00MTAyLTljZmYtYmE5MGU2MWViNWEz	{"key": "c934821c-aac8-4df7-a50d-a64259bd966b", "flow": "LOGIN", "method": "PASSWORD"}	600	h5cha_S-QDmi8GCeXN2iePCm3gtloXLimgN9WbR41IQ	f	\N	2026-09-11 07:42:40.567145+00	authentication
6ovz1xojJlbHe5zKcBZmveLWFRSvUxLxNjAyN2MyOWUtZGMwZC00MTM1LWJjNjQtZDljMWVlYWUwNzZl	{"key": "fa75ae61-16d2-47c1-a056-a469fd0e199f", "flow": "LOGIN", "method": "PASSWORD"}	600	EpRcnPLDH-MwemIRcC0lwHeQlobsAo3i3L9VcHgTukk	f	\N	2026-09-11 07:55:42.504555+00	authentication
gvUW1d3d-FV4VGg-ZW8RNuM9s0h318jOMzBhMWE2NDQtZGU3Yi00YmI3LWI2YjYtN2I0ZGM3MzJjNDY2	{"key": "0aa8fa5c-050a-4f60-9fc1-8ac8c260dbfc", "flow": "LOGIN", "method": "PASSWORD"}	600	0qlepLARMuJ1KrhU6-0iUkPClBmmJ8lB_Sg_yVKxdkY	f	\N	2026-09-11 08:54:58.834264+00	authentication
wHaSCwHmSuL52KuY-CgxSU_mWIOoXOszNjM3NjdiYzEtZjExYy00YjJkLWJlOGMtZjZkMzJmMGM4ZGIx	{"key": "44689d5e-7ef5-4bda-b16b-75c9fab83410", "flow": "LOGIN", "method": "PASSWORD"}	600	1xNav0yQAvouIXmcAXq1KqKQjT4L73nyZToNBaCaRbI	f	\N	2026-09-11 12:39:49.125959+00	authentication
b_8crmnSVJzDMdqfxnH8Kk0wQq8BH8sdOGRkNTM1NDctNjY0OS00NWMyLWI0ZmUtOWEwMGFkMWEzM2M1	{"key": "e93344ec-3c72-44bb-a0dd-41360a1964dc", "flow": "LOGIN", "method": "PASSWORD"}	600	nZmorHAdq8Fpxpmv0fiTrEgviDHL-entIyNK7LaI-b8	f	\N	2026-09-11 12:42:16.801982+00	authentication
fB6tQHFoxFNyI6BuW6GebhSjGhf3wcN-YmE4M2NkZDktNjBhMy00OGY5LWFkNjktYzc4ZDYwMDNhNzQ5	{"key": "44275c63-0ff5-41bb-a89d-aa3ec52a4abb", "flow": "LOGIN", "method": "PASSWORD"}	600	OoKhLdVkE1JbyskWvefbDwFYNugggzy4gwjyUfzZG8A	f	\N	2026-09-11 13:01:25.373526+00	authentication
r0HGU-qI2ZmtWZs4407VgAPxDnzauip8ODdiMTcxMjUtNDI5OS00MzZlLWEyYjUtYmQ4ZThlMTgwNWQ2	{"key": "4342c232-9d42-4647-9d3d-078bf93e80df", "flow": "LOGIN", "method": "PASSWORD"}	600	Wo32Wm5UCctzMbbu2Q8HdJkNan5gs8ErCSaJ1mzaVew	f	\N	2026-09-12 00:55:33.304009+00	authentication
GuDrk_9De9w7PppBErQwV0j-7gMhX2ZuMDJhMGMzNjQtNzY2YS00OGY5LTk4NDItYmFhOTAxNmZkN2Mw	{"key": "5785296b-b52e-42a4-b1f4-6370f71dc87e", "flow": "LOGIN", "method": "PASSWORD"}	600	Kg18V1VUVgL9tAQsV6PkHeluu0wFEeYjRHHQ4fLrT6I	f	\N	2026-09-12 09:51:42.397787+00	authentication
rGCo2ou825C4ad1hEjHRi8fsgSeQuoNaNDllM2QyYjktOTI0ZS00ODk2LTlhM2MtZjZiYjQ4ZjRhMTNh	{"key": "7e523af0-5a52-4373-8cfa-3d76e565febf", "flow": "LOGIN", "method": "PASSWORD"}	600	uVm36kGhxyXC2NkkKpZhH1G4LJrzdrUKJgEl2HKejxU	f	\N	2026-09-12 09:52:55.406093+00	authentication
7712H7PmHWtQB7-UpkfgB3ALuxjQEL7rYTE5MGQ0ZTAtOWZiMS00Yjg3LWIzNmYtMTU1MWEyZGNhY2E1	{"key": "c439e0b1-cd42-4789-96e9-e6b4da6f7f9f", "flow": "LOGIN", "method": "PASSWORD"}	600	qYCDEZN9WVCIC9gxi08Of9EwfLWYIn6oPbBBI-1UzSA	f	\N	2026-09-12 10:37:57.49101+00	authentication
Y9DfFCZJQT9eqrWvjCbJLHo-GDhYC4HuNzgyOWYxOTEtNjViMC00NDkwLWIzZDAtMmRhNTM5ZjRiNTdm	{"key": "88e58930-d011-4157-a6a9-509884d10481", "flow": "LOGIN", "method": "PASSWORD"}	600	4cqcM4cdkeQ9MW4GKy391ZSamJ2GXTDiRw51q8LWGd0	f	\N	2026-09-12 14:25:17.518473+00	authentication
F1Jb27aBxyNVlSTEVbuJGtd0WtG57k1lNTA4N2YyNDEtZTA2MS00YjQ0LWI3NDctNmIzMWE0MWNiN2Jh	{"key": "0eebca87-e9ad-43d3-b012-6f05059743bd", "flow": "LOGIN", "method": "PASSWORD"}	600	0mwPXG4m_TIFb0naZUzX5nXHq5uL4QoapQD8QtSIrRg	f	\N	2026-09-12 14:25:19.457477+00	authentication
Kc7qfEU1lVre5lNiv3u26kiGmvMStm0NYzJiNjdkYjctYzVmYy00NWZhLWJlMDItMDBlYTUxZTY1NjNl	{"key": "c93ae713-9ee0-4447-bbd8-1f450311fd93", "flow": "LOGIN", "method": "PASSWORD"}	600	4T2Jwd0Q0h3xkhWZWeoFXQPOcRrnc0vsMDtzqguE5xY	f	\N	2026-09-12 14:25:54.259575+00	authentication
2TFWLYVHk1suI9V7hKLV9rmlVEB7sFw2NTBkMzUxODYtMTdiYi00YzMwLWJhNjEtMTBkOTNhOWY0YTM1	{"key": "d7429da1-f0d5-47ce-8571-be1330996415", "flow": "LOGIN", "method": "PASSWORD"}	600	n-004E88tWi0rtrjyX0dFd5y-CzjbyYkUxSypxMP7-o	f	\N	2026-09-15 10:32:37.106753+00	authentication
\.


--
-- Data for Name: client_entity_scopes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.client_entity_scopes (client_entity_id, assigned_at, scope) FROM stdin;
\.


--
-- Data for Name: clients; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.clients (id, client_authentication_methods, client_settings, created_at, grant_types, ip_access_control_list, name, org_id, status, token_settings, type, updated_at) FROM stdin;
\.


--
-- Data for Name: documents; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.documents (id, data, format, name, "timestamp") FROM stdin;
\.


--
-- Data for Name: images; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.images (id, created_at, data, image_format) FROM stdin;
\.


--
-- Data for Name: keys; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.keys (id, algorithm, archived_at, created_at, curve, default_client_certificate, expires_at, key_size, name, org_id, origin, priority, public_key, status, type, use, version) FROM stdin;
4b1c9ef7-f123-4cb6-b092-532617c4cf43	RS256	\N	2026-09-10 15:56:59.011063+00	\N	f	2026-12-09 15:56:59.011065+00	2048	auth	\N	GENERATED	2147483647	17577	ACTIVE	RSA	SIG	1
\.


--
-- Data for Name: login_events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.login_events (id, occurred_at, org_id, user_id) FROM stdin;
47e85abb-da4a-4ff6-93c2-d86aa31e7a9a	2026-09-10 17:34:45.612624+00	\N	3c4fbffc-b5bf-4e90-992b-e1c916503d93
a48d7b69-6049-41fe-86fd-625da3035dd9	2026-09-10 17:36:15.948088+00	\N	3c4fbffc-b5bf-4e90-992b-e1c916503d93
d16c8967-819b-4cf0-87ad-7c12f4d7b17a	2026-09-10 17:37:01.750964+00	\N	3c4fbffc-b5bf-4e90-992b-e1c916503d93
dd8b207b-65c5-438e-92b0-c17cab10ed44	2026-09-10 17:51:33.207793+00	\N	3c4fbffc-b5bf-4e90-992b-e1c916503d93
3a72edae-d5b9-4cbb-8ca9-0c4a5c7aa961	2026-09-10 20:18:27.98199+00	\N	77363c25-ecbc-4a67-a3bb-21546a9d0a80
6ad8ac22-41ed-4513-8653-d0dc836cb918	2026-09-10 21:05:55.405201+00	\N	77363c25-ecbc-4a67-a3bb-21546a9d0a80
19af119f-a947-4a07-8a72-76f3ee8ed163	2026-09-10 21:13:47.314075+00	\N	77363c25-ecbc-4a67-a3bb-21546a9d0a80
d07e55b9-1173-4975-ab70-c3828e0189da	2026-09-10 21:16:17.322041+00	\N	77363c25-ecbc-4a67-a3bb-21546a9d0a80
44db7c74-4936-404a-b115-919605e51903	2026-09-10 21:16:41.803666+00	\N	77363c25-ecbc-4a67-a3bb-21546a9d0a80
fe427f13-51d9-4bdb-b6d7-9f5ede5880fb	2026-09-10 21:27:55.155705+00	\N	77363c25-ecbc-4a67-a3bb-21546a9d0a80
d592e44f-2b83-4355-bdea-65ae4a2746d4	2026-09-10 21:29:49.801931+00	\N	77363c25-ecbc-4a67-a3bb-21546a9d0a80
af32644b-8747-432a-b3bf-baa2730092e0	2026-09-10 21:32:10.769634+00	\N	77363c25-ecbc-4a67-a3bb-21546a9d0a80
f60ca57f-0162-47e9-aa5d-110b2cb9a484	2026-09-10 21:39:50.362333+00	\N	77363c25-ecbc-4a67-a3bb-21546a9d0a80
4114b108-edf8-4063-9bc1-2d4fe62db3c7	2026-09-10 21:45:39.424017+00	\N	77363c25-ecbc-4a67-a3bb-21546a9d0a80
db729f9d-8c4c-43b8-a8af-14d7378a0199	2026-09-10 21:52:46.875156+00	\N	77363c25-ecbc-4a67-a3bb-21546a9d0a80
fad06cc7-1cb1-40e4-b870-22337d6d7446	2026-09-10 22:05:35.602765+00	\N	77363c25-ecbc-4a67-a3bb-21546a9d0a80
0fc18a00-6b04-41c4-9501-55918043e40b	2026-09-10 22:38:59.497022+00	\N	77363c25-ecbc-4a67-a3bb-21546a9d0a80
21647a37-153e-4fa2-b51c-96ad7ffcc947	2026-09-10 22:46:38.782118+00	\N	77363c25-ecbc-4a67-a3bb-21546a9d0a80
d4755c30-5389-4662-b073-8120d9e6804e	2026-09-10 22:59:40.605978+00	\N	77363c25-ecbc-4a67-a3bb-21546a9d0a80
ff63c606-216e-47ea-bbd2-700baaf4e492	2026-09-10 23:07:29.202891+00	\N	77363c25-ecbc-4a67-a3bb-21546a9d0a80
66401751-3d1b-468f-9887-05b8bb7c1697	2026-09-10 23:14:08.671107+00	\N	77363c25-ecbc-4a67-a3bb-21546a9d0a80
3f83f1a4-130a-44db-bca6-42af8982c709	2026-09-11 07:14:19.946722+00	\N	77363c25-ecbc-4a67-a3bb-21546a9d0a80
6512ec9d-b387-4cba-abff-9078a7655de2	2026-09-11 07:22:48.270583+00	\N	77363c25-ecbc-4a67-a3bb-21546a9d0a80
8886e3ff-4d52-4f22-95a1-89b249854139	2026-09-11 07:43:07.630421+00	\N	77363c25-ecbc-4a67-a3bb-21546a9d0a80
47205d3a-c3f3-43d3-a18b-6720ca0672f5	2026-09-11 07:55:53.414847+00	\N	77363c25-ecbc-4a67-a3bb-21546a9d0a80
86bd51e7-e0a6-482b-8e19-ef4802759723	2026-09-11 08:55:19.896371+00	\N	3c4fbffc-b5bf-4e90-992b-e1c916503d93
a32e8ade-e555-443c-94a0-a557a06fceb8	2026-09-11 12:40:10.796355+00	\N	3c4fbffc-b5bf-4e90-992b-e1c916503d93
4cc4a2db-304e-4088-8a6d-5309865e9a2e	2026-09-11 12:42:36.626999+00	\N	3c4fbffc-b5bf-4e90-992b-e1c916503d93
96e61235-c03b-451a-ac1d-07aa2f616995	2026-09-11 13:01:43.99001+00	\N	3c4fbffc-b5bf-4e90-992b-e1c916503d93
cdd44fa7-8a29-4b0a-8fd6-010688647955	2026-09-12 00:55:56.093222+00	\N	3c4fbffc-b5bf-4e90-992b-e1c916503d93
051eeeb1-ed59-46e9-ae59-d01d82d84f84	2026-09-12 09:52:22.824139+00	\N	3c4fbffc-b5bf-4e90-992b-e1c916503d93
69168aac-5a5b-455c-8532-4c44c865bcba	2026-09-12 09:56:46.666558+00	\N	3c4fbffc-b5bf-4e90-992b-e1c916503d93
837d36b7-88ca-4238-a3dc-409624a06b6a	2026-09-12 10:38:51.461862+00	\N	3c4fbffc-b5bf-4e90-992b-e1c916503d93
f27d775f-3360-4069-9c0b-b50c42c235a8	2026-09-12 14:25:59.202533+00	\N	3c4fbffc-b5bf-4e90-992b-e1c916503d93
e81ce72d-628c-4e64-a13d-bb6c560685e4	2026-09-15 10:33:13.456945+00	\N	3c4fbffc-b5bf-4e90-992b-e1c916503d93
\.


--
-- Data for Name: organization_access_approval_circuits; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.organization_access_approval_circuits (circuit_id, org_id, created_at, description, enabled, entries, item_types, name, priority, risk_levels, stages, temporary_only, updated_at) FROM stdin;
demande-generale	96101814-b255-4348-bb24-d5a963439148	2026-09-15 10:37:26.591354+00	Demande générale	t	{}	{ROLE,GROUP,PROFILE}	Demande générale	1	{STANDARD}	[{"code": "super-admin-validation", "mode": "ALL", "label": "Validation Super Admin", "order": 1, "approverRoles": ["super_admin"], "approverUsers": [], "selfApprovalAllowed": false}]	t	2026-09-15 10:37:26.591354+00
\.


--
-- Data for Name: organization_access_catalog; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.organization_access_catalog (entry_id, org_id, created_at, description, enabled, justification_required, label, max_duration, risk_level, target_id, type, updated_at) FROM stdin;
acces-referential-console	96101814-b255-4348-bb24-d5a963439148	2026-09-15 10:38:32.457281+00	\N	t	t	Acces referential console	5	STANDARD	admin	ROLE	2026-09-15 10:38:32.457281+00
\.


--
-- Data for Name: organization_access_certification_campaigns; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.organization_access_certification_campaigns (campaign_id, org_id, closed_at, created_at, description, due_at, expiry_policy, groups, name, opened_at, profiles, reviewer_roles, status, updated_at, user_ids) FROM stdin;
campagne-initiale	96101814-b255-4348-bb24-d5a963439148	\N	2026-09-15 10:39:44.343828+00	\N	\N	KEEP	{}	Campagne initiale	\N	{}	{admin}	DRAFT	2026-09-15 10:39:44.343828+00	{}
initial-campaign	96101814-b255-4348-bb24-d5a963439148	\N	2026-09-15 10:41:43.560971+00	\N	\N	REVOKE	{}	Initial Campaign	\N	{}	{admin}	DRAFT	2026-09-15 10:41:43.560971+00	{79397ae7-db25-4553-a4f2-df3a607da5e3}
\.


--
-- Data for Name: organization_access_certification_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.organization_access_certification_items (item_id, access_type, application_note, applied_at, campaign_id, comment, created_at, decided_at, decided_by, decision, org_id, reviewer_id, sources, target_id, updated_at, user_id) FROM stdin;
\.


--
-- Data for Name: organization_access_request_decisions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.organization_access_request_decisions (request_id, comment, decided_at, decided_by, outcome, stage, decision_order) FROM stdin;
\.


--
-- Data for Name: organization_access_request_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.organization_access_request_items (request_id, entry_id, target_id, type) FROM stdin;
\.


--
-- Data for Name: organization_access_request_resources; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.organization_access_request_resources (request_id, resource_name, resource_type_name) FROM stdin;
\.


--
-- Data for Name: organization_access_requests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.organization_access_requests (request_id, applied_at, beneficiary_id, circuit_id, created_at, current_stage_order, decided_at, duration, granted_policy_ids, justification, org_id, outcome_reason, requester_id, risk_level, status, updated_at, warned_activities) FROM stdin;
\.


--
-- Data for Name: organization_activities; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.organization_activities (id, created_at, deprecated, description, display_name, localized_descriptions, localized_display_names, name, scopes, updated_at) FROM stdin;
\.


--
-- Data for Name: organization_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.organization_groups (group_id, org_id, created_at, description, external_ref, external_source, managed, name, parent_id, roles, status, updated_at) FROM stdin;
organization.legal-entity:9ae734b6-ae8f-4f87-a103-44ba78f70d04	96101814-b255-4348-bb24-d5a963439148	2026-09-11 08:30:18.32312+00	Opur SAR	9ae734b6-ae8f-4f87-a103-44ba78f70d04	organization.legal-entity	t	Opur SAR	\N	{}	ACTIVE	2026-09-11 08:30:18.32312+00
organization.legal-entity:OPUR-ACA	96101814-b255-4348-bb24-d5a963439148	2026-09-15 10:46:56.416931+00	\N	OPUR-ACA	organization.legal-entity	t	Opur Academy	\N	{}	ACTIVE	2026-09-15 10:46:56.416931+00
\.


--
-- Data for Name: organization_invitations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.organization_invitations (id, approved_at, email, expires_at, first_name, gender, id_hash, last_name, org_id, rejected_at, sent_at, status) FROM stdin;
\.


--
-- Data for Name: organization_member_group_assignments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.organization_member_group_assignments (organization_member_entity_org_id, organization_member_entity_user_id, assigned_at, group_id, source) FROM stdin;
96101814-b255-4348-bb24-d5a963439148	3c4fbffc-b5bf-4e90-992b-e1c916503d93	2026-09-11 08:48:17.602882+00	organization.legal-entity:9ae734b6-ae8f-4f87-a103-44ba78f70d04	MANUAL
\.


--
-- Data for Name: organization_member_profiles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.organization_member_profiles (org_id, profile_id, created_at, default_groups, default_roles, description, name, status, system, updated_at) FROM stdin;
\.


--
-- Data for Name: organization_member_role_assignments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.organization_member_role_assignments (organization_member_entity_org_id, organization_member_entity_user_id, assigned_at, role_id) FROM stdin;
9529b669-de02-43d0-a902-638878a85a7f	3c4fbffc-b5bf-4e90-992b-e1c916503d93	2026-09-11 08:09:31.64373+00	super_admin
96101814-b255-4348-bb24-d5a963439148	3c4fbffc-b5bf-4e90-992b-e1c916503d93	2026-09-11 08:30:18.257063+00	super_admin
96101814-b255-4348-bb24-d5a963439148	79397ae7-db25-4553-a4f2-df3a607da5e3	2026-09-15 10:33:28.478727+00	admin
\.


--
-- Data for Name: organization_member_roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.organization_member_roles (org_id, user_id, archived_at, created_at, member_profiles, status, suspended_at, updated_at) FROM stdin;
9529b669-de02-43d0-a902-638878a85a7f	3c4fbffc-b5bf-4e90-992b-e1c916503d93	\N	2026-09-11 08:09:31.64373+00	{}	ACTIVE	\N	2026-09-11 08:09:31.64373+00
96101814-b255-4348-bb24-d5a963439148	3c4fbffc-b5bf-4e90-992b-e1c916503d93	\N	2026-09-11 08:30:18.257063+00	{}	ACTIVE	\N	2026-09-11 08:48:17.602882+00
96101814-b255-4348-bb24-d5a963439148	79397ae7-db25-4553-a4f2-df3a607da5e3	\N	2026-09-12 19:53:12.086113+00	{}	ACTIVE	\N	2026-09-15 10:33:28.478727+00
\.


--
-- Data for Name: organization_permission_usages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.organization_permission_usages (org_id, permission, user_id, last_used_at) FROM stdin;
\.


--
-- Data for Name: organization_role_delegations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.organization_role_delegations (delegation_id, org_id, created_at, delegate_id, delegator_id, groups, reason, revoked_at, revoked_by, roles, status, updated_at, valid_from, valid_until) FROM stdin;
\.


--
-- Data for Name: organization_roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.organization_roles (org_id, role_id, activities, created_at, description, name, system, updated_at) FROM stdin;
9529b669-de02-43d0-a902-638878a85a7f	guest	{}	2026-09-11 08:09:31.644962+00	Rôle de base en lecture seule, sans accès prédéfini.	Guest	t	2026-09-11 08:09:31.644962+00
9529b669-de02-43d0-a902-638878a85a7f	admin	{}	2026-09-11 08:09:31.64496+00	Dispose des droits complets de gestion des données et opérations de l'organisation.	Administrator	t	2026-09-11 08:09:31.64496+00
9529b669-de02-43d0-a902-638878a85a7f	super_admin	{}	2026-09-11 08:09:31.644665+00	Propriétaire du compte. Détient le contrôle total de toutes les ressources et configurations.	Super Administrator	t	2026-09-11 08:09:31.644665+00
9529b669-de02-43d0-a902-638878a85a7f	iam_admin	{}	2026-09-11 08:09:31.644963+00	Gère les identités, les accès, les rôles et les membres de l'organisation (IAM).	IAM Administrator	t	2026-09-11 08:09:31.644963+00
9529b669-de02-43d0-a902-638878a85a7f	dev	{}	2026-09-11 08:09:31.644964+00	Accès aux ressources de développement, gestion des clients d'intégration et des configs.	Developer	t	2026-09-11 08:09:31.644964+00
96101814-b255-4348-bb24-d5a963439148	guest	{}	2026-09-11 08:30:18.257167+00	Rôle de base en lecture seule, sans accès prédéfini.	Guest	t	2026-09-11 08:30:18.257167+00
96101814-b255-4348-bb24-d5a963439148	super_admin	{}	2026-09-11 08:30:18.257152+00	Propriétaire du compte. Détient le contrôle total de toutes les ressources et configurations.	Super Administrator	t	2026-09-11 08:30:18.257152+00
96101814-b255-4348-bb24-d5a963439148	dev	{}	2026-09-11 08:30:18.25717+00	Accès aux ressources de développement, gestion des clients d'intégration et des configs.	Developer	t	2026-09-11 08:30:18.25717+00
96101814-b255-4348-bb24-d5a963439148	iam_admin	{}	2026-09-11 08:30:18.257169+00	Gère les identités, les accès, les rôles et les membres de l'organisation (IAM).	IAM Administrator	t	2026-09-11 08:30:18.257169+00
96101814-b255-4348-bb24-d5a963439148	admin	{}	2026-09-11 08:30:18.257166+00	Dispose des droits complets de gestion des données et opérations de l'organisation.	Administrator	t	2026-09-11 08:30:18.257166+00
\.


--
-- Data for Name: organization_security_policies; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.organization_security_policies (org_id, created_at, device_check_enabled, ip_access_control_list, lock_duration, locked_user_check_enabled, max_login_attempts, multifactorial_required_always, multifactorial_required_on_risky_login, password_config, updated_at, updated_by) FROM stdin;
96101814-b255-4348-bb24-d5a963439148	2026-09-11 20:28:55.292979+00	f	{"empty": true, "notEmpty": false, "allowedNetworks": [], "allowedIpAddress": [], "allowedNetworkStrings": [], "allowedIpAddressStrings": []}	3600	f	2	f	t	{"blackList": ["admin"], "maxLength": 12, "minLength": 8, "requireNumber": false, "requireNonAlpha": false, "requireMixedCase": false, "withSpecialCharacters": false, "maximumPasswordAgePolicy": {"enabled": false, "daysDelay": 120}}	2026-09-11 20:28:55.292979+00	3c4fbffc-b5bf-4e90-992b-e1c916503d93
\.


--
-- Data for Name: organization_segregation_rules; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.organization_segregation_rules (org_id, rule_id, created_at, description, enabled, left_activities, name, right_activities, severity, system, updated_at) FROM stdin;
\.


--
-- Data for Name: organization_segregation_violations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.organization_segregation_violations (org_id, violation_id, conflicting_activities, created_at, detected_at, resolved_at, rule_id, severity, status, updated_at, user_id, waived_at, waived_by, waiver_reason, waiver_until) FROM stdin;
\.


--
-- Data for Name: organization_system_role_definitions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.organization_system_role_definitions (role_id, activities, created_at, description, name, updated_at) FROM stdin;
super_admin	{}	2026-09-10 15:56:58.742877+00	Propriétaire du compte. Détient le contrôle total de toutes les ressources et configurations.	Super Administrator	2026-09-10 15:56:58.742877+00
admin	{}	2026-09-10 15:56:58.742889+00	Dispose des droits complets de gestion des données et opérations de l'organisation.	Administrator	2026-09-10 15:56:58.74289+00
guest	{}	2026-09-10 15:56:58.742893+00	Rôle de base en lecture seule, sans accès prédéfini.	Guest	2026-09-10 15:56:58.742893+00
iam_admin	{}	2026-09-10 15:56:58.742897+00	Gère les identités, les accès, les rôles et les membres de l'organisation (IAM).	IAM Administrator	2026-09-10 15:56:58.742897+00
dev	{}	2026-09-10 15:56:58.7429+00	Accès aux ressources de développement, gestion des clients d'intégration et des configs.	Developer	2026-09-10 15:56:58.7429+00
\.


--
-- Data for Name: organization_temporary_access_grants; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.organization_temporary_access_grants (grant_id, created_at, emergency, expiry_notice_sent_at, granted_groups, granted_policy_ids, granted_profiles, granted_roles, org_id, reason, request_id, review_note, reviewed_at, reviewed_by, revocation_reason, revoked_at, revoked_by, status, updated_at, user_id, valid_from, valid_until) FROM stdin;
\.


--
-- Data for Name: organizations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.organizations (id, created_at, description, login_code, logo, name, rich_description, status, updated_at, website_url) FROM stdin;
9529b669-de02-43d0-a902-638878a85a7f	2026-09-11 08:09:31.64373+00	Solar LTD	solar-ltdrhkv	\N	Solar LTD	\N	ENABLED	2026-09-11 08:09:31.64373+00	\N
96101814-b255-4348-bb24-d5a963439148	2026-09-11 08:30:18.257063+00	Opur SAR	opur-sarhlwg	\N	Opur SAR	\N	ENABLED	2026-09-11 08:30:18.257063+00	\N
\.


--
-- Data for Name: resource_policy_entity_authorized_actions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.resource_policy_entity_authorized_actions (resource_policy_entity_id, authorized_actions) FROM stdin;
\.


--
-- Data for Name: resource_policy_entity_related_resources; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.resource_policy_entity_related_resources (resource_policy_entity_id, related_resources) FROM stdin;
\.


--
-- Data for Name: resource_servers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.resource_servers (id, created_at, description, display_name, name, updated_at) FROM stdin;
default	2026-09-10 15:56:58.570948+00	Serveur de ressources par défaut, réutilisé par tout ResourceType/Action qui ne précise pas de serverName.	Default	default	2026-09-10 15:56:58.570948+00
\.


--
-- Data for Name: resource_types; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.resource_types (id, created_at, default_policy_specs, description, display_name, localized_descriptions, localized_display_names, realm, server_name, updated_at) FROM stdin;
authorization	2026-09-10 15:56:58.603139+00	\N	APIs internes de contrôle d'accès et de résolution des permissions.	Autorisation	{}	{}	default	default	2026-09-10 15:56:58.603139+00
openid-connect	2026-09-10 15:56:58.67513+00	\N	Scopes OIDC standard, indépendants de tout catalogue métier.	OpenID Connect	{}	{}	default	default	2026-09-10 15:56:58.67513+00
user	2026-09-10 15:56:58.699024+00	\N	Compte utilisateur (profil, préférences) - APIs self-service /me.	Utilisateur	{}	{}	default	default	2026-09-10 15:56:58.699024+00
client	2026-09-10 15:56:58.707374+00	\N	Client OAuth2/OIDC (application) - gestion des clients.	Client	{}	{}	default	default	2026-09-10 15:56:58.707374+00
organization	2026-09-10 15:56:58.713802+00	\N	Organisation (compte multi-utilisateurs) - gestion des organisations.	Organisation	{}	{}	default	default	2026-09-10 15:56:58.713802+00
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.roles (id, created_at, deprecated, description, display_name, managed, parents, updated_at) FROM stdin;
user	2026-09-10 15:56:58.721451+00	f	Utilisateur standard, sans droit d'administration.	Utilisateur	f	{}	2026-09-10 15:56:58.721451+00
admin	2026-09-10 15:56:58.738846+00	f	Droits d'administration de la plateforme.	Administrateur	f	{}	2026-09-10 15:56:58.738846+00
iam_admin	2026-09-10 15:56:58.740443+00	f	Droits d'administration des users, orgs, roles, policies.	Administrateur IAM	f	{}	2026-09-10 15:56:58.740443+00
super_admin	2026-09-10 15:56:58.741807+00	f	Contrôle total de la plateforme.	Super administrateur	f	{}	2026-09-10 15:56:58.741807+00
\.


--
-- Data for Name: scopes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.scopes (id, created_at, deprecated, description, display_name, localized_descriptions, localized_display_names, managed, realm, resource_type, server_name, type, updated_at) FROM stdin;
auth.authorization.check	2026-09-10 15:56:58.654956+00	f	Autorise un resource server à appeler les APIs internes d'autorisation.	Vérifier les autorisations	{}	{}	f	default	authorization	default	MACHINE	2026-09-10 15:56:58.654956+00
auth.authorization.policies.manage	2026-09-10 15:56:58.673371+00	f	Autorise un resource server à créer des ResourcePolicy pour les resources qu'il gère.	Gérer les policies	{}	{}	f	default	authorization	default	MACHINE	2026-09-10 15:56:58.673371+00
openid	2026-09-10 15:56:58.677587+00	f	Requis pour toute requête OIDC : identifie l'utilisateur (claim sub).	OpenID	{}	{}	f	default	openid-connect	default	HUMAN	2026-09-10 15:56:58.677587+00
email	2026-09-10 15:56:58.679241+00	f	Accès à l'adresse email de l'utilisateur et son statut de vérification.	Email	{}	{}	f	default	openid-connect	default	HUMAN	2026-09-10 15:56:58.679241+00
phone	2026-09-10 15:56:58.680857+00	f	Accès au numéro de téléphone de l'utilisateur et son statut de vérification.	Téléphone	{}	{}	f	default	openid-connect	default	HUMAN	2026-09-10 15:56:58.680857+00
profile	2026-09-10 15:56:58.68288+00	f	Accès aux informations de profil de base de l'utilisateur.	Profil	{}	{}	f	default	openid-connect	default	HUMAN	2026-09-10 15:56:58.68288+00
address	2026-09-10 15:56:58.684266+00	f	Accès aux informations d'adresse de l'utilisateur.	Adresse	{}	{}	f	default	openid-connect	default	HUMAN	2026-09-10 15:56:58.684266+00
offline_access	2026-09-10 15:56:58.685492+00	f	Autorise l'émission et l'utilisation d'un refresh token.	Accès hors ligne	{}	{}	f	default	openid-connect	default	HUMAN	2026-09-10 15:56:58.685492+00
user.read	2026-09-10 15:56:58.70163+00	f	Autorise la lecture des informations de son propre compte utilisateur.	Lire son profil	{}	{}	f	default	user	default	ANY	2026-09-10 15:56:58.70163+00
user.write	2026-09-10 15:56:58.704476+00	f	Autorise la modification des informations de son propre compte utilisateur.	Modifier son profil	{}	{}	f	default	user	default	ANY	2026-09-10 15:56:58.704476+00
client.read	2026-09-10 15:56:58.710171+00	f	Autorise la consultation des clients OAuth2/OIDC.	Lire les clients	{}	{}	f	default	client	default	MACHINE	2026-09-10 15:56:58.710171+00
client.write	2026-09-10 15:56:58.711964+00	f	Autorise la création, modification et suppression des clients OAuth2/OIDC.	Gérer les clients	{}	{}	f	default	client	default	MACHINE	2026-09-10 15:56:58.711964+00
organization.read	2026-09-10 15:56:58.716547+00	f	Autorise la consultation des organisations.	Lire les organisations	{}	{}	f	default	organization	default	HUMAN	2026-09-10 15:56:58.716547+00
organization.write	2026-09-10 15:56:58.717875+00	f	Autorise la création, modification et suppression des organisations.	Gérer les organisations	{}	{}	f	default	organization	default	HUMAN	2026-09-10 15:56:58.717875+00
\.


--
-- Data for Name: tokens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tokens (id, active, claims, expires_at, issued_at, metadata, not_before, token_format, type, value) FROM stdin;
649c0138-5d9f-48a8-bdf1-feec5fdd5c2d	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789061685, "session_id": "bb7ab7c6-c611-4914-849c-0ceaeb3039e4", "session_exp": 1799429685}	2026-10-10 17:34:45.616036+00	2026-09-10 17:34:45.616036+00	{}	2026-09-10 17:34:15.616036+00	OPAQUE	REFRESH_TOKEN	pnchiKBYgqqTNz7boE-e-HWj8QiWAwOWM3MGE0YjAtNjQ2OS00YTNhLTk3Y2QtMmM2OWUwOWI4MDk0
11c1bdee-ca9b-410f-9867-0e0bb2ef7a04	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789061775, "session_id": "0d0acd82-63fc-4db0-8eab-05bdb394d8d1", "session_exp": 1799429775}	2026-10-10 17:36:15.948462+00	2026-09-10 17:36:15.948462+00	{}	2026-09-10 17:35:45.948462+00	OPAQUE	REFRESH_TOKEN	TKLZhowwgF6CcMoFjD51XC-s1lV-ygMmFiOWU1OTAtMDY2Mi00OWE4LTg5ZmUtNjhjYTdlOGUxYjVh
3f950264-b5e4-453e-ad3a-e691be4d8969	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789061821, "session_id": "fa64aea9-a90c-4d39-9172-88874ca3bd3d", "session_exp": 1799429821}	2026-10-10 17:37:01.751297+00	2026-09-10 17:37:01.751297+00	{}	2026-09-10 17:36:31.751297+00	OPAQUE	REFRESH_TOKEN	rIA-XPIFST3AUBMYdxi8x6M_yI_q5wYmI5YTA0OTEtNTRiOC00NjA4LWFjMzQtYTc2ODkwYjdkNjEy
8fb086fc-290a-4261-a20f-59e69f1425a0	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789062693, "session_id": "10d6a7eb-a28d-453a-8adf-f5d2cccf44cb", "session_exp": 1799430693}	2026-10-10 17:51:33.208215+00	2026-09-10 17:51:33.208215+00	{}	2026-09-10 17:51:03.208215+00	OPAQUE	REFRESH_TOKEN	dC69tFBgPRQUhQZuthd-ZvntHYjelwYzBlOWJkOTQtMGFkZC00OWU1LWJjYmEtM2Y1MGFmZjQ0NzE0
059e54ae-d7f0-4008-9433-9f77f8c18bb6	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "77363c25-ecbc-4a67-a3bb-21546a9d0a80", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "admin", "auth_time": 1789071507, "session_id": "bf8eea91-1a2f-4e9c-b485-f0611138fd4f", "session_exp": 1799439507}	2026-10-10 20:18:27.982611+00	2026-09-10 20:18:27.982611+00	{}	2026-09-10 20:17:57.982611+00	OPAQUE	REFRESH_TOKEN	bkhrk0vU--VY8-pE9PzDlREwkSXNxAZmE4MjcyYzQtMzI0Zi00YThiLTgxZWUtZjVlZDFiMDUzOWVi
a0d67219-5cb3-47f8-82ec-4b981758df04	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "77363c25-ecbc-4a67-a3bb-21546a9d0a80", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "admin", "auth_time": 1789074355, "session_id": "7c159d4a-adce-4da9-98b8-6e681eb59334", "session_exp": 1799442355}	2026-10-10 21:05:55.405524+00	2026-09-10 21:05:55.405524+00	{}	2026-09-10 21:05:25.405524+00	OPAQUE	REFRESH_TOKEN	I99GNq5CjSsQ2nNs8xnKK0rgeM-JgQZDgzMGE3Y2EtZWMwNS00NzIxLTljMmMtMjJmNGNlMjExMWY4
67c3e977-6123-4214-b557-771e6923ea83	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "77363c25-ecbc-4a67-a3bb-21546a9d0a80", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "admin", "auth_time": 1789074827, "session_id": "46b7069b-a12c-4b84-93c9-a14a76d47c0b", "session_exp": 1799442827}	2026-10-10 21:13:47.314444+00	2026-09-10 21:13:47.314444+00	{}	2026-09-10 21:13:17.314444+00	OPAQUE	REFRESH_TOKEN	oYjC-y7Dyk_bsJAumC5NAfNMpZn1cAZjAxNjU0MGEtMWZlYi00NGQ0LWExNWUtZmI3N2FmMGMzMDdk
bdaaa2a1-bbe6-4924-9441-63a815088d08	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "77363c25-ecbc-4a67-a3bb-21546a9d0a80", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "admin", "auth_time": 1789074977, "session_id": "20fa4557-8ae0-4abb-af9b-55ff0cd9fa68", "session_exp": 1799442977}	2026-10-10 21:16:17.322521+00	2026-09-10 21:16:17.322521+00	{}	2026-09-10 21:15:47.322521+00	OPAQUE	REFRESH_TOKEN	uHn1nfqsBcyKpZxZ3JzJ2YEmLfl3GwMjQ5YzA1NmMtN2ZkNy00MGQ1LWIwZTctN2JjNDcxMGU1YTIx
e91dd0dc-d5fa-4904-9011-acffd7fd735a	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "77363c25-ecbc-4a67-a3bb-21546a9d0a80", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "admin", "auth_time": 1789075001, "session_id": "f671c1eb-29b2-48da-91d5-8a33d893fb0a", "session_exp": 1799443001}	2026-10-10 21:16:41.804115+00	2026-09-10 21:16:41.804115+00	{}	2026-09-10 21:16:11.804115+00	OPAQUE	REFRESH_TOKEN	4TQNQHVj_NGlKHCVC507GsCCO-S9PQZGExOTg0ZTAtNTkyNC00ZjEyLTkyNzUtYzhlYTUzZWYxZjY3
128122dd-8868-41e1-a394-a2fd171d5f59	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "77363c25-ecbc-4a67-a3bb-21546a9d0a80", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "admin", "auth_time": 1789075675, "session_id": "5702cbea-8742-4dc0-8fa7-47e2fca07405", "session_exp": 1799443675}	2026-10-10 21:27:55.162046+00	2026-09-10 21:27:55.162046+00	{}	2026-09-10 21:27:25.162046+00	OPAQUE	REFRESH_TOKEN	Ye0hDzueFC19fj-pkqJPNlDapMlcQgZDFmM2MzMTUtMGJiYi00NjE0LTg5Y2QtNTNhZjZlNGRmNjNj
2ff09df8-7d7b-46c4-8ee1-8fbc2532e58a	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "77363c25-ecbc-4a67-a3bb-21546a9d0a80", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "admin", "auth_time": 1789075789, "session_id": "ed16edb2-f893-4703-9e51-60f24c24968f", "session_exp": 1799443789}	2026-10-10 21:29:49.802374+00	2026-09-10 21:29:49.802374+00	{}	2026-09-10 21:29:19.802374+00	OPAQUE	REFRESH_TOKEN	Cw7QN-G2Tlv0mt9aLlVB-I6YUtqccQNGJjZGE3MTItNGE2MC00MDZlLTk1NzgtM2FhODg1NzE5MDhl
4ce4f82a-e635-4eea-9425-83ae70a09b36	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "77363c25-ecbc-4a67-a3bb-21546a9d0a80", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "admin", "auth_time": 1789075930, "session_id": "9542a540-08cd-4a6c-924f-c74aabaec1e0", "session_exp": 1799443930}	2026-10-10 21:32:10.770087+00	2026-09-10 21:32:10.770087+00	{}	2026-09-10 21:31:40.770087+00	OPAQUE	REFRESH_TOKEN	9_Tj_uUfRiE1ZrUogry0Rb7KxW5v3QNmE1Y2RmOGEtMGVlYi00MWQ4LWExM2UtYmM3YTIxYzcxYzJh
39349ffc-15c5-4889-b33b-6b73ef305189	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "77363c25-ecbc-4a67-a3bb-21546a9d0a80", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "admin", "auth_time": 1789076390, "session_id": "d64ff17d-482b-41a1-a713-73961df5f9fd", "session_exp": 1799444390}	2026-10-10 21:39:50.36278+00	2026-09-10 21:39:50.36278+00	{}	2026-09-10 21:39:20.36278+00	OPAQUE	REFRESH_TOKEN	uY_vMe3nRsrWhWwoFJ_DKKKLyND53gZjY3NWJjMWYtNDE2MS00ODEwLWI1YjEtODA0ZjZiYTJiZjEx
bc89871d-dd40-4181-acc1-a8be3a0340fd	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "77363c25-ecbc-4a67-a3bb-21546a9d0a80", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "admin", "auth_time": 1789076739, "session_id": "a236975f-dfcd-4dbb-b07d-4c65b06b4f18", "session_exp": 1799444739}	2026-10-10 21:45:39.424371+00	2026-09-10 21:45:39.424371+00	{}	2026-09-10 21:45:09.424371+00	OPAQUE	REFRESH_TOKEN	rEJDBZE-C28x7X-mFEtC7NZg0LZoUQZmI4YmZkYzMtMDM0Yy00MTJlLWFiNWYtYjEyOTFmYTI1MzAw
4c5045bd-4d24-41c3-9b63-d1255e50238e	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "77363c25-ecbc-4a67-a3bb-21546a9d0a80", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "admin", "auth_time": 1789077166, "session_id": "b1ced0d8-29c5-47d5-9c5f-5e9633761c0b", "session_exp": 1799445166}	2026-10-10 21:52:46.875621+00	2026-09-10 21:52:46.875621+00	{}	2026-09-10 21:52:16.875621+00	OPAQUE	REFRESH_TOKEN	LnenuWM5R5fZvIJ8rweQwK4n_5QAowZDQxODNlNGYtN2ZhMS00ZjdhLWFmN2EtY2VlYzBiZWNiMDhm
598acd79-ed53-4ada-9828-faf546118f63	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "77363c25-ecbc-4a67-a3bb-21546a9d0a80", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "admin", "auth_time": 1789077935, "session_id": "d83164f4-6d3d-4ff6-b8c3-c7508b44ca93", "session_exp": 1799445935}	2026-10-10 22:05:35.603148+00	2026-09-10 22:05:35.603148+00	{}	2026-09-10 22:05:05.603148+00	OPAQUE	REFRESH_TOKEN	dYD1CYvykk4_u_5PfcZs9Sr6-cq4pwMmJmMTA3ZWEtZWJmMS00YjgyLTkzMzgtZGU0M2Q2NTExZGEz
fa189269-e766-4416-971d-7229e0163ce7	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "77363c25-ecbc-4a67-a3bb-21546a9d0a80", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "admin", "auth_time": 1789079939, "session_id": "76a6b219-e275-4b42-83e2-289483d65fdb", "session_exp": 1799447939}	2026-10-10 22:38:59.497451+00	2026-09-10 22:38:59.497451+00	{}	2026-09-10 22:38:29.497451+00	OPAQUE	REFRESH_TOKEN	euG5UcNEDV0o3-pM-ualG6p8poANNgMGIxYjJlZmQtYzkxNy00OTRiLWEyM2UtMWQ3YzhkNmQ0ZmEx
c7f6eab8-fc76-4a4d-97cc-7b9f9eba2216	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "77363c25-ecbc-4a67-a3bb-21546a9d0a80", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "admin", "auth_time": 1789080398, "session_id": "b0e1cd38-348c-4568-b15a-611955843d28", "session_exp": 1799448398}	2026-10-10 22:46:38.782595+00	2026-09-10 22:46:38.782595+00	{}	2026-09-10 22:46:08.782595+00	OPAQUE	REFRESH_TOKEN	opCcywneLPPOHoAlEh-d-eeVxB9oGAZjMyYzEzMmEtZTI5MS00NzU1LTk0ZGMtMjM3MjRiMzQ1Yzcx
000809e7-43d0-40c4-9b35-0c50026ec2b3	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "77363c25-ecbc-4a67-a3bb-21546a9d0a80", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "admin", "auth_time": 1789081180, "session_id": "dd710984-120b-4310-8728-613c0efc1ef1", "session_exp": 1799449180}	2026-10-10 22:59:40.606423+00	2026-09-10 22:59:40.606423+00	{}	2026-09-10 22:59:10.606423+00	OPAQUE	REFRESH_TOKEN	PTW8DtD6arm0z0eLYZ3YglvO9HFrbgZWM0NjA4OGYtNzJhMy00NjgxLTk2NTktZmFhM2U0ZTBjZjIx
4aff288f-3395-4a81-89e7-65b3ed513247	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "77363c25-ecbc-4a67-a3bb-21546a9d0a80", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "admin", "auth_time": 1789081649, "session_id": "612d080c-faec-42d7-b56c-ed93b67b6598", "session_exp": 1799449649}	2026-10-10 23:07:29.20339+00	2026-09-10 23:07:29.20339+00	{}	2026-09-10 23:06:59.20339+00	OPAQUE	REFRESH_TOKEN	iYHeRBuQI_PuUIuK-z1QK6dtugZJaQMjJkM2MyNGMtYzc4Zi00ZDgxLWE5MzgtMjk0NzUzMzkyN2Y2
0d9e88a2-41dc-43c3-8bf1-f66fb4ffeeb3	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "77363c25-ecbc-4a67-a3bb-21546a9d0a80", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "admin", "auth_time": 1789082048, "session_id": "af6a85bf-98ec-4b1d-bcad-7a5e8ec60305", "session_exp": 1799450048}	2026-10-10 23:14:08.671533+00	2026-09-10 23:14:08.671533+00	{}	2026-09-10 23:13:38.671533+00	OPAQUE	REFRESH_TOKEN	zbuU_1_liiuQxPhE1en5G6CJqZN8cgZDEyZTViZmUtN2UwZC00ZTNiLTg1M2UtZjg0Njk3NTZiMmI4
8bbeef9d-1d1c-4371-b726-70a09bba477a	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "77363c25-ecbc-4a67-a3bb-21546a9d0a80", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "admin", "auth_time": 1789110859, "session_id": "68fd65f8-289e-48b0-9b62-e8bfbd3ef32a", "session_exp": 1799478859}	2026-10-11 07:14:19.947296+00	2026-09-11 07:14:19.947296+00	{}	2026-09-11 07:13:49.947296+00	OPAQUE	REFRESH_TOKEN	qo8ngx1qEOyFKd8Pj6u3a1yuD6ISVAZjA0OGVjZDItZTVlNy00ZWNmLTkwODYtZTNhZjg5NjBjOWVh
58fc8e18-bc79-497a-9bf7-6f8b0f2f3cbe	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "77363c25-ecbc-4a67-a3bb-21546a9d0a80", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "admin", "auth_time": 1789111368, "session_id": "d7ca26ef-4975-4ee0-94e4-287d354b87c0", "session_exp": 1799479368}	2026-10-11 07:22:48.271053+00	2026-09-11 07:22:48.271053+00	{}	2026-09-11 07:22:18.271053+00	OPAQUE	REFRESH_TOKEN	qz7_R3AIJMcq_paomLDUPHexr-G1AQODkwM2M0YmYtMTBjMy00NjI5LWExNzEtMmQ0MzY3ZjU2N2Vm
84371a9d-d122-4164-a928-90eb0fcd450d	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "77363c25-ecbc-4a67-a3bb-21546a9d0a80", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "admin", "auth_time": 1789112587, "session_id": "0985f05f-a2df-4845-b876-b9623d90f3ca", "session_exp": 1799480587}	2026-10-11 07:43:07.630924+00	2026-09-11 07:43:07.630924+00	{}	2026-09-11 07:42:37.630924+00	OPAQUE	REFRESH_TOKEN	6MhyXsgR4Sa-y4ES1I_bV2z5IUXhQQM2RhMWUzMzItNGQ5OC00NTNiLTkwYjEtOWMxYTIwZjliOGUz
ff5d89ee-0488-4648-92b3-7cfe3f73df38	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "77363c25-ecbc-4a67-a3bb-21546a9d0a80", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "admin", "auth_time": 1789113353, "session_id": "6296a24b-62db-43f5-938b-c47baf857539", "session_exp": 1799481353}	2026-10-11 07:55:53.415288+00	2026-09-11 07:55:53.415288+00	{}	2026-09-11 07:55:23.415288+00	OPAQUE	REFRESH_TOKEN	T1JC5H9-YzaOCO65akRly8CIJW0B8wY2MzN2RlZTAtZGE3My00MTg4LWI0ZTEtOTg3M2MzYjg3YmI4
59a06aa2-2183-424a-958e-e3910583637b	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "77363c25-ecbc-4a67-a3bb-21546a9d0a80", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "admin", "auth_time": 1789113353, "session_id": "6296a24b-62db-43f5-938b-c47baf857539", "session_exp": 1799481353}	2026-10-11 08:00:57.797494+00	2026-09-11 08:00:57.797494+00	{}	2026-09-11 08:00:27.797494+00	OPAQUE	REFRESH_TOKEN	nwxxNeyMtrhguV_4ifrOfnaf8IX6CAMDNjZjZhNjMtNzIwNi00NTVkLThmN2UtNzg3M2ZhNzEzYjY0
478b806b-0aed-44ed-8caa-66285916b7c5	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "77363c25-ecbc-4a67-a3bb-21546a9d0a80", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "admin", "auth_time": 1789113353, "session_id": "6296a24b-62db-43f5-938b-c47baf857539", "session_exp": 1799481353}	2026-10-11 08:09:30.462479+00	2026-09-11 08:09:30.462479+00	{}	2026-09-11 08:09:00.462479+00	OPAQUE	REFRESH_TOKEN	bpv9C1uF4EXIUVBP5z03kExEYMtTwAMzQxNjY0MzctZTg4ZC00NDg4LTlmNDUtMjM1MmY0YmI5NDgy
8145b284-16fa-4b50-8282-7ea7667b1a8d	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "77363c25-ecbc-4a67-a3bb-21546a9d0a80", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "admin", "auth_time": 1789113353, "session_id": "6296a24b-62db-43f5-938b-c47baf857539", "session_exp": 1799481353}	2026-10-11 08:21:31.443512+00	2026-09-11 08:21:31.443512+00	{}	2026-09-11 08:21:01.443512+00	OPAQUE	REFRESH_TOKEN	qvRK2jjkjrtJmiWZAxMfsKyXDvWmgANzIwNDNlMTEtZTBjMy00OWE2LTk3MDMtZDY2YThiNDdkNmZk
a7e9f1a5-3b3b-4d2d-9a76-36733875b908	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "77363c25-ecbc-4a67-a3bb-21546a9d0a80", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "admin", "auth_time": 1789113353, "session_id": "6296a24b-62db-43f5-938b-c47baf857539", "session_exp": 1799481353}	2026-10-11 08:26:33.355018+00	2026-09-11 08:26:33.355018+00	{}	2026-09-11 08:26:03.355018+00	OPAQUE	REFRESH_TOKEN	Ka4bAI3CKJJuXgkdwLOVcc_NTnp-VgNzRhZTNmNGYtYWU4Ny00MmYxLWIzZWItMjI4N2YzZTIwNGIw
a8d7f620-92c5-4fe8-9643-c47e31e196be	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "77363c25-ecbc-4a67-a3bb-21546a9d0a80", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "admin", "auth_time": 1789113353, "session_id": "6296a24b-62db-43f5-938b-c47baf857539", "session_exp": 1799481353}	2026-10-11 08:32:11.041412+00	2026-09-11 08:32:11.041412+00	{}	2026-09-11 08:31:41.041412+00	OPAQUE	REFRESH_TOKEN	IHsL3pL5k5tSPwT1hSbIdpi-QisVkgZGRlMDY0MjMtZDM5Mi00NTExLTg1YjYtNmIyODcwZjBlYWFh
5b470dce-f329-4e86-b881-1e691cb18a14	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "77363c25-ecbc-4a67-a3bb-21546a9d0a80", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "admin", "auth_time": 1789113353, "session_id": "6296a24b-62db-43f5-938b-c47baf857539", "session_exp": 1799481353}	2026-10-11 08:41:58.687022+00	2026-09-11 08:41:58.687022+00	{}	2026-09-11 08:41:28.687022+00	OPAQUE	REFRESH_TOKEN	oW21C_Y7tln3bbHyti00h8s1s9Wb2wYzJjMzQyZmItZDljMy00ZWNjLWJhYzMtNzJjZWM3ODVmMjgy
1b0f7b59-4fb9-4964-9fad-a1dcc200b71e	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "77363c25-ecbc-4a67-a3bb-21546a9d0a80", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "admin", "auth_time": 1789113353, "session_id": "6296a24b-62db-43f5-938b-c47baf857539", "session_exp": 1799481353}	2026-10-11 08:47:00.973705+00	2026-09-11 08:47:00.973705+00	{}	2026-09-11 08:46:30.973705+00	OPAQUE	REFRESH_TOKEN	XGbuB2Ow-6vdKT8fb_UcIppFGCBgiQZGNiMDRkNDAtMDAzYS00YjNlLTkwYTUtODEwM2M5MGU2MTYz
d0cdd96c-d219-461f-a2fb-a1ab78309f20	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "77363c25-ecbc-4a67-a3bb-21546a9d0a80", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "admin", "auth_time": 1789113353, "session_id": "6296a24b-62db-43f5-938b-c47baf857539", "session_exp": 1799481353}	2026-10-11 08:47:01.571516+00	2026-09-11 08:47:01.571516+00	{}	2026-09-11 08:46:31.571516+00	OPAQUE	REFRESH_TOKEN	Q8GLpXmIirAoDjmjlIhYKdgHRxBRNgMWI2OGYxYjMtNjI5My00YjQ4LTk4ZTYtMTA2N2RiMTcyNDU0
53f823da-2ed1-4d31-b639-accde9b8745f	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "77363c25-ecbc-4a67-a3bb-21546a9d0a80", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "admin", "auth_time": 1789113353, "session_id": "6296a24b-62db-43f5-938b-c47baf857539", "session_exp": 1799481353}	2026-10-11 08:54:24.574723+00	2026-09-11 08:54:24.574723+00	{}	2026-09-11 08:53:54.574723+00	OPAQUE	REFRESH_TOKEN	NAnV6J6z11eY6JzjkzIl5W-Q4MGexAMmNkZDY3YmItMjM4ZC00YWZkLWJiNWUtNWI2MThmOTM5YzRh
cb58e209-00e6-474f-be5f-f0bd33c6befd	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789116919, "session_id": "d7eb1c34-9f11-423e-9e34-5dabad62e58f", "session_exp": 1799484919}	2026-10-11 08:55:19.896948+00	2026-09-11 08:55:19.896948+00	{}	2026-09-11 08:54:49.896948+00	OPAQUE	REFRESH_TOKEN	utocSyZSr_TM38S2Nq1DGWd-t2JucgZjJmNTg3MmQtNzNmNC00NzA4LThiMTYtZmEzYjliNzI1NGZk
96f02fc0-ece1-4817-9fb9-3e299966faf0	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789116919, "session_id": "d7eb1c34-9f11-423e-9e34-5dabad62e58f", "session_exp": 1799484919}	2026-10-11 08:55:25.161738+00	2026-09-11 08:55:25.161738+00	{}	2026-09-11 08:54:55.161738+00	OPAQUE	REFRESH_TOKEN	KTPXCaSARt7bUBCiUEw2MdWp-zktXgNzYxZmQwN2UtYjRiOC00NTQyLWJmNTAtNDNjYmFkY2QzN2Nh
da7b9878-8d91-44f6-a7c4-04917c97f540	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789116919, "session_id": "d7eb1c34-9f11-423e-9e34-5dabad62e58f", "session_exp": 1799484919}	2026-10-11 12:18:37.2257+00	2026-09-11 12:18:37.2257+00	{}	2026-09-11 12:18:07.2257+00	OPAQUE	REFRESH_TOKEN	zFBAZBwuTL1A_cGfrtwVxRypJCw10wNTFjMDA1NGUtNWM2Yy00ZDkyLThhOWQtM2Q4ZDcyNTY1N2U4
56ce145d-9982-40b7-b9f3-7ce9098a5dd3	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789116919, "session_id": "d7eb1c34-9f11-423e-9e34-5dabad62e58f", "session_exp": 1799484919}	2026-10-11 12:24:42.718413+00	2026-09-11 12:24:42.718413+00	{}	2026-09-11 12:24:12.718413+00	OPAQUE	REFRESH_TOKEN	dNnatNX4ZCDowyWycfq56nH1Ih5QGwNDgxMThmYWQtYjM4Mi00MDYxLWI5NjQtMTA4YmQxNWZlMGVm
b767b1ed-bd4a-48ac-a51c-e1a60b807138	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789116919, "session_id": "d7eb1c34-9f11-423e-9e34-5dabad62e58f", "session_exp": 1799484919}	2026-10-11 12:24:43.14951+00	2026-09-11 12:24:43.14951+00	{}	2026-09-11 12:24:13.14951+00	OPAQUE	REFRESH_TOKEN	sg5LvjFDq0AEoyRTrIwWojVQAF58-ANTQ4YTYyMmEtOWRiZS00Y2EwLWFkZTYtN2MwYzE2ZDMzYWQw
7f3ac8dc-14d9-43e7-81c0-ed3ecde5c569	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789116919, "session_id": "d7eb1c34-9f11-423e-9e34-5dabad62e58f", "session_exp": 1799484919}	2026-10-11 12:33:09.010912+00	2026-09-11 12:33:09.010912+00	{}	2026-09-11 12:32:39.010912+00	OPAQUE	REFRESH_TOKEN	7pxWwWT98xUHL73mPEeH4XGfiI1aKQMTViOWFkZWYtYWZhZi00OGU3LWFjYWItMmQ4ZGVkMGFmN2Fj
7535d813-3b77-4777-93dd-1d5fef326084	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789116919, "session_id": "d7eb1c34-9f11-423e-9e34-5dabad62e58f", "session_exp": 1799484919}	2026-10-11 12:33:09.47151+00	2026-09-11 12:33:09.47151+00	{}	2026-09-11 12:32:39.47151+00	OPAQUE	REFRESH_TOKEN	IaYgaxqyJIW9t_b5kuViAkJa6H9ggAYTA5ZWNjMWUtZWM5Yi00MTdmLWFkNzAtMTFkZTIxMmEzNjhl
e32a175f-bc62-4622-8142-36e5e89b7360	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789116919, "session_id": "d7eb1c34-9f11-423e-9e34-5dabad62e58f", "session_exp": 1799484919}	2026-10-11 12:33:09.716772+00	2026-09-11 12:33:09.716772+00	{}	2026-09-11 12:32:39.716772+00	OPAQUE	REFRESH_TOKEN	m2kyYj1g85t-XvpwC6NutVBmf6VhkQNzYzOTE5MDAtNzc0OS00NmI3LWIyYjktN2JhMTBhN2M0NmVh
3e95fbd0-51d2-4ddf-9c76-e39037bae94b	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789116919, "session_id": "d7eb1c34-9f11-423e-9e34-5dabad62e58f", "session_exp": 1799484919}	2026-10-11 12:33:10.061835+00	2026-09-11 12:33:10.061835+00	{}	2026-09-11 12:32:40.061835+00	OPAQUE	REFRESH_TOKEN	PmVtx76bAT9d1BKxK_kJUpWEBKNZjAZGNjYjU5OTktY2NkNC00ODhhLWFkMmEtODQwZDRhNDRiNTJm
1682ca89-5b59-4d5a-8134-c2fdbdb1a5a5	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789116919, "session_id": "d7eb1c34-9f11-423e-9e34-5dabad62e58f", "session_exp": 1799484919}	2026-10-11 12:33:10.436865+00	2026-09-11 12:33:10.436865+00	{}	2026-09-11 12:32:40.436865+00	OPAQUE	REFRESH_TOKEN	dvje_Wu3cCXVTeYtdkbovaAanM5ongMzU5MjI1ODgtNWZlOS00NzA0LTkxYjMtOGVlMGVmNWRmNTNk
c66f0078-c130-4872-8347-274297483037	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789116919, "session_id": "d7eb1c34-9f11-423e-9e34-5dabad62e58f", "session_exp": 1799484919}	2026-10-11 12:33:10.856636+00	2026-09-11 12:33:10.856636+00	{}	2026-09-11 12:32:40.856636+00	OPAQUE	REFRESH_TOKEN	UCFRcuggRVjWqmM0vwgZHtATtYbAGQYzVjYTJiMzUtNjBhNy00NGM5LTgzYzItMjBmYThmZWFlYTVk
14df300d-3e80-4616-b68c-6024fa2a3a94	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789116919, "session_id": "d7eb1c34-9f11-423e-9e34-5dabad62e58f", "session_exp": 1799484919}	2026-10-11 12:38:23.395684+00	2026-09-11 12:38:23.395684+00	{}	2026-09-11 12:37:53.395684+00	OPAQUE	REFRESH_TOKEN	vzteDn67C9hMicVTZcbNuNyqYe8A4AMTQ2MmJhOGQtODdkNS00ODNhLTllZTItNzA3NWJiZjU4ZjBl
b8c98dff-e76c-4fc3-82f4-e44047f02eed	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789116919, "session_id": "d7eb1c34-9f11-423e-9e34-5dabad62e58f", "session_exp": 1799484919}	2026-10-11 12:38:23.633486+00	2026-09-11 12:38:23.633486+00	{}	2026-09-11 12:37:53.633486+00	OPAQUE	REFRESH_TOKEN	apZNfB_egvK9-9i1_4cNzakDlkk8PQYmFlMGJiNjktMmNjNS00OWUwLTlhMjEtMGYyYzQwMTRiODNl
4296e97f-812f-4745-ae9a-9d09342e6a3a	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789116919, "session_id": "d7eb1c34-9f11-423e-9e34-5dabad62e58f", "session_exp": 1799484919}	2026-10-11 12:38:23.862466+00	2026-09-11 12:38:23.862466+00	{}	2026-09-11 12:37:53.862466+00	OPAQUE	REFRESH_TOKEN	efH07YmQaHzqxC0Xi0uyGVgnCWEcUgMTFlYThjMjMtNTQzNS00ZGU2LThkNTItZWJlYjcyMDFmMmYy
c2437e10-d535-422a-ae34-f39cc3758d25	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789116919, "session_id": "d7eb1c34-9f11-423e-9e34-5dabad62e58f", "session_exp": 1799484919}	2026-10-11 12:38:24.198009+00	2026-09-11 12:38:24.198009+00	{}	2026-09-11 12:37:54.198009+00	OPAQUE	REFRESH_TOKEN	LWTIVXJMg_SE1lYRqyfnBzZPRsQ_yQMzBiZGI3NzEtYjAzMy00ODAyLWE5OGEtMDk5YzlkMDdlNjkw
92beb5bc-37c0-436a-b1ed-d643e792cb46	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789116919, "session_id": "d7eb1c34-9f11-423e-9e34-5dabad62e58f", "session_exp": 1799484919}	2026-10-11 12:38:24.467347+00	2026-09-11 12:38:24.467347+00	{}	2026-09-11 12:37:54.467347+00	OPAQUE	REFRESH_TOKEN	xISsSEbyQpB84B2a9fygdz6KoIEJEAMjYxN2U1MWYtNzJjMC00ZWE5LThlOTktM2IxYWU1MDgwMjM2
91612167-de44-4ec9-b3aa-aaff3ec77f2b	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789130410, "session_id": "01cd6656-776e-4b80-afdd-b7890bc165ba", "session_exp": 1799498410}	2026-10-11 12:40:10.796911+00	2026-09-11 12:40:10.796911+00	{}	2026-09-11 12:39:40.796911+00	OPAQUE	REFRESH_TOKEN	6EL-Ux21QPGJAUpxkcq3NOE1-g_CzgNWIwN2U4MDAtOTk2NC00NzM3LTg3ZTAtOWNjNjllZDM2Yzgx
07e4f67d-a8b4-4c55-acac-0ff9b77ce641	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789130556, "session_id": "4276411f-0d02-42b7-b181-4b16476abbd2", "session_exp": 1799498556}	2026-10-11 12:42:36.627423+00	2026-09-11 12:42:36.627423+00	{}	2026-09-11 12:42:06.627423+00	OPAQUE	REFRESH_TOKEN	jKdMmvAZI3FHaiGEu9u5FFV4LGdz1gNTQ2OWRhN2ItYzc5Yi00NWY4LWI0NWUtZmE4ZGZhNjNmZTVi
dc7110bb-e31e-4fc6-ada2-ede4d0db636a	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789130556, "session_id": "4276411f-0d02-42b7-b181-4b16476abbd2", "session_exp": 1799498556}	2026-10-11 12:47:40.631931+00	2026-09-11 12:47:40.631931+00	{}	2026-09-11 12:47:10.631931+00	OPAQUE	REFRESH_TOKEN	mm-isv0ClyxFvTjfWXbxN3aAWb_ElgOWMxOTg5NzgtMmVhYi00ZjU3LTllNTItN2MwOWM3OTc0OGU2
8422650c-5d38-4f69-ad4d-2a753751aa72	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789130556, "session_id": "4276411f-0d02-42b7-b181-4b16476abbd2", "session_exp": 1799498556}	2026-10-11 12:47:41.494262+00	2026-09-11 12:47:41.494262+00	{}	2026-09-11 12:47:11.494262+00	OPAQUE	REFRESH_TOKEN	dd_IYEvXUW-3iIiqwxG80W3YFUU2OgZDg4MmZhNGUtODFlZi00ZjA5LWE1ZDUtYmEyOGMzZjliYTNi
f4710191-8b60-4bb7-af4c-c9b6005e7d25	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789130556, "session_id": "4276411f-0d02-42b7-b181-4b16476abbd2", "session_exp": 1799498556}	2026-10-11 12:56:44.954384+00	2026-09-11 12:56:44.954384+00	{}	2026-09-11 12:56:14.954384+00	OPAQUE	REFRESH_TOKEN	cdmzSgXlft0_tacQad-vIFIVnMJ1EgMmFmY2EzNmYtYTJkYi00ODQ0LWEyZGYtNDA0MWEyNDkwZDIz
e127db6d-de40-40b8-bcf0-a2bc62d55211	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789130556, "session_id": "4276411f-0d02-42b7-b181-4b16476abbd2", "session_exp": 1799498556}	2026-10-11 12:56:45.87829+00	2026-09-11 12:56:45.87829+00	{}	2026-09-11 12:56:15.87829+00	OPAQUE	REFRESH_TOKEN	-KqrtgvZ6hmrtcwwE95HZo9gZcpSQAZDI3YTUwZTctMTk1Yi00YWEzLWEwMjUtMGNiMzhiN2UxOTdm
612f5463-4c47-4071-9e4c-551bf72966e0	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 13:01:43.990344+00	2026-09-11 13:01:43.990344+00	{}	2026-09-11 13:01:13.990344+00	OPAQUE	REFRESH_TOKEN	rvqqf59mpQGaLtIgVW-AWcio9XhRJwN2M3ZDhmNGEtZGNhMi00ZjI2LTk4MjgtYjZkMzNmYmRmODNl
d19aa5eb-396e-4790-8d58-9347acc5a208	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 13:04:53.98638+00	2026-09-11 13:04:53.98638+00	{}	2026-09-11 13:04:23.98638+00	OPAQUE	REFRESH_TOKEN	N6ukY9InmzgSqs18r7quvhrphEl81wMTQzNDEzNTktYzk1NS00YzMyLWFkN2QtY2Q4NWI4YmUwOGIx
4924f5a0-ca0a-4fb0-bf6d-14c54515cecd	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 13:05:16.336525+00	2026-09-11 13:05:16.336525+00	{}	2026-09-11 13:04:46.336525+00	OPAQUE	REFRESH_TOKEN	nHjD2aB5Wo0HW7o-jjd7evzTL-jriwM2FiOTlhMDMtNmM2MS00NjExLWE0MTMtOTgxNzlhM2JkZmJj
2a4e8fbc-982c-447b-84bb-a5965925888f	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 13:11:51.32752+00	2026-09-11 13:11:51.32752+00	{}	2026-09-11 13:11:21.32752+00	OPAQUE	REFRESH_TOKEN	ZNdSlUFRcfQmX8Atu4THcjNlX8ofpgYTRkNGYzZGQtZmRmMC00NjVkLTljNDgtYTZlMDA2OTU4Zjc3
a9f66093-5334-4922-b7d7-a06d26a1324f	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 13:20:03.064868+00	2026-09-11 13:20:03.064868+00	{}	2026-09-11 13:19:33.064868+00	OPAQUE	REFRESH_TOKEN	Ch8Iy0zk-GdrXnixrrF_dRgdktJX_QYzVhZTc0NWYtODkxMS00ZmIxLWE5MzEtMGI3NDhmNTIwZjJi
b628682d-fd68-4f74-8d13-af0b2b6542aa	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 13:22:15.981163+00	2026-09-11 13:22:15.981163+00	{}	2026-09-11 13:21:45.981163+00	OPAQUE	REFRESH_TOKEN	pJ-zMsbO18VI1743oYI3HriTUsi8RwYzc5NDUyYTctMjllOS00ZWIyLTg4N2EtYjJkZTAyYmUwZDdj
8b3c1655-d4b8-41cd-8857-d5a3573405bd	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 13:27:50.23854+00	2026-09-11 13:27:50.23854+00	{}	2026-09-11 13:27:20.23854+00	OPAQUE	REFRESH_TOKEN	mZNkfsTdkTZ3s9zLwjpt84M0PkV1lgYzJiYzE3Y2QtMWI4NC00NzZmLWI3MDgtN2IwYzA0OTgyNmE3
83ee6818-c6c2-4ad6-9834-d0465200bba6	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 13:29:22.526177+00	2026-09-11 13:29:22.526177+00	{}	2026-09-11 13:28:52.526177+00	OPAQUE	REFRESH_TOKEN	d6BsCIjWInrWvX6IArJxnghsYVrhuwYjljNWMyODUtMzI5MC00MzBlLTg0MzEtMzEyZjNlZjZjN2Fk
804effc7-0ea9-458c-9cbb-773ace69ec59	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 13:30:11.742283+00	2026-09-11 13:30:11.742283+00	{}	2026-09-11 13:29:41.742283+00	OPAQUE	REFRESH_TOKEN	prHpAFK39hzQm-nPFwgW2eFNNhY0lAMTBlNzhjYTUtN2RkNS00MTI1LThiMmItNzc5NjhhZDM4ZDM5
801166c6-7fc8-4126-93b7-d887573bcb0c	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 13:31:34.098264+00	2026-09-11 13:31:34.098264+00	{}	2026-09-11 13:31:04.098264+00	OPAQUE	REFRESH_TOKEN	JmEKV6O2oUm_RpBSbebddK8kbf8zWgYmIzNjI2YTAtYzI1Yy00NjBkLWFjOGQtMzFhYjIyMzkxNDAx
85a274b6-5f27-4a05-a2bf-2e75a68f0b7d	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 13:37:16.601486+00	2026-09-11 13:37:16.601486+00	{}	2026-09-11 13:36:46.601486+00	OPAQUE	REFRESH_TOKEN	Q4B7XTczFqxi80ksjBAUJFbIrD5cDwMWNiNjA1NTYtYzY3Zi00NmI3LWE5ZDgtNzM3M2NjNmRjMWNi
844f026b-7b42-4c26-b8c8-13dfe6562520	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 13:43:19.750046+00	2026-09-11 13:43:19.750046+00	{}	2026-09-11 13:42:49.750046+00	OPAQUE	REFRESH_TOKEN	KFsxKfc7vethXb4jd_D85qiKe3uMigODk5NWUxMDgtNjZkOC00Y2M3LWFiOTUtNDVmYjg1ZmVjMjE1
675662be-f250-4937-8c26-72da9d89de45	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 13:43:20.157009+00	2026-09-11 13:43:20.157009+00	{}	2026-09-11 13:42:50.157009+00	OPAQUE	REFRESH_TOKEN	aZWfgl_I9ciTGtWSX6WqycNlCuKlIgZTdlM2EwZWMtMGQ4ZS00MjRhLWE4YjYtZTBiM2E3MjllYTg3
7a8638a4-ac45-4335-9528-288589647719	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 13:43:20.357166+00	2026-09-11 13:43:20.357166+00	{}	2026-09-11 13:42:50.357166+00	OPAQUE	REFRESH_TOKEN	50LKWHWxPdFc-sn7FgcEkX2ikl29tANmY5NmM4MWMtMDMxNi00YzIzLWFmZWEtMTFmMDM1YmYwMTFi
aadd27a4-1ad1-40a6-9ed1-6779b8360558	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 13:49:22.355424+00	2026-09-11 13:49:22.355424+00	{}	2026-09-11 13:48:52.355424+00	OPAQUE	REFRESH_TOKEN	RAm_UIFOy72Nv-X3JMKAOUCGS39KNQNjc5MTUwYjAtOTUxYy00ZWVmLTkyZWUtZDAzZWFiYjI3NDgx
baaeb998-4dc3-42ad-a8d8-a2c988f23389	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 13:52:26.557182+00	2026-09-11 13:52:26.557182+00	{}	2026-09-11 13:51:56.557182+00	OPAQUE	REFRESH_TOKEN	jf5NTuFdncqjETbj8QaaNGhBZKs6JANTQ5YWNhNTEtNGFlYy00OTcxLWE4YTAtNmQ1N2VmMGEyODYx
b849144b-0f2f-46ed-b30a-01e143edf553	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 13:57:28.274568+00	2026-09-11 13:57:28.274568+00	{}	2026-09-11 13:56:58.274568+00	OPAQUE	REFRESH_TOKEN	gwace7K-PkWuxWttXbxngKfuJAY7QANmQ4OTQwYmItM2M1MS00N2MxLWE1YzItYWE4MmI2MjQxMGVk
e629186b-05da-4a38-9d2a-1cc3b89eeaa0	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 13:57:51.384103+00	2026-09-11 13:57:51.384103+00	{}	2026-09-11 13:57:21.384103+00	OPAQUE	REFRESH_TOKEN	n55yOn8JFL8W0zS4htiy_h2u9LDNagOWRhYmY5ZmUtZDcwYi00YmYyLThlNTMtMDBkOGFhMWFjZjI2
4e8429de-023b-4e5c-b315-412e83a16381	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 14:03:26.790219+00	2026-09-11 14:03:26.790219+00	{}	2026-09-11 14:02:56.790219+00	OPAQUE	REFRESH_TOKEN	k5VGLesMaHsWr5AX7iut9vH09POzZANjM2NjlkMTgtMWEzNi00YWRkLWI2NGEtMDJlYzA5NDM1YTk5
a4354fd6-3541-4575-ad90-b498e551ce70	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 14:09:14.270518+00	2026-09-11 14:09:14.270518+00	{}	2026-09-11 14:08:44.270518+00	OPAQUE	REFRESH_TOKEN	xtmCRuJBAKIhYAPNQsoqch0ivz1VcgZDZjZGI2ZmUtYWIzYy00ZDBjLTlkMjYtYjYzMmM1YjhmMjE4
54dc0a31-f7ac-4594-bd41-4c96e02c85cf	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 14:10:16.052627+00	2026-09-11 14:10:16.052627+00	{}	2026-09-11 14:09:46.052627+00	OPAQUE	REFRESH_TOKEN	nBMcdVEnxGal3SKcuhRWj4fnEC8PsQY2ExZDM5ZDAtMTkzNS00NjA3LWJmZGYtZWM5MzRkNjk4ZDZl
860d1240-77bd-400d-b8ec-ceb8cf960046	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 14:26:44.23136+00	2026-09-11 14:26:44.23136+00	{}	2026-09-11 14:26:14.23136+00	OPAQUE	REFRESH_TOKEN	1Cu7T7XRCilsVpRuVHga2HfmyBCdDAZWU5NTZjMTMtMjBhNC00MjZiLThlZDEtMGEyNjM0OTBlZWJj
0bdf90ec-f874-45d6-b2d2-2996ebed6287	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 14:26:44.461286+00	2026-09-11 14:26:44.461286+00	{}	2026-09-11 14:26:14.461286+00	OPAQUE	REFRESH_TOKEN	MjMQJLfnVCkI66MUSIIccePEiD6S0wYmYwYzE5YzMtMGExYy00NzJjLWJiOWMtMzA2NTFjYTAwYzc5
f7938f34-4f2d-4aa8-8c12-fde975195f54	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 14:32:14.250514+00	2026-09-11 14:32:14.250514+00	{}	2026-09-11 14:31:44.250514+00	OPAQUE	REFRESH_TOKEN	DjUTl-8tZjMExzJpV4vtYjjHR2VBjQZDMzMGY2OWUtZTUwZC00NDI3LWJjNmMtNmYzNzAzMGE0NjUw
e84c0e76-f80b-4101-814f-361d646de21a	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 14:40:21.694113+00	2026-09-11 14:40:21.694113+00	{}	2026-09-11 14:39:51.694113+00	OPAQUE	REFRESH_TOKEN	EbT9WMg6nDskDvHCbIN07RC20UGTNQYmY2NThlMWUtY2EzMS00MjUyLTlhZTgtNWYxNWY2MWFlMDI4
0bd45ce6-c7bc-465e-ba48-14a2072197f0	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 14:40:21.919988+00	2026-09-11 14:40:21.919988+00	{}	2026-09-11 14:39:51.919988+00	OPAQUE	REFRESH_TOKEN	tUw47aIqpa49tF6_pUyOXrcOhgLdMAYmU4YTVmYzQtNGJjYy00ZTFlLTljYTYtZTE0MDU5NDM4MDlm
95c97fa4-f844-41ca-97ce-55b915374247	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 14:45:31.998306+00	2026-09-11 14:45:31.998306+00	{}	2026-09-11 14:45:01.998306+00	OPAQUE	REFRESH_TOKEN	HBUXs29VMGZ_IJ1XmR7uNRzxjGU7XQNTM1YWFhMjYtNTI1NS00NjRhLTgzOGUtYzZmMjdmMTMzZjlh
74c3dafb-791a-47cc-b970-4eee52871349	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 14:45:32.212633+00	2026-09-11 14:45:32.212633+00	{}	2026-09-11 14:45:02.212633+00	OPAQUE	REFRESH_TOKEN	MCm2PEfPcQcay2N-h7KToPiG6ph_2QMWRkMjYzMmYtMjM1Ni00YmE0LTlhYzUtZDI2MmMxYzdiYTA1
68f53e7b-c522-4433-902e-b23a6e04aab4	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 14:50:56.003899+00	2026-09-11 14:50:56.003899+00	{}	2026-09-11 14:50:26.003899+00	OPAQUE	REFRESH_TOKEN	BUSSHrL1M4RiaMgmywiyt31ffLrkBgZjljY2ZhMDEtODI4Ny00NTUzLThmN2ItOWU1NDk0NzgzMDc2
d9966534-d5d3-442a-9f02-9c8605e87f03	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 14:50:56.924515+00	2026-09-11 14:50:56.924515+00	{}	2026-09-11 14:50:26.924515+00	OPAQUE	REFRESH_TOKEN	AcD6JsOEaWrdrEIH2v6gW7WXM-1kRQNDAzODY1NGItNDc4MS00OWM4LTkzYzItYTU4ZGIyYjY4ZjNm
cabeb054-3339-411c-8593-881bf3bbd829	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 14:59:54.910024+00	2026-09-11 14:59:54.910024+00	{}	2026-09-11 14:59:24.910024+00	OPAQUE	REFRESH_TOKEN	qkuHxYjS1Qi8VdKKgfD1G1QoyI0HtAMjExNTg4YTQtMzk1Ni00MmMwLTlmZTktMTg1NzBlZDBiYjE0
8c4fde57-f187-4b7f-bd94-25c06b0d3157	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 15:05:28.660226+00	2026-09-11 15:05:28.660226+00	{}	2026-09-11 15:04:58.660226+00	OPAQUE	REFRESH_TOKEN	aSdv9Zfx1EXAzuXXyQVr0n4oeU7V6gMzc5NGM3YzMtOWZiNi00ZThjLWE4ZDYtYTZmMGVlMzBlZmY0
178311a6-4926-4570-b436-e346776083b5	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 15:20:17.51022+00	2026-09-11 15:20:17.51022+00	{}	2026-09-11 15:19:47.51022+00	OPAQUE	REFRESH_TOKEN	4sJhHrxTznwitfhp5nTcv9PrquOpeQZTMwMWYyMGItODVmMy00ZTc4LWI3MmItOGQ5OTJjMjViNWFk
ee1ffa46-78af-4ff0-8f32-8f830b93d47b	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 15:20:17.741786+00	2026-09-11 15:20:17.741786+00	{}	2026-09-11 15:19:47.741786+00	OPAQUE	REFRESH_TOKEN	MmEsNG20qZB2qOMMeMKwZZDBpoQ0NwNTkwNDIzYjQtNWNkNS00NThmLTgxMGItNzQ4NjBlZmNkM2M3
60452d05-0652-4abc-b2ef-fd07d747d116	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 15:29:00.66075+00	2026-09-11 15:29:00.66075+00	{}	2026-09-11 15:28:30.66075+00	OPAQUE	REFRESH_TOKEN	IGJJDDoyRsOCJGDP9U3YQbZWgEqxzgMGE5Nzc5Y2MtNTUwZC00MTdhLThkYzEtODdlOWFlZDllM2Y4
976e4e0e-2db1-454c-be0e-e5cb683b2047	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 15:29:00.929656+00	2026-09-11 15:29:00.929656+00	{}	2026-09-11 15:28:30.929656+00	OPAQUE	REFRESH_TOKEN	gdZz5SXhF-ZtDjDO7qgVoITFHd8YOQODA3NTg4ODctOGJlMS00YjQzLWEzNzgtMWRiOGNmOWQ4NzY1
1a8887f2-8816-42fb-bb9a-8d36d05edf67	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 15:35:00.351467+00	2026-09-11 15:35:00.351467+00	{}	2026-09-11 15:34:30.351467+00	OPAQUE	REFRESH_TOKEN	tIeMm4oN54uDrRX2yv5ex5fQled1XAY2MwZDliODctNmFkMC00ZmU2LTg3NTEtNzczYWViODFiNjNi
c0a19ab4-52ce-4f82-bf84-1999ea08aece	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 15:35:00.589697+00	2026-09-11 15:35:00.589697+00	{}	2026-09-11 15:34:30.589697+00	OPAQUE	REFRESH_TOKEN	tQZbOP4KiaWaqFiWqcZYkUjpLkCMXQY2M0MzE0ZWUtZmFkNi00M2RkLThiNDgtZGZkMmU0ZDZhYjlh
018dabb8-6136-4e34-acab-5e0fe0647d13	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 15:50:13.752455+00	2026-09-11 15:50:13.752455+00	{}	2026-09-11 15:49:43.752455+00	OPAQUE	REFRESH_TOKEN	lKmvusFWYDq7eVCgs1Rs5ME3qwQwGwYzFhZGQzNTQtNDI1My00ZmFhLWFiNjUtNjIxMGFiMGJkYmFk
d08a3e4e-10f0-49ac-82aa-dd5032168024	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 15:50:13.98009+00	2026-09-11 15:50:13.98009+00	{}	2026-09-11 15:49:43.98009+00	OPAQUE	REFRESH_TOKEN	LvljDwLpEe_PAQAXk-XpEQqrYoAAdwZmI4NWI4NzEtY2ZkMC00MTNhLTlmNGYtOTkxMmE4M2QzNTZj
73ab5d54-4ffb-4d18-85df-2b3cd2b28459	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 15:50:15.534125+00	2026-09-11 15:50:15.534125+00	{}	2026-09-11 15:49:45.534125+00	OPAQUE	REFRESH_TOKEN	RaJWf-8tf2rJ5mN48Iv3V65R-4baVAM2YyMGQ4YTktNmUwMy00NzQ4LWFkZTQtMjRjMzk1ODU1NzRl
41d945ac-0d43-487b-8627-46368642494e	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 15:50:22.04522+00	2026-09-11 15:50:22.04522+00	{}	2026-09-11 15:49:52.04522+00	OPAQUE	REFRESH_TOKEN	Xj73lDffEwDhrmjJfOq23FuyQP-0DQYjgxOGNhZDEtYzYwOC00ZWVjLWJhY2ItNjZhYTY2MTY0YjAw
a57e09e1-4e9b-4d1d-a4da-46ddccb2e20d	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 15:57:16.806435+00	2026-09-11 15:57:16.806435+00	{}	2026-09-11 15:56:46.806435+00	OPAQUE	REFRESH_TOKEN	kosNUpPjHXelElm2wlE0IYeRwxxXeQYTI3N2I0NDktYzg3Ni00ZTJhLTljNWYtNTM5YTZmMjQwZmVk
ccba8a57-426f-4f15-b9c7-8e9afb762ad2	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 15:57:17.823059+00	2026-09-11 15:57:17.823059+00	{}	2026-09-11 15:56:47.823059+00	OPAQUE	REFRESH_TOKEN	vz_ks3H9O-RVH7gDBwimMhNj0w1y3AOTJhMDg1YmUtOTY4Mi00OGI0LWEwNTMtNWU0NzEwZThlNDdm
df52665f-7c52-477f-aad7-1a5582505bce	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 16:01:14.60036+00	2026-09-11 16:01:14.60036+00	{}	2026-09-11 16:00:44.60036+00	OPAQUE	REFRESH_TOKEN	lnSVyB5P6U8YVxfpeTiz2CztThU4TQMGYxZGU3YWItMTQ0OC00YTMyLWJkNzYtN2UwZTdlOWJhYTZk
37595019-286a-4df9-8ebb-4499c015e9de	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 16:01:21.318529+00	2026-09-11 16:01:21.318529+00	{}	2026-09-11 16:00:51.318529+00	OPAQUE	REFRESH_TOKEN	EgLPsnOUwyGl6D17YwU9Moxi6-Lp6AMGYwNmYxYzQtYjBlZi00OTcwLTg5MjQtNDljNjRmMzMwYjI0
12a3530f-ed38-4f05-9666-6ca4e633f01a	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 16:01:51.43587+00	2026-09-11 16:01:51.43587+00	{}	2026-09-11 16:01:21.43587+00	OPAQUE	REFRESH_TOKEN	c8ZgWjG0KrZyykkaMSgX0CtsxxkmzwNWEzN2RmMjEtNjMzYi00MDFjLTlmMTQtZDEzN2VlNmE2ZDA4
74cdc255-72d7-41ba-96c6-6aca5f60f205	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 16:02:07.44089+00	2026-09-11 16:02:07.44089+00	{}	2026-09-11 16:01:37.44089+00	OPAQUE	REFRESH_TOKEN	PX6qhcFBNYaCh6CvLJEY1aEQ8K0K7wMWM4NTU5YmEtMzE4OC00Nzk2LWIxYzUtNTk1YmRhODVjNjIy
9542ff73-b531-4859-af35-a2b1b7b385f1	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 16:02:26.299231+00	2026-09-11 16:02:26.299231+00	{}	2026-09-11 16:01:56.299231+00	OPAQUE	REFRESH_TOKEN	Mzu3vi8OxYaNOCvLwCveLAlL_mgl4QZjA0YjlkOTAtMWZhMC00OWM0LTlmMGYtZjI1MjBjNjY5Mzcx
efa07a1a-21a3-48b2-b379-44e583d45ce6	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 16:05:01.344782+00	2026-09-11 16:05:01.344782+00	{}	2026-09-11 16:04:31.344782+00	OPAQUE	REFRESH_TOKEN	dNDSqnmbDA1xO1GSMKHno64sHuvBDANGYwZTE0NGItNzkxYy00OTI0LWIzODItZDNkYmI0YTAyOWVk
7c1a5b95-9a67-4a20-98bb-3f231cd79338	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 16:07:55.739663+00	2026-09-11 16:07:55.739663+00	{}	2026-09-11 16:07:25.739663+00	OPAQUE	REFRESH_TOKEN	BkYT9DnNv3LshORamiWXBHeYwvQ7VQYjlhMjdmM2QtZTY5NC00MmJiLWE0MWUtOWQ1NDE2ZTUyZjI0
8643d168-8e39-4c42-856d-d90b3f5b751e	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 16:08:25.562091+00	2026-09-11 16:08:25.562091+00	{}	2026-09-11 16:07:55.562091+00	OPAQUE	REFRESH_TOKEN	7qQ599W9L8G9Rq7YQ100PvHh0MBbrQYTBmYTY4NjAtZjEwYS00MGEzLTk1YjItYzE1M2ZmMDkzODM3
33f51169-025e-4d89-a966-a9de48409882	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 16:11:46.037689+00	2026-09-11 16:11:46.037689+00	{}	2026-09-11 16:11:16.037689+00	OPAQUE	REFRESH_TOKEN	Ln2je-4GTk8Xl9dkdsIy48VoTKcDbAZjM4YTUxZTQtZjk4Yi00OTM4LTkyYTktMTE2Mzg2OTkzOTkz
6c397248-5529-4fe4-939e-a6166c2261b5	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 16:12:26.50396+00	2026-09-11 16:12:26.50396+00	{}	2026-09-11 16:11:56.50396+00	OPAQUE	REFRESH_TOKEN	f7KStbNwNihzLxBlMEpFjNkUlcO_MwZWM4YWEwYmYtNGI0OC00NGQwLThmMWYtNmJiOWQyZTVhOGFm
d5874cc8-2cb4-43d2-90c2-6f57051036a9	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 16:13:28.376842+00	2026-09-11 16:13:28.376842+00	{}	2026-09-11 16:12:58.376842+00	OPAQUE	REFRESH_TOKEN	CzA3PwAhcTETDYGA2Hmn8xfa1RMdfwMmRhY2RkZmQtYjYwMy00ZGVkLThjZWMtM2NmZjdlYzJlZTAy
f318de20-a145-4d03-aad8-ce8b09c0fd64	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 16:14:39.175118+00	2026-09-11 16:14:39.175118+00	{}	2026-09-11 16:14:09.175118+00	OPAQUE	REFRESH_TOKEN	HEPVq-Jp8jmYZmhlKEaja2eMz-wArgNzRlNDA3ZjAtN2RmOC00M2Q4LWIxNDMtMjE2ZDU1YTkxMmM4
557e104f-b175-4548-a2df-7d784d1a7f71	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 16:14:47.769956+00	2026-09-11 16:14:47.769956+00	{}	2026-09-11 16:14:17.769956+00	OPAQUE	REFRESH_TOKEN	Y2HcjMuK0tUzw3aetQ2QzGsA0GYh3AOGI3NWI0MjMtNTMxZS00N2RlLWJkZGItNDk1MjhlM2U5M2Q3
2b48aae3-071e-41e6-9343-6e3f93754590	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 16:16:54.610848+00	2026-09-11 16:16:54.610848+00	{}	2026-09-11 16:16:24.610848+00	OPAQUE	REFRESH_TOKEN	3kGJFYKGr1B6KQMCt7xvxw05RYMHDgZDVlNzhjODgtMzRiNi00ZWJkLWI1NzQtZWIwYmJkOGQ0OTJi
f5acba75-867d-4733-a309-bc24df4b5c2f	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 16:18:39.106324+00	2026-09-11 16:18:39.106324+00	{}	2026-09-11 16:18:09.106324+00	OPAQUE	REFRESH_TOKEN	QNdbRrxR2Ltpr5usDQCBpoGFo_l6qgNWE0NTBiZjMtZjVhMC00ODhiLWFmZjEtMDI0ODM2YjcwNGM4
368da446-2ee2-4bf2-a2df-13b200f7cdf6	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 16:20:18.867207+00	2026-09-11 16:20:18.867207+00	{}	2026-09-11 16:19:48.867207+00	OPAQUE	REFRESH_TOKEN	H_opZrcoPkeTCZ-WuBtM3bKTiva9ZANjA1M2VmN2ItNmEwMS00NTIzLWJkNTQtYzRiMTBjOTE0Y2I5
09443bf9-84e0-4e57-abb1-11f5354b9cd7	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 16:20:24.776629+00	2026-09-11 16:20:24.776629+00	{}	2026-09-11 16:19:54.776629+00	OPAQUE	REFRESH_TOKEN	uYSlEv5oZR8m1q_pUtaYkps6Nx-VIAMzQ5MGY5M2QtOGU5Zi00ZDlhLTkxNzktYTJhZmRjMTUyNDg3
5025b486-4848-49cc-867f-2fbe59207548	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 16:20:33.100297+00	2026-09-11 16:20:33.100297+00	{}	2026-09-11 16:20:03.100297+00	OPAQUE	REFRESH_TOKEN	eFMbyP63lK6s9KEM-_MO__TZobDCOQN2MyNTk0N2ItNWI5NS00ODRjLWFjZDItMDUwN2IyYzBjOTk1
9572a728-7859-4a55-939c-dc27c0ce0992	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 16:21:11.513186+00	2026-09-11 16:21:11.513186+00	{}	2026-09-11 16:20:41.513186+00	OPAQUE	REFRESH_TOKEN	dsJnlzD25Eel44d04p7VxJYXeh7zaQMDM1NWQxY2MtYWVkMy00MTFlLTk4ZjctOThjMDcxODZjNGMy
9ebf5b25-0ca7-49aa-8329-4335d6fe705f	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 16:26:24.94744+00	2026-09-11 16:26:24.94744+00	{}	2026-09-11 16:25:54.94744+00	OPAQUE	REFRESH_TOKEN	16U6cfG3aFBHNPOkkzS3GgYCMZ7ThgZmFlOTk5OTYtZDg4Mi00NDBiLThlZmEtMDYwNDBiYTExMjI2
cfce4c57-614f-47c3-99ad-2d24b855eeb2	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 16:26:25.199121+00	2026-09-11 16:26:25.199121+00	{}	2026-09-11 16:25:55.199121+00	OPAQUE	REFRESH_TOKEN	I529Smzom-gUmWyGFzdwTZ3TW4XniANWEyMGQ3MzQtMzIwOC00ZjNkLThkZWYtYmUxZmIwMWY0YzIx
642ed2e0-788e-4ddd-95f0-451cb75a028d	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 16:26:26.246925+00	2026-09-11 16:26:26.246925+00	{}	2026-09-11 16:25:56.246925+00	OPAQUE	REFRESH_TOKEN	UjAcFnJWwNMVx8WuIxTCIepbGD7YGwYmE4NDM2YzItZGFkOS00NmQ5LWI1NjAtMjdjNGVjZWQ1ODcw
e1f8ee34-1155-45d4-b5b5-269b578cacd8	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 16:26:26.824004+00	2026-09-11 16:26:26.824004+00	{}	2026-09-11 16:25:56.824004+00	OPAQUE	REFRESH_TOKEN	qJc2a6o-zA7xBXolhMdEMrZnOwSpnAMGJlNmU3N2EtNDc4MS00YTA1LTkzMzEtOGJlNjJhZjZlZTNi
821be35d-18cb-4beb-a39c-838d80c5f175	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 16:28:32.560031+00	2026-09-11 16:28:32.560031+00	{}	2026-09-11 16:28:02.560031+00	OPAQUE	REFRESH_TOKEN	BMDZNeUasXiwfE9sL_6T9Jpknns4uANTQ2MmVlMWEtN2E4My00MTZiLTg1NDAtNGZiNzUzMzJhMTQ3
83c65604-222e-4b23-8fa4-47c136ce9216	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 16:28:50.464757+00	2026-09-11 16:28:50.464757+00	{}	2026-09-11 16:28:20.464757+00	OPAQUE	REFRESH_TOKEN	UsN7ecG8ZBBHuzO5yzS6Ym8h35HTTQYTg5MzBmYzEtY2M5Ny00YTYwLWE3Y2YtNzIyZWU1ODFjYzM3
bb837234-8144-43c1-8fc2-8f04bbee5ec7	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 16:29:19.316297+00	2026-09-11 16:29:19.316297+00	{}	2026-09-11 16:28:49.316297+00	OPAQUE	REFRESH_TOKEN	IvPe_U_zfNz6EczJ8XjGxWvwdxWHIAMzBiNWQzZWUtZjFkZS00NGNiLTgxNTgtZGYwYzBmN2FmMDhi
231a1a26-1449-4dd6-8073-a6ec22c3fd34	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 16:29:39.483246+00	2026-09-11 16:29:39.483246+00	{}	2026-09-11 16:29:09.483246+00	OPAQUE	REFRESH_TOKEN	dd1mxEWLkLFyCTMG_uY_U0hSJ6A64gNWY1YTFlYTctNTEyYy00ODY0LTkyN2QtYTNlODc3NDg1Njgz
e7d545a5-f1b7-40af-99c6-317fdf21e6ee	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 16:36:10.496538+00	2026-09-11 16:36:10.496538+00	{}	2026-09-11 16:35:40.496538+00	OPAQUE	REFRESH_TOKEN	H5cqx8vOMwCR0vutROJti39YWkeUFQNGU1N2UzMTAtYmFjNy00NzJlLWIzYWItYTVjYzY0Njc1Y2Fm
682b6022-c2e7-437c-a9bb-01d75d66a14d	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 16:36:10.786377+00	2026-09-11 16:36:10.786377+00	{}	2026-09-11 16:35:40.786377+00	OPAQUE	REFRESH_TOKEN	vYrTCHEizu_A9krJYisBsZ_HODYhRAYTRmNTk4OTMtZjAxNy00MTdmLWJlZDItMjg2MGI2NmFkYTRh
3f620df1-9b8b-4b94-bf75-a5cb12a0efa8	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 16:36:11.223746+00	2026-09-11 16:36:11.223746+00	{}	2026-09-11 16:35:41.223746+00	OPAQUE	REFRESH_TOKEN	nFRpNbSJJjZaF4cJ0EtCAFnY77Yh-gNDhiOGY4N2UtZjRhMy00MWFkLWIwODMtZDI1MGMxZWFkZDkz
aad3e729-e859-460b-ad85-33999551cc4d	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 16:42:45.386952+00	2026-09-11 16:42:45.386952+00	{}	2026-09-11 16:42:15.386952+00	OPAQUE	REFRESH_TOKEN	MneRWGod_PvAIeMzqXqUqos51WClRQZmFiNmUzMjAtZmMwMS00MzlmLTk4YWQtZGRkNDM0NTY1MzVl
c5dc24bb-94f2-495a-8846-dad342026817	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 16:42:45.658383+00	2026-09-11 16:42:45.658383+00	{}	2026-09-11 16:42:15.658383+00	OPAQUE	REFRESH_TOKEN	9-WxcEec3LwTxzcmCLwjc6xCFMUg0AMTg4MjdiZWQtZTM2Zi00OTg5LWFhNmEtYmFhYmY1YTViZDE3
5c3ef72c-e058-443f-8cfd-bd08e2dad212	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 16:42:46.603099+00	2026-09-11 16:42:46.603099+00	{}	2026-09-11 16:42:16.603099+00	OPAQUE	REFRESH_TOKEN	KEsnSrGDJOveWAEnZu-NX_l88JfL5wYTQ2NjA3YTEtYmE0NS00YmU0LWJlZWItOTUwN2VkMzg4OGZi
dee71a9d-72de-437d-97be-26488bd8c7fb	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 16:42:53.657197+00	2026-09-11 16:42:53.657197+00	{}	2026-09-11 16:42:23.657197+00	OPAQUE	REFRESH_TOKEN	gIA9zGW97ppSUAzuFwBy9dp9rOVPKQZTBjODVjYjAtNzEwNi00MWJmLWE0OTQtOTZmY2JmNmRkMTgx
3c087026-9aa7-4ceb-8170-0889306360f4	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 16:49:12.465057+00	2026-09-11 16:49:12.465057+00	{}	2026-09-11 16:48:42.465057+00	OPAQUE	REFRESH_TOKEN	_w05zRHRfRdj1ovdg095SjT3P0Eu4AZjQ1ZjRhNzAtNDczMi00ZTYxLWFmOGUtMmM2YWNiYzdkZGI0
e4242839-528b-4864-ab9c-901079429a5c	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 16:49:13.197411+00	2026-09-11 16:49:13.197411+00	{}	2026-09-11 16:48:43.197411+00	OPAQUE	REFRESH_TOKEN	ggVyFfSWXMO8A3vMXUFAZcUq1KBgEgY2E4NzNlNjItMWUwNS00ZTA2LWE5NTItMWVhYWNkNDBiYzE2
9de303a5-1dab-4f68-9fb6-af1eea459558	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 16:49:13.468265+00	2026-09-11 16:49:13.468265+00	{}	2026-09-11 16:48:43.468265+00	OPAQUE	REFRESH_TOKEN	EGJW2fSQ8-PmsYDcPInpLXoLgfBy8gMDE1Nzg5YzktODBmMC00MzlmLWJiMTYtNTljNTQ1ZTZiN2Qz
c4793df0-63d8-4275-b7df-62dc0ed76d00	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 16:49:13.791675+00	2026-09-11 16:49:13.791675+00	{}	2026-09-11 16:48:43.791675+00	OPAQUE	REFRESH_TOKEN	QxfP5mEvD_-xKZCzPbuaAR3lL64EAgNmNlMTg4ODgtMDFmOC00YzNhLTk5OTItYzY4M2NjNzY2MDg4
0974efc0-7ff7-4f90-bfc1-47704e640470	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 16:49:14.087197+00	2026-09-11 16:49:14.087197+00	{}	2026-09-11 16:48:44.087197+00	OPAQUE	REFRESH_TOKEN	UJcZsQ4pWvHYW9yTdX5ReSz8wvFKcgZjU2NTY4YmYtYjZmZS00ZWE4LWI1NDItMjMzZDc4NDVhMTY1
bf710f83-354a-45c8-b08d-776dea3b9b11	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 16:54:39.757567+00	2026-09-11 16:54:39.757567+00	{}	2026-09-11 16:54:09.757567+00	OPAQUE	REFRESH_TOKEN	wHDD4JRNsXp-ueFD4cqPhxkj1FDMewMGQxZmQwMTAtNThjNy00NTU3LTk4ZGItZTYwMTFhNzZlYTE2
a3721ab3-974b-44c5-9dbd-7c22bfb61103	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 17:55:33.856498+00	2026-09-11 17:55:33.856498+00	{}	2026-09-11 17:55:03.856498+00	OPAQUE	REFRESH_TOKEN	O6WoHBDHubR-q3xacH5jaNdP67HK9AYmNjOTYwYTYtNmRlOC00NWI5LTg4YjItZWI3MjUyMDRhYTRk
2539d265-c433-4115-a571-13ae8c61196f	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 17:55:34.539325+00	2026-09-11 17:55:34.539325+00	{}	2026-09-11 17:55:04.539325+00	OPAQUE	REFRESH_TOKEN	YIhCZS40uhe5f-T4AADmwqTQP13lmAYmQ2ZjhmMzgtMmU4ZC00Zjg1LThiNWYtNWQxYjQ3NzhjMGIy
80764886-5f3a-4865-9abc-5dc0525852d7	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 18:36:25.476789+00	2026-09-11 18:36:25.476789+00	{}	2026-09-11 18:35:55.476789+00	OPAQUE	REFRESH_TOKEN	1KFB4vFZ5NT2sNt4-Qfx3rEhUkj8yQZTUxZjNlMTEtNDlkMy00ZDgyLWEwMzUtYWY2NThlY2NlZmJi
6d09a1a5-67bf-4210-8ac2-e008ed1d64ed	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 18:36:26.090324+00	2026-09-11 18:36:26.090324+00	{}	2026-09-11 18:35:56.090324+00	OPAQUE	REFRESH_TOKEN	VgL7vQqNksTsZuGEomgVvnBueqAPMQODgzNjYxY2ItZjhlMi00MDNhLWJiNDEtMTAzY2ZmYjhiYzc3
95b01958-64e7-4080-8b9b-61e42237ed6b	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 19:00:19.072866+00	2026-09-11 19:00:19.072866+00	{}	2026-09-11 18:59:49.072866+00	OPAQUE	REFRESH_TOKEN	7QMK9UG8j_O9F8XpPiw-B4rvaYgq7wMDVlMjA0YmUtNzE5Zi00NWYwLWE5YWItNTBhOTJhMjg0NWE0
34c18b74-43d3-4946-9fa9-98565e642c75	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 19:00:19.702254+00	2026-09-11 19:00:19.702254+00	{}	2026-09-11 18:59:49.702254+00	OPAQUE	REFRESH_TOKEN	OCajaug0zyrXnGZ78Qrxvr_b9A7-PQM2Q2NjU3N2MtNGQwNS00YTdmLWFiYTItYTRjMjJiYWNiOTYz
433a1046-9278-447a-88ea-0a6437c9e420	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 19:05:03.456956+00	2026-09-11 19:05:03.456956+00	{}	2026-09-11 19:04:33.456956+00	OPAQUE	REFRESH_TOKEN	cg2TwVfYP1xopPvtzcq-Y8xi9F__CwMzIzZjZhZWItYTE4Ni00MTgxLWFkODQtOGM4OWE5OTdmNzAx
167355b4-b984-41ba-9150-71e04a676219	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 19:05:21.92682+00	2026-09-11 19:05:21.92682+00	{}	2026-09-11 19:04:51.92682+00	OPAQUE	REFRESH_TOKEN	tgc75kh2285rZThlxwbz33D14HaLuwZmI2ZWU0YWQtYzU2OC00MjFkLWI0OTMtNGJiYmRhOTFiNWU0
bf8b2cf2-b20c-4fa6-82b0-c9bce23b6586	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 19:06:01.753876+00	2026-09-11 19:06:01.753876+00	{}	2026-09-11 19:05:31.753876+00	OPAQUE	REFRESH_TOKEN	blovVDV4QqG8C41uFCnSqpKHMBYhwQZWNkNWU1OWMtYjFjNy00OTMxLTkxOTgtNTJlNTQwN2I5MGEx
179155f3-6b96-4b44-801b-d338f3fcbc68	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 19:12:15.0532+00	2026-09-11 19:12:15.0532+00	{}	2026-09-11 19:11:45.0532+00	OPAQUE	REFRESH_TOKEN	R5-Cxv4tWvRR_jKrpT05vVc3rP6_EgNjMxMGI5YzMtZWM2ZC00NjFmLWFhMDktNjMwMDc1NTFkZTkz
ab1692d2-23e4-4dcb-9253-4dca055ba097	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 19:12:16.343754+00	2026-09-11 19:12:16.343754+00	{}	2026-09-11 19:11:46.343754+00	OPAQUE	REFRESH_TOKEN	cslZGWGlfRERvUiBuQm0c89hvk0YRQN2RiMjMwZjEtMmM3MC00ZDNkLWJhYzUtN2RlM2Q4NzdkODdh
eaf35b6e-4e2d-4e63-a3ee-c5e855d6bf02	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 19:12:18.746419+00	2026-09-11 19:12:18.746419+00	{}	2026-09-11 19:11:48.746419+00	OPAQUE	REFRESH_TOKEN	WDNzDkAVkIHl36bbJaMArL5Qtm2gEwZWUxMjFkMWYtYzgyMy00ZDJmLTlmOWEtYzdiYWE0YWZhZGFj
0e788d88-e7de-4ef7-9007-432b934746ba	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 19:12:19.267529+00	2026-09-11 19:12:19.267529+00	{}	2026-09-11 19:11:49.267529+00	OPAQUE	REFRESH_TOKEN	4eWaIvwp52todtH9D-2ptKIN160ANQZmI0NjVkZGYtOTJiNS00YjUzLTlhYmEtMDk1OWIyYzc3Mzg3
1b9a82fd-0591-41c6-be46-b072361f334e	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 19:17:34.047023+00	2026-09-11 19:17:34.047023+00	{}	2026-09-11 19:17:04.047023+00	OPAQUE	REFRESH_TOKEN	Hqd5x7tzOcG7DgotcjvLxPmgIktRZAY2IwZTFhYTctMmE2YS00OGEzLTliMTQtMzIyYzVlNDk5Y2Uw
75899a4a-dc80-46bd-b6c0-24ca77478bf9	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 19:17:34.36849+00	2026-09-11 19:17:34.36849+00	{}	2026-09-11 19:17:04.36849+00	OPAQUE	REFRESH_TOKEN	d0MxRiJ3dvAjHQ5zAPhCtRuiPe9YqQMGNiN2Y2ZTYtNjg3Yy00Yjg3LWE5YmMtMTJkMGU1OTgwODA0
f6b0183f-f55a-403e-9b61-8f0d488af0c0	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 19:17:34.647248+00	2026-09-11 19:17:34.647248+00	{}	2026-09-11 19:17:04.647248+00	OPAQUE	REFRESH_TOKEN	IDWm-BdPdKRZEXtpHKj2mG3sWdtlGgMjEzYTkzMzUtZjk4OC00ZmE3LTlhMDctZGMwNGNmYmY4ZWFj
e3eb7574-f781-4c77-af29-fff869d965c8	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 19:17:35.448205+00	2026-09-11 19:17:35.448205+00	{}	2026-09-11 19:17:05.448205+00	OPAQUE	REFRESH_TOKEN	yw5KRf-8OJd1R3n8gp1hwdV4L5a8kQMmNjOWExYmItMTA0Yi00OThkLTllNzktNDNmYjc5NDU3ZTM3
713cb1ff-1d85-4936-b1cf-01a18d4d2725	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 19:25:26.636532+00	2026-09-11 19:25:26.636532+00	{}	2026-09-11 19:24:56.636532+00	OPAQUE	REFRESH_TOKEN	0lr40NX0E76tS7VJQ2wBIEIkRRrzTgYTE0ZTQ3MmEtN2M1NS00MzU0LTlhZTAtOWQ0OGFhZDRhMzdk
b330969f-b4c0-40e0-ac59-74a1c7a9930d	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 19:25:26.727342+00	2026-09-11 19:25:26.727342+00	{}	2026-09-11 19:24:56.727342+00	OPAQUE	REFRESH_TOKEN	gu3Fzhn0aMl89RFJAql8ae3Ovd8AjwMzcwZDlhZTgtOWVhYy00NDIwLTlkZDItNTliYTMxOWM2YTdk
dbe7a8c9-b419-4e45-a92f-77a797d9c367	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 19:25:26.915792+00	2026-09-11 19:25:26.915792+00	{}	2026-09-11 19:24:56.915792+00	OPAQUE	REFRESH_TOKEN	G2ErqrfRAkxv1sX27F2uEeLtX3kZqwNzcyYzhkMzItZWVhMS00YmJjLTg1ZTEtNWMxMjJkNzEyMDll
99ae1231-f3d8-43a9-94e5-936ec29af8f5	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 19:29:30.00118+00	2026-09-11 19:29:30.00118+00	{}	2026-09-11 19:29:00.00118+00	OPAQUE	REFRESH_TOKEN	OgJAOztoYsAn6yZeJPoZhR_mr6_c-AYmE1Yjc2MjQtYTcxNi00OTAwLWJhOWEtZjJlNzIyZTBlMGJl
f0d3f85c-6f7c-49d4-b34c-744fb8a443f0	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 19:30:17.728058+00	2026-09-11 19:30:17.728058+00	{}	2026-09-11 19:29:47.728058+00	OPAQUE	REFRESH_TOKEN	GJabG5dflwiPRMu7RGhc2aRx3K7f1AMGFlMzc5MWEtYzYyOC00YzVhLWIzMDgtMjVjMzljOGE2OTk1
9831a62c-b90a-4630-b5e3-8647c1cc6c44	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 19:36:17.759252+00	2026-09-11 19:36:17.759252+00	{}	2026-09-11 19:35:47.759252+00	OPAQUE	REFRESH_TOKEN	nSdCIBZLB9p8NQKSYGaKZInVW4LobgODYxMjI4MzItMGNjNi00NmMzLWEzY2MtMzQ2M2MzMmMyNDdm
f45498a8-add6-407a-bb3e-2eacb8899bef	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 19:37:21.832221+00	2026-09-11 19:37:21.832221+00	{}	2026-09-11 19:36:51.832221+00	OPAQUE	REFRESH_TOKEN	1brvTU9XKr_XmjWJmkRdcBb1DF1j8QNzk3NGUzMDYtMzc0Zi00MjY2LTlhZGYtOWRlYjM2MmExZTkw
78880279-44f9-4fd7-a2bc-dcd2e6f51eea	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 19:39:35.124037+00	2026-09-11 19:39:35.124037+00	{}	2026-09-11 19:39:05.124037+00	OPAQUE	REFRESH_TOKEN	jn7dbiTHK2dRyUyjnVecAch65Hgj0wNTQ2MDQwYjMtNjNhMS00YjEyLTk5NTctYmY2MDE1NzEyNGQ3
95e51765-0b13-48e2-8efa-a23ccb9beb84	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 19:41:18.24656+00	2026-09-11 19:41:18.24656+00	{}	2026-09-11 19:40:48.24656+00	OPAQUE	REFRESH_TOKEN	5_1k9RipMw1Tfe4y3nVI6ApQDPS0WgYWE4MDg1MjktNDUzNS00YTA5LWFlNGItMmZkMjFkNjgyYzcx
f8a84b2b-4a08-49c2-9ceb-463e02447b19	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 19:41:25.892179+00	2026-09-11 19:41:25.892179+00	{}	2026-09-11 19:40:55.892179+00	OPAQUE	REFRESH_TOKEN	xbcx5RZfK7Auiky-QMvvqXWFQnkMmQODk1MTI2ZGEtMjk5Mi00ZmQ0LThiMWQtMzE5MDAwMDRkNDY5
e67ffaab-4306-457b-9d2f-47d3d9baed70	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 20:19:50.783074+00	2026-09-11 20:19:50.783074+00	{}	2026-09-11 20:19:20.783074+00	OPAQUE	REFRESH_TOKEN	hA9YobDMDzPcRLjzsLYAiPH20aRr1AZGFiNGQ0MWUtMGQ0Ni00YjhlLWJlYjQtYzAwZTkwZDYzZjUx
b3fc83bd-1d8a-4e11-9c86-e6aa073a2e78	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 20:19:54.809952+00	2026-09-11 20:19:54.809952+00	{}	2026-09-11 20:19:24.809952+00	OPAQUE	REFRESH_TOKEN	ZrgAglwjyNEmkimimzA7VjL9LEufsQOTc1YWFkODktZDhlZC00ODU5LWE0NWMtNDgzZTY0Mzg3ODM1
75a1c01f-665e-477f-b375-f2981f35e4cd	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 20:19:58.488826+00	2026-09-11 20:19:58.488826+00	{}	2026-09-11 20:19:28.488826+00	OPAQUE	REFRESH_TOKEN	OEbtdn5Tp15Wyeuk-z1VoY3Iv7pGsAMDI2NzJhNjktMzljNi00MGRiLWEwOTAtNmY0YmM4N2FkYTg5
f448cac1-26d5-467a-aeb7-7248af9f274a	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 20:20:11.582484+00	2026-09-11 20:20:11.582484+00	{}	2026-09-11 20:19:41.582484+00	OPAQUE	REFRESH_TOKEN	jNGgEM2Ivvii5-nJ20JkB7zszBK-SQMGMwZTdlZjQtMmFiMS00NjczLWJhYmYtZTBhNmExYzkxNWZm
3c8b38b6-b535-4245-869e-a3f2c273f19e	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 20:25:50.889421+00	2026-09-11 20:25:50.889421+00	{}	2026-09-11 20:25:20.889421+00	OPAQUE	REFRESH_TOKEN	uEc0LQAGQ-hrxa26TWDpxdbtarkDVwYjkyYmM4MTQtYzIyNC00OGQ3LWE4NDgtYjExYmFkMTMyYWE3
d7b97a37-53b5-4b39-ab12-b982f18cfcf3	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 20:25:51.192061+00	2026-09-11 20:25:51.192061+00	{}	2026-09-11 20:25:21.192061+00	OPAQUE	REFRESH_TOKEN	nm1sFwtJwvCn7wydKL4OPu0uL1F_TQZWJlMTQzZmItNzNlMi00YmNlLThmMmYtYTk4ZDcwZGQxOGQw
9e4fe278-9bbe-4fc3-8364-192fedd9a34d	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 20:25:51.555054+00	2026-09-11 20:25:51.555054+00	{}	2026-09-11 20:25:21.555054+00	OPAQUE	REFRESH_TOKEN	UKV9hbQxQoiNqz0WupWGtNgdXpBqVAM2JjODMxN2YtYTE0ZC00NzRjLTlhNDEtZDdjYjhhOTQyNTMy
1b518332-2f09-4cec-be31-84dcd9b8003b	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 20:25:51.899691+00	2026-09-11 20:25:51.899691+00	{}	2026-09-11 20:25:21.899691+00	OPAQUE	REFRESH_TOKEN	Z1X86O2Jm1Scho0Fj5yPpzpvt27OYwZTQ0YmJhOTYtNTNkNi00M2VkLWFlOTktOWY4MTJjMWY2Zjc1
6be5be54-5922-4ca3-8857-5a5a25f775b1	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 20:43:19.853054+00	2026-09-11 20:43:19.853054+00	{}	2026-09-11 20:42:49.853054+00	OPAQUE	REFRESH_TOKEN	rvUo-sJeDur6GWRRQEmviS8FHaFklAZThjNWVhNDAtMDg3My00MTdiLWFiNTEtMjBiZTRlNmQ0Mjlh
f49cdb44-19da-420b-8051-255556c0c92d	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 20:43:21.179687+00	2026-09-11 20:43:21.179687+00	{}	2026-09-11 20:42:51.179687+00	OPAQUE	REFRESH_TOKEN	6DnWFr6sAauTSZ-5WJxulyZPOmQi5AYjUzMmJjOTEtMmIyMS00ODczLTkxNWYtYWI4MzNhMTRhY2Ez
d5470986-0e99-42f0-b661-bfc1e5b7e8da	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 20:43:23.941259+00	2026-09-11 20:43:23.941259+00	{}	2026-09-11 20:42:53.941259+00	OPAQUE	REFRESH_TOKEN	OqaYn_8CUH99FAgLfBtNrWGB_9etgQZmQ3ZTI5ZDItMjUwYi00ZGQ2LWI3ZGMtZWQ0ZjZkZjk0NWQ1
555929fc-05cd-4bad-a718-11f602441d8b	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 20:51:04.389737+00	2026-09-11 20:51:04.389737+00	{}	2026-09-11 20:50:34.389737+00	OPAQUE	REFRESH_TOKEN	F3W0dTmzYaLVVbbsDvFY5kcx3NJzGwOTgxMDkwYzktY2M5OS00YmJiLWE0NWYtNTRlZTRjNzA4ZDdh
da22db7e-3db1-407a-a950-515070c29fa6	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 20:51:04.684439+00	2026-09-11 20:51:04.684439+00	{}	2026-09-11 20:50:34.684439+00	OPAQUE	REFRESH_TOKEN	YQxp9LacQ_lf5yjQlN5f3DUcKpLc9gODFjYjNmYmItYTFlNi00NDBhLTlmMzYtMTg3MzFhMzIyZTc3
4d6b6e6b-b7fe-47bb-887c-4d93bf2c3582	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 21:01:23.426161+00	2026-09-11 21:01:23.426161+00	{}	2026-09-11 21:00:53.426161+00	OPAQUE	REFRESH_TOKEN	L95GvRNuu9cE_ZAKegcBsgqap8CEiwYzIxN2IxNGQtMjAzYi00NzRmLWExYjYtNjBjOTJjMGVjMWJl
1b62e8e7-00da-4468-b89c-e6cf02ff37dd	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 21:01:23.750464+00	2026-09-11 21:01:23.750464+00	{}	2026-09-11 21:00:53.750464+00	OPAQUE	REFRESH_TOKEN	NMcy_yTD3cmFEeK3XWJV4gSopGMMpQOWYxMDEwM2ItMGY5YS00NTJiLWIwNzMtM2NlNDZhYzliYWZj
805fcc9c-a928-4717-af66-bbe7ad63c8e3	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 21:01:25.467574+00	2026-09-11 21:01:25.467574+00	{}	2026-09-11 21:00:55.467574+00	OPAQUE	REFRESH_TOKEN	zher54b5QPAAaDluyWQSzy9KaASUagOGMwNjU5NGUtMDk0ZS00YzE3LThlZDQtOGU4MDZmYTA4MzM3
c691657d-1c11-4520-bf0e-4287068c8da0	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 21:01:25.748626+00	2026-09-11 21:01:25.748626+00	{}	2026-09-11 21:00:55.748626+00	OPAQUE	REFRESH_TOKEN	9NC-yR8bpJpd9OrNFCMyLjVVWvYPDQNmQ0ZTVmYTQtYzA1Yy00NmJiLWFiNWUtZjZlMWU1ZjVhNzNj
50ab7bba-d379-4c30-a68e-53e7aa433e0d	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 21:01:26.031021+00	2026-09-11 21:01:26.031021+00	{}	2026-09-11 21:00:56.031021+00	OPAQUE	REFRESH_TOKEN	JaAkh4mIHwotxQO0NP6qq3THvt_ccgNzM1NzEyZmMtOWRlNC00N2Q3LTgxODktMThkODNmNzJhYmRm
333a8cd4-9700-4e91-99ac-9afc84e89030	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 21:01:26.053764+00	2026-09-11 21:01:26.053764+00	{}	2026-09-11 21:00:56.053764+00	OPAQUE	REFRESH_TOKEN	Yxjuk5EmdRCoqnEMR81ESxwQBbX-SwZDZmN2RkOGMtZDQ4My00ODBlLTlkODEtZWIxZGIyYzU5MjJl
a4d795b2-76b4-41f7-a538-64dfafe70735	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 21:18:55.805856+00	2026-09-11 21:18:55.805856+00	{}	2026-09-11 21:18:25.805856+00	OPAQUE	REFRESH_TOKEN	Mrx8AwmIaZgkkg8eRFj9xuQpebIaQwMDc3NGZlMzMtMGFjYS00YWZjLWJjMzctZjdkYmVkNDc0MzU5
8cd24716-7a40-4cd1-b036-f9b771baf951	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 21:18:56.133137+00	2026-09-11 21:18:56.133137+00	{}	2026-09-11 21:18:26.133137+00	OPAQUE	REFRESH_TOKEN	BpdxnjR3p3koMhH0S0DFhj-MUCsIKgMzIwN2I3ZmEtYzQ5ZC00ZGFlLTg5ZjYtYWJmZTQzNWQ4ZWYx
053d87cf-6471-4693-8b04-27ba1cfa6e7c	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 21:18:56.738637+00	2026-09-11 21:18:56.738637+00	{}	2026-09-11 21:18:26.738637+00	OPAQUE	REFRESH_TOKEN	4kRsRREcKymXJo8bZuEezsfbDnHsAAMjU5YmIwMDUtZDQyZi00ODg0LWE0ODMtNjIyZmRmMWRmNDE3
4030346b-7acc-439e-b82d-bcab47b3675c	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 21:18:57.537873+00	2026-09-11 21:18:57.537873+00	{}	2026-09-11 21:18:27.537873+00	OPAQUE	REFRESH_TOKEN	bc0nqEj22nHsMILZs6tmnDrAwcnISQZjgyZWI5MjgtYmRlYS00NDgyLWE5OTAtMDAwMjUxOWFlODgw
ec302383-c35d-4480-9eb2-e7d03d663dbd	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 21:18:57.841069+00	2026-09-11 21:18:57.841069+00	{}	2026-09-11 21:18:27.841069+00	OPAQUE	REFRESH_TOKEN	pFkOsmaj4Yg3giSx8jjwRht7UYKTlwMjBkOGQzYzctMzcwZC00MzRhLTljM2UtMGJhOGNlNjA1NWIz
42494d7c-0f0c-4741-8242-b9767364ac06	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 21:18:58.1473+00	2026-09-11 21:18:58.1473+00	{}	2026-09-11 21:18:28.1473+00	OPAQUE	REFRESH_TOKEN	UxnqcLQJSplvyVoCQUo0sr8sy6vmlgYzdhNmVjNjQtOTZiMi00MDIyLTg3NDEtOTFiNzgzNTcxMDIw
cf9067dc-b638-4415-8c33-c2fdafa77ca1	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 21:18:58.180094+00	2026-09-11 21:18:58.180094+00	{}	2026-09-11 21:18:28.180094+00	OPAQUE	REFRESH_TOKEN	V7b6J4eXbLVh25OI2_RyyBhVwpxvBgNzUyNzkzNmUtMTdlYy00NTg4LWEwNmMtNjA1YzU2ZWI1YzFi
1110a368-495f-4625-890a-7e36920bc653	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 21:18:59.091249+00	2026-09-11 21:18:59.091249+00	{}	2026-09-11 21:18:29.091249+00	OPAQUE	REFRESH_TOKEN	UxAkHMgR-CF3ucK92W2pNsZD5ewi7wODFhNjRhNzUtYzMzMy00NzNmLWExZmMtZWUyZjExMDRjODZi
40823a0d-9fa0-465b-9bda-d5e9d85a6d62	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 21:24:44.735101+00	2026-09-11 21:24:44.735101+00	{}	2026-09-11 21:24:14.735101+00	OPAQUE	REFRESH_TOKEN	xGy8tfwBGTGUFQVCkKKsBKDOjOfIagZjE1MGNiYmItNTg1Ny00NWUxLTgwMmQtNzYzZGViYjRjZDY0
eb2cbae7-3427-4e05-b60a-6e3f2a07717f	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 21:24:45.113439+00	2026-09-11 21:24:45.113439+00	{}	2026-09-11 21:24:15.113439+00	OPAQUE	REFRESH_TOKEN	xfzMAPpTgZxc12w1Nt6taeNVV4QEhgZjM1ODcwOWItNzBhOC00YmY2LWI0OTAtNzJkY2FkZTQxMmJl
8bbf107c-6c15-42dd-961f-cbc5bc0581f9	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 21:24:45.576618+00	2026-09-11 21:24:45.576618+00	{}	2026-09-11 21:24:15.576618+00	OPAQUE	REFRESH_TOKEN	fQkeWtt8wjxTLpd-Aj8vWriEz8m3gQMWQ3MjZhN2ItMDAyYy00OTA4LTk5NDQtMjZiNTZlYTNlMzcz
34fb4508-fb67-4f89-b345-91761ab794d6	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 21:30:42.706195+00	2026-09-11 21:30:42.706195+00	{}	2026-09-11 21:30:12.706195+00	OPAQUE	REFRESH_TOKEN	YdoaoBx2h8nmM8zNRGHv1aCk_MTIjwM2MxN2Y4ODMtNmYzYy00ODhlLThjZTgtZWVhNTE1ZmUwNTNi
9d95b545-e18e-4621-9fbd-94cdc1656567	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 21:37:43.855961+00	2026-09-11 21:37:43.855961+00	{}	2026-09-11 21:37:13.855961+00	OPAQUE	REFRESH_TOKEN	6-PpXdg_-FqaTAoBxZsp9j2BuJimHgM2YzM2Q3Y2ItZmQ1ZS00OTg1LTg4MTUtNDg5MzI2YTFhMWVh
67b56d41-93cd-4ff6-a6a5-955804121a1d	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 21:55:32.405728+00	2026-09-11 21:55:32.405728+00	{}	2026-09-11 21:55:02.405728+00	OPAQUE	REFRESH_TOKEN	3ItGvFykcIaz681iAFoBenvZPQrtfAYjg1YTdmMzItNzdjNC00Njk1LWJjNmMtZmZiZmM4NWVhNmUz
e1f652aa-b085-416c-970c-09ae197025d5	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 21:55:32.742254+00	2026-09-11 21:55:32.742254+00	{}	2026-09-11 21:55:02.742254+00	OPAQUE	REFRESH_TOKEN	KC8FIhyYBzR5DHgUTGZTB9jUioqrrAZmMxZTZlNjQtNGM1ZS00ZTljLWI2N2ItZTJhYzY5OTBhNjUz
efcc9b60-37b8-4421-8242-a51d7ce2d236	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 22:15:25.052218+00	2026-09-11 22:15:25.052218+00	{}	2026-09-11 22:14:55.052218+00	OPAQUE	REFRESH_TOKEN	J3p_8_-mMSjBC9Y2qvreGXgfFFgkIQMjNjMDNhZjAtMGFjYy00OGNjLWI2ZTAtNDA5NmExMjNkMWIy
749190cc-37c1-4941-8266-b5cbc76929de	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 22:15:25.35397+00	2026-09-11 22:15:25.35397+00	{}	2026-09-11 22:14:55.35397+00	OPAQUE	REFRESH_TOKEN	BXQnuV4JAYQuPgiNZFPgcmKHk9r2bgYTMzNmVhOTctOGM0NS00MTQ2LWE3NmItMzM2ZjVkMjExMDY3
2346c082-c161-45cb-ab0c-b119b252103b	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 22:15:25.636659+00	2026-09-11 22:15:25.636659+00	{}	2026-09-11 22:14:55.636659+00	OPAQUE	REFRESH_TOKEN	_Fs4XGpqYYwjmHoufCW4gv3NAExA1gNzQ0NzNmYjktMzRkNy00NTIzLWEyZDgtMDM5NTBjNGUxOGE4
ee65ec48-f476-4faa-8cb7-d3a534bc9b62	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 22:15:25.91513+00	2026-09-11 22:15:25.91513+00	{}	2026-09-11 22:14:55.91513+00	OPAQUE	REFRESH_TOKEN	KXlm4RKCa0Swf02bZefw21QGvb-sfwMjQ0NjVhNmYtZDljZS00MjhiLWJhMGYtMTE2MTg5MTY3NWM4
d7b18496-db4d-44e0-8482-66c4c4ec1b85	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 22:15:26.201591+00	2026-09-11 22:15:26.201591+00	{}	2026-09-11 22:14:56.201591+00	OPAQUE	REFRESH_TOKEN	GnTQuFlPfJd9x58Bb5t9clTh8MFbMwNzUwZjJlZWMtNjM2OS00MjQzLWEzYzQtZDlkM2Y1YjRmMjg4
59cb034a-507e-45a6-88ee-fe2820c997a6	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 22:15:30.021817+00	2026-09-11 22:15:30.021817+00	{}	2026-09-11 22:15:00.021817+00	OPAQUE	REFRESH_TOKEN	N5BmZF6ecFNI7oOZbGMK8TrSzvXb-QOGZmMGQyMDItODk0MS00NmMxLTg5Y2YtMDgyOTZkYjc3MTk1
95c026e8-9db1-4e54-9c98-937fcfde00db	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 22:21:39.919117+00	2026-09-11 22:21:39.919117+00	{}	2026-09-11 22:21:09.919117+00	OPAQUE	REFRESH_TOKEN	6rTFm-_aawQ3z2aDS3z9z5ON2D-IgQZjgwMTdiOTctMGRmOS00ZjJjLTg1MzQtMzVmZTk5NmE2MjU2
9116693a-b2ab-4593-ae72-cab3198469b4	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 22:22:01.428802+00	2026-09-11 22:22:01.428802+00	{}	2026-09-11 22:21:31.428802+00	OPAQUE	REFRESH_TOKEN	tzODpQNaqWN9nRRLuZDnf9IRVH3NRwZTA1YjY5MjEtY2I5Ni00MmJlLWIzZWItZDYwZGU2MzUzYzQ2
146636e4-f47d-438b-9986-576dcaffc9c3	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 22:23:57.702187+00	2026-09-11 22:23:57.702187+00	{}	2026-09-11 22:23:27.702187+00	OPAQUE	REFRESH_TOKEN	-f5DCQ6ACAn9mUrDZrwABx2V6TrYTAZTg3ODZmN2ItYjZlMi00MGZhLTk3MTQtZDY5ZmViNmFjOTQ0
4032b14c-2d10-41ab-9273-e81ccd9c484b	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 22:33:27.540575+00	2026-09-11 22:33:27.540575+00	{}	2026-09-11 22:32:57.540575+00	OPAQUE	REFRESH_TOKEN	A5VEauZwxvIML-xqRR_uacTmpCp2yAYzVkZjg3MGYtY2Q3NS00NGIwLWIwYjUtMTNjMjM5YzMwZmUw
268f8805-44e4-44ab-aa79-3fa2a16879e7	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 22:33:28.052441+00	2026-09-11 22:33:28.052441+00	{}	2026-09-11 22:32:58.052441+00	OPAQUE	REFRESH_TOKEN	nh436hoe3sgAaptNOtBrxdoOFtYakgODhjY2M5NzItZWVhNi00MzU0LWFhMjgtMTc5MDgzNjNmZDM2
c3182e2e-ecb1-4371-a364-234d0ecf828e	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 22:33:28.397448+00	2026-09-11 22:33:28.397448+00	{}	2026-09-11 22:32:58.397448+00	OPAQUE	REFRESH_TOKEN	tAFY9nzRg0oseK8feKOd4c3f-lMKXANTE2OGQ2YzEtM2ExMy00MDY4LTgzN2UtYjU2ZTY3N2U3M2Q2
148a153e-6ccf-4f99-a396-62a1a43c9efb	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 22:33:32.804377+00	2026-09-11 22:33:32.804377+00	{}	2026-09-11 22:33:02.804377+00	OPAQUE	REFRESH_TOKEN	UAWXPCJWA6tX2sGSHwJH-QRcYCL0ZwMjNlNGYxNjMtZmMxYi00Zjc4LWIyMWUtMGE1NGU3NTNmZGNh
df3a68ef-27b8-4204-8eca-04b40dec570b	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 22:33:33.337124+00	2026-09-11 22:33:33.337124+00	{}	2026-09-11 22:33:03.337124+00	OPAQUE	REFRESH_TOKEN	Hvuku2du748RpGmArqPQi5TnmsCaUQYTllYjA3NzAtNmIwNS00YjAzLThkMGYtOWJlZmQwY2RjYmRj
a1a15e35-5012-4c4d-850c-11884b125e59	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 22:33:33.651523+00	2026-09-11 22:33:33.651523+00	{}	2026-09-11 22:33:03.651523+00	OPAQUE	REFRESH_TOKEN	Rhw0_JFVMpKbiuLU0JKUmEcBU7RbLwYjMyMmM5YWQtMWI3YS00NGE1LWE3M2MtYWJlOTRmZDdlZjg5
6641860c-f7ab-4629-b51e-6699786c562e	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 22:33:33.957448+00	2026-09-11 22:33:33.957448+00	{}	2026-09-11 22:33:03.957448+00	OPAQUE	REFRESH_TOKEN	M9EDe9RWSe5Q6_Aw7zAZ1Oas1zGzrwYzk4M2M2YmEtODVjMi00ZWEzLWEzODktNGEzMWU3NzlmZjYw
f89617cd-55e6-4974-8969-f408b1ed9cf6	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 22:33:35.177222+00	2026-09-11 22:33:35.177222+00	{}	2026-09-11 22:33:05.177222+00	OPAQUE	REFRESH_TOKEN	_r85ZBS39LjVQN00Pgwveam2GvscvgNzU3YWY4MGMtZjZlMC00ZmNhLWI4NTAtOGQ3N2IzN2ZmN2Yy
30045f87-7192-4b8e-b4a7-f8be13d04637	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 22:33:33.0765+00	2026-09-11 22:33:33.0765+00	{}	2026-09-11 22:33:03.0765+00	OPAQUE	REFRESH_TOKEN	3qymAyA4XH6QQvtN_FYSMtjSjlq73QMDhkYzQ2ZTEtYTdmMi00YWM5LTkwZTItMTdiOTQ4ZmU0MzZh
285a33d4-066a-4efc-a47a-eed9634172ea	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 22:33:33.963517+00	2026-09-11 22:33:33.963517+00	{}	2026-09-11 22:33:03.963517+00	OPAQUE	REFRESH_TOKEN	zof74tVmdoypSuYBDxFnbwCICGH4PwMmY2YzE5NzMtYmE4MS00YmUyLWFhNWUtZmIxYmQ5NWU5MzIw
91a41e53-9049-4e24-89b4-62123d72f3b3	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 22:33:34.860589+00	2026-09-11 22:33:34.860589+00	{}	2026-09-11 22:33:04.860589+00	OPAQUE	REFRESH_TOKEN	209Jbr9MascyaBPuaJV1FW6m_TsvgAZWZkM2M3NjctM2QzZi00ZmFjLWFjNGYtM2Q0NzJjMDM2MWI0
b75bc516-1b32-49cc-b615-d340baecc74f	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 22:43:58.671779+00	2026-09-11 22:43:58.671779+00	{}	2026-09-11 22:43:28.671779+00	OPAQUE	REFRESH_TOKEN	Kt1M-9V2e8C-Xir8URm6o9j9j6OglANWYzZmVhNzctMTNlYi00ZjE2LWE2NjAtNmFkOGQwMDc4Njhl
22e3a140-f8ee-4c85-bdde-27ceb2a84ad0	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 22:43:59.017252+00	2026-09-11 22:43:59.017252+00	{}	2026-09-11 22:43:29.017252+00	OPAQUE	REFRESH_TOKEN	BLGcBKjf9-rVtwO6TroofPhGnBptyAZjg3MGVjNTEtYzc5Mi00MzIyLWE1OTQtZTVkNGRjNDlkZTdk
46464e94-6ea0-4f66-bca1-4861a0c43e64	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 22:43:59.375583+00	2026-09-11 22:43:59.375583+00	{}	2026-09-11 22:43:29.375583+00	OPAQUE	REFRESH_TOKEN	TrxD7KGU4S-m75gV7WoYSMNPHqqfiwZTU3ZGZmM2MtZmM0ZC00MWZkLTk1ZDktMTZjYzJiYTVmZTA0
fef175d0-8668-47d9-9387-3fa45c5c048c	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 22:44:56.455488+00	2026-09-11 22:44:56.455488+00	{}	2026-09-11 22:44:26.455488+00	OPAQUE	REFRESH_TOKEN	6faB9FyzILyTQgagN5zrJ3CyWTpHYAMzgzZDc1Y2MtMDMzMC00OTRkLThlMzEtODNhNDlhZDNhYzA2
a0de6e28-69c4-4f4b-babb-11bc519c3bcf	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 22:50:48.122771+00	2026-09-11 22:50:48.122771+00	{}	2026-09-11 22:50:18.122771+00	OPAQUE	REFRESH_TOKEN	-Ho6atiX7nu2ndQG2yIPxN-WbRNzQAMDg3ZjFiNWUtZjBkYS00ZTVmLTlmM2ItMGY3MzI4ZDMxMDQ0
ebf50e8a-b620-4613-a1fb-d4299b97a373	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 22:50:48.421852+00	2026-09-11 22:50:48.421852+00	{}	2026-09-11 22:50:18.421852+00	OPAQUE	REFRESH_TOKEN	lPDmcpzRAoqbhX7hV9cMW4qOZ4I-LwNWUyMThkODAtNDk3NC00ZjBiLTgwNWItNjNkNjA5NDg2Nzkx
453f9169-d960-4e3e-b238-3259032d8d6d	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 22:50:48.70198+00	2026-09-11 22:50:48.70198+00	{}	2026-09-11 22:50:18.70198+00	OPAQUE	REFRESH_TOKEN	7LTAip19p0rpX0uXTZMTpDJkDmyT4wYmJlM2M5NzItNzBlNC00ZTlkLTgwYmUtMzE1MTYxNmVlMTNj
a84bd216-8bef-4dda-bf69-6323de34a0e8	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 22:50:48.97178+00	2026-09-11 22:50:48.97178+00	{}	2026-09-11 22:50:18.97178+00	OPAQUE	REFRESH_TOKEN	fXeRjCmRVovPHIU2qqzyq3po6ATuGgODBlZDJiZjMtMDg2Ny00M2FmLThmMWItYjkwNGFhYzU3MWMy
70aab1be-aafd-49bf-a5b7-9c913247f4b5	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 22:50:49.243483+00	2026-09-11 22:50:49.243483+00	{}	2026-09-11 22:50:19.243483+00	OPAQUE	REFRESH_TOKEN	NUsl8XbiVBAXe3sKSzBreF1rjVP2NAMjgyN2NmYmYtNzY1OC00NjE1LTllZTMtZjdmOGI2ZTBiM2E4
74dcc0da-4c54-4888-bdd7-aa43f52e9905	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 22:50:49.500875+00	2026-09-11 22:50:49.500875+00	{}	2026-09-11 22:50:19.500875+00	OPAQUE	REFRESH_TOKEN	dSE4L1yhyKZePXSEd5XKS1c65ez0EAYWQwZmYxZTUtMDBmYS00MzhkLWFmYjUtYWRhZjY3ZjRmNWFj
3a8a83fb-487f-4fca-b9dc-750fcf46b747	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 22:50:49.776249+00	2026-09-11 22:50:49.776249+00	{}	2026-09-11 22:50:19.776249+00	OPAQUE	REFRESH_TOKEN	gaPNz1jOz9MIiMnZOy_xohhhsGjGvgNzBmZTY2NTctNDhjZi00MmY1LWE1MzQtNGVkN2ZhNjFhMDUx
97935630-7da3-4dde-8268-7b0041c85699	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 22:50:50.055981+00	2026-09-11 22:50:50.055981+00	{}	2026-09-11 22:50:20.055981+00	OPAQUE	REFRESH_TOKEN	f1_Uj4tu4jJINAGq8RPMpHVRJXLbDQNTg1YjQ4MjYtZDU5OC00MmVjLWE5ZDEtZmQwNjA2MmIxZGY5
1326b6be-de89-45d4-bc41-5b729b95e543	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 22:50:50.318431+00	2026-09-11 22:50:50.318431+00	{}	2026-09-11 22:50:20.318431+00	OPAQUE	REFRESH_TOKEN	Uh339d0v5H4l6El4mgD5z0gqyqoKbwMmQyMTIyMjAtY2M5OC00MzVhLWJhYTYtZDEwNjVhZjFmZmFj
506cce48-9da0-4dca-af78-507434293824	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 23:30:05.91555+00	2026-09-11 23:30:05.91555+00	{}	2026-09-11 23:29:35.91555+00	OPAQUE	REFRESH_TOKEN	g0MyXCBPYz1LYzQbTvk1dwfbaLeJ2gNGE5MTMxNDktOWMyNS00YzdiLTg5NjctOGJjMWVkOWY2N2Q2
59ed8859-5cc9-43a2-859c-44245bd20fc9	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 23:30:06.202196+00	2026-09-11 23:30:06.202196+00	{}	2026-09-11 23:29:36.202196+00	OPAQUE	REFRESH_TOKEN	4p-iYIBDp7hdPrirpy2PUP1shAMoFwODI5MmM3MjctMmNmZi00ZDg5LTkwMTgtMGE1ZTg0YTY0YWI5
42339a59-5f51-459e-9032-70befab213c1	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 23:30:06.493067+00	2026-09-11 23:30:06.493067+00	{}	2026-09-11 23:29:36.493067+00	OPAQUE	REFRESH_TOKEN	mtaeGq-UBzT1kJWjwPuo28qekNxGbAZmY4YzMzNzItYzRkYi00OWE4LWIwNTMtODlhYmQ3Y2QyM2Uz
fb7890c3-4605-4160-94de-e07e56881050	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 23:30:11.128088+00	2026-09-11 23:30:11.128088+00	{}	2026-09-11 23:29:41.128088+00	OPAQUE	REFRESH_TOKEN	OmdFlrgBfSyhEc2KeyxdylVqZqmhjQZjA2Zjg2NjktZGVlYy00NTk5LTg0MDgtYzZjZWU2Yzg2MjIw
4da41ca6-419c-4f9f-a884-e1b71d814f21	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 23:44:27.011603+00	2026-09-11 23:44:27.011603+00	{}	2026-09-11 23:43:57.011603+00	OPAQUE	REFRESH_TOKEN	dt2AXtPmMmfrJ98mFtBkNlNd_xsNQgMTdlMTEwNjctMjdhZi00MDQ5LWExY2ItNjIyNzJlMWE3MTU2
6befb055-8165-472a-98d2-4546b04a7a45	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 23:44:27.301316+00	2026-09-11 23:44:27.301316+00	{}	2026-09-11 23:43:57.301316+00	OPAQUE	REFRESH_TOKEN	y1uAbUKdWlr_utKxe4e-EbiGbC4rBwNTQ1ZDc2Y2QtYmM0Mi00NmUzLWJiNGYtNzU1OGQ0NjlhMzQ1
3eac7cf4-f3ab-4bac-8f63-ce9f646e03ba	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-11 23:46:35.25315+00	2026-09-11 23:46:35.25315+00	{}	2026-09-11 23:46:05.25315+00	OPAQUE	REFRESH_TOKEN	pbFpjDg1lExNIC9gTgEs3VSRcK3VtwOThiNDllODUtODg1MS00OGZhLTkwNDYtZDg0NjNjYTU3MDhj
486b2fc2-2a6d-41af-9dd4-2c23b9b7c302	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-12 00:15:13.862336+00	2026-09-12 00:15:13.862336+00	{}	2026-09-12 00:14:43.862336+00	OPAQUE	REFRESH_TOKEN	P_CKloSKNQKDXc6ZJqMURXClkM5tUwZTM4NWIzMTYtOTkwMS00MWRlLWI2NGMtMTc0YTkwYWY5YTdk
ef74d8c9-277d-42bd-923c-d1c19ec37ac0	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-12 00:15:17.442899+00	2026-09-12 00:15:17.442899+00	{}	2026-09-12 00:14:47.442899+00	OPAQUE	REFRESH_TOKEN	J4KDfLfp6cv-sUttRAifsb9sQ7HmbgOTYyMmJkZjMtNzg0Mi00ZjQwLWFmZmEtMTQ5ZDdlYjVmODFj
f37703d0-64cd-4f87-a63e-997feb51d8e3	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-12 00:15:17.747649+00	2026-09-12 00:15:17.747649+00	{}	2026-09-12 00:14:47.747649+00	OPAQUE	REFRESH_TOKEN	UV8fmywX2mxD_1-cRgb-MpWL3xCSbAOGM4MTgxNTYtMjk5NS00ODA5LWI0ODQtZDFhYjc1OTJiMjA4
8d017e29-1e3e-41f3-9a55-6fa233d94eb2	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-12 00:15:38.002487+00	2026-09-12 00:15:38.002487+00	{}	2026-09-12 00:15:08.002487+00	OPAQUE	REFRESH_TOKEN	H3U5KmYdAINUIFc1uhs0WmuKVs9jeQYTg4YzI0OTktOWE1My00ZDFlLTkzNDAtNmYxNjNjODExZWY3
1e9872d4-f912-44dd-9610-a1059275ee3b	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-12 00:18:48.320504+00	2026-09-12 00:18:48.320504+00	{}	2026-09-12 00:18:18.320504+00	OPAQUE	REFRESH_TOKEN	mO0clIiUO7V9zdGDbSsSAjX5mVGouQMjg5NzJlYzItZGNmYS00ODlhLWJlMWEtMjIyYWI5NDA1YTYw
222ec12d-6f7c-4b9c-915e-26bd3439555b	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-12 00:22:54.662466+00	2026-09-12 00:22:54.662466+00	{}	2026-09-12 00:22:24.662466+00	OPAQUE	REFRESH_TOKEN	ccrg2fdOb_C06uDA1DpXFbe3nTiFGwMDFkYzZiMzUtZTMzMi00ZGJkLWEyMDUtNTExN2VmYTlkZTQw
54e9adc5-536f-41aa-8320-747c8e42c23f	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-12 00:24:27.632619+00	2026-09-12 00:24:27.632619+00	{}	2026-09-12 00:23:57.632619+00	OPAQUE	REFRESH_TOKEN	4c0yooikMgoEKnSwEuzPD9Bm2TWi5AM2M5NmQzNjUtMmRhOC00ZGFhLThmY2QtNjI5ZDU1MzUwMTc1
5cd9f129-2ad2-4dd5-8f4e-35d16a4ef9d9	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-12 00:25:51.186253+00	2026-09-12 00:25:51.186253+00	{}	2026-09-12 00:25:21.186253+00	OPAQUE	REFRESH_TOKEN	LgE9zaPb0fLxHLjCCgTUMnhhRyehbQNzY1MGUzODgtZTZlOC00MzU4LTkyMzktOTc1ZDkwZjU0MjMz
e1f07cfd-3e95-4784-8626-c979535c900f	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-12 00:26:21.296901+00	2026-09-12 00:26:21.296901+00	{}	2026-09-12 00:25:51.296901+00	OPAQUE	REFRESH_TOKEN	Q9_5uj4vnZPTJUl8vHu2AV8YW9gR6QNTI2MmUxZmQtZjA3Zi00Mzg3LWFiOWMtYTk4MjgxNDA1NDA4
bb52f20e-8caf-4925-950d-6e4321dd9be3	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-12 00:26:25.729019+00	2026-09-12 00:26:25.729019+00	{}	2026-09-12 00:25:55.729019+00	OPAQUE	REFRESH_TOKEN	7V4utIxQmQIoQvmHzyfEl-vnuNFqmgZThmMjY4NWQtYWYxNi00YWFjLWJmNzYtM2JmZTY4ZjMyZTRi
d353b3d2-c5ee-463b-a580-65f703cc5c45	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-12 00:33:17.753614+00	2026-09-12 00:33:17.753614+00	{}	2026-09-12 00:32:47.753614+00	OPAQUE	REFRESH_TOKEN	Qw4O0pMc7Pgf7qfoxz8R0cO5vV8A7AMDQzYzhiODMtZTg0ZS00OTVkLWE1MTUtMTQxZWVjOTJlY2I1
12c3a93b-368b-4000-89e2-73edc038c897	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-12 00:33:18.02669+00	2026-09-12 00:33:18.02669+00	{}	2026-09-12 00:32:48.02669+00	OPAQUE	REFRESH_TOKEN	QBjQCUY9HqYIP0a-qGTc07gocTLwZgODRmYTk1YjUtNTFhOC00Nzk1LWE2ZTYtN2I5NTM3YTM4MzAy
01e98ec9-c431-4c09-a313-95c41ee9f7d8	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-12 00:33:18.285419+00	2026-09-12 00:33:18.285419+00	{}	2026-09-12 00:32:48.285419+00	OPAQUE	REFRESH_TOKEN	sTzALnqwrwwii7hxYC-lFrJaitqFJAMmFiZGI4MGUtMTY3Yi00MTI0LWE4NWEtYTI1MmRhYjZkYmZh
3402bd59-5ec6-448e-839b-ab34a991e74d	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-12 00:33:18.549033+00	2026-09-12 00:33:18.549033+00	{}	2026-09-12 00:32:48.549033+00	OPAQUE	REFRESH_TOKEN	ZIsRYnCSOsKLxEYbdfGbzkJK-B4s3wN2U0OTg0YWEtNTZiNi00ZjhhLWJjNzQtNWZiMWFlZWM1ZDM5
eb1e07cb-1968-4cb6-8b44-a7cf1feb51b8	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-12 00:33:18.631013+00	2026-09-12 00:33:18.631013+00	{}	2026-09-12 00:32:48.631013+00	OPAQUE	REFRESH_TOKEN	DAvnaeHdQ7s66ep2G3VPQGodtMk_iQZDM3ODg0YzMtZjY0My00MTY4LWE3MGItODFkZDcyZjRmNDMy
e286a95a-793f-4879-940b-d3f4bff6c687	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-12 00:33:18.811639+00	2026-09-12 00:33:18.811639+00	{}	2026-09-12 00:32:48.811639+00	OPAQUE	REFRESH_TOKEN	HJ3AH1OuG6Tnd46zLce2pfjemI1JKwNGIyOTY3MjQtZThkYy00ZDM3LWFkYzEtOGUyYTcyN2ZhMmEz
d1f09c09-382c-4eab-b42e-1e90a1552747	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-12 00:33:19.097626+00	2026-09-12 00:33:19.097626+00	{}	2026-09-12 00:32:49.097626+00	OPAQUE	REFRESH_TOKEN	0A7aUq9e5yREL3QA0FffAeWML_b77AYzVkMTg3ZWQtNjMwOC00ZmE2LWFjYzMtMjIwMmZkNGE3ZjM5
df23cfd2-b14f-470b-98de-d8b6a5decdba	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-12 00:38:18.079462+00	2026-09-12 00:38:18.079462+00	{}	2026-09-12 00:37:48.079462+00	OPAQUE	REFRESH_TOKEN	Tl3iV1XQ7uab74kFBi7JN1RapE1NRwMzUwOTJkMDMtNTFiNC00NzZlLThlNGQtMDdhN2Q0MjQ0ODUw
c36b434a-6861-4656-9742-9564d60aac83	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-12 00:47:15.356867+00	2026-09-12 00:47:15.356867+00	{}	2026-09-12 00:46:45.356867+00	OPAQUE	REFRESH_TOKEN	KgIt9T1Kf4GVGlMzQeEWEWt23JmbBgZDk0ZGUwMjUtMjY2YS00Y2M4LTgyODktNDM4NGNhMzM3YTVk
f7eafcfa-c72a-42a9-87eb-ceeda0e01954	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789131703, "session_id": "8f3e04c8-a450-413e-b626-fbf611c4ad5d", "session_exp": 1799499703}	2026-10-12 00:54:18.640476+00	2026-09-12 00:54:18.640476+00	{}	2026-09-12 00:53:48.640476+00	OPAQUE	REFRESH_TOKEN	aMev4RdRBdIPe3CkIHyP0o8831C4kAYzRiYjM0MTEtYThhNi00ODc5LWIzZmItMjY4YTlkZjZkNWM1
1f4c17c4-45b1-45fd-94a4-118acffe55cc	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789174556, "session_id": "e4bd88b2-8624-4549-8a57-4dc4c65a1d45", "session_exp": 1799542556}	2026-10-12 00:55:56.093615+00	2026-09-12 00:55:56.093615+00	{}	2026-09-12 00:55:26.093615+00	OPAQUE	REFRESH_TOKEN	3sM-ILAblXD97lVfA_m4B0YNnV8w8wNDhkMTIxNGQtYmYwZC00ZTAyLWJlOTctM2RhYTQ3ZWIzZDI2
3065b72d-4502-4c60-a551-48f2d0572a39	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789174556, "session_id": "e4bd88b2-8624-4549-8a57-4dc4c65a1d45", "session_exp": 1799542556}	2026-10-12 00:56:00.422643+00	2026-09-12 00:56:00.422643+00	{}	2026-09-12 00:55:30.422643+00	OPAQUE	REFRESH_TOKEN	aDV9bhftYwEBJo_E_tX3dU1eWnH8ggNjY1MGExNjktODRhNi00Mjc0LTg4NzAtYmU1NTNjN2Q2N2Zh
b1205b2b-f793-4dc7-833c-d6212b9bb7fc	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789174556, "session_id": "e4bd88b2-8624-4549-8a57-4dc4c65a1d45", "session_exp": 1799542556}	2026-10-12 00:56:15.163061+00	2026-09-12 00:56:15.163061+00	{}	2026-09-12 00:55:45.163061+00	OPAQUE	REFRESH_TOKEN	P1gRXKh9IfEImWse6_uhs5UyOVfhGAZjQ2YjQ1MzAtMGVkMS00OGM1LWFkNzAtYzNmNzhhYzBhYzlm
edd98094-2f89-4bfc-8967-c2541e0f4263	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789174556, "session_id": "e4bd88b2-8624-4549-8a57-4dc4c65a1d45", "session_exp": 1799542556}	2026-10-12 01:03:18.271063+00	2026-09-12 01:03:18.271063+00	{}	2026-09-12 01:02:48.271063+00	OPAQUE	REFRESH_TOKEN	jHJJlFQj97kMm9sJ8q8AbDeAhaJfCgYzZmMDFlYWYtOTZmYi00MzM1LTlmNzctNmU5OGQ5MzRjZjgy
c3de72a3-a43e-44c3-942b-d032a65c35f7	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789174556, "session_id": "e4bd88b2-8624-4549-8a57-4dc4c65a1d45", "session_exp": 1799542556}	2026-10-12 01:08:07.210484+00	2026-09-12 01:08:07.210484+00	{}	2026-09-12 01:07:37.210484+00	OPAQUE	REFRESH_TOKEN	etbmtN6lOotnS0byw5yAZ7Tg_DRrZQOTY0ZDVkMzItNGYwMy00MTRjLWJkMGEtYjQ1MTY4YTM2MGYx
c25f420b-dfc9-4807-a04f-df9f5cfba235	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789174556, "session_id": "e4bd88b2-8624-4549-8a57-4dc4c65a1d45", "session_exp": 1799542556}	2026-10-12 01:17:58.695138+00	2026-09-12 01:17:58.695138+00	{}	2026-09-12 01:17:28.695138+00	OPAQUE	REFRESH_TOKEN	pSI4g_6yeDmdU5jJ_oT595E_qBDuEQNDM0ZWI1N2ItMTYxNy00NGJjLWIyYzEtZTZlYWQyZjIyMjZh
5ab9a7c3-b103-4602-be2d-0b2ff6c6399a	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789174556, "session_id": "e4bd88b2-8624-4549-8a57-4dc4c65a1d45", "session_exp": 1799542556}	2026-10-12 01:17:59.539761+00	2026-09-12 01:17:59.539761+00	{}	2026-09-12 01:17:29.539761+00	OPAQUE	REFRESH_TOKEN	Ft7SPL4MliwQ1zp0-Elbn225iI8kgAZTVhYTE5ZWUtOGExNi00ZjU3LTg0MDYtNzEyNzBlNzNmM2U5
46786a73-1416-4bfe-97b5-b60ff132768d	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789174556, "session_id": "e4bd88b2-8624-4549-8a57-4dc4c65a1d45", "session_exp": 1799542556}	2026-10-12 01:19:01.764636+00	2026-09-12 01:19:01.764636+00	{}	2026-09-12 01:18:31.764636+00	OPAQUE	REFRESH_TOKEN	SgWRL201NAbuhoSVIhV2pu6-LSmKHgYWVhMjg1MGYtNzhjNC00YzQ4LTgxYzQtNTA1NmY2NWM0ZDYy
6633c9cb-89d2-4a30-b592-a411f9c8e209	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789174556, "session_id": "e4bd88b2-8624-4549-8a57-4dc4c65a1d45", "session_exp": 1799542556}	2026-10-12 01:25:04.953368+00	2026-09-12 01:25:04.953368+00	{}	2026-09-12 01:24:34.953368+00	OPAQUE	REFRESH_TOKEN	wdsDydZ5Pm4_KizwNNAh_K7cowyGnwM2RmOGIzNWUtNGNiZS00ZmZhLTgyNGUtZjQ0MTc3OWZmYzlj
3ae49274-9dbf-41b0-8203-b732fa9676dd	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789174556, "session_id": "e4bd88b2-8624-4549-8a57-4dc4c65a1d45", "session_exp": 1799542556}	2026-10-12 01:25:05.220663+00	2026-09-12 01:25:05.220663+00	{}	2026-09-12 01:24:35.220663+00	OPAQUE	REFRESH_TOKEN	EzlfzyQ1znnhGvCtTWwJyFHWsutPVQM2Y5Mzg1MDctNTY0NS00OGEyLWIzYWMtZDIyYTNkZWRkNTky
a139c14e-3262-4b7d-a5f9-7113d20d48a3	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789174556, "session_id": "e4bd88b2-8624-4549-8a57-4dc4c65a1d45", "session_exp": 1799542556}	2026-10-12 01:25:05.476101+00	2026-09-12 01:25:05.476101+00	{}	2026-09-12 01:24:35.476101+00	OPAQUE	REFRESH_TOKEN	AvU493GI65HBGtnyF1CI-dMmVtiEhQNGU3ZDZiZmUtMDkyYS00YTllLThlZGEtZjYxODRmNDM0Njk0
d3d247fb-9947-4673-89df-029787c79598	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789174556, "session_id": "e4bd88b2-8624-4549-8a57-4dc4c65a1d45", "session_exp": 1799542556}	2026-10-12 01:31:26.882397+00	2026-09-12 01:31:26.882397+00	{}	2026-09-12 01:30:56.882397+00	OPAQUE	REFRESH_TOKEN	1DROaJs1wQO-AIO_A8csGe8puGbzLwNDMzMjg3YjktZjExMy00MzNmLWE3NzMtM2I2OGYyMjM2MGUz
1ccc08c5-cc25-41ad-9189-841d3ec75352	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789174556, "session_id": "e4bd88b2-8624-4549-8a57-4dc4c65a1d45", "session_exp": 1799542556}	2026-10-12 01:31:27.156997+00	2026-09-12 01:31:27.156997+00	{}	2026-09-12 01:30:57.156997+00	OPAQUE	REFRESH_TOKEN	JYMA0eycaoJTrXE70xL3GgLNNJAAEAN2Y0NGUyYmItZTJiMC00ZTNkLWFhNWMtMGM5YzY5MWZhMmYx
3c1f8d65-d92c-41b4-89be-74bbac8eed36	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789174556, "session_id": "e4bd88b2-8624-4549-8a57-4dc4c65a1d45", "session_exp": 1799542556}	2026-10-12 01:31:27.431863+00	2026-09-12 01:31:27.431863+00	{}	2026-09-12 01:30:57.431863+00	OPAQUE	REFRESH_TOKEN	yQCValv6NZSGtf2eqrjeJhvYaGac-QNjBlMTg1YTYtNzkzMC00N2IzLWI1YTEtODE0NTk5MTEzMGIx
f69556ce-ebbd-48eb-b7db-5022bf0d2534	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789174556, "session_id": "e4bd88b2-8624-4549-8a57-4dc4c65a1d45", "session_exp": 1799542556}	2026-10-12 01:31:47.97817+00	2026-09-12 01:31:47.97817+00	{}	2026-09-12 01:31:17.97817+00	OPAQUE	REFRESH_TOKEN	Hfn0LP4uRXThxjCLr9j0zgNKpVIhQQZDdmNDAzMTQtMTZlMC00MWI4LWJkNGEtYzE1YWUyYzk4NTNl
a629ec22-54bb-4f3f-9f75-f7857c99609c	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789174556, "session_id": "e4bd88b2-8624-4549-8a57-4dc4c65a1d45", "session_exp": 1799542556}	2026-10-12 01:33:59.575239+00	2026-09-12 01:33:59.575239+00	{}	2026-09-12 01:33:29.575239+00	OPAQUE	REFRESH_TOKEN	zlqYVzwWJ0TEnVgMd7iw0OAer5uU5QMGE0YzIyOTYtYWY0Zi00YzFhLTgxMTUtNGFmMDM5YWUyMmJi
2d712fe8-640b-4939-94e9-722a5d8b07e2	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789174556, "session_id": "e4bd88b2-8624-4549-8a57-4dc4c65a1d45", "session_exp": 1799542556}	2026-10-12 01:35:12.447448+00	2026-09-12 01:35:12.447448+00	{}	2026-09-12 01:34:42.447448+00	OPAQUE	REFRESH_TOKEN	Eve_DVo-epK7v-sp0_mWEgZn0OB6ogMzg4YTQ5ZWMtZTk1OS00ZGFmLTllY2MtZTRkMzg5M2ViODA2
b2f1f81f-9308-46ef-a80c-7b00de46da18	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789174556, "session_id": "e4bd88b2-8624-4549-8a57-4dc4c65a1d45", "session_exp": 1799542556}	2026-10-12 01:38:25.080975+00	2026-09-12 01:38:25.080975+00	{}	2026-09-12 01:37:55.080975+00	OPAQUE	REFRESH_TOKEN	WhLDR6zJAkZNxWMKExfYDdCHx9-GegMTgxYzc4N2EtY2ZmYi00ZmE4LTlhMmMtZGU0ZmMxYWZhN2Zm
e15874c3-1ee6-468f-b285-f14e640c49f9	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789174556, "session_id": "e4bd88b2-8624-4549-8a57-4dc4c65a1d45", "session_exp": 1799542556}	2026-10-12 01:41:51.023536+00	2026-09-12 01:41:51.023536+00	{}	2026-09-12 01:41:21.023536+00	OPAQUE	REFRESH_TOKEN	YHjPRrwSO-_RSEzhAKFgRKTsbcIG8QNDk4MWY3YTUtZTU2OC00MmM0LWJhOGYtMTI3MzQyOWE3YTU3
8fd17470-e1db-4153-8419-130a6826fbde	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789174556, "session_id": "e4bd88b2-8624-4549-8a57-4dc4c65a1d45", "session_exp": 1799542556}	2026-10-12 01:42:48.067678+00	2026-09-12 01:42:48.067678+00	{}	2026-09-12 01:42:18.067678+00	OPAQUE	REFRESH_TOKEN	PQVdiNyjJO8ox6zgMKGhRh7ovMntKQNTY5ZjQ0ZDMtNDZkMS00ZWU1LTg2MzAtZGQ1ZGUwNzMzMTQ4
8448cb16-418a-4e3a-ab8b-2651e6c5561f	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789174556, "session_id": "e4bd88b2-8624-4549-8a57-4dc4c65a1d45", "session_exp": 1799542556}	2026-10-12 01:48:28.600219+00	2026-09-12 01:48:28.600219+00	{}	2026-09-12 01:47:58.600219+00	OPAQUE	REFRESH_TOKEN	63oXoVNknhD2qRAiseYj7XYyQ6RJfAZjlmNzBlZGQtODhhMy00NzI0LWJjYWEtOWUwZGE5ZTJhNGVm
40ca5fa3-2322-4ebe-998a-e3726df76973	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789174556, "session_id": "e4bd88b2-8624-4549-8a57-4dc4c65a1d45", "session_exp": 1799542556}	2026-10-12 01:48:29.983305+00	2026-09-12 01:48:29.983305+00	{}	2026-09-12 01:47:59.983305+00	OPAQUE	REFRESH_TOKEN	LCEvqg2_roqc8k45ikzzE4ReGba3CAZTAwODNkZmItYmZjNC00ZmQ0LWFhM2MtNDI4Mzg2MTAzM2Mx
771fc72c-0819-415f-b95d-8e2124d5fbb9	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789174556, "session_id": "e4bd88b2-8624-4549-8a57-4dc4c65a1d45", "session_exp": 1799542556}	2026-10-12 01:51:08.095404+00	2026-09-12 01:51:08.095404+00	{}	2026-09-12 01:50:38.095404+00	OPAQUE	REFRESH_TOKEN	BIRHJMUAMjdY05tds2v8XVAzP1GAigMWIyZDNiNDQtMjAxMS00NjY2LWI0ODItOGY5ZGQ1ODFlOGE4
bda684e5-50a2-404d-95cd-e3563c7e0de3	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789174556, "session_id": "e4bd88b2-8624-4549-8a57-4dc4c65a1d45", "session_exp": 1799542556}	2026-10-12 01:52:50.213497+00	2026-09-12 01:52:50.213497+00	{}	2026-09-12 01:52:20.213497+00	OPAQUE	REFRESH_TOKEN	YM726cjpEc1j2uL-C32hE3iL_WU-RwMjc4OWFkOTItMTU0Yy00MWFhLWE2MGQtYzM1ZGJjZTI5MjFj
2b1d1180-300c-475f-ac65-0480534e2832	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789174556, "session_id": "e4bd88b2-8624-4549-8a57-4dc4c65a1d45", "session_exp": 1799542556}	2026-10-12 01:58:27.308038+00	2026-09-12 01:58:27.308038+00	{}	2026-09-12 01:57:57.308038+00	OPAQUE	REFRESH_TOKEN	Pqfda5bhAHidB7YjCiAsjvj5tkoJKwZGMzM2I4N2MtMzk5NC00NDQ4LWI5NDUtMzU3MzllMzg2ZmE4
38442cb8-b5f0-4438-8bb1-1dbbd61246ec	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789174556, "session_id": "e4bd88b2-8624-4549-8a57-4dc4c65a1d45", "session_exp": 1799542556}	2026-10-12 01:58:28.126396+00	2026-09-12 01:58:28.126396+00	{}	2026-09-12 01:57:58.126396+00	OPAQUE	REFRESH_TOKEN	C5AIwv1vpEeXX8hCE3RJZqo1I769gwOGU2MDU0MTYtNGY0MS00OTVlLThmMDEtNTkxZGY0ZGJmZjI2
b87182bf-8a4b-486e-991d-07fe84193b2f	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789174556, "session_id": "e4bd88b2-8624-4549-8a57-4dc4c65a1d45", "session_exp": 1799542556}	2026-10-12 02:09:50.257257+00	2026-09-12 02:09:50.257257+00	{}	2026-09-12 02:09:20.257257+00	OPAQUE	REFRESH_TOKEN	X5kYajBk1mkPMnrmV6vEHnO7wmPfQgMjcxM2NjZTQtOGZlYi00NTgwLTliZjQtYzBjNDM2M2ExNTFj
7797bf51-69fd-446a-bdf3-6031ed5b1ff0	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789174556, "session_id": "e4bd88b2-8624-4549-8a57-4dc4c65a1d45", "session_exp": 1799542556}	2026-10-12 02:16:18.875622+00	2026-09-12 02:16:18.875622+00	{}	2026-09-12 02:15:48.875622+00	OPAQUE	REFRESH_TOKEN	TUM7rgdxGtOcILuLyRQDk4xk-6SZywYmViOTJhMjgtZGRjOS00ZWU3LTk2ZGYtY2VjMWI0MzUzZDJj
117da80a-1f12-4fa8-a017-20481001d710	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789174556, "session_id": "e4bd88b2-8624-4549-8a57-4dc4c65a1d45", "session_exp": 1799542556}	2026-10-12 02:16:19.591855+00	2026-09-12 02:16:19.591855+00	{}	2026-09-12 02:15:49.591855+00	OPAQUE	REFRESH_TOKEN	QnQADlCU5knwBM27jLh1uglGXxVmpgODMyMTcwMWItOWU2Ny00ZTI5LWJlZTQtOGRkYWFkYTQwZGNk
e4fdfd90-71c2-4f95-a72f-8d951f87a8b7	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789174556, "session_id": "e4bd88b2-8624-4549-8a57-4dc4c65a1d45", "session_exp": 1799542556}	2026-10-12 02:31:46.471565+00	2026-09-12 02:31:46.471565+00	{}	2026-09-12 02:31:16.471565+00	OPAQUE	REFRESH_TOKEN	dAKxG3he_-eL89WRzPllO91HJk5MmAYmEwZDJjMmQtYjliNy00ODhhLTkzNmMtNjQ0YjRjZjY1YzYx
a07b4c42-15a3-43eb-be00-51dfdedb3fb4	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789174556, "session_id": "e4bd88b2-8624-4549-8a57-4dc4c65a1d45", "session_exp": 1799542556}	2026-10-12 02:31:46.76476+00	2026-09-12 02:31:46.76476+00	{}	2026-09-12 02:31:16.76476+00	OPAQUE	REFRESH_TOKEN	mqTnhCunf0jxXM5Xg-ySQG4RABgUeAY2Q3YzYxOWQtZDIzZi00ZDAyLTg3NzYtNjNhODdlN2VmN2Ez
27ae7dd3-b6f0-41e5-bb1f-e7d8ea76bceb	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789174556, "session_id": "e4bd88b2-8624-4549-8a57-4dc4c65a1d45", "session_exp": 1799542556}	2026-10-12 02:31:47.552065+00	2026-09-12 02:31:47.552065+00	{}	2026-09-12 02:31:17.552065+00	OPAQUE	REFRESH_TOKEN	fmJDbOLIL7U3hSHXf-wpKlJP9ZUm7wZmE5NDlkZTUtYzhmYy00NzM3LWFiYmEtNTQxMjEzNTQ0ODUx
853b8e5e-fc0c-4578-9cd3-f4faf5aae214	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789174556, "session_id": "e4bd88b2-8624-4549-8a57-4dc4c65a1d45", "session_exp": 1799542556}	2026-10-12 02:31:49.355049+00	2026-09-12 02:31:49.355049+00	{}	2026-09-12 02:31:19.355049+00	OPAQUE	REFRESH_TOKEN	lpo3ZU7yGdS8MwluQeWI2l1je4ooYQYTdmMTk0MzgtNGJjNC00NWNmLWJiZTUtOGM2NWJmYjZlMjJi
3fb26193-0fc1-46cd-ba71-72b0f39a0630	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789174556, "session_id": "e4bd88b2-8624-4549-8a57-4dc4c65a1d45", "session_exp": 1799542556}	2026-10-12 02:31:49.988151+00	2026-09-12 02:31:49.988151+00	{}	2026-09-12 02:31:19.988151+00	OPAQUE	REFRESH_TOKEN	8PNmf1zD7WxDvINRDIVfEF1x5CpApgMDA3YjA0NzctZWFjYi00YzFmLWE1ZTktYjhmNTFiNWIwMzNm
30a2aa20-ec5a-462e-bc38-663bfcd90a97	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789174556, "session_id": "e4bd88b2-8624-4549-8a57-4dc4c65a1d45", "session_exp": 1799542556}	2026-10-12 02:44:42.503077+00	2026-09-12 02:44:42.503077+00	{}	2026-09-12 02:44:12.503077+00	OPAQUE	REFRESH_TOKEN	sc-uCp-FNBjfDY1WvxnK8EqjkURWJAMDBmYmZjYzQtOTViZS00ZmZkLTgyNWEtNDc2YzY5NTUwYzhh
dcd1541c-fa85-4f3c-b8cb-36465b66dcb5	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789174556, "session_id": "e4bd88b2-8624-4549-8a57-4dc4c65a1d45", "session_exp": 1799542556}	2026-10-12 02:44:43.256685+00	2026-09-12 02:44:43.256685+00	{}	2026-09-12 02:44:13.256685+00	OPAQUE	REFRESH_TOKEN	6hPX0t8QZy_rDeQDjKAELwckOi7oygMjE0MzQzMmQtNjAzMS00OGQxLTk2MTItYjc5OGQ0ZWYxODEx
5b0cbd34-838e-4474-be95-d553b3f69a4d	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789174556, "session_id": "e4bd88b2-8624-4549-8a57-4dc4c65a1d45", "session_exp": 1799542556}	2026-10-12 02:56:05.609848+00	2026-09-12 02:56:05.609848+00	{}	2026-09-12 02:55:35.609848+00	OPAQUE	REFRESH_TOKEN	B8NJN8Lw_Uscm24etcoRQD62JPqztQMWZkNjcyODMtZWQ0My00ZjRhLTkyZjYtNjdjZWU5ODMwY2Mz
45bdeac6-eb89-4342-96dc-098b3836b470	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789174556, "session_id": "e4bd88b2-8624-4549-8a57-4dc4c65a1d45", "session_exp": 1799542556}	2026-10-12 03:27:59.285585+00	2026-09-12 03:27:59.285585+00	{}	2026-09-12 03:27:29.285585+00	OPAQUE	REFRESH_TOKEN	orxca6bGZRCOE5ZQmIUH57ngQEpK7wYTc5NjlmZWEtNzBjZS00MWQ0LTk0NjAtZDE5YTUwNjA1MTlj
211bd2c2-cef4-4ef5-a6bb-6d0ad3a45c01	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789174556, "session_id": "e4bd88b2-8624-4549-8a57-4dc4c65a1d45", "session_exp": 1799542556}	2026-10-12 03:28:14.427362+00	2026-09-12 03:28:14.427362+00	{}	2026-09-12 03:27:44.427362+00	OPAQUE	REFRESH_TOKEN	h1Vq_gycuAcR_gGzEPb-W0E3mr83lQNjc1OTdhMjUtNTk2NC00YTRkLWFmNDYtYzMxYTE1MjU5MzRj
c1c79938-a19e-4200-bbed-9a68c6946748	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789174556, "session_id": "e4bd88b2-8624-4549-8a57-4dc4c65a1d45", "session_exp": 1799542556}	2026-10-12 08:24:08.806008+00	2026-09-12 08:24:08.806008+00	{}	2026-09-12 08:23:38.806008+00	OPAQUE	REFRESH_TOKEN	YaENdcIz6G7IgxFwtd39AjW_D0FyAAZGNhMTE1NTAtYjYyMC00Yzc2LTg1MzMtOTZmMmU3MTEzMWI4
86f15713-1aa5-4ec9-9920-525681b55e6b	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789174556, "session_id": "e4bd88b2-8624-4549-8a57-4dc4c65a1d45", "session_exp": 1799542556}	2026-10-12 08:24:09.135531+00	2026-09-12 08:24:09.135531+00	{}	2026-09-12 08:23:39.135531+00	OPAQUE	REFRESH_TOKEN	cCDlyEdOsC9L1NnL26OSIX_yEKAiFQM2I1ZmI4MmYtZTIxZS00NTQzLWI5NDAtM2RmZTM1YWQ4MDA1
8e7175ac-e22a-4bcc-9de9-ff46894dc7fb	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789174556, "session_id": "e4bd88b2-8624-4549-8a57-4dc4c65a1d45", "session_exp": 1799542556}	2026-10-12 08:24:09.706435+00	2026-09-12 08:24:09.706435+00	{}	2026-09-12 08:23:39.706435+00	OPAQUE	REFRESH_TOKEN	Mzf3g3XHvYvb0rxO9pWSLaC-hpTfMQNTkwNzg2M2UtNzVkZS00OTI5LWIxM2MtMjE1YzFkOTQ2MjQ2
75c1629c-5565-446a-9457-bddd5aa7e6eb	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789174556, "session_id": "e4bd88b2-8624-4549-8a57-4dc4c65a1d45", "session_exp": 1799542556}	2026-10-12 08:26:14.437394+00	2026-09-12 08:26:14.437394+00	{}	2026-09-12 08:25:44.437394+00	OPAQUE	REFRESH_TOKEN	dysR5cn9smyIZwCH-R74iXud4Dv3hgNzllMzMwM2QtMjA5Ny00MmRjLTlhZjktNTUyYzM5MDRiNTc3
4c229367-96aa-4eb5-91aa-3bdbec2ee9d1	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789174556, "session_id": "e4bd88b2-8624-4549-8a57-4dc4c65a1d45", "session_exp": 1799542556}	2026-10-12 08:36:48.921103+00	2026-09-12 08:36:48.921103+00	{}	2026-09-12 08:36:18.921103+00	OPAQUE	REFRESH_TOKEN	WSH9BEbmbFdOCmBBNdW4-YYdbTFX9QNjI3M2MxYTMtYWJjNy00MzZiLTk0N2YtZThlMDIxMWYyM2Iy
f208baa5-e930-42b4-a1dd-76a85586d463	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789174556, "session_id": "e4bd88b2-8624-4549-8a57-4dc4c65a1d45", "session_exp": 1799542556}	2026-10-12 08:36:49.791568+00	2026-09-12 08:36:49.791568+00	{}	2026-09-12 08:36:19.791568+00	OPAQUE	REFRESH_TOKEN	_1TgDI8KUodrdYY6O-CW5128RxyUUwMzc1NTliOTItZTI5OC00MzZmLTlhNTItMmI1MWVjYzk5Y2Vj
8cf6b264-5678-4f00-969d-3706a2e89546	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789174556, "session_id": "e4bd88b2-8624-4549-8a57-4dc4c65a1d45", "session_exp": 1799542556}	2026-10-12 08:42:26.420538+00	2026-09-12 08:42:26.420538+00	{}	2026-09-12 08:41:56.420538+00	OPAQUE	REFRESH_TOKEN	TJVs3fQ4KNnacAoxtIaKqk8Hp-6MLAYmUwNGM1NDQtMTI1ZC00ZTgyLWJkZmMtMmFhYzhhYzYwNWQ2
478a0f58-6a9c-42c1-940e-825dd9930196	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789174556, "session_id": "e4bd88b2-8624-4549-8a57-4dc4c65a1d45", "session_exp": 1799542556}	2026-10-12 08:42:26.715997+00	2026-09-12 08:42:26.715997+00	{}	2026-09-12 08:41:56.715997+00	OPAQUE	REFRESH_TOKEN	zmzvTnPliBV-NX2A1O_pg0JCuc6wdAYjkzYmNiMTEtZDA5Ni00ZDNhLTliZTMtZDQ2MTdmZWU3OWI4
dc86be3b-89ce-4bb9-9a58-37333d053821	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789174556, "session_id": "e4bd88b2-8624-4549-8a57-4dc4c65a1d45", "session_exp": 1799542556}	2026-10-12 08:42:27.508977+00	2026-09-12 08:42:27.508977+00	{}	2026-09-12 08:41:57.508977+00	OPAQUE	REFRESH_TOKEN	2-djbd8cWw-Hs1j8_OWzw_nLrQCGhwNjNmMTM1ZTItMjYyNC00OTJlLWFhZWUtNjc4NzNiNzkzZTJi
30438cf3-dd6a-4c99-8b8c-b0849e3404a5	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789174556, "session_id": "e4bd88b2-8624-4549-8a57-4dc4c65a1d45", "session_exp": 1799542556}	2026-10-12 08:42:47.025759+00	2026-09-12 08:42:47.025759+00	{}	2026-09-12 08:42:17.025759+00	OPAQUE	REFRESH_TOKEN	KJ0VTejUNNAkUWJr4Wnd84VMIGT9YgNTdhNzc3YmItZWQ0NC00ZDQ4LTk0NzctOTc5ZTVlYWY0MGRl
2ad8d1f5-8496-4050-90ac-41c9f1207deb	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789174556, "session_id": "e4bd88b2-8624-4549-8a57-4dc4c65a1d45", "session_exp": 1799542556}	2026-10-12 08:44:33.83666+00	2026-09-12 08:44:33.83666+00	{}	2026-09-12 08:44:03.83666+00	OPAQUE	REFRESH_TOKEN	4rIAf7iDeLHbOFDUvL1DB4ilEP_9PQY2U5MjNmMTUtYTYyNS00NDJmLTgwZTItNzQ2MmI4NWI0M2Jj
4f308820-6ea3-44fd-b73e-1e3e331a782f	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789174556, "session_id": "e4bd88b2-8624-4549-8a57-4dc4c65a1d45", "session_exp": 1799542556}	2026-10-12 08:50:19.307227+00	2026-09-12 08:50:19.307227+00	{}	2026-09-12 08:49:49.307227+00	OPAQUE	REFRESH_TOKEN	LyGBpWigVbCmHvvgGC1YsERz2AKQSANDkyZTQ5NzItM2E2ZS00ODM0LWJlZmItYTNkYmUwMzNhYTUy
29ad2d55-88c3-4d9c-8fa6-eefc638d2780	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789174556, "session_id": "e4bd88b2-8624-4549-8a57-4dc4c65a1d45", "session_exp": 1799542556}	2026-10-12 08:52:00.118208+00	2026-09-12 08:52:00.118208+00	{}	2026-09-12 08:51:30.118208+00	OPAQUE	REFRESH_TOKEN	SqbXNkMWzZHzu6ZJxCd4ufYL2s97GAM2EzM2UzMjMtMmYxOS00Yzg1LTg4MDgtMDM0MDA3YTk1ZDc5
9a49dab4-abd5-4c59-b418-6ecb8e0a0c88	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789174556, "session_id": "e4bd88b2-8624-4549-8a57-4dc4c65a1d45", "session_exp": 1799542556}	2026-10-12 08:57:50.529653+00	2026-09-12 08:57:50.529653+00	{}	2026-09-12 08:57:20.529653+00	OPAQUE	REFRESH_TOKEN	QxLyBxLbkdOMOQYOpSPf7YhMwNN3xAM2JkNTBjYzItZWI3Ny00ODVjLWEwMzAtZDFlYmMwODc2NDhj
d70a114f-62b5-4357-895d-dd66d998b540	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789174556, "session_id": "e4bd88b2-8624-4549-8a57-4dc4c65a1d45", "session_exp": 1799542556}	2026-10-12 08:58:11.244148+00	2026-09-12 08:58:11.244148+00	{}	2026-09-12 08:57:41.244148+00	OPAQUE	REFRESH_TOKEN	W6vNPdL6t1GdeQ1SdXzOp7CQQI3dhAY2IyNTc0ZTctMjY1Ny00NDQyLWJmOGYtY2QxNTUxMTA0NGJm
61bd7690-e01a-492a-a6c5-edaa6dc840e6	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789174556, "session_id": "e4bd88b2-8624-4549-8a57-4dc4c65a1d45", "session_exp": 1799542556}	2026-10-12 09:01:04.980957+00	2026-09-12 09:01:04.980957+00	{}	2026-09-12 09:00:34.980957+00	OPAQUE	REFRESH_TOKEN	uJL4Z_njhkdoppNh4RYr40vXLQK7PAMjNkYjg0YzMtNjIxMy00NmU2LWI1ZTQtMmJlOTcwYzEzNzUx
2ac423c6-37ab-448b-8632-553f24e2350d	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789174556, "session_id": "e4bd88b2-8624-4549-8a57-4dc4c65a1d45", "session_exp": 1799542556}	2026-10-12 09:06:08.407333+00	2026-09-12 09:06:08.407333+00	{}	2026-09-12 09:05:38.407333+00	OPAQUE	REFRESH_TOKEN	QExJr_QaTOwgHpGkDvhkSn4kLXv0tQMmQwMTI2MzEtNzhlYS00OGFmLTlmM2EtN2FkOWNmY2Q2ZDRm
a44cda99-e702-4611-a96c-f1c30f85ed26	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789174556, "session_id": "e4bd88b2-8624-4549-8a57-4dc4c65a1d45", "session_exp": 1799542556}	2026-10-12 09:06:09.577169+00	2026-09-12 09:06:09.577169+00	{}	2026-09-12 09:05:39.577169+00	OPAQUE	REFRESH_TOKEN	ZPns6Lzpjy6bh21IHlj0UncgYqgQgANjZjYTQzYmQtOTZkOS00MWQ2LTgxOTItNzdiODkzOGE5NGY3
5f141f5a-3af3-4a71-af72-02f6ae0589dc	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789174556, "session_id": "e4bd88b2-8624-4549-8a57-4dc4c65a1d45", "session_exp": 1799542556}	2026-10-12 09:07:16.285655+00	2026-09-12 09:07:16.285655+00	{}	2026-09-12 09:06:46.285655+00	OPAQUE	REFRESH_TOKEN	rFxs3jdalGrrG_-oHlalBsnQbkBHnQODRkNGEwZDEtZDZmMi00YWExLThiODctOTVlZjI1M2FjYzI3
279ff9fd-df29-4c28-90cd-fcb8516aac9a	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789174556, "session_id": "e4bd88b2-8624-4549-8a57-4dc4c65a1d45", "session_exp": 1799542556}	2026-10-12 09:09:25.723104+00	2026-09-12 09:09:25.723104+00	{}	2026-09-12 09:08:55.723104+00	OPAQUE	REFRESH_TOKEN	vVCevUsjaYWtt3Ivg5-Mw02X50pXKgNWJjZjNiYzEtYjQ3My00Y2RlLTg1MGQtMTk1MWI5NWYzZjY4
725a139f-e832-44a8-9212-e04bdef57330	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789174556, "session_id": "e4bd88b2-8624-4549-8a57-4dc4c65a1d45", "session_exp": 1799542556}	2026-10-12 09:14:32.599145+00	2026-09-12 09:14:32.599145+00	{}	2026-09-12 09:14:02.599145+00	OPAQUE	REFRESH_TOKEN	gh3ALLKXKwhh44bxL-K5YfzsBUADTgY2Q2YmI0NzEtMGJlMC00MjZkLTkwZDAtZjI5NmE1N2YzOTE0
e19c8a8f-5d95-4f80-b08f-717c684245cb	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789174556, "session_id": "e4bd88b2-8624-4549-8a57-4dc4c65a1d45", "session_exp": 1799542556}	2026-10-12 09:14:33.493417+00	2026-09-12 09:14:33.493417+00	{}	2026-09-12 09:14:03.493417+00	OPAQUE	REFRESH_TOKEN	JNifa-p5iZwqbCpZTIhep2YRlxTbsQMTNjMWVhZjMtZjhlYS00ZjllLTkyYWEtM2MwODk0M2IwYjBi
b37ab3fe-bc06-4993-ac13-ccd33feb8b37	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789174556, "session_id": "e4bd88b2-8624-4549-8a57-4dc4c65a1d45", "session_exp": 1799542556}	2026-10-12 09:17:24.997609+00	2026-09-12 09:17:24.997609+00	{}	2026-09-12 09:16:54.997609+00	OPAQUE	REFRESH_TOKEN	2DjcIossdJ3En4NTP7YjNoXK7ayaNwYzE3MWY3ZDEtZGNmYy00MTRjLTgzYmItNmU5NWMxYjgxYjg0
9c155fe3-9457-4d92-87b2-513b95f7176b	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789174556, "session_id": "e4bd88b2-8624-4549-8a57-4dc4c65a1d45", "session_exp": 1799542556}	2026-10-12 09:21:13.753057+00	2026-09-12 09:21:13.753057+00	{}	2026-09-12 09:20:43.753057+00	OPAQUE	REFRESH_TOKEN	FGIphA_zh8aJ13NLHw7INwyaOH71bQZDRlNDgyYWYtMGU3MC00MWI4LTg5MjYtMGI5NGM1MjEyOTk4
e5b54836-caf4-447b-825e-b10d90abd48a	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789174556, "session_id": "e4bd88b2-8624-4549-8a57-4dc4c65a1d45", "session_exp": 1799542556}	2026-10-12 09:26:52.010351+00	2026-09-12 09:26:52.010351+00	{}	2026-09-12 09:26:22.010351+00	OPAQUE	REFRESH_TOKEN	i5gOIukN07J7438cqyEhRN9aRUV0ZgNWFmNWExYWUtNDY0ZS00YzQwLWEzYmEtZDIwMGMxZTI3ZjI0
d6c962e1-0074-4d16-8acd-8ed9326b79d4	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789174556, "session_id": "e4bd88b2-8624-4549-8a57-4dc4c65a1d45", "session_exp": 1799542556}	2026-10-12 09:34:56.02627+00	2026-09-12 09:34:56.02627+00	{}	2026-09-12 09:34:26.02627+00	OPAQUE	REFRESH_TOKEN	MId0kr0X2AtJikbd8aaGxmoDwwvZTgNjEzNWNkY2MtMjRiZS00OWYxLThjNGMtMjY4YWUxODIzMmJl
4ecbd217-34c1-4fc9-bdb7-b3318db40911	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789174556, "session_id": "e4bd88b2-8624-4549-8a57-4dc4c65a1d45", "session_exp": 1799542556}	2026-10-12 09:34:56.328274+00	2026-09-12 09:34:56.328274+00	{}	2026-09-12 09:34:26.328274+00	OPAQUE	REFRESH_TOKEN	amb1jS61gUpqwrlVUNjPn3bjizycEAOTFiYmEzOGQtNTEyNC00MGNiLTg4YzctYmI0ZmUxNzlhNWU4
2ae17b77-7327-440a-809e-e1883a5ce2ac	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789174556, "session_id": "e4bd88b2-8624-4549-8a57-4dc4c65a1d45", "session_exp": 1799542556}	2026-10-12 09:34:57.146879+00	2026-09-12 09:34:57.146879+00	{}	2026-09-12 09:34:27.146879+00	OPAQUE	REFRESH_TOKEN	ahFHD3T-bIck2fp441cLMZawpEVpvwYjJlN2FiN2YtZDMxYy00YTE0LTgxNjgtZTgxNmM0ZmJhZjM3
00330b8f-4508-4527-b38c-ccac44f5d2ea	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789174556, "session_id": "e4bd88b2-8624-4549-8a57-4dc4c65a1d45", "session_exp": 1799542556}	2026-10-12 09:49:08.421256+00	2026-09-12 09:49:08.421256+00	{}	2026-09-12 09:48:38.421256+00	OPAQUE	REFRESH_TOKEN	70CyhzX0F7WGda3xcsvFFQbrRLZ7uQZDcxZjUxYjctOTllMC00OTU1LWIwYTktOGUwNWI3OWVhMjE4
78830fd0-2dab-4517-9f51-857145ec6f20	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789174556, "session_id": "e4bd88b2-8624-4549-8a57-4dc4c65a1d45", "session_exp": 1799542556}	2026-10-12 09:49:08.737567+00	2026-09-12 09:49:08.737567+00	{}	2026-09-12 09:48:38.737567+00	OPAQUE	REFRESH_TOKEN	Sw246tsWqC5ZR1MmGIEOZYq7kOW72wZTA3OTg5ZjctYjJkYi00OGIwLWJiOTktMzUyNTFkMjBhOThk
d3b92870-197c-4ac3-b116-8f070bc85e3b	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789174556, "session_id": "e4bd88b2-8624-4549-8a57-4dc4c65a1d45", "session_exp": 1799542556}	2026-10-12 09:49:09.307463+00	2026-09-12 09:49:09.307463+00	{}	2026-09-12 09:48:39.307463+00	OPAQUE	REFRESH_TOKEN	38vs3LZBOa4HMZtzZ4xjPqbNOC0OsQMGVjN2NiZmItMTkxYS00ZmIxLWFjMTgtNjRkMjhlZWE2Y2Rj
7cbc3ef2-ea11-4968-a74b-5a48b3be006e	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789206742, "session_id": "db2a5fa7-50e0-4b7d-a4bf-13c4954e2f3b", "session_exp": 1799574742}	2026-10-12 09:52:22.824602+00	2026-09-12 09:52:22.824602+00	{}	2026-09-12 09:51:52.824602+00	OPAQUE	REFRESH_TOKEN	gfmAr4RkHwIhsrV-k6K37hhyWh2-oQNDY5NjdkMTAtMmI0Ni00MTE4LWFmYTUtMmJjZDg5NGUwZmMy
5be2235d-5319-4122-a442-3e918425f8d3	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789206742, "session_id": "db2a5fa7-50e0-4b7d-a4bf-13c4954e2f3b", "session_exp": 1799574742}	2026-10-12 09:52:25.908707+00	2026-09-12 09:52:25.908707+00	{}	2026-09-12 09:51:55.908707+00	OPAQUE	REFRESH_TOKEN	XeMtTTeiLVQfb4nwGjf77VK1LYJDEQYjhjMGY3MDktYzY5Mi00NjY2LTg4N2QtN2VkMDQ0YWI4ZjVi
e2465306-9ee4-40c1-af48-ac560089c13e	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789207006, "session_id": "51a72811-7b38-488f-af37-8f3e94398ba6", "session_exp": 1799575006}	2026-10-12 09:56:46.666977+00	2026-09-12 09:56:46.666977+00	{}	2026-09-12 09:56:16.666977+00	OPAQUE	REFRESH_TOKEN	_QCQGs-zX_Z4opkGw5EXNl6G5X4BPwMTUwMmFmZWMtZmEyOS00NWY5LWJiNDAtODc1NzYxMWJkMjA5
1bdd5dfc-0325-4e11-8c28-d33583c83093	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789207006, "session_id": "51a72811-7b38-488f-af37-8f3e94398ba6", "session_exp": 1799575006}	2026-10-12 09:56:48.873092+00	2026-09-12 09:56:48.873092+00	{}	2026-09-12 09:56:18.873092+00	OPAQUE	REFRESH_TOKEN	Y9Erd9mc9X5zCuJvHe5OLnQTEBr4JgZTdhZTk2YjMtMDIzMi00ZDU5LTk0YTAtOTE5MjkzODE2MTJi
7f98608d-2022-4d31-8265-1f30d9b44a3d	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789207006, "session_id": "51a72811-7b38-488f-af37-8f3e94398ba6", "session_exp": 1799575006}	2026-10-12 09:57:08.457909+00	2026-09-12 09:57:08.457909+00	{}	2026-09-12 09:56:38.457909+00	OPAQUE	REFRESH_TOKEN	GFBDc71KaIf06bIA2l--hJH3uDDZ0wZWZjYTkwNmUtZjUwMS00NTJkLTlmNDYtOGNiYjExNzYxY2Q3
2992cc91-919d-4719-a2f4-3b3b90bfd14d	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789207006, "session_id": "51a72811-7b38-488f-af37-8f3e94398ba6", "session_exp": 1799575006}	2026-10-12 09:58:24.084295+00	2026-09-12 09:58:24.084295+00	{}	2026-09-12 09:57:54.084295+00	OPAQUE	REFRESH_TOKEN	9wqLMIHo8PZHYqBo128ZO07ix6OsqgMGZkNDUyNWEtNDNjNS00YWE0LTgzMTgtM2U1NDhiYmI5Zjgw
81a1560f-9bb0-4174-92a0-832b0185c677	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789207006, "session_id": "51a72811-7b38-488f-af37-8f3e94398ba6", "session_exp": 1799575006}	2026-10-12 09:58:33.618688+00	2026-09-12 09:58:33.618688+00	{}	2026-09-12 09:58:03.618688+00	OPAQUE	REFRESH_TOKEN	4RAnaLlpmdgYQrZUZd8va4idQ8WhcQNTJkOWU4ZGQtY2Y2My00OWNjLWE5YjAtYzcxY2ZmMTBlNTE5
33205cde-a025-48e2-9d5a-de392dc1390f	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789207006, "session_id": "51a72811-7b38-488f-af37-8f3e94398ba6", "session_exp": 1799575006}	2026-10-12 10:05:26.120011+00	2026-09-12 10:05:26.120011+00	{}	2026-09-12 10:04:56.120011+00	OPAQUE	REFRESH_TOKEN	DURmpTlB64pzDj1WtzEkDAJ3YUv01gYTFlYTMxODYtZDJmZC00Yjg0LTg4NmItMzNlNDczOTk4Y2Yy
0755502e-7a54-4c6f-a35b-69c6075c56b4	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789207006, "session_id": "51a72811-7b38-488f-af37-8f3e94398ba6", "session_exp": 1799575006}	2026-10-12 10:05:26.975459+00	2026-09-12 10:05:26.975459+00	{}	2026-09-12 10:04:56.975459+00	OPAQUE	REFRESH_TOKEN	uxiY_k4YQdyXJlGdmFYqp2p-N8L1bAZGE5MDYwNWEtMzIyMC00YmVmLWI5OTMtZmUwYjE0Yzk4NzAy
5b362157-d28d-4ac4-9f1f-a574d7fd9151	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789207006, "session_id": "51a72811-7b38-488f-af37-8f3e94398ba6", "session_exp": 1799575006}	2026-10-12 10:12:29.9352+00	2026-09-12 10:12:29.9352+00	{}	2026-09-12 10:11:59.9352+00	OPAQUE	REFRESH_TOKEN	G0B4gNwrHsMW3DcCbzvW-VK3JKFUyAMTNkOGViZjYtZjcyNC00ZjhjLTlmMDYtNmUyN2VjNjdkYmEx
4fb7ed75-4c41-44c9-a404-05ce51a181d2	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789207006, "session_id": "51a72811-7b38-488f-af37-8f3e94398ba6", "session_exp": 1799575006}	2026-10-12 10:12:30.990024+00	2026-09-12 10:12:30.990024+00	{}	2026-09-12 10:12:00.990024+00	OPAQUE	REFRESH_TOKEN	_c2j8q32uifICzBI8FGgZNMzUwf1wQYmViZTkxYjgtOTVmOC00NjcxLWJiZDEtOTA2YTgyMWY1NGU4
b5e61ca0-abc4-43f3-81a3-d5bb22bb790f	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789207006, "session_id": "51a72811-7b38-488f-af37-8f3e94398ba6", "session_exp": 1799575006}	2026-10-12 10:18:40.237279+00	2026-09-12 10:18:40.237279+00	{}	2026-09-12 10:18:10.237279+00	OPAQUE	REFRESH_TOKEN	q_emVqKP0_BRLD4Oqd-vr6yVHEtCyQMDA2MGU5OWItYWY2Zi00ZTg4LWE0ZGItNzc2YzkzZjVkMzM1
41ab2e3e-d0b4-498c-8022-144e0cb59bea	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789207006, "session_id": "51a72811-7b38-488f-af37-8f3e94398ba6", "session_exp": 1799575006}	2026-10-12 10:18:40.523816+00	2026-09-12 10:18:40.523816+00	{}	2026-09-12 10:18:10.523816+00	OPAQUE	REFRESH_TOKEN	02JY4zNK4DZaO_k8-ZZbXxCV7uHU9QMWY4MjU5ZTEtNTc3Yi00MDhiLWFlMmQtMmQ1OGM3NzEwNTY3
02d7f3de-bb4a-4ef7-9993-6b2407a78e4e	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789207006, "session_id": "51a72811-7b38-488f-af37-8f3e94398ba6", "session_exp": 1799575006}	2026-10-12 10:18:40.841263+00	2026-09-12 10:18:40.841263+00	{}	2026-09-12 10:18:10.841263+00	OPAQUE	REFRESH_TOKEN	knPE2c4g0npnQTMltr656JwbBDIfYwYmQ5ZDVlMjEtMzA2NC00ZGY2LTlhODMtYjVjMjQzZjdiMjRm
6edf7027-b1cb-41ce-b477-dec2b55a5b39	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789207006, "session_id": "51a72811-7b38-488f-af37-8f3e94398ba6", "session_exp": 1799575006}	2026-10-12 10:18:41.19082+00	2026-09-12 10:18:41.19082+00	{}	2026-09-12 10:18:11.19082+00	OPAQUE	REFRESH_TOKEN	b2M_Ymm44fTsUx_4Rv_Izyy1cE6MdQMmU3ZjI1OTItMDA4Yi00NjlhLTk4ZDUtOTg5MWRjNGJhYzQ1
92a4cee1-c4f6-4ae3-a0ee-e6d7114ce7c7	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789207006, "session_id": "51a72811-7b38-488f-af37-8f3e94398ba6", "session_exp": 1799575006}	2026-10-12 10:37:42.873556+00	2026-09-12 10:37:42.873556+00	{}	2026-09-12 10:37:12.873556+00	OPAQUE	REFRESH_TOKEN	qc_Jk7BGaJzcxLfbTJtxyFAEL69ISANWZkMmVhNDMtMzMxMy00NDE4LTlhNWMtMzdjYmU3MjQ0MjVk
43303fae-0537-4362-9ccc-e9109e37e4fe	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789207006, "session_id": "51a72811-7b38-488f-af37-8f3e94398ba6", "session_exp": 1799575006}	2026-10-12 10:37:43.173764+00	2026-09-12 10:37:43.173764+00	{}	2026-09-12 10:37:13.173764+00	OPAQUE	REFRESH_TOKEN	y1uIyVel7xxIdvoH2GPeBTrC4Ax7zQMzFiMmQ3YTktOWE1NC00YjIwLWI2MjEtMjQzMjc2MDI5MzBm
e8122b4f-d376-46ba-b5e6-d432ad7867a8	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789207006, "session_id": "51a72811-7b38-488f-af37-8f3e94398ba6", "session_exp": 1799575006}	2026-10-12 10:37:43.443532+00	2026-09-12 10:37:43.443532+00	{}	2026-09-12 10:37:13.443532+00	OPAQUE	REFRESH_TOKEN	Ai_lwHaa54J2iIsscybYDYgAZwyBDQYjQyZjg3MzEtNDY1OC00ZTNmLTkwYWEtNzQzZTdlZTlhZjZl
0d172c3d-3b79-4b6e-86ca-8beb24c61346	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789207006, "session_id": "51a72811-7b38-488f-af37-8f3e94398ba6", "session_exp": 1799575006}	2026-10-12 10:37:43.723425+00	2026-09-12 10:37:43.723425+00	{}	2026-09-12 10:37:13.723425+00	OPAQUE	REFRESH_TOKEN	BcxqyifghNQIDnmnzgRNkSiqtVfu_gZGI1NjYzOTAtOTU1YS00YTRmLWI3NTMtMzU0OTc5YTQ1NDEw
0f3ccbbb-46d9-4177-bda3-59a5f599669e	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789207006, "session_id": "51a72811-7b38-488f-af37-8f3e94398ba6", "session_exp": 1799575006}	2026-10-12 10:37:44.594293+00	2026-09-12 10:37:44.594293+00	{}	2026-09-12 10:37:14.594293+00	OPAQUE	REFRESH_TOKEN	lkv283Tmi18Ng_IMtSmXFsvLoo6E_wOGFjZmI1MjQtOTg5Yi00ZWQxLTg1NTMtNWI3MzRjY2U3MmFm
08dcbe11-35e0-4ff5-9d8e-5403dcb235cf	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789207006, "session_id": "51a72811-7b38-488f-af37-8f3e94398ba6", "session_exp": 1799575006}	2026-10-12 10:37:45.834149+00	2026-09-12 10:37:45.834149+00	{}	2026-09-12 10:37:15.834149+00	OPAQUE	REFRESH_TOKEN	1TBYOredx79-Ab7DP9jnRwlrTn53qgZDgzYWYwYTMtYzU3My00ODY0LTk4YmItYzQ0YzdhM2MxNDA1
1a30fa42-3a2a-485e-9486-8adeaec50e2c	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-12 10:38:51.462417+00	2026-09-12 10:38:51.462417+00	{}	2026-09-12 10:38:21.462417+00	OPAQUE	REFRESH_TOKEN	rMW6t-0QMuS-IvUJcap3m26LugqI9wYjI0YTUyYmUtZjY5My00ZTZkLThmMTYtZWM5ODkzMjhmMmU0
3f532d2b-5b72-4e7d-b954-1c4e41240fb7	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-12 10:38:54.191864+00	2026-09-12 10:38:54.191864+00	{}	2026-09-12 10:38:24.191864+00	OPAQUE	REFRESH_TOKEN	os47HPo33kwXFIxR3G_cWJN5f6iV1gNTQ5NzZiZDctNmY0OC00ZWZmLThjMWItMWI5ZWJkYmNmNDRj
6f2bb86a-3d26-4c33-81ed-224b751543e2	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-12 10:44:31.622917+00	2026-09-12 10:44:31.622917+00	{}	2026-09-12 10:44:01.622917+00	OPAQUE	REFRESH_TOKEN	kpvNH2FpgLOrytFMdzGGnG424_TSdAOGE1OTJkN2QtYjJiOS00Nzg2LWFkNmMtMDA3MmU2OTkyNjBm
1e3d9f47-954a-4a95-9a32-c728a4a8905d	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-12 10:44:31.905483+00	2026-09-12 10:44:31.905483+00	{}	2026-09-12 10:44:01.905483+00	OPAQUE	REFRESH_TOKEN	nWuD1Ha9Hib_RU4v43-d_nW49YwUgQMWQ2NGI3MWEtOWM2Mi00MTA4LThkYzEtOGI0MGQyMTMwN2M5
79138288-fc14-49c2-a9fd-8bf77c6aee6f	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-12 10:44:32.189868+00	2026-09-12 10:44:32.189868+00	{}	2026-09-12 10:44:02.189868+00	OPAQUE	REFRESH_TOKEN	Y68FZVEk8A2E8IYVtI2LAnboqjPl7wNzg1MzA4NWUtYTQwNS00OTQ5LTgyNWQtODEwZmUwODBkYWRi
92c50bb0-52d0-435b-8376-3ce80df97718	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-12 10:49:56.976693+00	2026-09-12 10:49:56.976693+00	{}	2026-09-12 10:49:26.976693+00	OPAQUE	REFRESH_TOKEN	pe5QlBpCb7s1yVRlBz22pHFWn7OiSQN2YyZDhhNjEtNGFhMy00YjVhLTk0OTAtYjY4NjQwNGQ4MzU0
bddec3f7-88f0-4312-91ac-9606da35e7a1	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-12 10:55:02.758671+00	2026-09-12 10:55:02.758671+00	{}	2026-09-12 10:54:32.758671+00	OPAQUE	REFRESH_TOKEN	ADk6wgKxJM_GzDJpFGdiIpi0Ax-3_gZDQwNmU4NTQtMzQ1NC00MThiLWFkMjItZjk1YTgxZTM5Y2U3
0cfe4583-ca50-457f-9fcb-279c2d13ea40	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-12 10:55:03.069709+00	2026-09-12 10:55:03.069709+00	{}	2026-09-12 10:54:33.069709+00	OPAQUE	REFRESH_TOKEN	KZjaGZ6ED1u-pb0pre_MPIvUidvbzgZjg1MmI3MjQtMGFhYy00YjAzLWIzNTQtOTY5MjA3YjliY2I4
ab9e57a7-65d6-4d98-837d-01461c6761ea	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-12 10:55:03.374233+00	2026-09-12 10:55:03.374233+00	{}	2026-09-12 10:54:33.374233+00	OPAQUE	REFRESH_TOKEN	gU_2Ck5Xp8FGJGLQRU-PMqjwgYdW6wZjg4MDU4YTktZTYxYi00NjM3LTk1NDMtNmQ5NDAwNDM2Njdm
d2beb33e-2e66-403e-918b-1d9d6daea425	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-12 10:55:03.648972+00	2026-09-12 10:55:03.648972+00	{}	2026-09-12 10:54:33.648972+00	OPAQUE	REFRESH_TOKEN	g2qNfMICqV8gEkeypFpDbOtm6BRhbwYTNkMmQ4NGEtNWEwYS00MjYxLWIyMTItNzliYmFkMjhmYjFi
fde2be99-da6d-43f3-b530-e7d1b1d208fa	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-12 10:57:35.518224+00	2026-09-12 10:57:35.518224+00	{}	2026-09-12 10:57:05.518224+00	OPAQUE	REFRESH_TOKEN	sb6Y9OxYGlqo8tPblCOvTykfE5mgLgMzQ5N2NhNzQtYTI4OS00YjUyLTg5YWMtMTk0YTY0NmE2YjI4
d55ae310-2eb2-4d5a-952a-88c2e5bb6f31	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-12 11:07:38.96124+00	2026-09-12 11:07:38.96124+00	{}	2026-09-12 11:07:08.96124+00	OPAQUE	REFRESH_TOKEN	RNlAUD-ZcV5aTfR7wPkfUQTjKVJ7WgNWExNTgzZGQtZWQ2Zi00ZjlhLTlhYTAtY2U1MmZhMTRmNTFk
e2c759fe-234b-4f2a-a7b9-fc3661ac1ad5	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-12 11:07:43.930809+00	2026-09-12 11:07:43.930809+00	{}	2026-09-12 11:07:13.930809+00	OPAQUE	REFRESH_TOKEN	Uvu62dDHsmJTg2yFg4K9KpsmWaeFRAOWI5ZTNmYjEtMTM3ZC00NzA5LWE2OWQtNDYwNDRkNDUyZjQx
f5339e43-2c6d-498d-ba26-2632df0206a9	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 14:25:59.203046+00	2026-09-12 14:25:59.203046+00	{}	2026-09-12 14:25:29.203046+00	OPAQUE	REFRESH_TOKEN	TkqPLctJGQHI-8OqudlRbkLeN-Cu9AM2NkYjBlOWQtOWUwNi00MTBhLTk1ODctOGRlNjVkYjg1NmFj
dcacc18c-e15d-4d78-a642-10eaff748159	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 14:26:23.489407+00	2026-09-12 14:26:23.489407+00	{}	2026-09-12 14:25:53.489407+00	OPAQUE	REFRESH_TOKEN	SNcnmtUqOH8UrOsGt_I0i7Z-Zj7I9wMGM2ODQwMjItZTJhYi00N2U5LWE3ZGYtZmE5OTA1YzkzZjli
ac96007c-b713-469d-9e14-7ad25c29b95f	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 14:26:31.296547+00	2026-09-12 14:26:31.296547+00	{}	2026-09-12 14:26:01.296547+00	OPAQUE	REFRESH_TOKEN	q5CKbzrSKEyI292vY9u4CJ25-2aNqwODU2N2E1MjUtNDU0MS00Y2ZhLWJjM2EtMzg0Nzc0NTIxNDdk
32de0966-9116-455b-93d8-3c992851c02f	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 14:28:30.047699+00	2026-09-12 14:28:30.047699+00	{}	2026-09-12 14:28:00.047699+00	OPAQUE	REFRESH_TOKEN	z2JGZx452_z7GQ6GF9lPumnhqJiFtgZDRiMGFmOTMtNGE0YS00ZWUxLWFlNTgtN2FlM2U0NTVjNzQw
0cf4bc76-aca5-4819-8615-9b5d5e34b364	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 14:57:25.889689+00	2026-09-12 14:57:25.889689+00	{}	2026-09-12 14:56:55.889689+00	OPAQUE	REFRESH_TOKEN	7GS3u5GOnUdcWxI4FJjt9wr_nM9P6AN2JmZmY2ZTYtMGMxOS00NDIxLWFlNTAtNTQ4ZjM2NjU3NzEy
bceb076d-ab5f-487e-8208-6c68c2c1c1f1	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 14:57:26.082707+00	2026-09-12 14:57:26.082707+00	{}	2026-09-12 14:56:56.082707+00	OPAQUE	REFRESH_TOKEN	fzrga3GUAVocdXE4gBR5tONCDfL3KAM2M1NGY1MWItMTcyMy00YjdkLWI1NGQtMDU5ODM5OTZiYzk2
03ef33bc-75e3-4bb6-a731-2e1b51fc7449	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 14:57:26.27794+00	2026-09-12 14:57:26.27794+00	{}	2026-09-12 14:56:56.27794+00	OPAQUE	REFRESH_TOKEN	UuOQ5rUHJnhNsQ2tI7tfKoA0EroRIgZDdkYWVhNTMtOWRmYS00ZjBiLWI4ZGMtYTY3YjBkMmFmNWRh
56d3aa47-1c28-4bc2-a28e-5e994e64f16c	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 14:57:26.471614+00	2026-09-12 14:57:26.471614+00	{}	2026-09-12 14:56:56.471614+00	OPAQUE	REFRESH_TOKEN	91EYG7tgIZ0P2S5pGJiWRvWnHwhnxwZWRkNTdjNjgtNTkyZi00MGIxLThjYzAtMDVmZTQ3ODkxZDZk
6683ef88-e775-444d-823e-494bdea4d010	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 14:58:04.933445+00	2026-09-12 14:58:04.933445+00	{}	2026-09-12 14:57:34.933445+00	OPAQUE	REFRESH_TOKEN	dY0jxbZK4EmBunVFA_COcgzFW1kz7ANGUyNzMzODUtY2Y4Ny00NmZhLWE5NDEtNmNjMGRlMjA3ODI0
b693d4bb-da6e-4d82-ae66-897f19f96026	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 14:58:44.093374+00	2026-09-12 14:58:44.093374+00	{}	2026-09-12 14:58:14.093374+00	OPAQUE	REFRESH_TOKEN	JcwkIoxVff54xvTfyfMFAbYV3AVmLQNTliZDYzZTctN2JmMS00OWQ3LWFiODQtM2FiMDY4YjQwNTVk
47a5149c-1652-4f9c-9d4b-dca05af996dd	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 14:58:56.627769+00	2026-09-12 14:58:56.627769+00	{}	2026-09-12 14:58:26.627769+00	OPAQUE	REFRESH_TOKEN	ytSb4K-L7yiZUul61abCc33io0riLAODM0Mzc3YjMtMTFkNC00OTVlLTgwODUtZWI5NzI1ZWQ5NGFl
cc75e797-0a5f-4bd8-be98-a8601cac6740	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 15:04:30.815525+00	2026-09-12 15:04:30.815525+00	{}	2026-09-12 15:04:00.815525+00	OPAQUE	REFRESH_TOKEN	ohrCZmKR33u06YUXV0E0agQrl8jMoQNTAwYTcyMjMtZTNkZS00ODc5LWIzODItOTVmMDZhYmZhMzNh
5af23dbd-b12c-4368-90d8-47c03335b195	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 15:04:47.77324+00	2026-09-12 15:04:47.77324+00	{}	2026-09-12 15:04:17.77324+00	OPAQUE	REFRESH_TOKEN	5K23GEOp216TX5O1jQ1BAyUVNHZOPwMmU4ZTM1NTUtNjg1Zi00OTU0LWI1ZTAtNDFhNzdkMjFkNWY2
f65b060e-3c6c-420f-a7eb-857a63662573	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 15:08:31.872807+00	2026-09-12 15:08:31.872807+00	{}	2026-09-12 15:08:01.872807+00	OPAQUE	REFRESH_TOKEN	hrumey7c7oB_hfLKMYQ3KjX3ycca6QMTlmMTczZTgtZTFiMS00YjBiLWE0MDMtNzk1YTc1NGIzZWRl
a4074be4-dd14-49ac-8e44-9bda24a15f85	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 15:13:42.747098+00	2026-09-12 15:13:42.747098+00	{}	2026-09-12 15:13:12.747098+00	OPAQUE	REFRESH_TOKEN	oca9v2a9FXJNWnNM02kiJmJLtHQqwwYTJjNWIzNGQtYjI1Zi00YzFiLWJlMWItMjI5YzRhOTg0MzBl
4b68a42a-f249-4e40-9b31-afadcb63b1e0	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 15:25:04.446894+00	2026-09-12 15:25:04.446894+00	{}	2026-09-12 15:24:34.446894+00	OPAQUE	REFRESH_TOKEN	IydCoKM5H-SwB439ArPewHAHz4z28gYWE1ODkyOWUtOTkwZC00ZDllLWFhNTItMWRjNDAwZWJhZGQ5
6479ebe9-37e2-44c6-b059-f718da7e0f7e	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 15:32:33.644424+00	2026-09-12 15:32:33.644424+00	{}	2026-09-12 15:32:03.644424+00	OPAQUE	REFRESH_TOKEN	Rdhow2kWyyyRawy2CzKQfsTb4zTFGQNmE5Y2FmNmMtNTUwNi00ZjAwLTlmNzEtMzdkNjkzOGEzOGVj
ebcbbd6e-6d48-4a99-83d1-ee5363654b15	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 15:44:29.196858+00	2026-09-12 15:44:29.196858+00	{}	2026-09-12 15:43:59.196858+00	OPAQUE	REFRESH_TOKEN	zfaRWOUihOj1nCK-Tabus8j0G4rekwZjBiMThmMmEtYzZmOS00MTA5LThkMWMtMGNkYmJmN2I1NDVj
fbf84dc4-bc10-441f-b072-8495efa00bf8	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 15:51:16.094182+00	2026-09-12 15:51:16.094182+00	{}	2026-09-12 15:50:46.094182+00	OPAQUE	REFRESH_TOKEN	gcs6a7E5ND1-IvleFXgemni263RaeQMjExNTc0OTctMzBhZS00YzBmLWFmMTgtOTdjOGM3YWJlOTYx
68fe98df-d350-498a-a9b0-5bc2a881e0d6	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 15:51:16.45333+00	2026-09-12 15:51:16.45333+00	{}	2026-09-12 15:50:46.45333+00	OPAQUE	REFRESH_TOKEN	7cglEyXL3AspzEwWkc8Vhqx5VSu_jAZjAyZDczNmMtYjE5My00ZGQ4LWFkMDYtOWFjMmYwZjJkMTA5
1d853b08-a851-4120-8d02-433d3deea4d2	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 16:01:11.350416+00	2026-09-12 16:01:11.350416+00	{}	2026-09-12 16:00:41.350416+00	OPAQUE	REFRESH_TOKEN	Ytk-A3Cp7Z8cfULAJixCrVKxW2QELgNmIyMzU3MzktOGJlZS00MGE1LTg0ODQtYzkzMjNiNDQ0MGIx
c6b4df47-985a-4c4c-aca0-5d9e4a5d57c5	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 16:01:11.72454+00	2026-09-12 16:01:11.72454+00	{}	2026-09-12 16:00:41.72454+00	OPAQUE	REFRESH_TOKEN	KrZ0H7q849zg7POBN3REQMrKHpB4rQZjNlMjU3NDItMjcxZi00NDdiLTk0NTctZWZlMzkxOThkZmRh
c92a0938-77a9-4793-9706-ab037ae23385	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 16:09:00.777258+00	2026-09-12 16:09:00.777258+00	{}	2026-09-12 16:08:30.777258+00	OPAQUE	REFRESH_TOKEN	U-71ZeB6vgIicD9B0icRXRWy3fN-BgMjA2MzY3NTUtMDcyYy00YmJiLTg0OGMtZDVkZDcwZTVkOTJi
60430e81-1d7b-4ce2-8dd7-148bd0f605df	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 16:09:16.30661+00	2026-09-12 16:09:16.30661+00	{}	2026-09-12 16:08:46.30661+00	OPAQUE	REFRESH_TOKEN	h-Vt6w0sETNGxbzNAaUxJxCTe99kwQZGFhNjA4YmItNzlmZC00ZTdkLTg3Y2ItZGZlMTRhNWZjMmIx
6eee7b43-d94d-41d9-a99d-3c397f4ac340	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 16:24:58.106007+00	2026-09-12 16:24:58.106007+00	{}	2026-09-12 16:24:28.106007+00	OPAQUE	REFRESH_TOKEN	JeYR0HDm7EezN3Y6uh9Dhe8d-CKjXQMmZjNjJhNDItZTkxMC00ZTQ1LWJmZDYtNmIyN2I0NzQyNjQ1
0a472d2d-1b5e-4cb5-9a4d-fa991cdc4ad2	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 16:30:27.502305+00	2026-09-12 16:30:27.502305+00	{}	2026-09-12 16:29:57.502305+00	OPAQUE	REFRESH_TOKEN	3By0UXSMnzIbHDQEeynU7DNz93_zogMWUzYzcyNDYtMjRkYy00MWVlLTg2OWEtMjhkZjA0ODY3ZjRm
c2502925-5ad6-4c0a-add7-9bbd50b90e2b	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 16:38:30.985869+00	2026-09-12 16:38:30.985869+00	{}	2026-09-12 16:38:00.985869+00	OPAQUE	REFRESH_TOKEN	dhb7cFtGcWqSoun1i7Nc9Zu6PeiupQYzNjNzRkOGYtMGM1ZS00NWU3LTlhYWMtM2YwZTVhMTllNTBh
97e75e86-fe55-4ff5-b152-9469ef2b3bc9	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 16:38:31.191704+00	2026-09-12 16:38:31.191704+00	{}	2026-09-12 16:38:01.191704+00	OPAQUE	REFRESH_TOKEN	ggdHInLMmtrX7BcTjl92ZA43dd0ShQMjgwYjgwYjctMzdiZC00N2IyLTgwNmUtNzQ5ZWQzNjg1ZGE5
f7d6a599-cad9-447f-8a03-44a371ccf3d7	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 16:47:11.744263+00	2026-09-12 16:47:11.744263+00	{}	2026-09-12 16:46:41.744263+00	OPAQUE	REFRESH_TOKEN	smJmfym5YoSkw3av0E1-2rY38XuXzgZjdmZGUyZmUtYmIxOC00OTEwLWI5ZDgtNWQ0NzAzZjRlYWI4
87a1cb26-9e50-45d9-ba8e-6bdc788d2cfa	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 16:47:11.941681+00	2026-09-12 16:47:11.941681+00	{}	2026-09-12 16:46:41.941681+00	OPAQUE	REFRESH_TOKEN	6qFHaUAjjS5h8sTKAYUETfaPQTxVvgZDBmMTBiNGMtODUyYS00YjU3LWEyODgtNDllMGZhNWVlMTU0
542c311e-2f6d-4db7-97ab-f8ccf43164eb	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 16:47:12.176322+00	2026-09-12 16:47:12.176322+00	{}	2026-09-12 16:46:42.176322+00	OPAQUE	REFRESH_TOKEN	aY3VT3q364vmWK3dJr8lP02HHOCX7ANDg2ZDA0YTUtNDMxMi00ZTMwLTk1YjMtNTEyZmY2ZjVhNzRk
6fdeb387-9dea-44bd-99e1-45f3f2270de2	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 16:47:38.536016+00	2026-09-12 16:47:38.536016+00	{}	2026-09-12 16:47:08.536016+00	OPAQUE	REFRESH_TOKEN	m-SyWy80uNV3tvtRkGzBkZg-0ceykAZGZmMjY4Y2QtMjIxYS00ZGU1LTg5YTQtZWFjYjZlM2RiMjI5
01905d78-a457-4a32-bd8b-e20a2431f09c	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 16:57:05.097942+00	2026-09-12 16:57:05.097942+00	{}	2026-09-12 16:56:35.097942+00	OPAQUE	REFRESH_TOKEN	8KhoRtvN4elF1KUg-0IB6b1EP2IhlgN2Y3OWIzMTYtMDE5MS00MDc3LTgyODMtNjA5MTVkMGVlOTg3
89848c1d-3303-40b1-b96f-e53c606319aa	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 16:57:05.515525+00	2026-09-12 16:57:05.515525+00	{}	2026-09-12 16:56:35.515525+00	OPAQUE	REFRESH_TOKEN	tElE3pSqG7u8wjoPrgVdFdsBhR7oDAZmIwZjNmOWMtMzM5Mi00MTQwLThiOTEtYTJjZDk2ZmU1NWM3
ae665aa9-87db-40ad-829e-1e35520def14	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 16:57:13.382895+00	2026-09-12 16:57:13.382895+00	{}	2026-09-12 16:56:43.382895+00	OPAQUE	REFRESH_TOKEN	bOnXrwi4NMtMRPo101mjw9Htg6wpSANDM2NGFjZDEtMzliOS00ZDVjLWI2MGUtNTU1OTU5Nzc5OGU0
4eeb1f3c-f841-45dc-b1c5-d4f533eded35	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 16:57:15.803211+00	2026-09-12 16:57:15.803211+00	{}	2026-09-12 16:56:45.803211+00	OPAQUE	REFRESH_TOKEN	N7KOdfN0xz5fyuNGLffty5AVobcFWQNWM5MGE1MTktZGFhMy00N2RlLWFhMjUtNzdhZDYyNTQyMTdj
d68406b4-7637-49ff-85fd-bea1d7303217	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 16:57:29.175286+00	2026-09-12 16:57:29.175286+00	{}	2026-09-12 16:56:59.175286+00	OPAQUE	REFRESH_TOKEN	KbKOCWmEmsNNb61YHDimz_Pvk77yiQZjE2MmQ4NjgtZGJkMC00NmU3LWFhOGMtMGU3MzdiOWE0ZTQy
ea523714-d951-49cb-a1a5-af4edf23217d	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-12 16:59:57.303706+00	2026-09-12 16:59:57.303706+00	{}	2026-09-12 16:59:27.303706+00	OPAQUE	REFRESH_TOKEN	xjeqBDDY6Pn3rQH-4DB6V4d3vdaCWgYzAzYzQ0NWItMDFkYy00MjY3LWJjMjYtM2MxODI1YjE0YjUy
1b4eed82-7efe-4c4f-a7db-a6d3338de9ec	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-12 16:59:58.764081+00	2026-09-12 16:59:58.764081+00	{}	2026-09-12 16:59:28.764081+00	OPAQUE	REFRESH_TOKEN	_Ex1ATbVwTYc1U450mC6x3QjZH7-yAOWUxY2Q1ZWQtMjk2MC00MTg0LTk4ODAtNzJmMDg3ZDA1Nzlk
1a4ca414-554f-410e-8324-b1788bb97d69	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-12 17:01:44.803253+00	2026-09-12 17:01:44.803253+00	{}	2026-09-12 17:01:14.803253+00	OPAQUE	REFRESH_TOKEN	Y8EteUDdV0s3ZGK869Kk0y3Qf6Oo3QYWNiNzdmYjMtZGQ2OS00MmVhLWJmNjItNWMzMmIxM2VjOWIx
4615d821-0186-4dfd-b85f-aef11e5aa0fd	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-12 17:08:14.079867+00	2026-09-12 17:08:14.079867+00	{}	2026-09-12 17:07:44.079867+00	OPAQUE	REFRESH_TOKEN	J3STHZQgn116o_Xv8MqLQeIs452K3QNjE1N2QyYzMtMWU1NC00N2I4LTlhN2EtMjNkNTI1NzU2NzYz
b2f9f6c2-49f6-4262-bee1-99d64b0851b3	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-12 17:08:14.922679+00	2026-09-12 17:08:14.922679+00	{}	2026-09-12 17:07:44.922679+00	OPAQUE	REFRESH_TOKEN	5XdvnJ0_ws6Zp-sMvp4dQM7ISuMsygZTI2YWJjMTctZjM0Ni00YmYzLTk5MzctYzYyZjYwNjAwM2E5
857551b9-c608-49c8-8582-db06d57bd0a2	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-12 17:09:39.507976+00	2026-09-12 17:09:39.507976+00	{}	2026-09-12 17:09:09.507976+00	OPAQUE	REFRESH_TOKEN	7ehVdsdlFao-1SdrWdjeHuipdD6drwZDhmYzg3ZTMtMTg5My00NGZmLTk0MDQtZWE2MjQyNDAzMTBk
904e67b4-e8b3-4478-b11a-d9a19d73255b	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-12 17:17:48.542578+00	2026-09-12 17:17:48.542578+00	{}	2026-09-12 17:17:18.542578+00	OPAQUE	REFRESH_TOKEN	HwYJiYh6F-3pyQIPNwoFvLTRmPHPFQODY1NGNjZTEtOTVhNC00YWY1LWE3MmQtOWNiZWZlOGQ1ZThk
5bf71627-823c-4ad1-8a77-66a706232270	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-12 17:17:49.562319+00	2026-09-12 17:17:49.562319+00	{}	2026-09-12 17:17:19.562319+00	OPAQUE	REFRESH_TOKEN	FuaufL1gsbeZL-oC-uDjUNJfpK1b-wMzAyMGU2YWEtZDRjMC00YzkwLWJhZDYtOTFmYTI5MGEzN2Q1
4f8583d9-00df-44bf-b141-ada15cc63ecd	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 17:17:55.996483+00	2026-09-12 17:17:55.996483+00	{}	2026-09-12 17:17:25.996483+00	OPAQUE	REFRESH_TOKEN	Ju9WgKfA-IJpaNvWT6pZGJ_zOU8aAANDczMzY1ZDEtYTNjYS00ZGFlLTg4ZTEtNzNlMjE1NTBkMTU3
49bad33f-74fb-4b3b-b49a-7289f62de71a	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 17:17:56.224469+00	2026-09-12 17:17:56.224469+00	{}	2026-09-12 17:17:26.224469+00	OPAQUE	REFRESH_TOKEN	_eC46PueUqu5hgLC6kBbRYyh8VbGIgM2QzZDJiZDgtYjllZC00MDdlLThhNTgtMTY5N2FjNWU5ZmYx
53e0199e-df2f-4bdb-8f7f-f7bfd8681d26	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 17:17:56.436992+00	2026-09-12 17:17:56.436992+00	{}	2026-09-12 17:17:26.436992+00	OPAQUE	REFRESH_TOKEN	Yx37rkuad1i9XtjvqggM4hHH2RWu4wZDJmZWM2ZjQtZTNjNi00YThhLWEwNDgtZTdmMzllMzI5NTcw
0988778d-25a8-434c-9b2e-ffc0c29ce60a	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 17:17:56.643691+00	2026-09-12 17:17:56.643691+00	{}	2026-09-12 17:17:26.643691+00	OPAQUE	REFRESH_TOKEN	6VkB1_-EzD3sTcBmFHhK3z8zoSGEkAZGZlMDZjMGEtMzQ0MS00M2FiLTk2OGEtOWNiNzg0YmY1ZTk0
315eff72-6076-4bfe-8b3a-e894246e93bc	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 17:17:57.222342+00	2026-09-12 17:17:57.222342+00	{}	2026-09-12 17:17:27.222342+00	OPAQUE	REFRESH_TOKEN	zO4J1bWsbU-HkdZQVN_3t7l-QdyIKwYTBiYWEyM2UtOWJmYi00Y2QyLWE4MzktMTM4ZTkzNDBhNDA4
0640b95d-fade-4847-8047-86986cda0699	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 17:29:34.11365+00	2026-09-12 17:29:34.11365+00	{}	2026-09-12 17:29:04.11365+00	OPAQUE	REFRESH_TOKEN	t5CfdAdFVdwWGLLq9EGJ0u5Zq_3NMAMjY1ZGJjNWYtOTc1OC00YjQ4LWJmYjQtYWM2MjI1YjhjOTc2
d2841a32-2ad9-434b-a607-886e3e775330	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 17:29:34.490727+00	2026-09-12 17:29:34.490727+00	{}	2026-09-12 17:29:04.490727+00	OPAQUE	REFRESH_TOKEN	OtmEewJRXJJPyagaCc9LuHHhbn8nGwZTFjYmQ2ZDYtNjkyNS00OWNhLWFlZjItZDhiNmQyNTU1NjQ1
43bfb0eb-0b21-4be8-81d3-f5ceab168d64	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 17:29:34.577026+00	2026-09-12 17:29:34.577026+00	{}	2026-09-12 17:29:04.577026+00	OPAQUE	REFRESH_TOKEN	C1vL-np0P1BdorOkU7ZV4S3dsxmfIwZTQ0MWYzMTktOWU1OS00ODE3LWJjNGUtODUyOGNhM2JiMjgx
1dca0ffa-3ae5-4fad-b6de-f171a6b8d763	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 17:30:05.276128+00	2026-09-12 17:30:05.276128+00	{}	2026-09-12 17:29:35.276128+00	OPAQUE	REFRESH_TOKEN	GgIRyHnXZTIY9o1cxG0eTswJSTNSjQMzViZDAxNDYtYWRmNC00MDQzLWE2ODEtM2YxOWE0OWVhOTQ0
c0811665-8eb4-48b4-a75e-d2bfd3261db9	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 17:30:07.940104+00	2026-09-12 17:30:07.940104+00	{}	2026-09-12 17:29:37.940104+00	OPAQUE	REFRESH_TOKEN	u9odsD_dqKWuCH7ApVSL64l1oQIzrAMzQ3MDVkYmItZjg1Yi00YmNjLWI3ZTUtNzQyZjczYmNlZjk3
533bebd8-6faa-4120-8e20-41da05971f36	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 19:02:32.261936+00	2026-09-12 19:02:32.261936+00	{}	2026-09-12 19:02:02.261936+00	OPAQUE	REFRESH_TOKEN	2RYIrsDQwkxmcEbVm2B8ZQiL_QMbZQMWI2ZTc3YjEtOTRhYi00ZTA3LTkwODMtN2EwMjAzYzQ4NWNj
15a0c2e5-1edd-4305-b7c0-e2813e6018a6	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 19:02:54.512364+00	2026-09-12 19:02:54.512364+00	{}	2026-09-12 19:02:24.512364+00	OPAQUE	REFRESH_TOKEN	FzY0tl0qVUdgaMzsI7POFfW7vOX8mgYjUyZmIzYTUtODc3NS00YmM4LWEzZWEtNjI4OWY5MzMzOTVh
4a7835ea-f607-4293-b962-8fa93e4d9008	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 19:04:12.222138+00	2026-09-12 19:04:12.222138+00	{}	2026-09-12 19:03:42.222138+00	OPAQUE	REFRESH_TOKEN	8tku8XFHjt4OWOyR_XeCLG3_-VNd6QNTQ2ZmUxNGItMjRiYS00YjMwLTgwOTEtZDc5NWIzMDJkNDdk
d68c93a0-c708-42d4-b9af-0cdfca4482fa	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 19:05:59.22328+00	2026-09-12 19:05:59.22328+00	{}	2026-09-12 19:05:29.22328+00	OPAQUE	REFRESH_TOKEN	cvkcrFsHaAmKQYZc1iElx9aNeITzBQMjBhMWVkNDYtNDIwOC00M2NiLThjMTItOTkyZjgwMWUzMWYz
ecd93b2a-ba6c-43dc-ad47-25472d1f6bf3	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 19:11:07.197887+00	2026-09-12 19:11:07.197887+00	{}	2026-09-12 19:10:37.197887+00	OPAQUE	REFRESH_TOKEN	jf2F_bjxwPf00d55B75v0P7EghpyigZmQwMWQ0ZGItYWRmYi00Y2QyLWIyMWQtOTVkNmNkZjZmYTA4
f7c1839d-764b-4d2c-9469-5073f6140afb	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 19:11:07.736694+00	2026-09-12 19:11:07.736694+00	{}	2026-09-12 19:10:37.736694+00	OPAQUE	REFRESH_TOKEN	YvIHOg-RuTDPepQbcr6N7itg2kj4JgNGFhMTBjZTItOWQ2ZS00MDQxLTg2ZjgtZjE0YmU3NzIxMTBk
4e6bee6f-de80-49d1-b0d7-05398a02fc94	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 19:11:46.345621+00	2026-09-12 19:11:46.345621+00	{}	2026-09-12 19:11:16.345621+00	OPAQUE	REFRESH_TOKEN	Z8JQsK6Kp1q3YVwJLE1zuCLuy7YNdAZGUyOGUxYzktYTlmNS00NjliLWFkZDUtZTE2YTgyOWQyMDk0
1c606fd1-dc62-4319-94e7-b51130cb8754	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-12 19:17:38.788952+00	2026-09-12 19:17:38.788952+00	{}	2026-09-12 19:17:08.788952+00	OPAQUE	REFRESH_TOKEN	asppGjK4nV1V1GTtP9HKqsptMZ7YOQYTNlMzA0MGMtNjM2ZS00OTQ5LWJmOWUtYzBjNjI0ZjIwMjQy
2e353453-eed0-4d84-8591-871b74e75b77	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-12 19:17:39.075587+00	2026-09-12 19:17:39.075587+00	{}	2026-09-12 19:17:09.075587+00	OPAQUE	REFRESH_TOKEN	rwJnreSs0T92xwcDuSYYv7c6wZ4GBwNzA4YzQ0YWYtN2E2Mi00ODc1LTkwMGEtNTRmMWJjMDhmMmEx
ada272ec-87a4-4817-b93c-00f9ee5774d0	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-12 19:17:39.845472+00	2026-09-12 19:17:39.845472+00	{}	2026-09-12 19:17:09.845472+00	OPAQUE	REFRESH_TOKEN	-6H-0-1QO9AdFWd8ZvdXaq0NwKFfsgZjBkNTI1MjYtYmIwOS00MmUzLWE4OWUtOThiNGIwOGQ1M2Y3
494be6eb-09f2-4a8f-ab53-1c4ea1e65fc6	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 19:18:22.594769+00	2026-09-12 19:18:22.594769+00	{}	2026-09-12 19:17:52.594769+00	OPAQUE	REFRESH_TOKEN	iit8pG1-ClbfHLCeJxIUJphEG6KUogODllYWY0YWUtNGQ4Zi00YThkLTlhZWEtZDViMDZjYTI4NTYx
3bd0919e-f9c7-4dd4-9e3d-40895c7f51ba	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 19:18:22.824751+00	2026-09-12 19:18:22.824751+00	{}	2026-09-12 19:17:52.824751+00	OPAQUE	REFRESH_TOKEN	01_8WP3D_rVn9mQiOS_RJmZoJIkOdQZjFlMTQ1OGEtMzViOS00YTA0LWI5ZDQtYzUyNDE0YWIzNmQ2
72c40c48-4d7d-418b-aedb-efc26e6dd084	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 19:18:23.057978+00	2026-09-12 19:18:23.057978+00	{}	2026-09-12 19:17:53.057978+00	OPAQUE	REFRESH_TOKEN	RKba6Ua-MMQrVqITXFRd2ExQ_YslOwZTJhNDMyNzItODEzMS00MjJjLTk0NjYtNDFlYTllN2Y2MmZm
29fb46f3-84a6-4f8e-bd10-493e89a48e91	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-12 19:18:39.881012+00	2026-09-12 19:18:39.881012+00	{}	2026-09-12 19:18:09.881012+00	OPAQUE	REFRESH_TOKEN	BW4LiV0sj2vU_dTr9--Y0ZphD3b6dwYzg4M2ViZjUtYjgyYi00MTZjLWI5NDktNDMxNmQxZWQ5NTEz
eacd9a0c-b8c9-4f18-ae95-3cf65f295996	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 19:22:28.614962+00	2026-09-12 19:22:28.614962+00	{}	2026-09-12 19:21:58.614962+00	OPAQUE	REFRESH_TOKEN	g-QwooDhvVd0rhMUfNkGMwmChtDpigYmVjNDQyZDAtMzlhOC00MmNlLWE3YWQtMGYwMGZmYmVlYTcw
0bd879de-bf96-4baf-ac56-2bccfb46859d	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 19:22:41.652153+00	2026-09-12 19:22:41.652153+00	{}	2026-09-12 19:22:11.652153+00	OPAQUE	REFRESH_TOKEN	GxVHdGdjyDRkVpo9P2z730_zDG2jUAMTVhODZiZDUtMTAyMS00YWEzLTk4ZDItYTdhODIwN2RkOTBi
980d7ad4-2be1-4d20-bd17-29d10dd00231	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 19:22:50.064933+00	2026-09-12 19:22:50.064933+00	{}	2026-09-12 19:22:20.064933+00	OPAQUE	REFRESH_TOKEN	6MPjb15xYX-ZQGQkXLgkyg726KiisAY2UzYzkyNDQtNjNlMy00NTYyLTg5ZGYtZmM0ZDJiZTRhOTcw
a846d2aa-3cb7-4244-a0a7-27364461fa0d	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 19:22:57.287384+00	2026-09-12 19:22:57.287384+00	{}	2026-09-12 19:22:27.287384+00	OPAQUE	REFRESH_TOKEN	yuSOS4erm4C_CnYvLLPzgcHL0JAzAANjE0MjZmM2UtNWZjYS00YjJiLWI2NzEtMjI3M2YxNDRmMjNj
f07ec2d0-a530-4c4a-a93e-c397aee32c68	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 19:28:31.19309+00	2026-09-12 19:28:31.19309+00	{}	2026-09-12 19:28:01.19309+00	OPAQUE	REFRESH_TOKEN	GSvizWDKoi8PtGW3WJEvtdan_gLXRQNTUyYTE0NTAtYmUxYi00MGIzLTliYjctODUxNTFlZmYxOTBm
63192da4-b233-4c63-9cb7-d82a3c4b75e3	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 19:28:31.400834+00	2026-09-12 19:28:31.400834+00	{}	2026-09-12 19:28:01.400834+00	OPAQUE	REFRESH_TOKEN	R92RNqUYo5KcXs_O1wD0rjf0BzoMCANTNkMjdlM2EtYjA0ZS00ZDBiLWI0MmItMGRkZGRmNGNkMGYx
27ab82a7-663a-4198-b387-18039d1bf264	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 19:35:48.87818+00	2026-09-12 19:35:48.87818+00	{}	2026-09-12 19:35:18.87818+00	OPAQUE	REFRESH_TOKEN	qpgg-U45f7VVVYXkx1Y6BRLt2R_FnQNGRmNTgxNmItN2U5My00YWJmLTk1ZjYtNTU1ZjQxODM4ZGI1
d2147941-ced7-4c40-8384-597a5175f0fd	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 19:35:49.293792+00	2026-09-12 19:35:49.293792+00	{}	2026-09-12 19:35:19.293792+00	OPAQUE	REFRESH_TOKEN	2vv0HcotiXZwDczta3WdIvC0iimZmwZTFhYTU2MmItNDY3Ny00MGJkLTg0OWItZjI4MmM3NTgwN2Y2
53640845-a1af-4bca-9160-c131b54c9cb9	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 19:36:09.415485+00	2026-09-12 19:36:09.415485+00	{}	2026-09-12 19:35:39.415485+00	OPAQUE	REFRESH_TOKEN	7LQX92Hownxd4xOX4QLcErpjkEFs-QNTI4OThkNmEtNmQ2My00ZTMzLWExMjUtOWRjNGJhOGZkODkz
7d638632-935e-420b-995f-fdbce909abda	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 19:41:28.951253+00	2026-09-12 19:41:28.951253+00	{}	2026-09-12 19:40:58.951253+00	OPAQUE	REFRESH_TOKEN	luETNXJqfZFPYKLR4K6goVwBDeSyWQNTcwMWMzN2EtZTY2OS00MzI4LWE4ZDYtZmYzNzUyMjAyY2Y1
82498758-0b24-41b9-90e5-c5966d8773fa	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 19:41:29.136234+00	2026-09-12 19:41:29.136234+00	{}	2026-09-12 19:40:59.136234+00	OPAQUE	REFRESH_TOKEN	Mqu9eDGjKW7JxfkegsHGQKthb4hDjgMGI5ODU0N2MtMjBkNC00NDExLWExZTQtOGM0OGU2ZGZhODg3
c5789915-7681-45f3-ad9c-44a52fe00065	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 19:51:01.358102+00	2026-09-12 19:51:01.358102+00	{}	2026-09-12 19:50:31.358102+00	OPAQUE	REFRESH_TOKEN	BmrMhRTLSXr0UxzdtMTYD9W_xqLYnAMTcyZjY2YjItYTA0Ny00YzIzLTgyNGItY2U5MzkwNzg0N2Vk
fe9951a0-2db7-408c-83bd-cef417fe75d6	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 19:51:02.140463+00	2026-09-12 19:51:02.140463+00	{}	2026-09-12 19:50:32.140463+00	OPAQUE	REFRESH_TOKEN	F45dahgdcmzJjvDKUDGG8AAGXYchLwMzgzMTcyODItMDM3Mi00MWE0LTkzZTYtNDI3MDUwZTM4N2Jj
c1fdad0f-a6cf-4584-8a83-5e0578956969	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 19:51:02.672308+00	2026-09-12 19:51:02.672308+00	{}	2026-09-12 19:50:32.672308+00	OPAQUE	REFRESH_TOKEN	bKrxKthTg_P3x0B0tQMg6nhLfg9DLwZDc2MjlkZmYtMGMyYS00ZmM5LWI0ZDEtZmY5NDhhOGM3NThj
fc20f12a-b6e2-473b-bfdf-24ab8d22d441	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 19:51:03.008664+00	2026-09-12 19:51:03.008664+00	{}	2026-09-12 19:50:33.008664+00	OPAQUE	REFRESH_TOKEN	9RNSmrSydSU15ANh0KFWsXpw0dZnVQNzljNzVkYTctNmM1MS00ODI1LWI5MTgtZWNiNzIzODEzNDVi
15b999fd-bace-456e-93c2-11782bb3b04e	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 19:53:54.705054+00	2026-09-12 19:53:54.705054+00	{}	2026-09-12 19:53:24.705054+00	OPAQUE	REFRESH_TOKEN	kvWAMaQZMy_sGZkNNyvwPuwvLzFazwNTIyYjk2OTctMGYzZS00YTNmLTg1YjYtY2NjMzk5ZGM2Y2Mz
0a7ee395-b4d0-48c6-8428-a4f7c5a5219f	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 19:58:25.144231+00	2026-09-12 19:58:25.144231+00	{}	2026-09-12 19:57:55.144231+00	OPAQUE	REFRESH_TOKEN	TJiFu8RT9Cs203zUpZjzgA0qWZU-6wM2IxZTRhZjgtMWY5OC00Y2RiLWJmYmMtYzJhNjhhNjhiMGQ3
e8f3de44-496f-43e0-912e-bb5bf03f401b	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 20:05:40.273519+00	2026-09-12 20:05:40.273519+00	{}	2026-09-12 20:05:10.273519+00	OPAQUE	REFRESH_TOKEN	_9rhp-a0tolk5qdGVtT7l3FtWSNWJwYjkxY2I1MTctZDEyZi00N2Y0LTk5YjktYzc4MjExNDYwZDIz
d5293a6b-c821-42b0-b136-262083b89dd9	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 20:05:40.538868+00	2026-09-12 20:05:40.538868+00	{}	2026-09-12 20:05:10.538868+00	OPAQUE	REFRESH_TOKEN	azDNmtPSXuPtJsHitkG35iGxwi52VAYTBkZmQ3YTctMWI4MS00MzA3LTkwYjctYzhjMGMyN2NlY2Zm
b2373e52-1bd6-4549-8030-4c2c88b06784	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 20:10:47.718059+00	2026-09-12 20:10:47.718059+00	{}	2026-09-12 20:10:17.718059+00	OPAQUE	REFRESH_TOKEN	KX7DjR2GUg_m2DAoA30I-mYxVNuTnANzllZmU5YTQtNjNjNC00MDMyLWFmZDEtODczZDAyNjFkZmQ5
0caa12ff-5a89-461e-8ace-c67dbfbaa77a	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 20:10:47.92963+00	2026-09-12 20:10:47.92963+00	{}	2026-09-12 20:10:17.92963+00	OPAQUE	REFRESH_TOKEN	s-zDo4v-xF7aNjJCTQPaTJ-3lbq79gNzA0NGRhYWMtZmQ4YS00MDU4LWE4ODItN2FjNmU5ZmM5ZmMy
a954ef0b-94b1-4ee9-8489-768cad5fdafa	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 20:19:03.93913+00	2026-09-12 20:19:03.93913+00	{}	2026-09-12 20:18:33.93913+00	OPAQUE	REFRESH_TOKEN	MD6MDnxzLKh081Q7DbrpQ0EW2bnWLAYmU5YmE3OTgtMDBmOS00M2RjLTk2NmYtNjQxMzNkZTAyZTBl
680d39bb-40db-4ae5-8392-b020584755f2	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 20:19:04.153946+00	2026-09-12 20:19:04.153946+00	{}	2026-09-12 20:18:34.153946+00	OPAQUE	REFRESH_TOKEN	qT3goITCdkNnLn3W3Hvq5LrI8vaNJAZTFjMjAxNTUtYWZkYS00NzU5LTgwMzgtM2E2ODA5OTNiYjgz
1a44b5f4-a2b1-41d0-a679-5106402d6460	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 20:19:04.564339+00	2026-09-12 20:19:04.564339+00	{}	2026-09-12 20:18:34.564339+00	OPAQUE	REFRESH_TOKEN	QIbDYvmBrk4DY4EVsteelG5ML7AZFAY2JkZWU5MmYtOTQ3Ni00ZGY4LTk4ZTktNDgwYjdhNTliYWYz
add09377-b9c9-41ce-996c-0548000f368e	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 20:24:18.817244+00	2026-09-12 20:24:18.817244+00	{}	2026-09-12 20:23:48.817244+00	OPAQUE	REFRESH_TOKEN	FUegFnVODb6Xur2oCxUgdn1b4SL-iQODRkNzAzNjctMWEwOS00NGQwLWJmNGMtM2RkYThiZGE4YTFh
05a37765-b153-4b82-9542-d2920f122e87	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 20:24:19.01538+00	2026-09-12 20:24:19.01538+00	{}	2026-09-12 20:23:49.01538+00	OPAQUE	REFRESH_TOKEN	29_xVqlM5ppXezi5DmYWGePKw0vOsgMTkxODYzYWYtMmQ4Ny00NjQwLWI3NGMtYjhlMDljMDNkNjAx
823815de-6818-4439-a40d-9b9ad8a7e179	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 20:24:19.433263+00	2026-09-12 20:24:19.433263+00	{}	2026-09-12 20:23:49.433263+00	OPAQUE	REFRESH_TOKEN	r58JK4Teer7KSgqW-MWJrYrmAl_eEQNjYxNjhhODItOWI4NS00YjRmLWFlMmQtNWI0OGMyZWU1MDY3
b4480a39-b03f-4a0d-9662-8bbb05da95a2	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 20:35:38.345849+00	2026-09-12 20:35:38.345849+00	{}	2026-09-12 20:35:08.345849+00	OPAQUE	REFRESH_TOKEN	iqK9n8tu2fnH7OfAJOFYFz7r9UASNgMDEyNDkyMzAtZTA0NS00YzE1LWEzNTUtYmI3NTdmZDBhNmI3
8f3b8603-d43f-46d4-8967-67638f6cd108	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 20:35:38.54141+00	2026-09-12 20:35:38.54141+00	{}	2026-09-12 20:35:08.54141+00	OPAQUE	REFRESH_TOKEN	RAUsHYRPWCZ3sFGdeiUyxC3oxPqFCQYzQ3MWMxMzgtNTEwZC00ODM5LTgzZmQtYjhlMjAyYzAyN2Qw
b0f305b2-64ab-4c70-9114-1bee79dafcf9	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 20:35:38.751376+00	2026-09-12 20:35:38.751376+00	{}	2026-09-12 20:35:08.751376+00	OPAQUE	REFRESH_TOKEN	_vmixqvq6V0lA98vJo10HhA2Fh2NNgMGMxZjYwZjEtMDk4Zi00MGM0LTkxMWEtOWE4MTNkZDIwNjdi
8965074a-749e-4c03-ae8e-87ac4c635004	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 20:35:38.97781+00	2026-09-12 20:35:38.97781+00	{}	2026-09-12 20:35:08.97781+00	OPAQUE	REFRESH_TOKEN	Zf-shJz9_drBTPx1jMNdg40OCMB_1AZjdhOWM4YzAtY2ZkOS00ZTQ0LWE3NDYtYzQ3ZjkzNWNlMDRl
9e97f93e-04ca-471f-845c-b45617c19b5f	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 20:36:24.575081+00	2026-09-12 20:36:24.575081+00	{}	2026-09-12 20:35:54.575081+00	OPAQUE	REFRESH_TOKEN	Cve19PlHx4VqlaLUmZuQrvmiNSj52ANTljNjM4NGUtNjA0NC00ODY2LWE5OTItOTdkZWMxZjAwMWNh
0272cfa7-c38f-4d7b-a064-39751a72880f	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 20:46:52.797225+00	2026-09-12 20:46:52.797225+00	{}	2026-09-12 20:46:22.797225+00	OPAQUE	REFRESH_TOKEN	3H6fS49BJFbINNfIa07CI1LEz-IX4QNDBjYjUwNDMtZWNmYS00NWNmLTg2NzAtNDVmMzhjMjc5OGUz
5d24fec6-b533-4496-a73b-106b555c4988	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 20:46:53.532474+00	2026-09-12 20:46:53.532474+00	{}	2026-09-12 20:46:23.532474+00	OPAQUE	REFRESH_TOKEN	W0Mg2ZDhKT3rEo34zqTWD1paxkRwRQZTRhMTUxNWQtYThmYS00N2ZhLTg2MzktN2RjZTIzZTU0MjJm
50a4b45c-3f2e-44ae-9c13-40f17b3e7dfa	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 20:46:53.743592+00	2026-09-12 20:46:53.743592+00	{}	2026-09-12 20:46:23.743592+00	OPAQUE	REFRESH_TOKEN	9GqJ50Bs_s65jgrO5kgLLP9_1WJ9KAZmNkZDRlZGMtMjQyOS00MDVlLWIzNTUtNDVkYzk5YTZlMmRi
387b38a2-01ef-40dd-b773-a5f06cdbf2d8	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 20:46:53.934503+00	2026-09-12 20:46:53.934503+00	{}	2026-09-12 20:46:23.934503+00	OPAQUE	REFRESH_TOKEN	pBy_OLr5PxMRggQ862lxVXYJ2vd03wZGZkMGY5YWItOWRhNC00OGFjLWIwODQtZTZmMGFlZGFmYmJh
c580742d-f023-4556-be18-a233de376cd2	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 20:46:54.140819+00	2026-09-12 20:46:54.140819+00	{}	2026-09-12 20:46:24.140819+00	OPAQUE	REFRESH_TOKEN	eLt0W1XLcgvmpsAgwQUBMhQ-BOOVZwNDAzODIxZmYtZTgxNC00YWU3LWFjNWYtZjA1MTBhYWY3MjBj
6b543d35-33d1-4002-ad05-17c6a8bfbe54	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 20:46:54.334821+00	2026-09-12 20:46:54.334821+00	{}	2026-09-12 20:46:24.334821+00	OPAQUE	REFRESH_TOKEN	CWMuTWF3IQPhMWMxhh7vFnMF7CBbzgOWEwZmU2Y2MtZmEzOS00NzU5LTk5Y2UtNzg0OGE1NjYzNDdk
c8d29457-0983-4854-996d-6e856ffc94c5	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 20:46:54.53397+00	2026-09-12 20:46:54.53397+00	{}	2026-09-12 20:46:24.53397+00	OPAQUE	REFRESH_TOKEN	vyxhnvNJ0aVBI8RsRuLxtMybxOK1nAM2MyNWM0YzQtNjFlZS00ZmQ5LTk2NDEtNzk3Y2RmMzgwYWFm
b7cbeaa4-276c-40a5-ad72-846945cac96f	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 20:46:54.730292+00	2026-09-12 20:46:54.730292+00	{}	2026-09-12 20:46:24.730292+00	OPAQUE	REFRESH_TOKEN	IEPKym1JkMExSVfO9mBxxtKfk3-tUgMDE1ZWU5ZTItZjY2Ni00NzRiLWJiODUtOTBiMWY0OWRiZWQw
39c715e6-c5e9-4462-a484-8f6a6c9f5493	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 20:46:54.919731+00	2026-09-12 20:46:54.919731+00	{}	2026-09-12 20:46:24.919731+00	OPAQUE	REFRESH_TOKEN	grIuCJcbdJ4hdvPlGLQuqIylBFpUngMTYyYWRjMjMtNDkyNy00NDc0LWJjMTMtMGJmMWRhNTkyMjg5
d1d95643-d53a-48ff-9b32-d20214b1abe7	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 20:46:55.109531+00	2026-09-12 20:46:55.109531+00	{}	2026-09-12 20:46:25.109531+00	OPAQUE	REFRESH_TOKEN	Ssa9r12S1_txhDbA_YJak4gZDNC_9AZDY3YTI1ZjAtNmYwOS00Y2Y1LTllNjctZTk1MmQ5MWI1NWQ2
3676f9de-a9bd-40ba-af41-d2c0cec48056	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 20:46:59.96785+00	2026-09-12 20:46:59.96785+00	{}	2026-09-12 20:46:29.96785+00	OPAQUE	REFRESH_TOKEN	aEIxCkGr9Puw2Bab6k_QAD1LAiOmbgZGE4M2VjMWMtZDgwMy00MWNiLTkxMDMtNmJlYWQyMzkxNjMy
d1f5a0e7-7ca8-4076-8d6e-1e44e2929e9c	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 20:54:27.19458+00	2026-09-12 20:54:27.19458+00	{}	2026-09-12 20:53:57.19458+00	OPAQUE	REFRESH_TOKEN	9OJ4xnCcVEudgWAcUyAF79DoKTVKbANzJlYjczZTMtZDc2OS00N2QwLTllYTUtMzU0ZjUxODEzNWY5
e7ed597e-ad56-457e-ae1b-e7905e78e388	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 20:54:27.44776+00	2026-09-12 20:54:27.44776+00	{}	2026-09-12 20:53:57.44776+00	OPAQUE	REFRESH_TOKEN	wUAwk9RVKu2rt36dmoTlWZ_hgrrF2wNDlhNWViYTYtOGY0Yi00ZjY3LWI2OGQtYzFiYmY3ODQwZDMy
1c0401fd-7b40-488e-abaa-a78f32802151	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 20:54:27.880176+00	2026-09-12 20:54:27.880176+00	{}	2026-09-12 20:53:57.880176+00	OPAQUE	REFRESH_TOKEN	nHfH0S0oQkanIHgKFVk5OR6gY0-IPgNmVkN2MwOTItNWVjZC00ZTYwLWIzZDEtNTg4Y2QxY2Y3MGQ4
f6b805c4-8aac-44f6-aa2b-9477b7c9e8a6	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-12 20:56:10.838535+00	2026-09-12 20:56:10.838535+00	{}	2026-09-12 20:55:40.838535+00	OPAQUE	REFRESH_TOKEN	BsmHSr0TA0c2WYrwHm0aY512RXr3awYWRjNmE5ZWQtZjBkYy00YzlhLThjMTYtODk5ZWFlYTZlZDY2
fbe19fe1-d6eb-4270-beb6-6b7976850042	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 10:03:24.640492+00	2026-09-13 10:03:24.640492+00	{}	2026-09-13 10:02:54.640492+00	OPAQUE	REFRESH_TOKEN	UCa7NBa4nWAqHU0fMhkkRsq8tmsX9QMjUxOThhNTctYTVjMC00ZWQ3LTg2MTktY2MwMGQwOGViMTFj
d2995f0a-7139-4529-842a-156e3470d549	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 10:09:58.752307+00	2026-09-13 10:09:58.752307+00	{}	2026-09-13 10:09:28.752307+00	OPAQUE	REFRESH_TOKEN	wctdhrjjFBxWAKiJxwgkF2h52RWuuwNjhjZGIzMmYtYzI3OS00OGE5LThiNmEtYjIzYjk4NWMyOTE1
4b20a394-84c2-48c0-8e16-142ce1fb0253	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 10:09:58.966599+00	2026-09-13 10:09:58.966599+00	{}	2026-09-13 10:09:28.966599+00	OPAQUE	REFRESH_TOKEN	YGCibLI70tjpxnzXe5jYprR05a2snQMTAzZDgxODQtMDc1Yy00Nzk0LThhZGQtMjE1YmFkMzdlN2Ey
5db7ee5d-b23a-4c9c-b66b-809532d51c59	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 10:16:01.210049+00	2026-09-13 10:16:01.210049+00	{}	2026-09-13 10:15:31.210049+00	OPAQUE	REFRESH_TOKEN	skHFuV-MVNHQbdGlO_wot6-eGjoRrgYTYwOTkwMDYtOGE4Ni00MGJhLWI0ZDMtODhiZThjNWMzYjcy
d4970d29-28d7-4f0d-977b-eb7857da189a	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 10:16:01.424501+00	2026-09-13 10:16:01.424501+00	{}	2026-09-13 10:15:31.424501+00	OPAQUE	REFRESH_TOKEN	q65tI7b4bTIKxQ7p7BC5XWXlRniTigMjUwYjk1OTgtMDk5Zi00MjMzLTg4YWMtMmFjN2UzYTFiYTA4
efb888f7-903a-4ea3-b88f-244996b11261	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 10:16:01.639409+00	2026-09-13 10:16:01.639409+00	{}	2026-09-13 10:15:31.639409+00	OPAQUE	REFRESH_TOKEN	blaAC0VOFCmssWYG-_HWKEv0_2-EKwNzExYjdhYzYtYTUwMS00YjVlLTlkNDAtM2FkM2U5YTk2NTMx
c6024b9a-d5b1-4e1b-93a2-2991b18ef333	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 10:16:01.854238+00	2026-09-13 10:16:01.854238+00	{}	2026-09-13 10:15:31.854238+00	OPAQUE	REFRESH_TOKEN	9z9XH8bsPFSbLny2tmhmGJJIRO8YOwNmM5OWM2NTktMjMzZC00Y2MyLTgyZTctN2Q5Y2JkMjI5NWU1
11aed2ba-8e95-49d8-a4f3-85995c0df52c	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 10:16:02.050025+00	2026-09-13 10:16:02.050025+00	{}	2026-09-13 10:15:32.050025+00	OPAQUE	REFRESH_TOKEN	dy6Qq77q70t3lXzoorgvbPOyTDotLgYTAzMjhjOGItYTFiZC00ODA3LWJjYjQtOWEyNWQ1ZDc2NDI3
52555413-a024-444c-9116-350307193de7	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 10:16:02.240682+00	2026-09-13 10:16:02.240682+00	{}	2026-09-13 10:15:32.240682+00	OPAQUE	REFRESH_TOKEN	JShvNb-mkB3ygt69C-pWWLpQkyXsYAMjc0N2JhNWMtMmViYi00YThmLWE0NWEtNTk5YzJlMjhmODhj
5d2caafd-b3d7-4904-9796-03abe95690ce	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 10:23:00.654282+00	2026-09-13 10:23:00.654282+00	{}	2026-09-13 10:22:30.654282+00	OPAQUE	REFRESH_TOKEN	Abf1CiEK8XsG0hxjQn4OGwsXP7mmhgOTNhZTlkYzYtMmYxMy00ZGUyLWIyMDctZGIyODI1M2NkNjhh
b4d6721d-5d32-4f52-92ea-3f3c67f43c0c	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 10:24:06.553144+00	2026-09-13 10:24:06.553144+00	{}	2026-09-13 10:23:36.553144+00	OPAQUE	REFRESH_TOKEN	db1ldbZeByUBESH79dNpXIsN2vHlmwMGQ4N2Y3NWUtY2MwYS00MDM5LWJkZTUtOGY0MGFjNzUyYjZh
89b9d0f0-a878-49a4-aa5f-0a3aed5e5b7d	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 10:30:50.44215+00	2026-09-13 10:30:50.44215+00	{}	2026-09-13 10:30:20.44215+00	OPAQUE	REFRESH_TOKEN	M5gqvmUaPUpENL9x0flkzQVC8texsgNGJlNjY0ZDYtMGQ0Mi00Y2FlLTljODYtMjIzMTRiNDQ3MWEz
5e18f9cc-4cd0-4b57-bd1d-275a68c38afe	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 10:38:30.841736+00	2026-09-13 10:38:30.841736+00	{}	2026-09-13 10:38:00.841736+00	OPAQUE	REFRESH_TOKEN	JphVE2TYz2mCc1FJ6rCDk72MJsmmIgNjU2ODcxYjgtMjgwNy00NmRhLThlOTItMTc2OTgxYTZmZmNi
e737b81b-3e59-473a-b3d6-5f398a2beac9	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 10:38:31.028316+00	2026-09-13 10:38:31.028316+00	{}	2026-09-13 10:38:01.028316+00	OPAQUE	REFRESH_TOKEN	p0G91XjzOlfhJ9P7xd66ISEL3dTeBAZDY5YWU1ZmYtYmZlMi00ZmM4LWJiMWQtNGNjNGNhMzM0Mzg4
f6eb9c4e-9cb3-4657-9e8f-58a140032167	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 10:38:31.254631+00	2026-09-13 10:38:31.254631+00	{}	2026-09-13 10:38:01.254631+00	OPAQUE	REFRESH_TOKEN	ELtM_VMBa2A6_V0kWHKSzhM_nXBShgMTUxNWJlYjAtNTFkMi00Y2Q1LWIzMWUtYzUxZDIxZGRhMDg0
265ae4c5-68e4-4b6f-80f9-46804959e49b	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 10:38:31.481831+00	2026-09-13 10:38:31.481831+00	{}	2026-09-13 10:38:01.481831+00	OPAQUE	REFRESH_TOKEN	MGdMXuUqGa8YaxC84Sa37STN4LEr7QMTc4YmFmOWYtOTg4Yi00ZGRjLWIzMmItMmFjNWI0NGVhZTBi
3578dd28-c2b5-45e7-825f-ff19e3ac7ada	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 10:38:31.696398+00	2026-09-13 10:38:31.696398+00	{}	2026-09-13 10:38:01.696398+00	OPAQUE	REFRESH_TOKEN	ioNAC0U3mJMjpEzrROei9MZV08pKhwNzcyMDM3YjYtNDlmMS00YzI1LTg1ZWItOTc1NjQwZThjYzFl
e688c285-9e2e-4891-8c95-ac9d56618396	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 10:38:31.974571+00	2026-09-13 10:38:31.974571+00	{}	2026-09-13 10:38:01.974571+00	OPAQUE	REFRESH_TOKEN	nQ397YDoH58vSygqfv8bwL3Y1UBgKgNmNmZGFjNjgtY2ZhZi00MTI4LWFhN2MtYzk2YTQ2MmYwMjgy
f3dc90ee-e3cd-4b78-9175-e2fb930eb756	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 10:46:04.489889+00	2026-09-13 10:46:04.489889+00	{}	2026-09-13 10:45:34.489889+00	OPAQUE	REFRESH_TOKEN	xeLa7_AVIG8S7Z3bjPXjqqNWpRL4FQZWZjN2I1OTYtODAzYy00NDE5LTgyNDItZThlZDZhYWJhOTE2
d263e146-a6b3-4b65-abb6-b9d9591e17ac	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 12:06:55.632669+00	2026-09-13 12:06:55.632669+00	{}	2026-09-13 12:06:25.632669+00	OPAQUE	REFRESH_TOKEN	itE_w6L5HAIxV84C-dAtIQ38IkSdSgM2NkZTMwYmEtMjczNC00OTU1LWFlYmYtOTdmOGMzOGU1ZmE2
97bf671e-84d2-4d8c-bab4-8d7d2f6f8567	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 12:06:55.851688+00	2026-09-13 12:06:55.851688+00	{}	2026-09-13 12:06:25.851688+00	OPAQUE	REFRESH_TOKEN	Uq878i8RxIzh3X0RHUSFd1i8F5uEggZTM2OWU2NGItMGY4YS00ZGFmLTg4OWEtYzVjZmEzMzkyMzdl
26bbc2fc-a602-4ed5-bcc4-0d746ac0cf3a	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 12:06:56.073539+00	2026-09-13 12:06:56.073539+00	{}	2026-09-13 12:06:26.073539+00	OPAQUE	REFRESH_TOKEN	BIodGrSLGk_HcHqTQ6Meab3YayTRBAYWM1MTY2MGQtOTU0NC00YzJlLTg1NzctMTI4NjI3ZDQzMmM2
83555c0c-75a3-4f6c-a7dc-95cced302fb0	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 12:06:56.70619+00	2026-09-13 12:06:56.70619+00	{}	2026-09-13 12:06:26.70619+00	OPAQUE	REFRESH_TOKEN	7afw5cx0bjt79Nh5CQxChTDKGThCywNGZiNzFjM2ItNTFmMC00YWI1LWIwNjEtN2E3ZGMwY2I0Mjg1
59e41ebc-22ab-4dcb-b31a-50f6b534810b	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 12:12:07.990445+00	2026-09-13 12:12:07.990445+00	{}	2026-09-13 12:11:37.990445+00	OPAQUE	REFRESH_TOKEN	3Azt_0189eBGk02L1DCZNcSzSS-y_wN2FlYTQxN2MtY2Y1Yy00Zjk5LTkxY2YtNDQwNGVhN2M1MmVk
4c1afac8-ba47-440f-a146-280ae4ed5840	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 12:12:08.815466+00	2026-09-13 12:12:08.815466+00	{}	2026-09-13 12:11:38.815466+00	OPAQUE	REFRESH_TOKEN	j43bDIAN1ABU4YL-IhO9tjMwi7wz_wOWM5NzZjNzEtNWQ5Ny00OTRlLTljNmYtMmZlYzU0MTM4MzFl
567d54c4-138c-411b-a63b-2a8ab2d60430	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 12:18:19.266798+00	2026-09-13 12:18:19.266798+00	{}	2026-09-13 12:17:49.266798+00	OPAQUE	REFRESH_TOKEN	jD-WniidN8rSCamEUexjBVjqNazSsQODVhZTA5ZjMtYjUzYy00ZTkwLTljNDAtMTM1NGQ3NmI0ZTFm
768c6849-6b00-4e49-992f-3afbcdda5c2b	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 12:18:19.528266+00	2026-09-13 12:18:19.528266+00	{}	2026-09-13 12:17:49.528266+00	OPAQUE	REFRESH_TOKEN	ah89BCFdMrMsOLO3Ti7b4OiQbdqnuQMGMxNTIyNzItYjBlNC00NTg1LTk4NDQtMGUwYjI2YzA0OGE1
f4cf2a39-ffe0-4f5d-a428-a8b72f2494e1	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 12:18:19.779684+00	2026-09-13 12:18:19.779684+00	{}	2026-09-13 12:17:49.779684+00	OPAQUE	REFRESH_TOKEN	q98kWHE4ZL0tFa2Q9vZ29Vvz0vgpSwYTY4Yjk4NDYtNTdmYy00ZTkzLTkwYzItY2ExMTczMDM5Yjk3
f44511f8-1b2e-4f2a-8e1f-72777deabca0	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 12:18:19.997123+00	2026-09-13 12:18:19.997123+00	{}	2026-09-13 12:17:49.997123+00	OPAQUE	REFRESH_TOKEN	gP6kaCsJJ24R6s6SLGMCuD49s4uykwNDRiMWZjYTktOGY1ZC00NDc2LWJlYzItMzc5YzE2ZjJiNDVk
37e5afb4-a0a2-4528-b075-a804babaef12	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 12:18:20.319324+00	2026-09-13 12:18:20.319324+00	{}	2026-09-13 12:17:50.319324+00	OPAQUE	REFRESH_TOKEN	nR6-QmDwKDL0LhfTDBWde7wQprfBYgNmMyMDBjOTUtNzM2Yi00NTJkLThjYWEtYjIyOTdmNzI5YjEy
40fe4090-d1fb-43c8-b77f-3855c9dc9441	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 12:20:05.412293+00	2026-09-13 12:20:05.412293+00	{}	2026-09-13 12:19:35.412293+00	OPAQUE	REFRESH_TOKEN	7vgFW2YJDUfIgYaxYXKx8ENza5A88AZjFiMGVhYTAtOTBkYi00MjM3LTg3NTMtODcyMjQzOTEwMjM1
7389a84d-64ed-462f-a1ee-712adbce2bbc	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 12:40:19.154916+00	2026-09-13 12:40:19.154916+00	{}	2026-09-13 12:39:49.154916+00	OPAQUE	REFRESH_TOKEN	yeauyQHqWQTDOTG1apO624yJ_NKV-gZjNhNzNlNzQtMmU4MC00MTJhLWFhNWEtOGQxOWVlYWMzMGQ5
8fc08dc8-ec70-4aca-9680-e80a4de09c79	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 12:40:26.046351+00	2026-09-13 12:40:26.046351+00	{}	2026-09-13 12:39:56.046351+00	OPAQUE	REFRESH_TOKEN	GOiRoIBg-dU3t7ncyoSM4MpgPxZ9uwMDcyODIwZGMtZThkZi00YzYwLThlZTItMWQ5NDI1MzY4ZGI3
dcb49248-00b6-4f03-8bd5-dcfcbb24c562	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 12:40:26.251995+00	2026-09-13 12:40:26.251995+00	{}	2026-09-13 12:39:56.251995+00	OPAQUE	REFRESH_TOKEN	IcMtaZRHYyMI-FLPrwGDQuA7QnRwPwYzFhZDgzYzktZGFjZS00ZThlLTkzYTUtNzcxMzU2NDc5MTM2
474b00c5-bb50-4724-92b9-0dcccd1a784e	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 12:40:26.608307+00	2026-09-13 12:40:26.608307+00	{}	2026-09-13 12:39:56.608307+00	OPAQUE	REFRESH_TOKEN	Ci8pJltRCpu80MX6CzxUeI8GQTI9JwMDgxMTBjM2ItYzhlZS00ZWVmLTlhMzAtMWMwOWI1N2QzNTgy
bee680bd-8606-4c20-be8b-6748d9a010fb	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 12:40:26.807907+00	2026-09-13 12:40:26.807907+00	{}	2026-09-13 12:39:56.807907+00	OPAQUE	REFRESH_TOKEN	uF22OCAcGtpDjir_G3Em4HHrtiyeswM2U4NDVlYjctZTJhOS00ZGJiLTk1ZDktNDFmMzQ3MWFmY2Fi
0b0f2207-34ea-4d7f-8b5d-bed58597b7c1	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 12:40:27.012161+00	2026-09-13 12:40:27.012161+00	{}	2026-09-13 12:39:57.012161+00	OPAQUE	REFRESH_TOKEN	0H7cb_Dkw0nZZcSkjgrlRjg1FmbvOQMWY3MDgxZTAtNmMxZC00ZTMxLWE3M2YtZjZmMjI0ODZjODlh
b277faaa-5d7e-4413-8874-bc3dcb9b2edd	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 12:40:27.217621+00	2026-09-13 12:40:27.217621+00	{}	2026-09-13 12:39:57.217621+00	OPAQUE	REFRESH_TOKEN	CUtiAz0mPv-gcUhnD8aQQA3guujXcQNjYyMTU3MmYtNDRiOS00YjJkLWEzOTYtZWM1OTM4MjFjM2Fm
fce5fa36-efc6-44a5-aff1-6a7804a09924	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 12:40:27.415687+00	2026-09-13 12:40:27.415687+00	{}	2026-09-13 12:39:57.415687+00	OPAQUE	REFRESH_TOKEN	Mhw2Cybypc-FATE36qrXAswATIXU-gZTI2M2Q0Y2EtZWY5YS00NWJlLTk1YmItMzZjNWQwNDlhYmRl
ccbfaedc-b196-49a4-94e6-2860c097dcb3	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 12:40:27.61305+00	2026-09-13 12:40:27.61305+00	{}	2026-09-13 12:39:57.61305+00	OPAQUE	REFRESH_TOKEN	01U8m_VQskf4nasHeBFN_furVMbCQwYzhlNmI1YjktMWQwNS00YjRiLTgzZTEtOTFlYjU0ZDc3MGM1
36e0b64c-7434-4024-a090-bd907581c02e	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 12:40:27.813453+00	2026-09-13 12:40:27.813453+00	{}	2026-09-13 12:39:57.813453+00	OPAQUE	REFRESH_TOKEN	1sjLRRVqGWdikRZxgrqAfmC4O05sswZjliNDI4YWMtZmZmNC00ZDljLWI1NGUtNDNlYzdjNGM1ZDM1
e7a37f85-597c-4f16-9783-6c94f18d42bc	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 12:40:28.014276+00	2026-09-13 12:40:28.014276+00	{}	2026-09-13 12:39:58.014276+00	OPAQUE	REFRESH_TOKEN	ZASrQZLWN2WEpzLGu2zWH4ngGcQFbgYzBkZWYzM2QtODZlOS00NDJjLWJkNDAtZmFmNTBiODI2Njdm
7c86dd67-dc9c-48f0-98e9-231e711cb2fb	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 12:40:28.221365+00	2026-09-13 12:40:28.221365+00	{}	2026-09-13 12:39:58.221365+00	OPAQUE	REFRESH_TOKEN	6NCCfEUR7z39iHrBCbXIbLRPF6r1FAYTU5ZTNhZTQtNjczMC00YThlLWE1MGUtZjIzOGQ3ZjUzZDRl
93ef5a4f-3506-40b8-858d-bb4b19ad2727	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 12:40:28.432983+00	2026-09-13 12:40:28.432983+00	{}	2026-09-13 12:39:58.432983+00	OPAQUE	REFRESH_TOKEN	57kTdtrqqYFE4A8g9EB6Jys51nPIpQYjA2NTk3ZGMtOGMyYi00ZDMwLTg2NDAtZDc0MTk0YWMzZTEw
e888f1ac-5487-4b5e-a1ca-b03df709227c	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 13:03:19.644102+00	2026-09-13 13:03:19.644102+00	{}	2026-09-13 13:02:49.644102+00	OPAQUE	REFRESH_TOKEN	1WIu0P1b6PNNBz3FzvCOhV9edHu_7gOWU4MTQ3ODUtMDg3MS00MTE4LTkzODEtMTE4M2I3ODM0MGQ2
fff2a893-5732-42c9-a3b6-7870f912ae05	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 13:03:19.831082+00	2026-09-13 13:03:19.831082+00	{}	2026-09-13 13:02:49.831082+00	OPAQUE	REFRESH_TOKEN	MnZgOKnsqA3m69twTTWCpKJev6Q-zwODI2NTcwMzMtZWNkNi00ZWRlLTgwMTUtYTg5MzgyZGE1YWRk
67009e23-2c88-48c6-8bf3-9f0dd7af3dec	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 13:03:20.01951+00	2026-09-13 13:03:20.01951+00	{}	2026-09-13 13:02:50.01951+00	OPAQUE	REFRESH_TOKEN	GBzYnzdmK8ngVoA0kaL03ap3OWbfXgOGI5ZTRiYTctNDczZi00YmMzLTk2YjMtMzI4OTlkMDJkZTk4
d8f75af7-a56b-480a-b9e8-1415e916e892	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 13:03:20.216248+00	2026-09-13 13:03:20.216248+00	{}	2026-09-13 13:02:50.216248+00	OPAQUE	REFRESH_TOKEN	oRcF4V7ojjDm4ToGenutVqPAEHFsOQNDllNDI5NDAtZjZhOC00MTNkLThkYWEtMzM2OGY3YWI3NjJk
9ab05789-cc2a-41ad-92a0-95183d9f7050	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 13:03:20.39129+00	2026-09-13 13:03:20.39129+00	{}	2026-09-13 13:02:50.39129+00	OPAQUE	REFRESH_TOKEN	ZNtRMCMvZUaOlTG6c9O4nOVmbBvKnAMTBmODllYjctY2Y0NS00ZTNmLWIxNzUtMzU4MDQxMmEyMWVi
04a85af3-b1fb-4fe3-8535-391186c2e5bf	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 13:03:20.58072+00	2026-09-13 13:03:20.58072+00	{}	2026-09-13 13:02:50.58072+00	OPAQUE	REFRESH_TOKEN	NpQyJVwgEDEg-TU6QKp9-bZsAeNH1AOTM4ZWQzZmItYWI3MC00YTQxLTgwYTQtOTk4NTAyMWRhZWMy
000f4039-4b1a-4fa7-8ba3-49e86736e146	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 13:03:20.780782+00	2026-09-13 13:03:20.780782+00	{}	2026-09-13 13:02:50.780782+00	OPAQUE	REFRESH_TOKEN	2gGGtJCXpIt7nIT5kyjqvF-FZ7C25QNzYxOTA3MzYtYTczZi00NmVlLTk2ZGMtODczZDc5YzQyMWMy
f901a8b6-27c3-4d33-b104-5c97796aa530	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 13:08:27.196093+00	2026-09-13 13:08:27.196093+00	{}	2026-09-13 13:07:57.196093+00	OPAQUE	REFRESH_TOKEN	Jf9ouzxSpwCix6hw0AJgSmAyn8FeVAZDNlODgyODAtZTgxMy00Mjc0LWFjZGUtZjc3MmRmMzExOGM3
a4b13679-008f-4e82-9435-32776e324bc5	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 13:08:27.434548+00	2026-09-13 13:08:27.434548+00	{}	2026-09-13 13:07:57.434548+00	OPAQUE	REFRESH_TOKEN	6gr3J3oO0mp-DTx1-9FdpWZ18RGC0wNTI4ZTRmODctNWZiZi00YWM5LTliZGYtMDliMThiYTlmYWU3
d39d7ce4-6ef3-459f-a9b9-ca505a9fb49c	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 13:08:27.646236+00	2026-09-13 13:08:27.646236+00	{}	2026-09-13 13:07:57.646236+00	OPAQUE	REFRESH_TOKEN	hiEf_S6ULGMZBoQHM-PsuRfg-tQxwQMzMzZmNjNWMtYzgxZC00YzY1LThjNDEtYWMzOTljMDk0NGVh
c664c63b-e9cd-48b9-a220-a5997fe29e49	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 13:08:27.900231+00	2026-09-13 13:08:27.900231+00	{}	2026-09-13 13:07:57.900231+00	OPAQUE	REFRESH_TOKEN	If6tZnQ3e8U9k2O-bL8cXoFeWEtlSwY2YyNjYyMjMtYjFlMy00YTJhLWI1MjItZTU3NGM3YjdiODZj
1cb02fe6-821d-4f4f-8694-1d29815a79e0	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 13:08:28.105202+00	2026-09-13 13:08:28.105202+00	{}	2026-09-13 13:07:58.105202+00	OPAQUE	REFRESH_TOKEN	Nv-mgvKLDBgH-5o4sikjfM9ZdbIL6AZGQ1NTlhYmYtN2M4Ny00MzZjLTk0ZWMtZGRmNjZlNjg3MzM2
4c0a8f11-2981-4b89-b11b-cb8962c81fcd	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 13:11:12.987984+00	2026-09-13 13:11:12.987984+00	{}	2026-09-13 13:10:42.987984+00	OPAQUE	REFRESH_TOKEN	mjjwFqNuePA0xayac95dQiWoG0WBawZDM1Nzc0MmEtN2M5Ny00MDU2LTlmOWMtMDJlMTdiY2M1NDc1
63b6f252-8bd9-4b1b-8b8b-fa4703e6b5e2	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 13:19:45.4316+00	2026-09-13 13:19:45.4316+00	{}	2026-09-13 13:19:15.4316+00	OPAQUE	REFRESH_TOKEN	nBijB9-UEXjWmDn1kxTZ62QohCmg_wOGIyMTNkZTYtZmQ2NC00OGNhLTlkZWQtZWJkYzBhY2U4MzI0
522f9cdf-f12e-4975-b27e-c35be7c6b9a6	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 13:19:45.63936+00	2026-09-13 13:19:45.63936+00	{}	2026-09-13 13:19:15.63936+00	OPAQUE	REFRESH_TOKEN	gjWV4JE_0Dl6p6uymGm7nHPhdy4xiQMjViNjY1NWEtYTM5NC00YWNhLTlhMjYtMjc5ZGFiMGE3YjU2
173397bc-ace3-4884-a128-b996ab6b58b7	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 13:19:45.821683+00	2026-09-13 13:19:45.821683+00	{}	2026-09-13 13:19:15.821683+00	OPAQUE	REFRESH_TOKEN	ySqGYolwy7WHBpPVY_B20UFR1P41cQNTI5MTI5YjUtZDdjZS00ZTQxLTg3ZDAtMjZmNjUwYjlmMWJk
8080e006-78cd-4032-9c82-cb6b87cc9a74	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 13:19:45.997096+00	2026-09-13 13:19:45.997096+00	{}	2026-09-13 13:19:15.997096+00	OPAQUE	REFRESH_TOKEN	NFfRlvlhvcg2N-RtXFcEoBxjeQ0HDwYTE2OTcwOWEtOGRkMy00MGM4LTk3MTItNzE2NjA0MzZkYTdl
6fae47ac-9e78-4c39-a33a-1f4da7a37f1d	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 13:19:46.170308+00	2026-09-13 13:19:46.170308+00	{}	2026-09-13 13:19:16.170308+00	OPAQUE	REFRESH_TOKEN	r_CpJg1cAskHutrL0yRK_VEcfQRZsQNzQyZjQ5MTEtMWJiNy00ZmM1LThhMGYtYzhkMmNlNGY5Yjg4
1a59f7d6-e5e4-4f92-8709-d26509d68c94	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 13:19:46.342325+00	2026-09-13 13:19:46.342325+00	{}	2026-09-13 13:19:16.342325+00	OPAQUE	REFRESH_TOKEN	4UATRvpjpzobBu71tibOdLVOkj0HEwYzc2NWNmZTQtODIzMi00MDkxLTliNDMtNTVlZmZiZjE1Yzll
eff9fd46-3a3a-4a1c-bf6b-e702e0971f00	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 13:19:46.512065+00	2026-09-13 13:19:46.512065+00	{}	2026-09-13 13:19:16.512065+00	OPAQUE	REFRESH_TOKEN	kLP3OozWu8-DaAWTxEQfPqZXfkTuZANzAwNDc2MzItMjgxMS00YzA0LWJmYjMtMWFjYzRhNGI0ZGNk
748536a3-b1fc-4687-98e3-48a102f5faec	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 13:19:46.690409+00	2026-09-13 13:19:46.690409+00	{}	2026-09-13 13:19:16.690409+00	OPAQUE	REFRESH_TOKEN	XEo5T3KNIVcg8As1xdex-zRzEaiS9AMTgyY2VjNGEtYTkyNy00NjA1LTg1MDItNTdkZmFiYzg4YzQw
8e2f14b4-5734-48d6-8be2-2e6d6aa8f532	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 13:26:22.325209+00	2026-09-13 13:26:22.325209+00	{}	2026-09-13 13:25:52.325209+00	OPAQUE	REFRESH_TOKEN	Vg-_djtp-YFTXiTCemagpep8--KOxwZjcyZDlhOWItMjk2MS00MDYxLWIxMTItMjU4Nzc4NDJlNWFk
486d84d6-eb7e-44bd-82c7-efb62b57eee9	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 13:29:09.151745+00	2026-09-13 13:29:09.151745+00	{}	2026-09-13 13:28:39.151745+00	OPAQUE	REFRESH_TOKEN	6YJLC1kBfVNj0L-FPSSaZGX0PtZhPAZjE0OTlmNjUtMWQ5MC00NjBhLTk4ZTktZGVjYTBlZDU1MmFj
d2f98a1d-216f-4546-9f84-365d8827123b	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 13:43:07.69362+00	2026-09-13 13:43:07.69362+00	{}	2026-09-13 13:42:37.69362+00	OPAQUE	REFRESH_TOKEN	cwXgjDi1q1slI4sGnahVb78a78rmTwMDRmYzUyOWEtZWVhYy00OTNhLTlkY2UtYzY3YjhhYjQ5YTFl
bf452216-f79b-4a44-8e7f-4b831e2219c8	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 13:43:07.894356+00	2026-09-13 13:43:07.894356+00	{}	2026-09-13 13:42:37.894356+00	OPAQUE	REFRESH_TOKEN	YnWFogKzjqCMw-NqgTtp_YWbp0UxhQYzIzM2U1NzItZmRhMy00NjZiLTk2M2EtOTZkMDUzYTE4NmYy
e87ecb3e-0241-4603-8e2e-6c2736ef82aa	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 13:43:08.075148+00	2026-09-13 13:43:08.075148+00	{}	2026-09-13 13:42:38.075148+00	OPAQUE	REFRESH_TOKEN	0Jse1r10BbbSNoHAauGkdq41QfGkywNWJhMTNkMDctNTIwYS00ODhjLTkxMjctZTQ4ZGU2ZmM0Yzdj
5d886cae-9236-4dcc-a572-26c527b6ccf2	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 13:43:08.260122+00	2026-09-13 13:43:08.260122+00	{}	2026-09-13 13:42:38.260122+00	OPAQUE	REFRESH_TOKEN	UAUOmbGRNNYE178ZdktWUveLmgXD3QNTQ4YjZmODktZTA1ZC00MWFmLWE2YjctZmNhYzg1ZGM1Y2M5
2948b4fa-0cc6-427c-8583-8f3f08e53e1f	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 13:43:08.444705+00	2026-09-13 13:43:08.444705+00	{}	2026-09-13 13:42:38.444705+00	OPAQUE	REFRESH_TOKEN	ngQ5MMeNDv_TLBtSWeizP3UGelTl8wZWNmN2RkYjQtYmZmYS00OTVmLThmYzItZjZlMzQxNmRmM2Y0
b956e0e0-4f63-4da6-9556-83596f1c6200	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 13:43:08.628521+00	2026-09-13 13:43:08.628521+00	{}	2026-09-13 13:42:38.628521+00	OPAQUE	REFRESH_TOKEN	Q0hvvFn6aay7T5v0L1QCD0Q21d1uBQNGY3NWY5YzctYzZkMC00MWUwLWE0YmEtYzQyMDJhZmM3NGMw
c4fc3908-92ba-457f-ba38-09694a384024	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 13:43:08.808102+00	2026-09-13 13:43:08.808102+00	{}	2026-09-13 13:42:38.808102+00	OPAQUE	REFRESH_TOKEN	v7OIBMmTeAJ7nUqL3v_VPFkIRNsdWQYjQyMjkzYjUtZjY2My00NGE4LWFkMDAtNjg2YmQzM2MzYTY2
dccff7b6-1546-47dd-abdd-9a2d5e415f15	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 13:43:09.006965+00	2026-09-13 13:43:09.006965+00	{}	2026-09-13 13:42:39.006965+00	OPAQUE	REFRESH_TOKEN	eBSChvPo4Q3oi2j8mCihWy3GEn2zCwMTk3MWM5NmYtN2JkMC00YjJkLWFjMGUtZDViNjg3YTBiZGM2
2130676c-49d6-4ba0-acdb-6bc112846566	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 14:20:14.237728+00	2026-09-13 14:20:14.237728+00	{}	2026-09-13 14:19:44.237728+00	OPAQUE	REFRESH_TOKEN	tFv8msr8BhWVFjfupF-9hlZVidJVZQZmQ0MjM0NGEtOWRkOS00MjFkLWI4YmEtNzg3Y2Q4YmYwZWFh
b8a5a71d-8c34-47bd-b22b-2a0c010fb338	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 14:20:14.455466+00	2026-09-13 14:20:14.455466+00	{}	2026-09-13 14:19:44.455466+00	OPAQUE	REFRESH_TOKEN	hX4hSsrwPTkMv8eDJ3uH1ylIeQq_ewZGMwYmI0MDEtN2E1NS00YjkzLTk3MmEtZjE2YWVkNGI1ZDJl
2c5ae320-5ca0-4704-9d0b-3a56713c5c4d	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 14:20:14.64421+00	2026-09-13 14:20:14.64421+00	{}	2026-09-13 14:19:44.64421+00	OPAQUE	REFRESH_TOKEN	HPWrtZykpKICncFplD8tzeA8aUWl1gZGY1Y2Y0MmEtNWRmOS00MTFiLTk0MzItMDE0ZDMwYmJjOGIw
bd03c366-b62f-4c96-97ca-7bdac6575b2e	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 14:20:14.82269+00	2026-09-13 14:20:14.82269+00	{}	2026-09-13 14:19:44.82269+00	OPAQUE	REFRESH_TOKEN	LqX5fErnR7HI8KoTL_3OoVbI70JTvQYWE2NWFkNjctMWJlMS00ZjExLWFkYTItNDBjNWQ2YjIyNTVl
d4f27e94-0095-4387-bfe3-2b8f46fd3f68	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 14:20:15.012938+00	2026-09-13 14:20:15.012938+00	{}	2026-09-13 14:19:45.012938+00	OPAQUE	REFRESH_TOKEN	RGffn2rj6J_caX2DuVhBQ5-rrgUB5ANWEwZTVhZGQtZTcwYy00NGRjLWE0MGQtYTAyMjg2ODZlODlk
cd2078cc-c0bf-4f43-9628-88b0d9ff91ae	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 14:20:15.213789+00	2026-09-13 14:20:15.213789+00	{}	2026-09-13 14:19:45.213789+00	OPAQUE	REFRESH_TOKEN	Hn8M-Hgal20kFHPMLh59Ve2FRzE-yAMDc0YWU4M2ItNWE3Yy00ZmMxLWI0NWItZjE2ZDVmZDQ0YjZk
01de0799-768c-4698-a07e-a56a3fecd6ac	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 14:20:15.418014+00	2026-09-13 14:20:15.418014+00	{}	2026-09-13 14:19:45.418014+00	OPAQUE	REFRESH_TOKEN	4rKwNl0WCiwX9tYD3n_fp1kTI2QQYQNzJmZDIxN2EtNTkyMi00ZmZjLWJiNTItYTQ4YzViZTU4YTc4
5e5ccb2a-3843-4c3c-a6f6-0eb24468017a	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 14:20:15.611332+00	2026-09-13 14:20:15.611332+00	{}	2026-09-13 14:19:45.611332+00	OPAQUE	REFRESH_TOKEN	-wMy0ihoE3B7xmr1-DidsyxWLQuX_AMzFjNmFlZWUtMzgxMy00ZTFmLTk5MTItNGQ4ZjMyZWQwYjEz
a2c8c023-7f6a-47e1-b858-66bc073f3170	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 14:20:15.801982+00	2026-09-13 14:20:15.801982+00	{}	2026-09-13 14:19:45.801982+00	OPAQUE	REFRESH_TOKEN	62RyWicYE-Bz_AGX9jRYAjcYBNhzFwYjNiMDdlMDQtZDFkNS00MGNlLWFiYmUtNjg1ZDc0ZmFhZGJm
1e3718dd-c2fa-42be-a180-f92fe585784a	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 16:55:36.146947+00	2026-09-13 16:55:36.146947+00	{}	2026-09-13 16:55:06.146947+00	OPAQUE	REFRESH_TOKEN	A1Hujr6sRGGQM9sw4Z28n3lAUiH1ewN2I1NTcwMDktYmFlYS00ZWRlLWE3NmQtYjczY2JkYTM4NDE2
678bde4c-b18f-431d-984f-627a41b77b6d	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 16:55:36.588504+00	2026-09-13 16:55:36.588504+00	{}	2026-09-13 16:55:06.588504+00	OPAQUE	REFRESH_TOKEN	k5jmB1KwbSpFzEEbJmSxIa8yTwQWWwNjkzMGU0ZDgtNTI2My00N2JhLTg2NzAtMzQ2YjYwOWEwM2Y4
69506fc2-dee8-407a-a902-0ebd8dac9076	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 16:55:36.8513+00	2026-09-13 16:55:36.8513+00	{}	2026-09-13 16:55:06.8513+00	OPAQUE	REFRESH_TOKEN	5ZkHHN2pKJHKWPjLUyz6Ga9JnFBM1AZDM3YWQ3YzUtZjliNi00NDMxLTkyMWEtNTkxMzc2Y2IzNDE3
bfe586df-47d4-439b-a4a7-5f27ec3649ed	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 16:55:37.290278+00	2026-09-13 16:55:37.290278+00	{}	2026-09-13 16:55:07.290278+00	OPAQUE	REFRESH_TOKEN	0K2a5zG4xm8vm_DtGuDg2hCHEsXdgwYzAxYWViMDctYjVmNS00ZDVhLWE5NjEtODMwY2I3NmMxZDJm
2dd538cc-b07a-4bdb-bb3e-5c9e8fed2736	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 17:00:50.47795+00	2026-09-13 17:00:50.47795+00	{}	2026-09-13 17:00:20.47795+00	OPAQUE	REFRESH_TOKEN	8GLG-u1I5d1J2N7vJW2JjyvwQBEPkQMDY1NDc3MWItMGFhNC00MjdkLTkxNmItNmZiNTE0YWQzMTI4
86b8c40b-9e5a-4236-9851-ed23a29a5ab9	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 17:00:50.670052+00	2026-09-13 17:00:50.670052+00	{}	2026-09-13 17:00:20.670052+00	OPAQUE	REFRESH_TOKEN	HSfxvQ19p1moLRJvlIP5g6zh5BgCLQMzY3ODk5ZjAtZDAyOC00MTk4LTk5ZDYtODA2NjFjMWNkMmEx
0d85c214-aedb-4296-ab5f-fc29a3ce08f3	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 17:00:50.862585+00	2026-09-13 17:00:50.862585+00	{}	2026-09-13 17:00:20.862585+00	OPAQUE	REFRESH_TOKEN	XaqvIsRgE9JxHXAiQa3dtbyoEVEkFgZWZmZmIyMDktMzYzYi00Y2RkLTg1ZjUtMzdlMzJmNDE4OTA5
8fc92d03-bd5f-4d68-9b73-09bca2494cc0	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 17:00:51.083355+00	2026-09-13 17:00:51.083355+00	{}	2026-09-13 17:00:21.083355+00	OPAQUE	REFRESH_TOKEN	pFguDPjfeisiUScNmwBTPaydPtAgvQZjQzMGJhMzAtMmFhZC00YjM4LThhYzQtYmZmMThhOTcyYjE5
604fb720-75dd-4853-8ada-185b36732e27	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 17:00:51.263759+00	2026-09-13 17:00:51.263759+00	{}	2026-09-13 17:00:21.263759+00	OPAQUE	REFRESH_TOKEN	XID7ZHiAsx9ZMBsFYWgAtjPJ6zyVFAYWZlMGE5MzktMTg5Ny00ZTdkLWIyYzQtODE5MWRhNWRmOTcz
51d4d6e5-6005-4d58-be56-69d7165a338c	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 17:00:51.44226+00	2026-09-13 17:00:51.44226+00	{}	2026-09-13 17:00:21.44226+00	OPAQUE	REFRESH_TOKEN	Gxp0rXTXWzw73a5N5zIlBgfK7EFN2wZTc3MTE4NjYtZWZlOC00NzliLTkwMWUtMDQ1NTU0YTdlNThh
fe3553f1-574d-46a3-bb01-032243fc8b5c	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 17:00:51.630506+00	2026-09-13 17:00:51.630506+00	{}	2026-09-13 17:00:21.630506+00	OPAQUE	REFRESH_TOKEN	UJBlBNodLnkSND5Qn-66avAetvF5kQNzhlNTNkY2YtNGJmMi00MDIwLTk5ZTItM2U1MDJmMThkN2U1
ba01c98d-f349-4d3e-83a7-a1968a7c2fb5	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 17:01:13.33686+00	2026-09-13 17:01:13.33686+00	{}	2026-09-13 17:00:43.33686+00	OPAQUE	REFRESH_TOKEN	JFsWN0GXhxXBEhS7MrvzKvHzybGHZwMmZjNDBmMzgtZjY5My00NzFmLTlhZDMtMmNlNzlhN2NhYWJj
ddedb7b0-8adb-4028-b3d6-9260c3653a1a	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 17:02:47.687099+00	2026-09-13 17:02:47.687099+00	{}	2026-09-13 17:02:17.687099+00	OPAQUE	REFRESH_TOKEN	dtqwtdV8A4oDjrpi-IFBMmc5Pe_figMjE2ZGUyNWEtZTA2ZS00YjA1LWI4ZDYtNTBkZDYzNWUxMmY2
c1255291-c0ba-46e0-9b2b-9324b6dad6bb	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 17:11:09.369406+00	2026-09-13 17:11:09.369406+00	{}	2026-09-13 17:10:39.369406+00	OPAQUE	REFRESH_TOKEN	w2_YYRSMXFT2_XISyd6_j_8VTrqPswZWE0ZWQyYzAtZDIwMi00YWJjLTkxY2ItMTQ5NDEwNzRkYTFl
744d5bde-77c3-4491-bd62-e867da54e327	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 17:11:09.631817+00	2026-09-13 17:11:09.631817+00	{}	2026-09-13 17:10:39.631817+00	OPAQUE	REFRESH_TOKEN	zbaq0gwhq3iYCJQMGrJM32Oi4URTDAMjZjYWQ0OTctMGJkOS00MmQ4LTlkN2YtNWM4OTFiYmZmNmUx
fdeb1237-6990-4378-afd4-b769f405e3c2	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 17:11:48.038731+00	2026-09-13 17:11:48.038731+00	{}	2026-09-13 17:11:18.038731+00	OPAQUE	REFRESH_TOKEN	Mel0r9S8OebYt6E54acb6UnreztMOQNjRkMzhkMjgtZDYzNS00YmY3LThkN2MtMjNhMmFhZjczNTI0
bc01f838-fc15-4be8-a64e-d9e20799d4ca	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 17:27:41.017154+00	2026-09-13 17:27:41.017154+00	{}	2026-09-13 17:27:11.017154+00	OPAQUE	REFRESH_TOKEN	a7Cuk7xWDR2I2HkvaP61ai8MT-hJGwZTg5Nzg2OGEtYjhiNy00M2Y0LWEyMWQtYmZkMzJlZTBkYjkx
b9ce83a7-94c5-473b-a550-f987d5b4cd94	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 17:27:41.366605+00	2026-09-13 17:27:41.366605+00	{}	2026-09-13 17:27:11.366605+00	OPAQUE	REFRESH_TOKEN	wEA4j4LDNA3PChZfFtbRedslQrmLQAZDhlNTg3OTgtOWU2OS00ZWMwLWI1OTMtMDRiNDM3ZmIxNjBh
a89e1843-843b-4799-8bfb-93fe4d0b7311	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 17:27:41.488784+00	2026-09-13 17:27:41.488784+00	{}	2026-09-13 17:27:11.488784+00	OPAQUE	REFRESH_TOKEN	6L-y5vvpgBF6ej1Ka8q5UVaDRTJHkgZDU5MmEzNDEtNGI4Mi00YWQ3LWE3M2ItNTlkZjdhOTJiZGE0
25d959e5-c4aa-4859-b1cc-d199ccf430c0	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 17:27:41.547866+00	2026-09-13 17:27:41.547866+00	{}	2026-09-13 17:27:11.547866+00	OPAQUE	REFRESH_TOKEN	xmq283YcqkZP-YwKOz-yR8G_7L-C6AMGFmOTAyYjMtYTdlZC00ZTAzLTgwMWEtYjVmODU2NDVhYmI3
1d4f27b2-bdc2-4c6a-89f5-354ea16c2956	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 17:27:41.726983+00	2026-09-13 17:27:41.726983+00	{}	2026-09-13 17:27:11.726983+00	OPAQUE	REFRESH_TOKEN	LCrW5ZfcxE-ue6N5GWN-3K-5EfJaIwNDA4ZTRhMGItMGMwNC00MGZiLWFiMTQtZTY2MDFmMTVlOGRh
05fb9cd6-1d57-4a19-bd59-7d6a86d40ec1	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 17:32:44.441665+00	2026-09-13 17:32:44.441665+00	{}	2026-09-13 17:32:14.441665+00	OPAQUE	REFRESH_TOKEN	tPqfAeycwFkJYN2Wh0TTAXAhgyoQ1gNmM3ZGUwNjItYTJiOC00NTJlLWI3OWUtMzE2NTVjNTE4OTMy
65229c5f-747f-457c-8df8-c8e7020f7043	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 17:32:45.134352+00	2026-09-13 17:32:45.134352+00	{}	2026-09-13 17:32:15.134352+00	OPAQUE	REFRESH_TOKEN	nuuBe8E6QXtMybii-C1ffN0S_5DHCwZDc1OWNkMDktYzQ0NC00ZmU1LTg2MTctYWM0N2U1ZWQ4NWIw
929e9030-78e4-4794-a35d-0f01354a3b64	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 17:32:45.137111+00	2026-09-13 17:32:45.137111+00	{}	2026-09-13 17:32:15.137111+00	OPAQUE	REFRESH_TOKEN	BREAiEA5dqliLVRZsA6jA3TaitbkeAYjE2ZWE1ZTAtNDg4MC00MGYzLWIxNTItYTMzOTQ1MzhhZGY0
c7a7f880-94b7-40f7-a81a-f98cb0d3ddb1	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 17:32:45.561893+00	2026-09-13 17:32:45.561893+00	{}	2026-09-13 17:32:15.561893+00	OPAQUE	REFRESH_TOKEN	6b50Q4Sq1bf6WXA1i7h_ZYmPt8SB0QZTAwNjM3MGYtZGYyZi00ZDhkLWI3YTctZDBkZjgzZTg3Y2U2
b82c2556-1246-4a06-9a7d-9d0619189d62	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 17:32:45.903565+00	2026-09-13 17:32:45.903565+00	{}	2026-09-13 17:32:15.903565+00	OPAQUE	REFRESH_TOKEN	dF0mGSKRygDUpqBsaPNXPPT94Igx6gMGRiNWY2YTAtYWUzZS00YmUxLWEzYmYtNzJjNWEyZmI1OWYz
2158ea23-2077-4a90-858f-c3f269f02937	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 17:41:38.122192+00	2026-09-13 17:41:38.122192+00	{}	2026-09-13 17:41:08.122192+00	OPAQUE	REFRESH_TOKEN	JMHWZFJFoVCFeqFMPPyVFxYfqyQirAMmViYTQwYzQtZDY4Ni00MmZmLWFlOGItMWM2ODYxOGM3Mjc3
c585c229-090b-49d3-a4d7-a6112d0f1d77	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 17:41:42.388326+00	2026-09-13 17:41:42.388326+00	{}	2026-09-13 17:41:12.388326+00	OPAQUE	REFRESH_TOKEN	Qtg-jmtGdzdHXJiI4Jqw3EEHX0B2bwZmUwNDZlYjYtOTdiYy00ZTc3LTk3YmQtMWJkNGY4ODJlNGUw
e0e5fd30-01fa-44f0-8615-a6303529b216	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 17:48:28.842919+00	2026-09-13 17:48:28.842919+00	{}	2026-09-13 17:47:58.842919+00	OPAQUE	REFRESH_TOKEN	qOjGYPhUKRD5y0bqhr5FLEf5-6XkXwNWJhMGRiNjItMWZiYi00ZmJiLThmYWMtNGE5OTAxZGFjMDBi
99a0a3bb-73f4-4335-8b0a-51ebfab51554	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 17:48:34.853675+00	2026-09-13 17:48:34.853675+00	{}	2026-09-13 17:48:04.853675+00	OPAQUE	REFRESH_TOKEN	3Cr3G_03-iKk6n1TH7Mc2i-fhwpFMQZDMwZDMyOGQtOWYzOS00MmVlLTk2MzctNTk3M2M2ZDVkZGU1
9482b49b-bf6b-459d-9d96-e344392e54fb	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 18:04:14.822122+00	2026-09-13 18:04:14.822122+00	{}	2026-09-13 18:03:44.822122+00	OPAQUE	REFRESH_TOKEN	5q3ryuuG5shj7-E89o8FDjZKr5YwiwNTRjZGRiYmQtMjQ5Zi00N2FhLWI4YWItNDkzYzA4MGNmOWE4
909e091d-e147-4ae4-b08e-cfc45c9ba878	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 18:12:40.146607+00	2026-09-13 18:12:40.146607+00	{}	2026-09-13 18:12:10.146607+00	OPAQUE	REFRESH_TOKEN	yraHsQPjOoG9K2wFhc2zU5OZ06Vp3gOWNlN2NlMWMtNTQyMi00MTJhLWI2NzctNGIyMGRjNzgxM2Nl
09606372-0346-4b91-a1bd-6af610a8e9d6	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 18:20:20.251444+00	2026-09-13 18:20:20.251444+00	{}	2026-09-13 18:19:50.251444+00	OPAQUE	REFRESH_TOKEN	WssZs57kHTWCODg1uelJfZZ06zuBlQZmMzNjUwOWYtYzFjZS00MjBhLWFjN2UtYTAyMTQ0ZWIwYjhk
06459e5a-ab13-4e54-9727-a7beb0c9c59e	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 18:20:20.443707+00	2026-09-13 18:20:20.443707+00	{}	2026-09-13 18:19:50.443707+00	OPAQUE	REFRESH_TOKEN	PfGPvba9p3dTkzjtZuwB_DYSVFBPdANzhjMjkzOTUtYWE3NS00YTU4LThhYmMtOTgzMDg5NjE0NWQz
731ebfbf-294a-42aa-85b7-62d4d0313b62	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 18:22:59.989098+00	2026-09-13 18:22:59.989098+00	{}	2026-09-13 18:22:29.989098+00	OPAQUE	REFRESH_TOKEN	Z8RA2UtdAMdl8mI5F0uUbAN83SodowMGY4NDZiNTctM2UxMy00MTQwLTkzODQtMDZjNzUzNTUwYjVm
6425254c-663f-45a3-ab92-c53dffb79833	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 18:39:29.413759+00	2026-09-13 18:39:29.413759+00	{}	2026-09-13 18:38:59.413759+00	OPAQUE	REFRESH_TOKEN	PpHfqzjEJZ9GkupHlluWale0MUGhBwMzViYTQ2MzMtYjc5Yy00NjdjLTgzMTItZDk4NzBhYjgzNzU3
c38e44b2-25b0-4446-b074-a13aace78e36	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 18:58:11.318663+00	2026-09-13 18:58:11.318663+00	{}	2026-09-13 18:57:41.318663+00	OPAQUE	REFRESH_TOKEN	591pdyrWobsFTysb3wtcnOY_ZCUeHANTg3NmM0M2EtNzcwYy00NDkwLWIwODktM2I2ZWI4OTY4NTQ4
1fcad994-a9dc-4254-a940-426d4579e5c5	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-13 20:25:47.889906+00	2026-09-13 20:25:47.889906+00	{}	2026-09-13 20:25:17.889906+00	OPAQUE	REFRESH_TOKEN	G_1Fvj3Np7oxF_o72RWMN-6eF72YQAMzE5Mjg5M2MtYWJlYS00NWFlLTkzMDEtYmZhM2FlYjY3YmY0
ea98bbde-b0ad-4da0-ad75-fb065057b239	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-13 20:25:51.62028+00	2026-09-13 20:25:51.62028+00	{}	2026-09-13 20:25:21.62028+00	OPAQUE	REFRESH_TOKEN	gG6k4fY3BEnqnOfdm-0A187Zw8ZCUgMDNhYjM3ZDEtOTk2NS00OGUyLThiMTctNDQ5MmU3ZGEwNjQz
9462cba6-c0a4-4de8-ab4d-60deffe5a2dd	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 22:10:42.759465+00	2026-09-13 22:10:42.759465+00	{}	2026-09-13 22:10:12.759465+00	OPAQUE	REFRESH_TOKEN	3zT8XNKmGEiocxLg_45-IGCuQ-aWzQMTUwODk0NzMtY2NkZi00OTc0LTkyMTQtMTNiOTRlNDY0OWU4
63205d1b-daba-4fc3-aad1-f88f502aa7de	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 22:16:58.456674+00	2026-09-13 22:16:58.456674+00	{}	2026-09-13 22:16:28.456674+00	OPAQUE	REFRESH_TOKEN	RXLhhSWmckLtTO041BBBFL4YpEglAgNjBmN2RjZDItN2QyYi00MGIwLTkyODUtYTQ5MmUxNmZjZTM0
e05caa1e-2f45-4655-b6c8-dab2552e2661	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 22:16:58.637223+00	2026-09-13 22:16:58.637223+00	{}	2026-09-13 22:16:28.637223+00	OPAQUE	REFRESH_TOKEN	wlbiEhPZPlYH873nQqpbNQbX8NtO4QYTk5MmVhOTMtZGExZS00ZmNjLTgyZjMtODVkMTAwYjA3Y2Y3
9a481a4d-b027-4841-8585-1391f5c7864d	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 22:16:58.813905+00	2026-09-13 22:16:58.813905+00	{}	2026-09-13 22:16:28.813905+00	OPAQUE	REFRESH_TOKEN	vZikP7WmA1eg1fJT7fygiSLyHO4UrQYWM5YzU2MDQtYTEzNC00MDJlLTlkOTUtZmNmZGI3NDQ0Zjk3
7f3f7a5a-ea26-40fb-9068-f0b3f47829c9	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 22:23:10.878834+00	2026-09-13 22:23:10.878834+00	{}	2026-09-13 22:22:40.878834+00	OPAQUE	REFRESH_TOKEN	aCGkCGktNXtxZDUDgLTr6m_47CzoLwNTY5MTAyMjctOWZjNi00YjNjLTlmOTctNDI1MWU3ZGI4MzAy
efea88bb-cce8-48a3-af77-9ec12c262cc9	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 22:23:11.079897+00	2026-09-13 22:23:11.079897+00	{}	2026-09-13 22:22:41.079897+00	OPAQUE	REFRESH_TOKEN	rEGOeR2YCBHBF-pePRu6sWxf4IBeRgNjE4MTI5YjktM2MzYS00ZDI0LWE4ZjktOTYxNmIxMmI0MGY0
7819a4ad-3a18-4abb-a835-288c2c1a7bde	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 22:23:11.263505+00	2026-09-13 22:23:11.263505+00	{}	2026-09-13 22:22:41.263505+00	OPAQUE	REFRESH_TOKEN	FImHVJf3AMpAHhySucnx4_Zvd5L9rwYWE3NTI5YmItYTEyMC00NGZmLTgxYTctYjEzZmQ4OTgwNTk5
65627ac2-e9af-4e3f-9ab5-07f80ab799a7	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 22:34:17.312003+00	2026-09-13 22:34:17.312003+00	{}	2026-09-13 22:33:47.312003+00	OPAQUE	REFRESH_TOKEN	EVl53NaT7EwIBHJH1U9rqa0vl86lngOWQ2MjJlYmUtNjljZi00ZTlmLWJkOGQtOTgyZGM4OGY2YmI0
55fb8fe9-ea24-478e-ad5a-037b43676b13	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 22:34:21.96635+00	2026-09-13 22:34:21.96635+00	{}	2026-09-13 22:33:51.96635+00	OPAQUE	REFRESH_TOKEN	zpDFqYJMIelKq-1DGGL2fTbdnXw6CANDc0MWVkYzYtMjBmNy00OTljLThjZjMtOTEwYzcwODhjZjgz
0eccdf54-74ee-42b0-bc90-c02e55517297	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 22:42:41.16755+00	2026-09-13 22:42:41.16755+00	{}	2026-09-13 22:42:11.16755+00	OPAQUE	REFRESH_TOKEN	9fGL5VLR_RAMNaoOxCCFUecvu0W91QZGU0M2E5NWItNjNhMi00MzcwLThiMWItNmNhMzZlNjJlODhh
6a6eef41-476d-4b7f-b88c-1b9649047d86	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 22:42:41.379087+00	2026-09-13 22:42:41.379087+00	{}	2026-09-13 22:42:11.379087+00	OPAQUE	REFRESH_TOKEN	TLgVFHD8T2q6idgbIdMTLCR-24AECQMmQ0ZDA2NmEtNDQ5Ny00MWUxLWE4MGYtZWVmY2IwZWUxNjlm
66f3c4f5-9338-4210-8176-06c94548a792	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 22:42:41.560678+00	2026-09-13 22:42:41.560678+00	{}	2026-09-13 22:42:11.560678+00	OPAQUE	REFRESH_TOKEN	bJYu4uo5iIOLdfIodiU16Y5LrrAWDQYzlmMTBhMDItNTZhMi00YjdmLWFhNmMtMmU3ODY2ZDM4ZWQz
86f986aa-762d-49a6-b702-36180a2bd95e	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 22:42:41.738242+00	2026-09-13 22:42:41.738242+00	{}	2026-09-13 22:42:11.738242+00	OPAQUE	REFRESH_TOKEN	-l3Y0nlpZg5WUL8wBzPHZCoG7MwCngYjkzZWY0NTktODg5MS00ZDdhLWFmMzQtYTBkNmZiODRlMTc4
71836550-ab55-4967-8290-9e163f1d1601	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 22:42:51.778746+00	2026-09-13 22:42:51.778746+00	{}	2026-09-13 22:42:21.778746+00	OPAQUE	REFRESH_TOKEN	_uCyJLw2VRVzxJI9f6K0llIpe_uYRQN2M4YjQ2NGEtNjA2Ni00ZWIyLWE5NmItNTEzZDhkM2E0MTI1
680f7d0f-1000-4212-a9d4-20e8101066d0	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 22:52:15.540733+00	2026-09-13 22:52:15.540733+00	{}	2026-09-13 22:51:45.540733+00	OPAQUE	REFRESH_TOKEN	gms9VCQn3F3SL1efPQsxlytIR7nnDgNjYxZDgwNTAtOTRlZS00MDljLWFhZWYtMzZkZDZiYzFlYjgx
73e6159a-a3e3-4b90-bc66-3c78405fabf8	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 22:52:15.748337+00	2026-09-13 22:52:15.748337+00	{}	2026-09-13 22:51:45.748337+00	OPAQUE	REFRESH_TOKEN	c23XCIeMQcnpkO88hVuIWq6a3F0AywYmFiZjVjZWUtZWQ4Mi00ZjYyLThjNDItN2ZkYmZiZmMxNzc1
9847805b-5b19-4931-9a6e-7e93fa6e9f07	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 22:52:15.929845+00	2026-09-13 22:52:15.929845+00	{}	2026-09-13 22:51:45.929845+00	OPAQUE	REFRESH_TOKEN	YpCoL0W_YA0eweMta1on5O8jv8o7mgYzYzM2ZlY2QtYWEyYS00NjVmLTg5MjgtYmU1YTQ3ZjE3MmY3
87f154b7-a7e9-483d-ad80-3b3e4fd3a8dc	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 22:52:16.12031+00	2026-09-13 22:52:16.12031+00	{}	2026-09-13 22:51:46.12031+00	OPAQUE	REFRESH_TOKEN	DTV5NR7O2ihAXJdTjGGkx-GfI5EjxAOTBjN2NiODEtMDZjYi00YWVjLWJiYzEtYjkyYjQ5MGY0YTcz
146ab379-42cc-4516-a6b3-3534d6cc8862	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 22:52:31.676124+00	2026-09-13 22:52:31.676124+00	{}	2026-09-13 22:52:01.676124+00	OPAQUE	REFRESH_TOKEN	1mIclbUqGFrvb8WbQO5-SpQQsPElTgZGRhY2UwODUtYzkxOS00M2M1LTllYTEtNDAwNjIwNDAyOGVi
848ded5a-8e95-4afa-812c-7faec00ef809	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 22:52:37.980446+00	2026-09-13 22:52:37.980446+00	{}	2026-09-13 22:52:07.980446+00	OPAQUE	REFRESH_TOKEN	wFCNXdYsE53l9S8YA4Gu_LZ9BQIYsANTY4OGUzZDMtYmE1OC00MDFhLTg1YTUtZTc1ZjMwMTZkYWRj
debaf345-c370-4e15-bdc1-a706d2aae094	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 22:53:01.914605+00	2026-09-13 22:53:01.914605+00	{}	2026-09-13 22:52:31.914605+00	OPAQUE	REFRESH_TOKEN	dpCTfP70-zvx20LwnuXum74fyQNdCQNTQyNmI4YzItZjIyZC00OWE4LTg1OGUtZGFkNGQ1NjAxYWEy
4f2e2084-1dc7-4eea-8b07-440923244022	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 22:53:53.770745+00	2026-09-13 22:53:53.770745+00	{}	2026-09-13 22:53:23.770745+00	OPAQUE	REFRESH_TOKEN	JxgGSlkJ8gSd-qRXMuh1RF0rcP2sQANDhjZjIwOTktZGUzMi00MGJiLTliNzEtYTE0NGUyMjYxMjYx
dc61cd68-2c9a-45a6-8b07-2b69b3f501f1	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 23:19:02.20832+00	2026-09-13 23:19:02.20832+00	{}	2026-09-13 23:18:32.20832+00	OPAQUE	REFRESH_TOKEN	48OWmi8A17vTQYV352CIHoszm6riqQODUzMThjYzEtNTI0NC00NmI4LWExZmMtMmY1YTYyMmRhZDJj
74bdd3c2-ee92-47c1-84c7-6179a435654d	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 23:19:02.404124+00	2026-09-13 23:19:02.404124+00	{}	2026-09-13 23:18:32.404124+00	OPAQUE	REFRESH_TOKEN	PosdpNgV2IOoyzWD4CKDuAfu3phhKwODQzNmM0ZmUtODQ3Mi00NDZmLWExOWItYzRiN2Q0YjU1NzFk
ecb4ed7a-f0f1-4385-8f3a-d39ee5b264f3	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 23:19:02.588549+00	2026-09-13 23:19:02.588549+00	{}	2026-09-13 23:18:32.588549+00	OPAQUE	REFRESH_TOKEN	dX9IiNvl7TEOnZpik9295UyZZjq2jgMmRiM2U0NTYtOWEwNS00YTE5LTgyZWItZTI2MTBjYjQ1ZGZj
1432a3f9-e55a-4fb5-990b-aa7412a3a82f	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 23:19:02.76633+00	2026-09-13 23:19:02.76633+00	{}	2026-09-13 23:18:32.76633+00	OPAQUE	REFRESH_TOKEN	UxEet9_7TQx353dlSI71kieUHj741AMTdhOGQxZjgtYjA5OC00MzdkLWJkZTctODdjYTY2ZmFhZGVl
61085d4f-a454-4c98-a5ea-9a73053b0712	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 23:19:02.950013+00	2026-09-13 23:19:02.950013+00	{}	2026-09-13 23:18:32.950013+00	OPAQUE	REFRESH_TOKEN	qMztXUVA6yhORgzaN0ksp-Ok79xerANDMzZTdhMGQtODFlMC00ZjJlLWIxODMtOTdjMTEyYWNkNTky
971e2c73-27ec-443c-ad53-a874784bea4e	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 23:19:03.131659+00	2026-09-13 23:19:03.131659+00	{}	2026-09-13 23:18:33.131659+00	OPAQUE	REFRESH_TOKEN	_n6kOv3Vs5yqixHUCZdAAxy2TKeJ1wYzJlZDM1NTktZjczOC00Njk4LTk1ZDMtZWY3NGEwNDU1MWRm
915ec837-72a9-4c23-9147-fc965c1215a5	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 23:42:20.549229+00	2026-09-13 23:42:20.549229+00	{}	2026-09-13 23:41:50.549229+00	OPAQUE	REFRESH_TOKEN	_vV-rZAP8FzmYfsTolSu0YUsOBCL0gMDEyYjU0OTgtZWJiOS00M2NmLThkMjAtMWE4OTYxZDBmNjUz
68bfccd3-14e6-4386-ac82-1e0713167cd4	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 23:42:20.738718+00	2026-09-13 23:42:20.738718+00	{}	2026-09-13 23:41:50.738718+00	OPAQUE	REFRESH_TOKEN	gF71nXnnWqNQM12tXPRNq7KSW9TDtgN2RjNWU2OGMtNGZhNC00MDkzLTg1M2MtMjU4NmRkYzk2YTNk
73fcf6eb-45cd-47f9-8b23-9f98d55e1f79	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 23:42:20.92091+00	2026-09-13 23:42:20.92091+00	{}	2026-09-13 23:41:50.92091+00	OPAQUE	REFRESH_TOKEN	A_fl45lA43VGYzW-cBUc2_CBBr7_BQNTIzYzM5NWEtMmZkNy00N2ZkLWIwMDQtODJiNWNhOGRjMzI4
ccb3d986-83af-4d47-a87b-3a906b5d4863	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 23:42:21.098591+00	2026-09-13 23:42:21.098591+00	{}	2026-09-13 23:41:51.098591+00	OPAQUE	REFRESH_TOKEN	B7WNSyyHyqVryfq_eKB4DSA1pRuIZwZDgyYTQxZTAtYzYzNy00NDA0LWI1MTItNTc4Y2ZkM2QwMTI0
73441038-7bac-4d9f-830f-af102e184ed8	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 23:42:21.280407+00	2026-09-13 23:42:21.280407+00	{}	2026-09-13 23:41:51.280407+00	OPAQUE	REFRESH_TOKEN	IuTy6YJ3FEeGKoiWm3JJ5VCpdO3lLgNTc4MjI3MzEtYjhjNS00Njg3LTk3NTQtYmMyNGU2ZGVmYTFi
76310d2a-4d10-4df5-b6ee-77bc9be3ad12	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-13 23:42:21.455091+00	2026-09-13 23:42:21.455091+00	{}	2026-09-13 23:41:51.455091+00	OPAQUE	REFRESH_TOKEN	D3fEMGvXH08Fja63v7i94konMjJAFAY2NmZWJiODYtYjgwMy00YTgzLWJkN2ItYWYxMGNhZjY0MTQ5
43319a65-3e81-4b1f-abbe-5f5f67dbe5d1	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 08:00:01.96129+00	2026-09-14 08:00:01.96129+00	{}	2026-09-14 07:59:31.96129+00	OPAQUE	REFRESH_TOKEN	Ed3GsSOVPNNsOCX3KE6hA21_K4aMdQOTdlNjFmYzEtMTc2MS00NTk3LTgyNjktZmJmNTk0MjM1MzRj
ccb6980e-1a2a-4a8d-83f2-f5a9e567b777	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 08:00:02.193006+00	2026-09-14 08:00:02.193006+00	{}	2026-09-14 07:59:32.193006+00	OPAQUE	REFRESH_TOKEN	kWJ6xea-c5590MSbYhfUopcD0YUMHgMGNhYzU4ZjUtOWNkZi00MTZjLWFjMWUtNTQzYTkwMjFiYTUw
baa9a214-26cf-4c59-ae3c-12ce51e5b826	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 08:00:02.684261+00	2026-09-14 08:00:02.684261+00	{}	2026-09-14 07:59:32.684261+00	OPAQUE	REFRESH_TOKEN	c9mgKfZTYmlcBbqsNJgr7WsePPov6wZWMxN2VlOWYtNTViNy00NjQ4LWJhZjUtMGRiYjQyNDI2ZTg5
180ff6f4-363e-4ce1-b5bb-14fb13600d1c	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 08:34:09.978204+00	2026-09-14 08:34:09.978204+00	{}	2026-09-14 08:33:39.978204+00	OPAQUE	REFRESH_TOKEN	mChgvfPyOQz3__wBVetKNgeqd25rNwOTZkNmFjNDYtYmZmNi00MThhLTk3NGMtYTBjOGI1ZWFlOTgy
33845217-ee4d-4670-bffc-a9883e85e720	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 08:34:10.313026+00	2026-09-14 08:34:10.313026+00	{}	2026-09-14 08:33:40.313026+00	OPAQUE	REFRESH_TOKEN	QcPsBl30mi4vtdKQjlqrjXs7qgqDogNmFiNzg4YzctZDM5NC00ZjM2LTk4Y2ItODgzMzQ3ZTM4M2Iw
e2c8e077-f22f-4571-baba-cddd785221fa	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 08:34:10.844027+00	2026-09-14 08:34:10.844027+00	{}	2026-09-14 08:33:40.844027+00	OPAQUE	REFRESH_TOKEN	K7g6229XOxmzQ2oIVyfBv5aCHg-UggYjJkN2Y4MzEtYjU2Yi00OWUyLWFjNTEtN2YyOGY3MGZiZGYz
fae25c84-db3c-4aca-a38e-092757cb6323	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 09:18:16.526571+00	2026-09-14 09:18:16.526571+00	{}	2026-09-14 09:17:46.526571+00	OPAQUE	REFRESH_TOKEN	nI2g_7Lym78G9UuALxURPlhQH6Z9jQMWEyOWQ4MTAtOGQ2Zi00YTc4LTlmMWEtYzU0ZmYwZThmNDhj
d0f5b53d-ad0f-400c-bcae-c4ffb182116c	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 09:18:16.795684+00	2026-09-14 09:18:16.795684+00	{}	2026-09-14 09:17:46.795684+00	OPAQUE	REFRESH_TOKEN	w-XJUmgtH-WtxJTvNChH7_nW4YSBXgMGFjNmM4MTMtMWQ1OS00ODRiLWJjZGEtYjU5Y2VmM2E2MTEw
2ca06bae-d9a5-45a8-97a3-ed8560e92a87	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 09:18:17.551528+00	2026-09-14 09:18:17.551528+00	{}	2026-09-14 09:17:47.551528+00	OPAQUE	REFRESH_TOKEN	qQ1CayJZtuCL9hefhwjSbZG1_ZxLFAMjY2ZGQ4NWQtZWU4My00MmYyLWFkZWEtYjU5NTY5ZjcyZmNj
68310f4d-7049-4fca-8359-157fbb7f2a35	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 09:18:26.63921+00	2026-09-14 09:18:26.63921+00	{}	2026-09-14 09:17:56.63921+00	OPAQUE	REFRESH_TOKEN	MGKuSgCByxlk0ApnuyAzx0NCO31HWAYzViNDQxMzgtYmE1Ny00M2Y4LWI3NjctZDgyZTRmZWQ2NTA5
6b8cf9f7-1732-4ccb-bcec-6a274401a294	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 09:34:18.076065+00	2026-09-14 09:34:18.076065+00	{}	2026-09-14 09:33:48.076065+00	OPAQUE	REFRESH_TOKEN	DXuGpeyqTnEgH9nL_I0sNclwTfsaRwNDJmYzE2YzMtNjhjNi00MjZlLWE1OGQtMGIzMzY1NWI1MTQ3
ff6a4fa5-3e9d-47f4-ab15-673c6ffcd1c7	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 09:34:18.876678+00	2026-09-14 09:34:18.876678+00	{}	2026-09-14 09:33:48.876678+00	OPAQUE	REFRESH_TOKEN	IPoDCvGgEiZ09MblePeqIn0PzLhuGwOGRmYjBhOGYtOTlkMC00NjIwLWI4NWItMGZiNmNiMjA3MjUz
c09d8c26-2710-436f-8716-c691d76e836c	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 09:36:54.458937+00	2026-09-14 09:36:54.458937+00	{}	2026-09-14 09:36:24.458937+00	OPAQUE	REFRESH_TOKEN	WMq_aeVEyuv4kwfbIooQiTMKQympRgODRkMGU0MmMtN2EwMy00NmZhLTg0NTAtNjk2NDMxYTMwNzRl
d3964229-9946-4621-9820-95114ca18051	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 09:43:03.791743+00	2026-09-14 09:43:03.791743+00	{}	2026-09-14 09:42:33.791743+00	OPAQUE	REFRESH_TOKEN	Usx59vDVbB_2rCYbpqhqQgsNkuTTCQMDhjYTYzNDYtNGMyZC00NzU0LWFhNjItZTVkYzcxOGQ4Y2Yx
e8ebcd63-313f-487f-a764-c5f74fa21e1a	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 09:48:48.727702+00	2026-09-14 09:48:48.727702+00	{}	2026-09-14 09:48:18.727702+00	OPAQUE	REFRESH_TOKEN	dxr1Aao9d2aORdzo0UBrBfVaqd7EAgNDk5NjY2NWEtNDhiMi00NGI5LTkxY2ItNzM4OTg4ZTRiOTcz
0c8a7e9a-cd35-4c5a-b041-1c43aa56af47	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 09:48:48.918558+00	2026-09-14 09:48:48.918558+00	{}	2026-09-14 09:48:18.918558+00	OPAQUE	REFRESH_TOKEN	nj2_L8oyLR3ooexFUTVE_BjlEpFc7gOWIwM2I3ZGYtODRkZS00MjBlLWE2MjktZmYwMDZkYTg5MmJm
545dcce0-e072-4244-9e2f-550e93290fe1	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 09:48:49.102671+00	2026-09-14 09:48:49.102671+00	{}	2026-09-14 09:48:19.102671+00	OPAQUE	REFRESH_TOKEN	PLiEH1vjHSCBL58hElG3GRqo_mIA9wNDhlZjRhYjMtZDMzMy00MDk4LTg4NWYtNmJkMTgxNzQ2MTkw
6762c2d5-c478-49c8-9847-38fe0f7bf427	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 09:48:49.300862+00	2026-09-14 09:48:49.300862+00	{}	2026-09-14 09:48:19.300862+00	OPAQUE	REFRESH_TOKEN	-MgKu274LBmHFoltLURIllIfNpyd7gODRkYjcyYjEtNjJiMy00NDhkLTlhOWMtNTVkZmNhM2FkNGNh
bfd937e9-373f-40db-90b3-883ba0ad666b	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 09:48:49.502698+00	2026-09-14 09:48:49.502698+00	{}	2026-09-14 09:48:19.502698+00	OPAQUE	REFRESH_TOKEN	BBanxUYq543Ob4_P1N5ABkounMzVyQNjU5YzUzOTAtZmYxYy00ZjI3LTgxMzMtMmRlN2RhZmIxZDc1
e1ef8c48-3bfe-408a-b340-d6fce065a34c	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 09:48:49.682443+00	2026-09-14 09:48:49.682443+00	{}	2026-09-14 09:48:19.682443+00	OPAQUE	REFRESH_TOKEN	8hLudbPl2A5U92l6McHJuAQX3taVDgMGM2ZGY2MzItYmE5ZC00NjcxLTlkMTMtZTQzZGEwYWU5YzVi
5d4df5bf-322c-4be9-bf6e-983db4b9545e	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 09:57:53.827874+00	2026-09-14 09:57:53.827874+00	{}	2026-09-14 09:57:23.827874+00	OPAQUE	REFRESH_TOKEN	uLX6GWOcT6uWaIBkyNUKGLBUz4AtqwOGI3OTU0ODItNzYzOS00NDc5LWI1NDUtMTQ3ODMzMzdjOWY0
66d2ac3a-2db7-4d8c-83e2-698055ed0133	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 10:03:32.816889+00	2026-09-14 10:03:32.816889+00	{}	2026-09-14 10:03:02.816889+00	OPAQUE	REFRESH_TOKEN	XRn1bttze4Bjbrb9an_QUZpS5ncuRgZDEyMzgxODItNTcwZi00ODEwLWE2MWYtOGNhYTRmMjJiMGM2
626ed483-4b21-4b2d-9fc1-c5dc1316cfc9	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 10:06:24.919483+00	2026-09-14 10:06:24.919483+00	{}	2026-09-14 10:05:54.919483+00	OPAQUE	REFRESH_TOKEN	DX0urvnWP9B9ltII8DuK5_-2m8AgZQYTNlN2VhYWItOTA2Yi00ODFmLWJmOTktOTJkZGJjYjA4ZDRi
4bf1da0f-df57-4181-b7f3-f9b3db3e109b	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 10:12:35.483014+00	2026-09-14 10:12:35.483014+00	{}	2026-09-14 10:12:05.483014+00	OPAQUE	REFRESH_TOKEN	KTVlCMsNRaOmJ4AQOQ9FDhCCZX1TAQM2Q3ZTBkY2MtZTA1ZC00ZGFmLWFlMmQtMWExNGQ3ZmY5YzE2
dae30647-a875-4506-bf12-b0d7be0c55c9	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 10:12:36.085365+00	2026-09-14 10:12:36.085365+00	{}	2026-09-14 10:12:06.085365+00	OPAQUE	REFRESH_TOKEN	KdIuuvjQWkD9Upl3mF_w_vBr0ubi5gODkyZmFkYTItOWI0OC00OWIzLTk3YWUtYTAxODM4NzRjZGY2
4786829e-e046-4489-b76c-bad3511e6401	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 10:21:01.56421+00	2026-09-14 10:21:01.56421+00	{}	2026-09-14 10:20:31.56421+00	OPAQUE	REFRESH_TOKEN	CP9n0Tj2YtdFedQp3P1UlFPZJj8NBwMDU1ZmNkZmMtMTA0My00OGE4LWJkYzMtMTlkNDhiZmJmODky
56de6da5-92a4-4468-b44e-d13774fc4312	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 10:21:01.814583+00	2026-09-14 10:21:01.814583+00	{}	2026-09-14 10:20:31.814583+00	OPAQUE	REFRESH_TOKEN	ivSo5JOXvJz8AJm9QbtojwHbgxWMCQYTc4OTQ4ZWMtYmM1My00ZDQyLTk2NTctYWM1NjZiYTU3NGFl
c5d01a4d-c043-4f75-bb19-40d4920f1fdb	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 10:21:02.047806+00	2026-09-14 10:21:02.047806+00	{}	2026-09-14 10:20:32.047806+00	OPAQUE	REFRESH_TOKEN	XzVC79h7h7y2BR7T92JtxDQxP7KaVAZTk2ZjdkZDYtOGMwZC00ZDlhLTkyOWEtZWQyYTE0MWNjY2Rj
8648a196-524d-4707-831f-4e8e381b4779	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 10:21:02.28646+00	2026-09-14 10:21:02.28646+00	{}	2026-09-14 10:20:32.28646+00	OPAQUE	REFRESH_TOKEN	9neSNNDX6rUlggGXirHAK_sOLfVWwgZGNhMDA2NWYtNTgxYi00NjA0LTg1ZDctY2FkMTQ3YjUwMmFk
4934415f-afff-4883-b6f3-9b6401202c86	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 10:21:02.519741+00	2026-09-14 10:21:02.519741+00	{}	2026-09-14 10:20:32.519741+00	OPAQUE	REFRESH_TOKEN	Dc1eCEcSLInJ0VN3UKt8V-coEh5OBQNGVhODZlZjItNGNkZS00MGNhLTlmYjItM2Q1NThlYTRmOTNk
ffc5532a-cbb9-4fa9-8381-0ee83fdc9a6c	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 10:21:10.857162+00	2026-09-14 10:21:10.857162+00	{}	2026-09-14 10:20:40.857162+00	OPAQUE	REFRESH_TOKEN	Lkme6fQWYaAicw_agTBIiMKv7HiZLAOWNiZDQ1NDgtNTNjNi00ZDE4LWE4MDktOGZkMjA0YmQ1ZmMz
216195c9-794f-49b0-a36b-89d71bc32d2c	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 10:31:28.448053+00	2026-09-14 10:31:28.448053+00	{}	2026-09-14 10:30:58.448053+00	OPAQUE	REFRESH_TOKEN	MY4dZVYxKS8trXUPZnrA3Wxrld1pwANDdjNTU5NzMtY2Q1My00ZjkwLTkzOWEtMDUzNmVmY2U5NmI0
62ca9d62-92d9-4dc0-bca0-99b813474f8a	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 10:31:28.64378+00	2026-09-14 10:31:28.64378+00	{}	2026-09-14 10:30:58.64378+00	OPAQUE	REFRESH_TOKEN	3PN5v1sUt9v0ru0oYJ8o0YPoyoePPAMTRhNGQxMmYtMmVlZi00OTk2LWIzYWYtODA2MmNmNWVhMjI0
9018ab81-d6ec-4fec-ba1e-6e70b89d13f0	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 10:31:28.834339+00	2026-09-14 10:31:28.834339+00	{}	2026-09-14 10:30:58.834339+00	OPAQUE	REFRESH_TOKEN	84QZxw0Bdlb7NeXvL2EuJbmLwUeZfwNTUwNmVjZTgtNjc2OC00YmUxLWE2MGItYjgxNDMxOWNjOGY2
20ee521e-36d6-4eae-ba97-3ec77bebe346	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 10:31:29.019903+00	2026-09-14 10:31:29.019903+00	{}	2026-09-14 10:30:59.019903+00	OPAQUE	REFRESH_TOKEN	uqY29mTbemXKytmU0Jkq0RYJuNgGuwYTBjMjlkNjItMTEzYi00YTE0LTliMDktYWFlMTcxNTQ2NTVm
5fcecf4e-b644-44e8-aa4c-a64be647f3e7	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 10:31:34.027335+00	2026-09-14 10:31:34.027335+00	{}	2026-09-14 10:31:04.027335+00	OPAQUE	REFRESH_TOKEN	_E2BCCBZJlznryziDHfu3OBf3zT-uwZjk3OTIzYTYtYTIzZi00YTQyLWEyODItNGE4Y2Y2MGFiYjEz
38c02b73-4a96-4b32-aa8e-620038803a15	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 11:31:10.460323+00	2026-09-14 11:31:10.460323+00	{}	2026-09-14 11:30:40.460323+00	OPAQUE	REFRESH_TOKEN	IcupRGuZS5raNYGZ4UZKvja4iMnQwAMGQ5YjQzMDEtYmJiYS00ZDBkLWFiNWYtNjQ2ZjZiNTk4NzJj
871e4820-2bff-49d1-a2ef-9c44b2182605	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 11:31:10.655364+00	2026-09-14 11:31:10.655364+00	{}	2026-09-14 11:30:40.655364+00	OPAQUE	REFRESH_TOKEN	03zSYZ_fXE-aueeZkjVBHtrAoWs7twMjVhOWU4NGQtYTQ5Zi00NzM0LThjYTMtZjdlY2RjMzcxNjdi
2809d208-a195-4fd5-8864-e4fbffbb9613	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 11:31:10.87166+00	2026-09-14 11:31:10.87166+00	{}	2026-09-14 11:30:40.87166+00	OPAQUE	REFRESH_TOKEN	ddDs-U6Jsmqx6EKK7GuL7k8PUm9OMgODVhMmZkYzMtODdjZi00MGU3LWFkMmEtOTJlMDEyY2E2ZGZh
fdc0a571-d07b-4138-b8fb-c0064a14b499	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 11:31:11.044841+00	2026-09-14 11:31:11.044841+00	{}	2026-09-14 11:30:41.044841+00	OPAQUE	REFRESH_TOKEN	1EInNXi94byyPmuElCm0wnH029PyzQZTU3N2MxZjAtZTliYS00ZjNkLWI3ODYtZTczMGE5ZGYwYWQx
87c6791f-b653-4891-a5a1-de6ab7cb51ac	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 11:31:11.395914+00	2026-09-14 11:31:11.395914+00	{}	2026-09-14 11:30:41.395914+00	OPAQUE	REFRESH_TOKEN	YVEv8UGh-naWxag8tPx9QQgbzCC5FgM2RiMDJkN2QtNGNhNi00YzI4LTlmNTItODhmN2JmODA2ODcz
61c04c01-92df-43e6-85a8-2c3e0344794b	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 11:31:11.652481+00	2026-09-14 11:31:11.652481+00	{}	2026-09-14 11:30:41.652481+00	OPAQUE	REFRESH_TOKEN	jQEjjk2f0KfNHNIRdg28UacWpMF4tANTk0YzA4ZDMtOWExOC00OWFiLWIxODQtMzdmNTg3ZmMxNWY5
5c21b544-0388-4102-a54a-0b7e0393e08a	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 11:31:11.828502+00	2026-09-14 11:31:11.828502+00	{}	2026-09-14 11:30:41.828502+00	OPAQUE	REFRESH_TOKEN	XE2Zu5KMEAnypgBdWj_bl0nvKeuKRANjRlOGNiZDgtNmJlYS00Njc3LWJmNjYtMWY1M2ZiMzkyNGI0
0942c709-e96b-4631-9f1a-3da2b958bc76	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 11:31:12.003962+00	2026-09-14 11:31:12.003962+00	{}	2026-09-14 11:30:42.003962+00	OPAQUE	REFRESH_TOKEN	p5JoPYcKPF8JjVzlyUzQx6TyDfCwhQMjhiOTc2N2MtYzVjMy00MjM1LTg2NTktOGZjM2NkMzEwNThi
98417709-aa77-4afb-b184-ff0c7d0474ad	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 11:31:12.189935+00	2026-09-14 11:31:12.189935+00	{}	2026-09-14 11:30:42.189935+00	OPAQUE	REFRESH_TOKEN	pbhn_C91MkUCHWhKVkA_IuyASjE-JwOTlkNjk1ZDktZmE0Yy00ZTJlLWE3OTQtYjExOTdjMjI4NGMw
81722881-f501-476d-9bd2-d478808bdc31	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 11:31:12.391878+00	2026-09-14 11:31:12.391878+00	{}	2026-09-14 11:30:42.391878+00	OPAQUE	REFRESH_TOKEN	paD_mi3qtrxTZEiR62iISDRLvmLbmAOTJiNzEzN2ItOGY1Ni00NGQ3LTliYzItODczMzdlMmZkMDIx
3716cdf9-0f9a-4d36-acca-f454ac6d352f	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 11:31:26.544802+00	2026-09-14 11:31:26.544802+00	{}	2026-09-14 11:30:56.544802+00	OPAQUE	REFRESH_TOKEN	44PxK87TO1Ewo9VqIV_Jl5z4YXQSBgYjhhNDJmNzQtYjNmMS00NDViLWIwZGMtNTZiM2FjOTc1MGJm
8ca6894d-6622-4cdb-9bad-80ab136e36d8	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 11:36:46.614168+00	2026-09-14 11:36:46.614168+00	{}	2026-09-14 11:36:16.614168+00	OPAQUE	REFRESH_TOKEN	PmpTg693c5ijRtFjFJgmvsf5pGY1LgOWQxOTViMDAtNzJmNy00MzUyLTk1ZTAtZDI2ODQ5NjZjNDA5
5f2dc17b-cf23-407a-b917-db01a7d6a937	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 11:53:46.135568+00	2026-09-14 11:53:46.135568+00	{}	2026-09-14 11:53:16.135568+00	OPAQUE	REFRESH_TOKEN	5o-jm7SRoJKdvze-EthdSt-NLjjZoQYzcyNjU4MTYtYTAwNy00ZGFkLThkYWUtZjI5NjQ2ZGU1OTk3
c3c5bf0b-814d-4bf0-be87-829d326242b8	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 11:53:46.327998+00	2026-09-14 11:53:46.327998+00	{}	2026-09-14 11:53:16.327998+00	OPAQUE	REFRESH_TOKEN	OX1HD891Sf7UmiJcqBKRP43RpA-rJQZTIxYTk2ZWQtODc2Mi00ODkyLTg0MWItMzVjNjdmNzdhYzY2
4de9e535-18cc-47b1-ae63-7f272eec3f1b	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 11:53:46.511093+00	2026-09-14 11:53:46.511093+00	{}	2026-09-14 11:53:16.511093+00	OPAQUE	REFRESH_TOKEN	J7CJ7tvNC0pUcyHyVuX8ChkZ_AUubwY2EzZjJhM2MtMmU4OS00ZTVkLTgzYzgtMjc0YWVhZDYxZGMy
97538528-929b-46c3-af75-528e81cba404	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 11:53:46.689094+00	2026-09-14 11:53:46.689094+00	{}	2026-09-14 11:53:16.689094+00	OPAQUE	REFRESH_TOKEN	tSS-shm1Kn0GmvaaLpL9D10EuqGvCgOWQ5MWRmMGYtM2UyMC00MTM3LWJjN2MtOGFlZDM5MjA0NTJj
c4f9ab12-4079-4fb7-95d4-4265896bba18	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 11:53:46.849995+00	2026-09-14 11:53:46.849995+00	{}	2026-09-14 11:53:16.849995+00	OPAQUE	REFRESH_TOKEN	62rfrmFoGaPBlAdUyNinjOOcze6n4QOTQyMmFjYTgtYTk5ZC00NTc4LTkyYmQtZDAxN2ZhODFkYTlj
e709ef1e-f195-4ac0-9210-a156000b134e	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 11:53:47.028356+00	2026-09-14 11:53:47.028356+00	{}	2026-09-14 11:53:17.028356+00	OPAQUE	REFRESH_TOKEN	dy0u-_z_cC31YB7n9FB6i3hdRUgAWwZTVkOTA1OGItMWM3Mi00MjM2LWFlZDItNzc2ZGU2NTcwNGQx
c12f6b51-5338-4358-b108-ebd27ddf912b	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 11:53:47.345761+00	2026-09-14 11:53:47.345761+00	{}	2026-09-14 11:53:17.345761+00	OPAQUE	REFRESH_TOKEN	PyZJ0vwfjB5lJ-7X_facf61SiwilfgZGE3NDVkMjUtZDg0MS00ZGQ5LThmMjctNTZkYTQ5ODg5Yjg0
f9a3749d-1446-40a6-99f2-18cbf0543dba	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 11:54:36.423975+00	2026-09-14 11:54:36.423975+00	{}	2026-09-14 11:54:06.423975+00	OPAQUE	REFRESH_TOKEN	zHzAkYIPmURJABUOusf0UENs60zprQZjBjYzUzOTUtMThlNi00ZDZkLTk3MWUtMGMwM2JlY2M0NWY2
3c75224e-e779-488a-af2e-2112b0b39e9a	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 12:00:53.280601+00	2026-09-14 12:00:53.280601+00	{}	2026-09-14 12:00:23.280601+00	OPAQUE	REFRESH_TOKEN	2DnYPF12bF3RKcWuTIA1zdUszGUgXAMGRmNmUwZjUtZGY4Mi00NTE5LTkxZTEtZjNkMjMwOGRmYjZm
87a404c6-d822-45cb-9dad-09a9a10165e2	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 12:11:02.676042+00	2026-09-14 12:11:02.676042+00	{}	2026-09-14 12:10:32.676042+00	OPAQUE	REFRESH_TOKEN	YrFTQZ0c0msBbFDk5pmnkNJbKin0QgOTRkZGI5YTEtZmNjZi00MzFmLTlkZDItMTUyZjhmMzcxMDQ0
456b9615-9fab-40fb-a0c3-c88dbfa03919	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 12:11:02.873736+00	2026-09-14 12:11:02.873736+00	{}	2026-09-14 12:10:32.873736+00	OPAQUE	REFRESH_TOKEN	ncXDKw6WoT2NmI_w5sQ4ANU6uWxVJANGZiMmY2NjMtZDZjMS00ZTYxLTkzYzUtZTkyZDM2YzYwMzNl
beaf8354-7e5a-40c3-9444-b25bc8198541	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 12:11:03.061709+00	2026-09-14 12:11:03.061709+00	{}	2026-09-14 12:10:33.061709+00	OPAQUE	REFRESH_TOKEN	87SUQhZ4rzsFv1-IlYvtoUbD54cCFANjA3ZDc0NTUtMWMwNi00ZTc5LWExNGEtNDNhN2I3YzhiMWRm
632d5669-d3d2-42c5-b0ce-0820574aa18b	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 12:11:03.406321+00	2026-09-14 12:11:03.406321+00	{}	2026-09-14 12:10:33.406321+00	OPAQUE	REFRESH_TOKEN	XNb3Iq8HPkjGj753T2Oel97-Yu3sagMTgzNTI0NTUtN2M1ZS00ZWYxLWE2NzgtZDI0YzJjYTE0ZDUy
30f9df65-629d-491d-875e-166227ea321a	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 12:17:45.689312+00	2026-09-14 12:17:45.689312+00	{}	2026-09-14 12:17:15.689312+00	OPAQUE	REFRESH_TOKEN	HE_d0nNl46vzz51LS9Tkanrs7msbDANTZmYWFlODAtZWNkMS00NjYyLWJkNjctMWMxNTUxNjg1NmUy
531a4396-e531-455c-810e-42d455e7bb82	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 12:17:45.880674+00	2026-09-14 12:17:45.880674+00	{}	2026-09-14 12:17:15.880674+00	OPAQUE	REFRESH_TOKEN	JLtHo48CordrKGzl00Ssj_4P_Qj97AZTFlNzRmYjMtNDQ0NC00NjFmLTllMGItOTdlZDRhYmZlNmU4
99b1b4e5-47a0-4e6c-ad67-2aa477f1083f	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 12:17:46.437572+00	2026-09-14 12:17:46.437572+00	{}	2026-09-14 12:17:16.437572+00	OPAQUE	REFRESH_TOKEN	5kMg3VFsTf28e7ELQVzpG03ej4FDwAN2MyYjU0NzAtNWQ5Zi00ZmYyLWIwOWUtZTc5ZmMzZmQ2MDM0
db129bf9-ba00-49af-9a00-8db944bb63d0	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 12:32:53.031615+00	2026-09-14 12:32:53.031615+00	{}	2026-09-14 12:32:23.031615+00	OPAQUE	REFRESH_TOKEN	v618w1LHXQO97qVIzpXuuyJwoALa6QZDUwN2MxMGYtOGEwYy00MDA4LWIxM2UtZDBkZjVkZDg1OTM1
0a09ce11-b9f5-49e1-8b4b-e03652d1f1dd	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 12:32:53.254865+00	2026-09-14 12:32:53.254865+00	{}	2026-09-14 12:32:23.254865+00	OPAQUE	REFRESH_TOKEN	wgVBmpHY3vS1BKK-tn1Mq7uSY7njGwYWNiZTBiNTAtMzViMC00OTM4LWIwMWUtOWYzMTVjN2ViMzM1
b60e64fe-4267-439a-92c7-00e8f7313a5d	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 12:32:53.448184+00	2026-09-14 12:32:53.448184+00	{}	2026-09-14 12:32:23.448184+00	OPAQUE	REFRESH_TOKEN	YK90V24iKZcUHh_Nj0NXrTayGC-jZAY2I0MDEyNjAtYjAyOC00ZmFjLTg4MTgtMzljYzVkZjFkZmU1
dde7435c-7b58-42a1-b521-2ca0add39d9c	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 12:32:53.964462+00	2026-09-14 12:32:53.964462+00	{}	2026-09-14 12:32:23.964462+00	OPAQUE	REFRESH_TOKEN	1v29IY2FMdZLMpBYm4AnoFsLU-mPkQZmY0YWIzNDMtOTFlNy00OWQ2LTllYjYtYzViOTgxMmM2ZDUy
a250b3fa-a052-4372-95e8-c4f21677bfa8	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 13:06:32.220514+00	2026-09-14 13:06:32.220514+00	{}	2026-09-14 13:06:02.220514+00	OPAQUE	REFRESH_TOKEN	Mv5yJTtVTCwmjl7U_HLajlFCf_L9hgZGRkY2U4YTQtMjkwZC00MGE0LWIzZmUtYmE0ZWIzZGNkMjYw
14b069f8-cfed-49bb-83e5-3cafd73cab3c	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 13:06:32.404979+00	2026-09-14 13:06:32.404979+00	{}	2026-09-14 13:06:02.404979+00	OPAQUE	REFRESH_TOKEN	9xMSMtNBhrBpgZ2mRyc3TL2VW3grxwYWI2MDEzMjctYzFkMi00ZGFlLWEwMmQtNzk5NmJlODE5YjE4
21155200-8bf9-48af-bd04-36b7b2d2afcc	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 13:06:32.59634+00	2026-09-14 13:06:32.59634+00	{}	2026-09-14 13:06:02.59634+00	OPAQUE	REFRESH_TOKEN	7HC6EMl8UChMdmQ6A-xGofQ5YK3vuAMTdkNmM3ZjQtNGY4OS00MTcwLWIxNjQtODc2ZDVkNDQ0OThi
1b01f001-050a-4ea8-bf59-57fc1469842e	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 13:06:32.786832+00	2026-09-14 13:06:32.786832+00	{}	2026-09-14 13:06:02.786832+00	OPAQUE	REFRESH_TOKEN	vFoq2DDzvXp6kVinMDJDhZfpAgHxLwYzcwOThlYzktNTM3ZC00OTQyLThiMDctZDUzZTgwNDdhMmQ4
ee2bab26-9b83-49e3-9041-7c26b69cb823	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 13:06:32.976012+00	2026-09-14 13:06:32.976012+00	{}	2026-09-14 13:06:02.976012+00	OPAQUE	REFRESH_TOKEN	bkM9uaHhGo0obwLUdCA3iIScXT1bGQYjJhZDdlNGQtNzdiMS00ZTZkLThmNTAtZjE0ZmU1OTY5OTMx
11c526fe-a4e0-440b-8ad7-0c33209104d2	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 13:43:58.579177+00	2026-09-14 13:43:58.579177+00	{}	2026-09-14 13:43:28.579177+00	OPAQUE	REFRESH_TOKEN	IrZeQvahye8XyWGz_xw3hd2mArNUHQYjhmYTc4YWQtYzlhYS00YThlLWFiNTUtNWU4NWE0YzA5ZDAx
587d5393-4598-4f32-b81e-385a382b9612	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 13:43:58.780417+00	2026-09-14 13:43:58.780417+00	{}	2026-09-14 13:43:28.780417+00	OPAQUE	REFRESH_TOKEN	N30AQQgOCo2jSJ-wRiQ09juVE4irsQODI1ZTgxYTYtODU3Yy00OTBjLTllYzYtODA5OGI2NjFjZGZm
8bfb6679-9757-4671-a933-ee4411324c7e	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 13:43:58.970949+00	2026-09-14 13:43:58.970949+00	{}	2026-09-14 13:43:28.970949+00	OPAQUE	REFRESH_TOKEN	7bqwJfsqsiYJTVYRXs566IMqbP6RXAYTk4YzAyZmUtMDVkMC00ODQ3LWIwZWMtMTUwNjAxMjIyNjhl
32d1d732-0820-4077-8018-0f9a5483902c	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 13:43:59.17748+00	2026-09-14 13:43:59.17748+00	{}	2026-09-14 13:43:29.17748+00	OPAQUE	REFRESH_TOKEN	RVdSSnRxdq0z2l_gLsXijPBD0HBFcwOWFlYWJlYzctMTIxNi00OTQ1LWJiMmItMDQ1MGNiNDA3NThh
88e32544-d6b8-4dce-91d2-00c4ccd55979	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 13:43:59.601285+00	2026-09-14 13:43:59.601285+00	{}	2026-09-14 13:43:29.601285+00	OPAQUE	REFRESH_TOKEN	7PoWXjI7aDd-DjMIGxhHxn9oqB6uLAYzg2ZjA2YmItMmI0OS00YzZkLWFhMjgtYzIzMjY4OWY1NGRj
33dec7d8-ec71-4ae3-bd96-17194af44874	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 13:49:46.546755+00	2026-09-14 13:49:46.546755+00	{}	2026-09-14 13:49:16.546755+00	OPAQUE	REFRESH_TOKEN	wJAgt9hmMYHL-tzTvwt0JKouFIc4VANGQyZmU5MGMtZDExOC00NmM0LTljNTktZWJlOWRkMjQxZDA0
28a61029-c948-405d-982b-60715e615786	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 13:55:40.353783+00	2026-09-14 13:55:40.353783+00	{}	2026-09-14 13:55:10.353783+00	OPAQUE	REFRESH_TOKEN	-MfV1_UtP_Qv5puj-XOqCLK6zgnVsgOGU0MjAxOTMtMmU1NS00ZDkwLTg0YjMtOWUyYmVmNjdlZjNi
de7ac5f2-5d6f-45eb-b98e-881fe9d024c4	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 13:55:40.548978+00	2026-09-14 13:55:40.548978+00	{}	2026-09-14 13:55:10.548978+00	OPAQUE	REFRESH_TOKEN	kL6v3yNkubizSFEWvge0ewgBwaOmSgNDI4NjRhN2MtMDNmYS00ZWI3LTg3YWMtZmU5ZjE2YzIxYzQ5
bf1c5746-7d0f-471f-9403-9c4e8ae3c0ec	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-14 14:08:44.814042+00	2026-09-14 14:08:44.814042+00	{}	2026-09-14 14:08:14.814042+00	OPAQUE	REFRESH_TOKEN	fcIK6IyoF2TIrcAWGFYSm2NJd7LHowNmU1MDUzMWQtN2JhZS00NDYzLTlmZmMtYzE4Y2ViNzFmNzkx
3d3d729b-af0b-4680-92e0-b928883a0ab2	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-14 14:08:46.119951+00	2026-09-14 14:08:46.119951+00	{}	2026-09-14 14:08:16.119951+00	OPAQUE	REFRESH_TOKEN	xlzkjEglTR2mcibBP7Jopkv_m80B-wYTMyN2JlYTMtZmNiYi00NTgxLTk4ZWMtZTE3ZWNmNWE4MTRh
072c2774-ae4a-47c1-a1b4-6914cac0b31c	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-14 14:09:05.071866+00	2026-09-14 14:09:05.071866+00	{}	2026-09-14 14:08:35.071866+00	OPAQUE	REFRESH_TOKEN	1-kRfJr2bz9If7V7e2aN5VC0R2mPGQOGQwNDk3ZDYtMjJhOC00M2ZlLTkzNjgtN2FkOTgwNDU1Mzc0
a993cf56-4327-4d73-9956-d5b351654399	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-14 14:14:08.28806+00	2026-09-14 14:14:08.28806+00	{}	2026-09-14 14:13:38.28806+00	OPAQUE	REFRESH_TOKEN	qyfnil6Q5PfCthWj0YYEV4LfQcfpoQZWNmMzMzYTUtZThlNy00YmIyLWJiZWEtMTczZGE5YWM1YjA0
61cf0200-7029-4142-86ec-59f65bba704b	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-14 14:19:16.89213+00	2026-09-14 14:19:16.89213+00	{}	2026-09-14 14:18:46.89213+00	OPAQUE	REFRESH_TOKEN	bY7CwnpzmE9NKGXU7VeiAV0XwB90KgMzMyZjgxZmMtZGVlNS00N2FmLTgwN2UtZjE4YjE4MTlhZWFj
10e75033-dedf-479a-90f2-3a5f2d2eb4aa	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-14 14:34:29.469447+00	2026-09-14 14:34:29.469447+00	{}	2026-09-14 14:33:59.469447+00	OPAQUE	REFRESH_TOKEN	UdDdCLN-shZTTsYI6wvaN75xPNGjowMjBkY2Q2ZjgtYjQyNC00NWM0LTg5ZDItMTM4ZDkwY2ZlM2Ey
cd1c01b0-a68e-48dd-8da5-f67220eb408c	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-14 14:34:29.768118+00	2026-09-14 14:34:29.768118+00	{}	2026-09-14 14:33:59.768118+00	OPAQUE	REFRESH_TOKEN	KJeR1RoT6PpcZRKvmCp1crKr3UuVlwNGU3YzU3ZmQtNDU5Ni00NGM3LTlmYTEtMzZhOTgzNWNhYzRj
13ddcd3e-8104-4396-a496-da961878469a	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-14 14:34:30.067698+00	2026-09-14 14:34:30.067698+00	{}	2026-09-14 14:34:00.067698+00	OPAQUE	REFRESH_TOKEN	sqxkdumAcDEl0Jz4CInpinUQ_2_hFAYjc1NDcyY2UtYzI2ZS00Y2MzLTk4YTYtYTYzNmU2ZWU3ZDI0
7325188d-3c83-4a0f-80c7-8b6718a87e1d	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-14 14:34:30.372727+00	2026-09-14 14:34:30.372727+00	{}	2026-09-14 14:34:00.372727+00	OPAQUE	REFRESH_TOKEN	5EyeSQbVMkBeFdN1fiDzAZjPMEIVqgYTYzNTQwYjktODg0YS00OWI0LTkxODgtYzhjZjI2ZmQyNzBm
0f779e0e-96cc-4b4e-a08d-59254ce8a541	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-14 14:34:30.714212+00	2026-09-14 14:34:30.714212+00	{}	2026-09-14 14:34:00.714212+00	OPAQUE	REFRESH_TOKEN	LSaMKRkjyoJ45alwI13zOO_xo2MoJgYjZlMWM1N2QtNTE2Mi00NjgwLWEyY2UtNWVhYjk1YzEwZjg3
8e228f30-9949-4efe-ba98-018610866269	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-14 14:44:15.536449+00	2026-09-14 14:44:15.536449+00	{}	2026-09-14 14:43:45.536449+00	OPAQUE	REFRESH_TOKEN	IIjWjrSHOVvDQMwcc23kAB-RDQGoCgYWUxMDU3NmEtZTdkNS00YmEwLWJkYzgtODZlMjI1YWYyMzVk
fd5abcc3-0063-4975-be71-6c732d6e8953	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-14 14:44:15.844934+00	2026-09-14 14:44:15.844934+00	{}	2026-09-14 14:43:45.844934+00	OPAQUE	REFRESH_TOKEN	UWh6fvd93hbzt5ufjkFbLH4u_EVvYwODMwZWJiMmEtYWVjNi00MGI3LTgwYWUtYmEyOGJkZTk3YzJi
88aa6bce-3080-4e47-80c5-8ba4416c7523	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-14 14:44:16.253149+00	2026-09-14 14:44:16.253149+00	{}	2026-09-14 14:43:46.253149+00	OPAQUE	REFRESH_TOKEN	G2wpyLdlVpwRIweY-WYo3v9l2mfbmQMjBiNmQzZTYtMGNlMi00ZDRmLWJmYTAtZDI4MTQ4ZGFjMzBi
12cadd13-6ba7-46e7-80c7-6d3b3ee791ed	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-14 14:44:16.66347+00	2026-09-14 14:44:16.66347+00	{}	2026-09-14 14:43:46.66347+00	OPAQUE	REFRESH_TOKEN	GwpUcmUoZJLxjAkE-tqETA2LVaHo4gZjY5M2I0ODItNzlmNi00YmUyLWJlZWQtNTI0ZDYyMTQ3NzU0
60bc14c7-fb9c-4b00-9334-bc4e5d1f4226	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-14 14:56:39.837926+00	2026-09-14 14:56:39.837926+00	{}	2026-09-14 14:56:09.837926+00	OPAQUE	REFRESH_TOKEN	DoVUsOuGqk1Vc4RIJLjeHTPjs_Y8owZTQ1ZWY2ZDAtZmMzMy00NzBiLTliYWYtMjA2YTJlNzU4ZTY1
515a8ac0-d63d-4e15-a905-555c9ff61a08	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-14 14:56:40.356138+00	2026-09-14 14:56:40.356138+00	{}	2026-09-14 14:56:10.356138+00	OPAQUE	REFRESH_TOKEN	WgbuGoNyI0HhJ_KbCDdPYmidEAvOIwOTUxZjFlYWEtM2Y4OS00YmYxLWJiOWUtZjg2Zjk4M2E4ZmE1
f82a1f66-cc61-476c-9b9f-2ee329e5f503	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-14 14:56:40.659295+00	2026-09-14 14:56:40.659295+00	{}	2026-09-14 14:56:10.659295+00	OPAQUE	REFRESH_TOKEN	lE28EFzIFCPpwXPqfUpYxgwShZdJ5QZWMyMmU4OGYtMjI0Yi00MDNjLTkxNjUtNzY2NmI2NzU3ZWJm
be807f69-672a-45ec-8d21-1a527d568c2d	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-14 14:56:40.973153+00	2026-09-14 14:56:40.973153+00	{}	2026-09-14 14:56:10.973153+00	OPAQUE	REFRESH_TOKEN	MOQUm-oOS3EY4JKgoLDk9QuqQHQohANzY4OTUzZTYtYjZjZi00NjM1LTk4MjUtMzY3ODNkODg3OWZi
906e4538-077d-4858-a089-7b5da1316284	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-14 14:56:41.414448+00	2026-09-14 14:56:41.414448+00	{}	2026-09-14 14:56:11.414448+00	OPAQUE	REFRESH_TOKEN	ZIrs7Zhk-CTHZe_tAvWMdgKcEi1mRANTgzZWVlYzQtNjEyNS00YmUxLTkxNGMtYjg2MGE3MDE1NjNk
111f172c-cb38-4092-b679-4b52f1ed7c89	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 15:00:17.620145+00	2026-09-14 15:00:17.620145+00	{}	2026-09-14 14:59:47.620145+00	OPAQUE	REFRESH_TOKEN	t6Mezg5rPwSq7PQHdT9ANiBcY_QMYAMGU3NzJlNGQtMjM3NC00ODJkLWJmM2ItMWYzOTkxYjQ1MTgw
46963490-57ab-4817-baf7-3bcb3733c93e	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 15:00:17.842953+00	2026-09-14 15:00:17.842953+00	{}	2026-09-14 14:59:47.842953+00	OPAQUE	REFRESH_TOKEN	FBF3kXBIPR_7ZXyV5rbDXlASDj1C5QZTQxMTgwNzctMzJjNC00YzUyLWFmNjAtZTVjYzIwZTEwMmNj
337a183c-f8b0-41ca-bb63-dae09820a640	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-14 15:02:06.860056+00	2026-09-14 15:02:06.860056+00	{}	2026-09-14 15:01:36.860056+00	OPAQUE	REFRESH_TOKEN	dUXkqNRP9KQ3vRMUd0c4eOe7kRQz4QZDgxNDQxMWUtODY0Ni00NzBjLThjMDMtNmUzOTU2ZWVkMTUy
0d2b39c3-55b4-414b-9e11-b3e5a9ab8d11	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-14 15:02:07.432818+00	2026-09-14 15:02:07.432818+00	{}	2026-09-14 15:01:37.432818+00	OPAQUE	REFRESH_TOKEN	vT7_mGz3eFdjjcfL35JOapnqhRmYHwNDAyOTg5ZmItY2VlOS00YjIxLTkwMTAtNTM0ZDcyZDBmNDUx
8fc697db-cbda-4cd5-a6f6-642316a78963	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-14 15:02:07.757404+00	2026-09-14 15:02:07.757404+00	{}	2026-09-14 15:01:37.757404+00	OPAQUE	REFRESH_TOKEN	mmvx5SCw1g31the4GlY_nvpIT3yqGQNzVhN2FmMmUtZDI2NS00Y2I4LThmN2EtNjUyMDJhNzJlODM2
7fa9f99f-d278-4b1c-bbb8-13e582728ca7	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-14 15:02:08.30968+00	2026-09-14 15:02:08.30968+00	{}	2026-09-14 15:01:38.30968+00	OPAQUE	REFRESH_TOKEN	GRDDkXPunNJxaxgujhBDz4up9pnfXQZmE2M2NhYjMtYTgwNS00ZjBlLTlmZmYtZTVmNTFmYTJjZGNj
3a94747a-2ca1-4a59-b7ec-1703fdfac807	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 15:17:15.835668+00	2026-09-14 15:17:15.835668+00	{}	2026-09-14 15:16:45.835668+00	OPAQUE	REFRESH_TOKEN	2K61-tWhHylWd5VYfPpN3isokAM4vwZjA5Yjg0M2UtOTE5MC00NjBkLTlkZjctYjBiMmI4NGQyZjc5
5f2b12a3-3b99-40f9-92aa-4eb3bca9025f	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 15:17:16.176965+00	2026-09-14 15:17:16.176965+00	{}	2026-09-14 15:16:46.176965+00	OPAQUE	REFRESH_TOKEN	4VrtjX2bf_GNMEZ8LdklqpfjpOJ0pgNzk2N2M5NTMtZDVkOS00NDU1LTg0ZjAtZWFhMjkxNWYxZmZh
97d72a6b-3e70-4434-8268-15e28ea81014	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 15:17:16.50874+00	2026-09-14 15:17:16.50874+00	{}	2026-09-14 15:16:46.50874+00	OPAQUE	REFRESH_TOKEN	IlGVRVRqOzTFexS-d_eKLre6eLIIDwNTQ1MDY1NDMtMmZmOC00ODdlLTg5YjAtYmNhZjljYThjNWQ4
12ffd7c4-acb7-49fb-8b12-166d7e3a42f4	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 15:17:16.825186+00	2026-09-14 15:17:16.825186+00	{}	2026-09-14 15:16:46.825186+00	OPAQUE	REFRESH_TOKEN	cafz7chojOziXHUWttQP9QJWVy3GGgN2U2ZGZiZTItNjM2NC00ZDRmLThlMzQtYjU0ZTQwM2EyNjBl
cdd6f88c-4b67-43b9-8da7-faf12ff071cf	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 15:38:30.577913+00	2026-09-14 15:38:30.577913+00	{}	2026-09-14 15:38:00.577913+00	OPAQUE	REFRESH_TOKEN	eAHB0szeCkI1TzGlsm7Dlu6L2dD4ngMDNhZTQ2MGUtMjI1Yi00NzA1LTllNDAtNDRjYzVlZTU5ODk3
15cd42aa-7106-4cba-85a5-fc782ab78f32	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 15:38:31.756173+00	2026-09-14 15:38:31.756173+00	{}	2026-09-14 15:38:01.756173+00	OPAQUE	REFRESH_TOKEN	G8_jfrpknL6vhCKARoAlqsGrMsiklQMGZmYTI2MTUtN2VmNi00MTdjLTg0MTQtMzAwYmRiNDRlNWJk
0b78485c-3e5a-4323-abfd-6dd44bf3035c	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 15:44:33.36986+00	2026-09-14 15:44:33.36986+00	{}	2026-09-14 15:44:03.36986+00	OPAQUE	REFRESH_TOKEN	DCX4ns-xsBmk1dOz0EF313AQcuNWawNTE2YmM0NzQtMmI4Zi00ZjYzLWFlMjUtZjFlZjE2YmQ2NGYz
f963d964-cf4b-4a64-b62e-e284cf6cfd66	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 15:44:47.157327+00	2026-09-14 15:44:47.157327+00	{}	2026-09-14 15:44:17.157327+00	OPAQUE	REFRESH_TOKEN	wB-bKDp9iLN9DKKQ6fnDXzeGEgbsOwMjU5MzEzNzctOTMxMy00Njk0LWE4YjUtMDgwOTA4MzY5NDE0
1a0b25e5-1129-43eb-8a0a-4a11951e428d	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 16:03:59.564924+00	2026-09-14 16:03:59.564924+00	{}	2026-09-14 16:03:29.564924+00	OPAQUE	REFRESH_TOKEN	nPnY0lrKmHsLB4yx_J5NdLDtZXvF9wMGQ0Nzc0ZDgtOGI1Zi00Y2FkLTk2ODQtZTlkZjhmMjI4NDBl
84199de1-b53a-48a2-a498-3f93bdc6fe07	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 16:03:59.775981+00	2026-09-14 16:03:59.775981+00	{}	2026-09-14 16:03:29.775981+00	OPAQUE	REFRESH_TOKEN	mz6UPoEb1lJXBD7tTMnSb_qfAzdUGQZDNlODFlOWQtN2UwYi00M2VhLTgxNTUtMTAzNTUyNTc4MWNj
7604657f-4da1-4ee2-b061-c6db4b335c4f	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 16:03:59.969328+00	2026-09-14 16:03:59.969328+00	{}	2026-09-14 16:03:29.969328+00	OPAQUE	REFRESH_TOKEN	y1jzcvdb2H1_3GKoqQX5YJrGbrhHgwMGYxOTkyNTEtMTIxOS00NzNmLWE3ZjMtMDFmOTQ3OTMwMTk1
b559b8a1-e673-4a94-9374-fc0497de40ae	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 16:04:00.164296+00	2026-09-14 16:04:00.164296+00	{}	2026-09-14 16:03:30.164296+00	OPAQUE	REFRESH_TOKEN	tKRZQmWY8Uw9vEK36PAO1RaxwYZTqAZDFmNjAxZDgtNDE2MC00Yzk1LTkwMTMtODkyZWE4YjE2MzNh
55e82581-cd5b-46d4-b682-34f7228a2034	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 16:04:00.729879+00	2026-09-14 16:04:00.729879+00	{}	2026-09-14 16:03:30.729879+00	OPAQUE	REFRESH_TOKEN	V0bxnSeJje6gBMWGyTqO5TGnl1AqBAMDBjNmE1NjAtMmZlYi00NmMwLWEyNmItMmY1NjI5ODI1NGUw
885ff0c9-ecf6-48aa-94de-280eb77133c4	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 16:10:42.497818+00	2026-09-14 16:10:42.497818+00	{}	2026-09-14 16:10:12.497818+00	OPAQUE	REFRESH_TOKEN	iQc3F2ppCU4c2Qvd_of3y6bhRu5hVAODkyYzkyMDgtMjIzOS00MWZlLWFlNWEtZDk1ODg4YWE2OWZl
b9239b93-b472-49dd-b273-2d541b02586f	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 16:10:42.673889+00	2026-09-14 16:10:42.673889+00	{}	2026-09-14 16:10:12.673889+00	OPAQUE	REFRESH_TOKEN	oiaW_PxeKXNtqKYN2yEyP4xUu05OMgZjRkYjA3OGUtNWUzOC00NDZmLWEzZDctYWVmZmMxYzM2ZjY2
d83e8843-222b-460f-abea-d3d5a0f57c73	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 16:10:43.07589+00	2026-09-14 16:10:43.07589+00	{}	2026-09-14 16:10:13.07589+00	OPAQUE	REFRESH_TOKEN	3MV6lqGR9lG9eNHGOKQg9EvhphXcGgN2U1YzE1ZWEtNTQxYi00ZTY1LWI0YmItY2M5YWY3NWIzYzFk
2f6309e9-7470-4899-b921-6907539482fe	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 16:10:49.827441+00	2026-09-14 16:10:49.827441+00	{}	2026-09-14 16:10:19.827441+00	OPAQUE	REFRESH_TOKEN	SoSTaiCoY8ny_t4_FRDuiOe5aXJSqgMmM5NjA1OWItOWE4NC00OTkyLTgwNjYtZTEyYWZkYTI0MDVj
1e5bc0e5-bfd3-401d-9b9b-047bf275761d	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 16:32:00.404804+00	2026-09-14 16:32:00.404804+00	{}	2026-09-14 16:31:30.404804+00	OPAQUE	REFRESH_TOKEN	tkGGWLKTHgRIzqTFvrBSlFjIl_1wWwOTU0YzQyZTQtYWQxNy00ZjIwLTk2ZGEtYjUwOTUyMmQ1YTJi
2ad74033-b237-41a1-9ca3-17afa8450186	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 16:32:00.674365+00	2026-09-14 16:32:00.674365+00	{}	2026-09-14 16:31:30.674365+00	OPAQUE	REFRESH_TOKEN	VMo7rLNOU0h29KWW8oKUKN5xym_5jgODMzYmFiZTAtMDc5My00OGMzLTg0NWMtNzg3MzEyNzlmNDky
aa5e53b8-302a-4a92-a145-b75adb924824	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 16:32:00.852862+00	2026-09-14 16:32:00.852862+00	{}	2026-09-14 16:31:30.852862+00	OPAQUE	REFRESH_TOKEN	7Fy-Tx2G4ORtgdsYUzxLwlspUB37UAYzRiYTAxN2ItZmVmOS00MDYwLTg2YjUtM2NiNGU0Nzc4MWJh
85954cd0-bd01-410c-b487-7995352e0ae1	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 16:32:01.196561+00	2026-09-14 16:32:01.196561+00	{}	2026-09-14 16:31:31.196561+00	OPAQUE	REFRESH_TOKEN	CsEJMOnS8D8e1XxXOtHQ-lQ8JwFUkAZjI5YmNhZDMtODRhZC00MGRmLTg5MjUtZTFiMzI3ZmViNTVl
2b411eb4-c215-48b3-9d18-5d604c422ba1	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 16:32:01.549053+00	2026-09-14 16:32:01.549053+00	{}	2026-09-14 16:31:31.549053+00	OPAQUE	REFRESH_TOKEN	6f-QKBLs7AM5uJeVdbrUKMBQOig3IQZWM5NDMwZjQtNjZmZi00ODA4LTkzZDMtMTVlMDgwOTU3MWFk
9556c7fd-80d6-43c0-8c16-4d00149701c7	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 19:41:00.934227+00	2026-09-14 19:41:00.934227+00	{}	2026-09-14 19:40:30.934227+00	OPAQUE	REFRESH_TOKEN	vcrjQnfwtnJQGv1y5oWgzc5srHEDiQMzUwMmE4Y2MtOGYxOC00YTU3LWE4ZjMtOWRiM2FhZGU1N2Yz
eb4b1e5a-755c-4369-a083-94c9f15d20bc	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 19:41:01.158935+00	2026-09-14 19:41:01.158935+00	{}	2026-09-14 19:40:31.158935+00	OPAQUE	REFRESH_TOKEN	Qt-2I-wNJx-qi824BkcA37EMEFwJ_wMGQyZTYwMjktZGExOC00NjRiLTg2MTYtYTZmZTY1ODc2ZjE1
30031af0-ae73-4144-8d82-5bc8fc8ac3e7	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 19:41:01.351984+00	2026-09-14 19:41:01.351984+00	{}	2026-09-14 19:40:31.351984+00	OPAQUE	REFRESH_TOKEN	ctJ1kgk1iNSTkF3tVtWEo7q1bQppUAMGM3MzcwOWItMTg1Ny00ZTQxLTk3MjAtZDZkYzQzNDQ2YTNj
b7e04804-7465-4ede-86aa-ebc9018ea2ab	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 19:41:01.547288+00	2026-09-14 19:41:01.547288+00	{}	2026-09-14 19:40:31.547288+00	OPAQUE	REFRESH_TOKEN	01a8DU9nVLdtzjOioJ3_6hEuon7vpQMGExNDZhYzAtOWYyOS00NGNkLWFhYTktZGNmODFkNjZmZTcw
a6fb38ad-f643-4a14-8bb2-8327576e63d7	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 19:41:01.747894+00	2026-09-14 19:41:01.747894+00	{}	2026-09-14 19:40:31.747894+00	OPAQUE	REFRESH_TOKEN	TQj7YPm-dS6_Pk8bL3c4cDEW8lq2qANmNkM2UzNWUtM2Q0MC00ZWU4LWIxNjYtNGRjNTlhMzY1YzRl
e5cf89d8-5a34-4be7-8921-5e25cf930c99	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 19:47:02.294549+00	2026-09-14 19:47:02.294549+00	{}	2026-09-14 19:46:32.294549+00	OPAQUE	REFRESH_TOKEN	i4w5_PEGdcgHBbKpmTk5MqGJi5bN6gYzg0MzdlNjAtMDM3ZS00OGNmLWFlYmYtMWM1ZmVlOTE0NTAx
6605c68c-0ffe-49c4-834b-83a04a961734	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 19:47:02.507545+00	2026-09-14 19:47:02.507545+00	{}	2026-09-14 19:46:32.507545+00	OPAQUE	REFRESH_TOKEN	d6JUB04nQ7KaPVqsgJrYJYPKO_0UzwNDE1NTkwZmQtYTUzZS00ZWQ1LTk1ZTYtNzc5OGVjNTM0MWYy
cb71f6a2-ed94-4cc4-b360-3ba100eed090	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 19:47:02.917563+00	2026-09-14 19:47:02.917563+00	{}	2026-09-14 19:46:32.917563+00	OPAQUE	REFRESH_TOKEN	ltlyap_tgU5IUqi_H2OzbQGp1OVKTQMmM2YWM0ZjAtNWIwNS00NzU5LWIwYmUtMjE1ZWI2NTY1N2Q3
563d0d31-e59b-4d22-a924-4b9c3a16a7ef	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 19:52:33.023441+00	2026-09-14 19:52:33.023441+00	{}	2026-09-14 19:52:03.023441+00	OPAQUE	REFRESH_TOKEN	C3aBXGvQjvWq2-KDIKZ1LIZatTa3OgYTNjMGFjYjctMjNjNy00ZTE4LTk3OTItM2M5N2U4ZjBlMDc2
6e087080-2ce2-46cf-8c6c-dec7445b1ba3	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 20:00:31.344242+00	2026-09-14 20:00:31.344242+00	{}	2026-09-14 20:00:01.344242+00	OPAQUE	REFRESH_TOKEN	L2ytECapwjVorFPguDpQap2OfgvbBAMDM4ZmJmMjEtYjNhNS00NjY5LTkxNDQtMDA1N2JjNTcwYzE0
6172659b-76bf-44b5-9a28-7f3f36349fec	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 20:07:22.081047+00	2026-09-14 20:07:22.081047+00	{}	2026-09-14 20:06:52.081047+00	OPAQUE	REFRESH_TOKEN	HmCduLGBUE4JnS3aiggJ62kdmUFf4QMjAzNzgxNjMtZTQxNy00MGZhLWFhYzMtNmQyYjViMTk3Y2Iy
568b1c45-d298-4bcd-9ad9-b147820e3f9b	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 20:07:22.289368+00	2026-09-14 20:07:22.289368+00	{}	2026-09-14 20:06:52.289368+00	OPAQUE	REFRESH_TOKEN	0ir3fzK4axkG0-zAs4aoaKpiTLEHqAM2ZkZGVlZTctMzZlMS00MjhhLWIzNDYtNzBhNDA1MTc2MTc2
e87ec56c-01fa-4f33-a277-c3b355477611	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 20:07:22.469005+00	2026-09-14 20:07:22.469005+00	{}	2026-09-14 20:06:52.469005+00	OPAQUE	REFRESH_TOKEN	ffHvjxDBWS7BNz2WJYwJLoMXZarN7gZmZkZDI2MGEtYThkYS00NDA5LThlY2MtNjU1YmU1OGQwMmZj
cba614e4-005b-4ffb-adb2-038ffb3261ca	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 20:07:22.649576+00	2026-09-14 20:07:22.649576+00	{}	2026-09-14 20:06:52.649576+00	OPAQUE	REFRESH_TOKEN	cTZPmPCigj4R7Vs5gDVZOpMLtuZ0tgM2EzNDE1NzktN2ViMi00NWE4LTg3N2UtY2QxYjhkMDE5N2Uy
d8e3938e-abbc-4bd5-bdc0-8e75e91fbf64	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 20:07:22.828011+00	2026-09-14 20:07:22.828011+00	{}	2026-09-14 20:06:52.828011+00	OPAQUE	REFRESH_TOKEN	UWHMVhCCdaowPBXiEmPKCarkAAQaVgZWY2NTFhMWQtNmExZC00YWFjLTk1MjItYmVjNDNhOWQ0Mzll
31846da7-f98a-452e-b7a5-fa5f697742c5	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 20:07:23.011995+00	2026-09-14 20:07:23.011995+00	{}	2026-09-14 20:06:53.011995+00	OPAQUE	REFRESH_TOKEN	cgDQ20n4HZSJZET0nRQ1h4YSAERgwwMmNiZTBhNzItNjYxNi00MzkyLWEzMDEtMGJhNmJhZmVkNTg0
8839ab19-73c9-4c0c-96d9-349ae529671e	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 20:07:23.192532+00	2026-09-14 20:07:23.192532+00	{}	2026-09-14 20:06:53.192532+00	OPAQUE	REFRESH_TOKEN	ocO8HmEd5ujqpkxgIXva8pPsLEHGMgODEyY2NiYTktYzEwOS00NDdiLWE4NjAtZjA0MTg1YzQ5YTA1
fad7f6d9-84d7-418e-8beb-368d1533b4d6	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 20:13:47.722468+00	2026-09-14 20:13:47.722468+00	{}	2026-09-14 20:13:17.722468+00	OPAQUE	REFRESH_TOKEN	C5IcperxFVSrNIAZ2B7lHaXWix59FwYjIzZjM1MzYtYzhkYy00MGUwLWE2MjQtOWUzNjI0NTY2OWVm
faefff5f-65ad-42ea-a78a-a6f0de36b17d	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 20:13:47.907411+00	2026-09-14 20:13:47.907411+00	{}	2026-09-14 20:13:17.907411+00	OPAQUE	REFRESH_TOKEN	1m3GbRaUGXcvcN6ObmG9FX_1Z7OX4wNmUwMThlM2ItY2QwZS00ODI3LWIxNTAtYjkwNjk5ZjBmODEx
e7564897-a255-4f1e-b8e4-3b9a0fe35343	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 20:13:48.089082+00	2026-09-14 20:13:48.089082+00	{}	2026-09-14 20:13:18.089082+00	OPAQUE	REFRESH_TOKEN	oyPwD6oa27s7lds54rTvhM7XK-7YOAYTE5NDlmN2UtNTljZi00OGJmLWFjZTYtNzViMWYwYzM1NzQw
6413a10f-ee50-4cd1-9d83-f9eedc4167a3	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 20:13:48.274004+00	2026-09-14 20:13:48.274004+00	{}	2026-09-14 20:13:18.274004+00	OPAQUE	REFRESH_TOKEN	H4LDKGZflZbyViT4mnKtSo3sVXIaqQMDg3ZmQxMzctMDlkNi00MzQ0LTg5OTYtYzgyMTU4YzQ2OGFm
e03fc5e3-b716-4504-9b8b-ad0b672d4e89	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 20:17:53.390918+00	2026-09-14 20:17:53.390918+00	{}	2026-09-14 20:17:23.390918+00	OPAQUE	REFRESH_TOKEN	Yknc8tkggpyQOIG0wmXPiIRmgwwdMwNzE2OWYzMmQtMzc4YS00MGJlLWFhYjItMzE0NjYxYmQxZmU0
931423ad-62c6-4eb3-839b-35ed54757809	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 20:23:47.771203+00	2026-09-14 20:23:47.771203+00	{}	2026-09-14 20:23:17.771203+00	OPAQUE	REFRESH_TOKEN	JXhH7ssN1cIcSTgntFeg_M-PYa0_eQMmZlY2FiZTUtMGI5OS00YjQzLWIyMzAtNDNmYThlOGQzMDM0
b7411762-63ed-4575-b7de-aa81829d1f89	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-14 21:05:25.407166+00	2026-09-14 21:05:25.407166+00	{}	2026-09-14 21:04:55.407166+00	OPAQUE	REFRESH_TOKEN	J2XfkhUtDtg6xDHXdwI3mTXgK5x0TwOTI2Mzg2OTMtNDFjMy00NDYwLWJlZjctMzliNjQ4MDE2NzIw
90cf7556-e33b-4f18-a3b2-eee2f26d10ac	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-14 21:05:31.529089+00	2026-09-14 21:05:31.529089+00	{}	2026-09-14 21:05:01.529089+00	OPAQUE	REFRESH_TOKEN	sFNQaYux-Eeym-9nETGfMZSysq-XSAYzdhYTg0NDItZmY4Ny00YjJlLWIwZWEtM2ZlYjM5ZTNkNDlm
312d1a67-d25a-4fdd-be9c-a4b168c441e6	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-14 21:05:34.838915+00	2026-09-14 21:05:34.838915+00	{}	2026-09-14 21:05:04.838915+00	OPAQUE	REFRESH_TOKEN	Ix4iqCfvE6HDJWGeosm4gammgDLDkQYjE0YmMxYjgtYWFhZS00OTc0LWFkYzQtMTM1ODg3YTUzNTUz
d71c9bc3-c746-45a3-9cac-9e170a133616	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-14 21:05:36.019692+00	2026-09-14 21:05:36.019692+00	{}	2026-09-14 21:05:06.019692+00	OPAQUE	REFRESH_TOKEN	rPNFQeCo-ziZk5_TYPOGxpcngDiIUwN2JmMmVlZTAtM2IyMy00Y2FmLWEyZjYtMDk0MDZjMmZjN2Q3
e87c8469-9369-4c3b-b944-60e6487d3b55	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-14 21:05:37.306949+00	2026-09-14 21:05:37.306949+00	{}	2026-09-14 21:05:07.306949+00	OPAQUE	REFRESH_TOKEN	R0lAFpgDxgiKUrGPCnxLRXB1SfXchQNWI3M2M2NDEtNGNjYy00NTc1LTg4ODktZWJmOTdkNmE4YTE1
a9eb3c21-dadd-4179-8472-26c78ae32bb1	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-14 21:06:17.564336+00	2026-09-14 21:06:17.564336+00	{}	2026-09-14 21:05:47.564336+00	OPAQUE	REFRESH_TOKEN	FZ1hSTRwBc-GEDSue8DjlKsWNuMYkQYmU2YTJiZDUtZTA5Ni00MWVlLTlkMjMtZTAxNWMzNmE5NzIw
7b89a792-008c-4e24-9b09-fee92f5b6fb9	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-14 21:13:27.393992+00	2026-09-14 21:13:27.393992+00	{}	2026-09-14 21:12:57.393992+00	OPAQUE	REFRESH_TOKEN	J_I0e0tOP9nTleaWvLHS7_TDc0L8qAZTk2NDRkY2UtMWE0YS00NjlhLWFkY2MtY2IwOTQ2ZTRmOGRi
0a35586c-4c51-4fa3-a6fb-ccc4b6107ced	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-14 21:13:27.728117+00	2026-09-14 21:13:27.728117+00	{}	2026-09-14 21:12:57.728117+00	OPAQUE	REFRESH_TOKEN	0wRdfFd6moQi_na8mzqzj-CpQ9gkqQNGVkYjA1NTUtODdjZC00MTVhLWJhNTQtZjMwYTg4MmIyMWYz
0e3d1d05-3467-4c9f-819c-4677466f129b	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-14 21:13:28.031511+00	2026-09-14 21:13:28.031511+00	{}	2026-09-14 21:12:58.031511+00	OPAQUE	REFRESH_TOKEN	i6NB2h5h9reVtw-m4sZQMTFWv7X_jAMjZkMDJjOTEtMzRhMi00MjIwLWI5YWUtZDlkZWM0ZjAwYjUx
d97c4244-5283-4712-a32a-9d4c33f33775	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-14 21:13:28.356225+00	2026-09-14 21:13:28.356225+00	{}	2026-09-14 21:12:58.356225+00	OPAQUE	REFRESH_TOKEN	pNTQgEoKMMZGgu7b6T6n0RAmdEhDzwYmQwYzE0ZTEtNTIyZC00OTkyLTg5ZmItYTE5NmMyY2M1YTVm
679f8a14-264c-45db-b69a-3049858a9c61	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-14 21:13:28.663954+00	2026-09-14 21:13:28.663954+00	{}	2026-09-14 21:12:58.663954+00	OPAQUE	REFRESH_TOKEN	uHcmUEkKG1_QODjP-mm_DV5zvNzI1wMTM5NDI1YWUtY2U1MS00YTA2LWFlMGYtNDA1YzVlM2YzMTMy
1e889c98-c4e0-4d19-a71a-4edcb60a9df3	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-14 21:13:29.01172+00	2026-09-14 21:13:29.01172+00	{}	2026-09-14 21:12:59.01172+00	OPAQUE	REFRESH_TOKEN	3oeUzMJLpom-PnoBxwQNLGezdXntuQMTU5ZTQzYTQtNmQ0Ny00YTkwLWJkYzgtZWNjZjE1NDFlZDc1
298c8db0-8ed2-4ea9-afc4-0148f584f7a1	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-14 21:13:29.313904+00	2026-09-14 21:13:29.313904+00	{}	2026-09-14 21:12:59.313904+00	OPAQUE	REFRESH_TOKEN	kXWPKkk2HoQPOPALfzFWiV-jAYS-QwMjczNDBjM2QtOGIxNS00YzdmLTg0MjktMDU3YjVhMTNhM2U0
0a22535b-46e4-437d-85c3-4400e17bae70	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-14 21:13:29.62873+00	2026-09-14 21:13:29.62873+00	{}	2026-09-14 21:12:59.62873+00	OPAQUE	REFRESH_TOKEN	O2I8GiS1RyHFpCY562ev35-R696jFQOTQxMjQ0ZGMtM2U4MS00OWEyLWE0MGUtYTAxMjcyZTk0ZDc4
c035a87d-2beb-4289-bab8-260428483694	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-14 21:19:39.176937+00	2026-09-14 21:19:39.176937+00	{}	2026-09-14 21:19:09.176937+00	OPAQUE	REFRESH_TOKEN	uS4dsJgoxrfcB7AbS1753h3-l3k0CAMzc1OWQ4ZDUtMTNmMS00ZjgwLWEyNTQtYjJlNTNlMDViOTli
8924e92e-09fc-4e27-88f8-03f3f920c945	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-14 21:19:39.440224+00	2026-09-14 21:19:39.440224+00	{}	2026-09-14 21:19:09.440224+00	OPAQUE	REFRESH_TOKEN	37vp2brCDJR3QF4Coc36NU1UNS5tBgYWQ1MjRjZDctMGMwOS00ZDZjLWFhYjYtOTRhMDYwMjRjNjlm
a3e16067-5f98-421e-aff6-154ec37b981d	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-14 21:19:39.712867+00	2026-09-14 21:19:39.712867+00	{}	2026-09-14 21:19:09.712867+00	OPAQUE	REFRESH_TOKEN	5yY230condeOFg7MGDicggqIwmvlXwYTNkZDdkZDYtYjEzNy00NmFkLWE5MWItNDU5ZDg3ZTg0NTc0
c17754a1-38f0-4f80-b3eb-4eb5f7e6dbe1	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-14 21:19:39.98176+00	2026-09-14 21:19:39.98176+00	{}	2026-09-14 21:19:09.98176+00	OPAQUE	REFRESH_TOKEN	N78DVl9UIF5GtZoikiGDQurLsUG7qwNzZjZDg3NWMtZDVjMC00M2EwLWJjOTQtYWMxMTZlZjU4MWU5
930ac905-a5f6-4924-aa0d-8e99d2fb2242	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-14 21:19:40.302047+00	2026-09-14 21:19:40.302047+00	{}	2026-09-14 21:19:10.302047+00	OPAQUE	REFRESH_TOKEN	lgEM9nLSnaZMVgqB50bzuvvcRizPggZTE0MjUzOTEtMDQzNC00MTFjLThjYmUtNDM1MTY3ZjFiNjRh
764e1b28-3010-4920-acd1-decd401de100	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-14 21:19:40.580082+00	2026-09-14 21:19:40.580082+00	{}	2026-09-14 21:19:10.580082+00	OPAQUE	REFRESH_TOKEN	m45nSh2DiacTn5uI5_8Jm0K33X-9TwOTVkY2JiODctYTNhYi00M2JhLWJlYWYtOTgzMzExZDg1OTFi
0b5afc4b-6308-4fd1-9225-290d76e0429d	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-14 21:19:40.869669+00	2026-09-14 21:19:40.869669+00	{}	2026-09-14 21:19:10.869669+00	OPAQUE	REFRESH_TOKEN	-Eniq015xJJC6thnhOTQWDg3kh3m4AZDZkM2EzZmMtMTA4ZC00YWM2LWIwY2YtMDRiNzJkMDViZDQ1
3902c775-ede8-485a-967b-385386024f4b	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-14 21:19:41.20992+00	2026-09-14 21:19:41.20992+00	{}	2026-09-14 21:19:11.20992+00	OPAQUE	REFRESH_TOKEN	2agGEIsPHx6mYGeVg6XbM_ibaRQJgwZDEzOTVkMjItYWM1OC00NzU0LWIxYjMtZTljNWRlNDg4OTZm
5e1d9bfb-804a-4145-bf60-a48194ba3f87	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-14 21:27:24.231384+00	2026-09-14 21:27:24.231384+00	{}	2026-09-14 21:26:54.231384+00	OPAQUE	REFRESH_TOKEN	sfJNRsWXDnzBkuB3KuG09XDPcwDFogYTMwYTMzODYtZjgyMC00MjI0LWE2MDQtNjljNWNmZTcxNmZk
52f59c50-7e79-455c-9d6b-54d7820b1e74	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-14 21:27:24.545237+00	2026-09-14 21:27:24.545237+00	{}	2026-09-14 21:26:54.545237+00	OPAQUE	REFRESH_TOKEN	IwxYmva9uz_0QZdA_PmEhC4JcVxBzwYjIxNTcxN2EtODdiMC00OTllLTllNDgtZmViY2U4ODRlYTk3
265dae99-c0f1-48c7-860a-27dc0c42e514	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-14 21:27:24.839378+00	2026-09-14 21:27:24.839378+00	{}	2026-09-14 21:26:54.839378+00	OPAQUE	REFRESH_TOKEN	1DEtcMMGU5tsH2neJQz2NFq_lnhkwAZWQ1OTNiNDUtZGIxMC00MTk5LWI5NDYtMzdiNjI1MGFhMjlk
61f7741b-7498-4c32-83c6-bd1b7c0a48d1	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-14 21:27:25.163812+00	2026-09-14 21:27:25.163812+00	{}	2026-09-14 21:26:55.163812+00	OPAQUE	REFRESH_TOKEN	4_X6_Uy5uANJWZrGmTtgXJheD0LJ4wOWEwOWRjMjctNDY5Mi00NzQwLWIwZGYtMmQyMWYwOTIxYjI1
f6dd18e6-3888-497d-8753-29f82cd78444	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-14 21:27:25.655633+00	2026-09-14 21:27:25.655633+00	{}	2026-09-14 21:26:55.655633+00	OPAQUE	REFRESH_TOKEN	VdeuI3R4HAC04Z1L6takg_5s425NTQOGE3OGRkZGEtZmJmZC00NjE5LTg1M2UtMmEyZTg3OWY5MDg0
8a9c59d7-f23c-4bde-b35f-eb7cbfde75c4	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-14 21:27:25.939698+00	2026-09-14 21:27:25.939698+00	{}	2026-09-14 21:26:55.939698+00	OPAQUE	REFRESH_TOKEN	dpjvmbAUhE52Dx3JkEa0RMgLYWkD1gMDAxYTA4ODEtY2E0MS00OTQyLThiZjgtOGRlZTFkNzQ3N2Fh
21153c19-0aea-4a46-9d35-c762ddc68e8b	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-14 21:27:26.223166+00	2026-09-14 21:27:26.223166+00	{}	2026-09-14 21:26:56.223166+00	OPAQUE	REFRESH_TOKEN	br1jPFiU3kvy-b5GLwnHgAYadeHJKwZmIwYzFlZGYtYmNmZi00ZWEyLTgwZmItN2E5ZTEwMWMyMjk2
2b63b82e-8825-4247-8789-0e57398f4f25	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-14 21:27:26.513659+00	2026-09-14 21:27:26.513659+00	{}	2026-09-14 21:26:56.513659+00	OPAQUE	REFRESH_TOKEN	SYZVn5QR12OHzwUZJRFAYqnZ39d_KAMzYyYzk3OTctZTZjZi00MmY1LTgzYzItODRlZTRhYWIzMjQ2
096e955a-04a5-4280-b899-eebee97f1ecf	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 21:33:32.369162+00	2026-09-14 21:33:32.369162+00	{}	2026-09-14 21:33:02.369162+00	OPAQUE	REFRESH_TOKEN	JllPXtmpLgcAndWQiAwnzjJPtvKnoQYmU0NzY4OGYtZmU4Zi00OTI5LTliYWQtZDdhNmFjNGI4YTY4
885955fc-6de7-4785-b817-c2f0059953a8	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-14 21:33:32.692117+00	2026-09-14 21:33:32.692117+00	{}	2026-09-14 21:33:02.692117+00	OPAQUE	REFRESH_TOKEN	aDMOjhNGcpS1pi8zu9YOLFgg85-xBgYmZiY2Q1ZjMtMTc0Mi00MzI4LTliYTYtMjIzOGZhODAyM2Ri
921caa77-1cba-4784-928b-3bc3f584adb3	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-14 21:33:32.956744+00	2026-09-14 21:33:32.956744+00	{}	2026-09-14 21:33:02.956744+00	OPAQUE	REFRESH_TOKEN	6zeei0PWBeJ9NXkbYyRg1EPWJ1yrkwMGQxODA3YWQtMDRkOC00ZGU1LTljZTgtZTJkNGJhNDdmYTQ0
1138d85f-9b67-45d2-bfca-9467f20eb1bd	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-14 21:33:33.22119+00	2026-09-14 21:33:33.22119+00	{}	2026-09-14 21:33:03.22119+00	OPAQUE	REFRESH_TOKEN	9KerZn1Yj_2EG1bmCTKPl4JK0qaTcAM2NiYTQxMTQtOGQzYi00ODljLTlhNmItMTZkOTA0MTQ1MTEx
8c6d86aa-910d-4e06-9f0d-de56765dad64	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-14 21:33:33.530693+00	2026-09-14 21:33:33.530693+00	{}	2026-09-14 21:33:03.530693+00	OPAQUE	REFRESH_TOKEN	US7Tf955Uo0Z7oUhjtEg0PCTXzJy6QYzVlMGEwNTMtZjk1NC00OGNlLTg5ZDUtZWFmOGM5YTI5M2Jj
8db3ef15-02d9-41a7-8ffa-3819b1b96327	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-14 21:33:33.811666+00	2026-09-14 21:33:33.811666+00	{}	2026-09-14 21:33:03.811666+00	OPAQUE	REFRESH_TOKEN	zCoMCIZfVlkEFKzK2JeaF2yOGAUBuwM2Q2NTY4MmEtOTZiYi00MGYxLThmZmMtOGE3MjUwODdiYjZj
1cfdee2f-5ae2-4fc4-97d2-dc19ea75e58d	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-14 21:33:34.053328+00	2026-09-14 21:33:34.053328+00	{}	2026-09-14 21:33:04.053328+00	OPAQUE	REFRESH_TOKEN	24Q3C8DIJ7i1ag6SRjnp4NVHBabdvQNTdiYjUxOTktYzA3Yy00MmIyLWE4MDQtOWFkZWMzYzU5YTJk
f9ccc420-a7ca-4e00-8855-08232e2b4f3f	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-14 21:33:34.299737+00	2026-09-14 21:33:34.299737+00	{}	2026-09-14 21:33:04.299737+00	OPAQUE	REFRESH_TOKEN	jOb_R-ux9FAV0eg7WtSJpbgv0MRmsAMDA1N2Q4YjgtMmZlMi00NzQxLWE3YmMtMWY5NGFmZTc0Y2Q1
e613bbee-022e-4a4e-b755-18b467a46f69	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-14 21:33:34.541253+00	2026-09-14 21:33:34.541253+00	{}	2026-09-14 21:33:04.541253+00	OPAQUE	REFRESH_TOKEN	C9iHUqzQm9F5khTc23aTqZ4MwNL7ZwY2YxY2ZhMDQtMzA5OS00ZDExLWFlYTYtZWUwYTg4YjY3ZDc5
f2c4389c-fa68-45c0-9f14-f4cec87befc3	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 21:34:24.560128+00	2026-09-14 21:34:24.560128+00	{}	2026-09-14 21:33:54.560128+00	OPAQUE	REFRESH_TOKEN	UjtRa66XP-M83ajlEyee-lKRizx79QYzAwODgzODAtMjk0NS00MmRkLThhNTYtN2E2OGE4NjYyM2Nh
7a095279-7d7a-42e4-b1b3-62d8bb71bb75	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-14 21:50:20.587175+00	2026-09-14 21:50:20.587175+00	{}	2026-09-14 21:49:50.587175+00	OPAQUE	REFRESH_TOKEN	8VemDDYZxzxLMqAto2oOeneJupdXcQYzA3MzE4YzAtYjBlMS00MjI0LTkyODItM2IwMzg0ODIwZjQ3
55d2578c-72e8-4e07-a2c1-481b6842c290	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-14 21:50:20.891473+00	2026-09-14 21:50:20.891473+00	{}	2026-09-14 21:49:50.891473+00	OPAQUE	REFRESH_TOKEN	5Uixqi0MayYUhDOrklcrxjyp9zS5JQZDlkZjdlOWYtYmVmOS00MDBhLWE2ZGMtZjkzOTNjNjk1ZDIy
2faff6c7-a5d3-41e5-b01c-2a5b79b3b4d2	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-14 21:50:21.178161+00	2026-09-14 21:50:21.178161+00	{}	2026-09-14 21:49:51.178161+00	OPAQUE	REFRESH_TOKEN	oz9F8KUnRxALGQVyhbvQCzUWx25Z9wY2IxNzdhYWQtODdhZC00YWFmLTlmYjAtNDVkMjA4NjQxZjk3
6478dc29-d787-4e97-80bd-77384cf1c5ee	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-14 21:50:21.588384+00	2026-09-14 21:50:21.588384+00	{}	2026-09-14 21:49:51.588384+00	OPAQUE	REFRESH_TOKEN	ocdNbGUiZpfSSO9PR3yS0aBwLapUPQZWYyYThiODQtZjA1Yy00NmRmLWI3OGQtNTM2ZWNiMzhlMTJm
af980929-7617-49bc-b4c2-5b04ff6f7edb	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-14 21:50:21.855878+00	2026-09-14 21:50:21.855878+00	{}	2026-09-14 21:49:51.855878+00	OPAQUE	REFRESH_TOKEN	1FVfL4V2xYrW-rItBqDQMhK1qvGPOQMTM4ZDczOWUtMTkwYS00MDNkLThjN2QtZjc4NmMzNDQ3Y2Qz
5bc57c8f-bdac-4335-9f87-a3d3ef144831	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-14 21:50:22.170695+00	2026-09-14 21:50:22.170695+00	{}	2026-09-14 21:49:52.170695+00	OPAQUE	REFRESH_TOKEN	tgHT-71QpXj6o_SzLK28w5Mi2GiTnwYTlhMmQ5MTQtNTNmZi00NDI3LWIzOTQtZGMwYmM5NmVkYmI1
7653872d-ce78-4812-b9d4-17f0641283b0	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-14 21:50:22.455704+00	2026-09-14 21:50:22.455704+00	{}	2026-09-14 21:49:52.455704+00	OPAQUE	REFRESH_TOKEN	yViGNTCU-W9Iks6-zY3itr8lCyy5aQODEzNWE2MTAtMmRhNy00MTQxLTk2MmQtODhlOWUxYzg5Mjc4
a464c367-dec8-49d0-bf30-8ec50e76ec15	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-14 21:50:22.739576+00	2026-09-14 21:50:22.739576+00	{}	2026-09-14 21:49:52.739576+00	OPAQUE	REFRESH_TOKEN	iKZjV3hYnuX0PoP8opemBQxMlcXOSQYTBhYTg5MjctYzY3Yy00NDUxLWFmZjAtOWNjYjNjOTZkYjE3
992a686a-9bad-4763-9d5a-726eb689de72	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-14 21:50:23.010902+00	2026-09-14 21:50:23.010902+00	{}	2026-09-14 21:49:53.010902+00	OPAQUE	REFRESH_TOKEN	58fbs7GGtNvPexWs2x01o-Byk6CejwMGJiMDNkYjctMmI4Ni00ZWJkLTgzYWMtZDlkY2IzNjk0MDJk
3fd79c59-bdd6-4dd7-96fa-4fb1a95e7e9d	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-14 21:50:31.319953+00	2026-09-14 21:50:31.319953+00	{}	2026-09-14 21:50:01.319953+00	OPAQUE	REFRESH_TOKEN	cg6H3dDtL-G3zITCNO1PkQENJUu3swMGVhY2IzNDgtNzJlMi00ODFhLWE1YzMtZjM1MzI1N2IwMmM1
2fcb1810-812e-4262-b57e-f32d6219eba7	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-14 23:54:13.180697+00	2026-09-14 23:54:13.180697+00	{}	2026-09-14 23:53:43.180697+00	OPAQUE	REFRESH_TOKEN	zt0xQVOQi__y23BeLq2WeBlqcMQeNAYzdiOTJhOGEtZjAxNi00NzQxLTk3NjQtMDQ1MTYzOWI3OTM2
48239ccb-3f60-425d-bb95-1f2f537406e6	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 00:10:47.372704+00	2026-09-15 00:10:47.372704+00	{}	2026-09-15 00:10:17.372704+00	OPAQUE	REFRESH_TOKEN	yJiiX1QjW1Pd7XI2bkguKXuY1TniPAN2I3M2JmZTgtMDk2ZS00NmY1LTlkNzItNGM3ZjM1YTdiYjAy
7309edb8-2fb2-467a-afd4-6f2af0215ded	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 00:10:47.56515+00	2026-09-15 00:10:47.56515+00	{}	2026-09-15 00:10:17.56515+00	OPAQUE	REFRESH_TOKEN	pdasci1caDaUGwC3ZHEkR13CFJXGtQY2U3ODlmOWUtNjlmYy00Mzc5LTlmNjYtMmZiNGUzMTdjOWVm
e0222d9f-8395-40fc-8dbd-328b1b04bb69	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 00:10:47.749423+00	2026-09-15 00:10:47.749423+00	{}	2026-09-15 00:10:17.749423+00	OPAQUE	REFRESH_TOKEN	Eaj_YL4o8HSQWOwfKDXEypMGxL5zxwMGEzM2YwYjMtNTEyOC00MzQ4LThmODgtYzNhNzhhMzkxNDNk
3fa935ec-71d8-4da1-8be2-360bf117441e	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 00:10:47.958427+00	2026-09-15 00:10:47.958427+00	{}	2026-09-15 00:10:17.958427+00	OPAQUE	REFRESH_TOKEN	7RMbvqoEruhxhy41K429Kn7G_ehklAZGVmODNmYjYtZTkyNC00MmRhLThlZDgtNWYyOTFkMTU2MmI0
e8b45a60-4cb8-4f78-8ebb-d288412dceb9	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 00:11:04.72994+00	2026-09-15 00:11:04.72994+00	{}	2026-09-15 00:10:34.72994+00	OPAQUE	REFRESH_TOKEN	Ak5Pf1hvqdBDXzNwuD_oc-dbqfZczQNzI0ZWNkM2EtZTlmOC00NmJhLThlMTQtZTI0ODM2ZWVjYWVl
7d45b510-bbca-4b05-8fac-04615ad404c3	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 00:17:53.043536+00	2026-09-15 00:17:53.043536+00	{}	2026-09-15 00:17:23.043536+00	OPAQUE	REFRESH_TOKEN	lyh1G2sPup24yUj8KUxO1OYwcXZ1YgNDBhMWUwNGYtM2FiNC00NTQwLWFlNGUtZjQwNTdjM2ZiYTM3
ff4877ad-1c39-43ed-ae47-ef20993b206d	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 00:17:57.457239+00	2026-09-15 00:17:57.457239+00	{}	2026-09-15 00:17:27.457239+00	OPAQUE	REFRESH_TOKEN	5QFgf1j0DrEbo6IbkBpwee2FlhxrZQODMwZTYxNjQtMjQxOS00ZWM4LTgyYTAtYTE5ZDdiNGU1MGM3
f51c68be-a471-4f17-a876-c72dd84db7e7	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 00:25:39.952924+00	2026-09-15 00:25:39.952924+00	{}	2026-09-15 00:25:09.952924+00	OPAQUE	REFRESH_TOKEN	iXmHTMLgdn1Nz4Y1BGKdmLCpD1PJeQNmRkNzUzOWYtMTliNy00ZWEyLWEyNzgtZTEyNGFjOTNlMTlk
a392f789-edf3-4d6b-bdcb-c2a4a6b97283	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 00:25:40.827864+00	2026-09-15 00:25:40.827864+00	{}	2026-09-15 00:25:10.827864+00	OPAQUE	REFRESH_TOKEN	oec2nh1E0hFqfipnmHtrxuclwbIKHgMmZhMzQ1MzctNGYwZC00ZDYwLTliMDAtMzg3M2Q1OTNkN2Vm
49a2b775-3549-4802-b86c-1b7f028c4713	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 00:34:23.847109+00	2026-09-15 00:34:23.847109+00	{}	2026-09-15 00:33:53.847109+00	OPAQUE	REFRESH_TOKEN	RnEaqbnh_p7k51-0LAPkL9PaKCgHngNDRjYjVmMjktZjVmZi00NDczLWI4YmYtNmRmNmMxOTAwOTJh
a82727a0-15b0-420c-adff-02411c278560	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 00:34:26.554982+00	2026-09-15 00:34:26.554982+00	{}	2026-09-15 00:33:56.554982+00	OPAQUE	REFRESH_TOKEN	xm52tHakh7YdhL9t68Vr8RzJOxH4uwNDhhNjgxZWEtODYxNi00YWY3LWI0NWItN2FmYzc3MmRkYWFm
c0e8ba81-5c31-4ebd-a304-b1504f3cbc42	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 00:39:54.577291+00	2026-09-15 00:39:54.577291+00	{}	2026-09-15 00:39:24.577291+00	OPAQUE	REFRESH_TOKEN	Vu131BzYONZc5r7q423BdQb3ahLdHgNzdiNTBmZjMtZWMxZC00MWY0LWIzNDktZWNkMDUwNDVkMDI1
de629e94-82fa-4c20-84d1-606563f159c4	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 00:54:21.697531+00	2026-09-15 00:54:21.697531+00	{}	2026-09-15 00:53:51.697531+00	OPAQUE	REFRESH_TOKEN	iQUQMrwjTgcZV5NEb0JrBk4z6oI-4wMjEwN2ZiMzgtODc0ZC00NzYyLTkxOWItYjNkYzgxZjNkM2Qw
44fb554a-56cd-4ddd-bbcf-4fdbc7919e03	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 00:54:21.960109+00	2026-09-15 00:54:21.960109+00	{}	2026-09-15 00:53:51.960109+00	OPAQUE	REFRESH_TOKEN	W7guVI71V3ecCyh5U_WE0T4dElEzAQYTU0NWQ1NTMtNmE5Mi00MGFiLTg5ZWMtNDRlNzFkMGQ2ZDIw
cb884642-e790-4a89-bf45-e67a6141198c	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 00:54:22.13338+00	2026-09-15 00:54:22.13338+00	{}	2026-09-15 00:53:52.13338+00	OPAQUE	REFRESH_TOKEN	Il5DE8yFdM8nQ6s-cuV5sNqP5b56lANjgyZmI5NmEtZTBmOS00ZTZiLTlhNWMtYmIzODQxN2YwNWIz
9661d726-db5b-4ca1-b327-81097fbfeeab	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 00:56:29.938252+00	2026-09-15 00:56:29.938252+00	{}	2026-09-15 00:55:59.938252+00	OPAQUE	REFRESH_TOKEN	P0B-0ZTsHBy9axNKkE7xnUshqIm_cwNzc4MDExMTMtMTdjNi00Mjg5LThkZWYtMDZiMTQ3MTZjNGEw
239fd45e-dc51-449f-bfe3-d54f36afc7a0	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 00:56:38.300373+00	2026-09-15 00:56:38.300373+00	{}	2026-09-15 00:56:08.300373+00	OPAQUE	REFRESH_TOKEN	TR3L7O5Jq9ILZzXGtzkgw5UOUKwwWgYzZlMDY1MjQtZmI2NS00NWYwLThkMGYtM2JhOGRiZjk4OTA4
d422b38e-8e42-4bb7-b327-8c50071b17d6	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 01:03:05.153304+00	2026-09-15 01:03:05.153304+00	{}	2026-09-15 01:02:35.153304+00	OPAQUE	REFRESH_TOKEN	0xWXO0k3GpwUG55itx9Y9YjEejVqTwYWY0YWY1ZTgtNjIxMS00ZjNkLTgxZDAtMjVkZDMzZGM4NDQ4
92b78578-c95d-4ca0-93ca-d4ffff026387	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 01:03:05.455765+00	2026-09-15 01:03:05.455765+00	{}	2026-09-15 01:02:35.455765+00	OPAQUE	REFRESH_TOKEN	JzW9HLIO4CoWzMqBo--sW-lWRyYvIAMDMyODZhYzAtYjJiZi00ZTMxLTgxZWUtMmU3MjNiZTA2NTc3
06f7f82a-3485-489a-a4bc-1f1aeb93b088	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 01:03:05.577833+00	2026-09-15 01:03:05.577833+00	{}	2026-09-15 01:02:35.577833+00	OPAQUE	REFRESH_TOKEN	hqYLsC_SLTtUETDP2Qi7cacXl3oW1QZmZhMzdhZWUtM2U0Yi00NGVjLWE0OGItN2MxOTNiMmQxNTgz
394cf810-db2e-4b03-bd54-41584137013a	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 01:07:51.89571+00	2026-09-15 01:07:51.89571+00	{}	2026-09-15 01:07:21.89571+00	OPAQUE	REFRESH_TOKEN	udRrR3N5Kgua2uYR3taH8yqs0tFTFwYTUzNzczMjQtZmNkNy00YmU5LWE3NTMtNGM1M2RhNGQ0NmI5
deda8910-443f-42a7-9836-b3efdec0582f	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 01:25:49.930561+00	2026-09-15 01:25:49.930561+00	{}	2026-09-15 01:25:19.930561+00	OPAQUE	REFRESH_TOKEN	okb81nApp8ES2szNn-A7056i16qKpgZDhiNjI3ZWEtMmE0OS00MDBhLTg4NTEtZTEyNzY4YWRkNDUw
8981e25c-339d-41b7-b04a-d537f4df60ed	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 01:25:50.903902+00	2026-09-15 01:25:50.903902+00	{}	2026-09-15 01:25:20.903902+00	OPAQUE	REFRESH_TOKEN	g8Xb4X1ZbuQTJrd4QaOv8UDRtzR_wwOGQzOTRkYmItZDBmNS00ZTM0LThmNDYtZWJiMWI3ZTA5ZDNk
ebf24353-3466-4358-b3e9-def8c14201c0	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 01:25:51.368674+00	2026-09-15 01:25:51.368674+00	{}	2026-09-15 01:25:21.368674+00	OPAQUE	REFRESH_TOKEN	FYsDcCPezZje6NDgZBQ82lhB-jjh7gYzk5NGE5ODYtZjg5YS00MWM1LWE0MzgtMjI3ODAyNzBhMDkz
08afb0dd-7a93-4220-922c-d03572a71437	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 01:27:11.873027+00	2026-09-15 01:27:11.873027+00	{}	2026-09-15 01:26:41.873027+00	OPAQUE	REFRESH_TOKEN	T-ybngGgax1sd_7OpNBq7hfzWrY3YQMTQ3NDM1ZDItNzAwYi00ZjM4LWFmZTAtMmUxMmRkYjAwNjI2
62819fe6-438d-4eb4-b278-2e71b177fdbe	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 01:27:50.130159+00	2026-09-15 01:27:50.130159+00	{}	2026-09-15 01:27:20.130159+00	OPAQUE	REFRESH_TOKEN	V7DSiA2fha_TPXrQC7fFRg3ynvj_GgNWMxYzBkM2YtMDcwZi00YzkxLTkwNmYtNzFkYzYwYjFlM2Qw
05166eb7-0f11-4b2b-aa32-939748b38293	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 01:28:51.05436+00	2026-09-15 01:28:51.05436+00	{}	2026-09-15 01:28:21.05436+00	OPAQUE	REFRESH_TOKEN	ZH_m8drgMZGpN3z0f3RJ1olcuyCVhwYTY5YmY5YmQtNGY2YS00ZDI0LThkN2QtYzBlMTFiYzE2MThl
b107bc97-4351-4ea9-89dd-ceb8587d28e8	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-15 08:27:26.319928+00	2026-09-15 08:27:26.319928+00	{}	2026-09-15 08:26:56.319928+00	OPAQUE	REFRESH_TOKEN	_Wk918XHHvpFXUSkV48hq-09hfm-zgYjQ3ZGJlMTktZTM5OS00MzcyLWIyZDktNTYwMTY1MWE0MzM5
e81183fa-37be-4d78-a9ff-0daaee0a4762	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-15 08:27:26.625783+00	2026-09-15 08:27:26.625783+00	{}	2026-09-15 08:26:56.625783+00	OPAQUE	REFRESH_TOKEN	se8RCh6lyyD4CZtLRUsokio7A3IzPgMGUzOTJiZWUtZDc0Yi00N2U1LWIyNTEtMzk1NGIzZTE4M2Vl
db1a46fb-ce6b-4eed-893a-bdbe99a0dbd1	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-15 08:27:26.99982+00	2026-09-15 08:27:26.99982+00	{}	2026-09-15 08:26:56.99982+00	OPAQUE	REFRESH_TOKEN	tVgshJSEkVYb2EOx1NR5nve0b07sEgZWU2OGE2YWUtZDY1My00NTlmLTlhMTUtMTEwZTZlOTE2OGEy
bb6f77c9-2200-4ad9-a162-136a0b0062e7	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-15 08:27:27.442185+00	2026-09-15 08:27:27.442185+00	{}	2026-09-15 08:26:57.442185+00	OPAQUE	REFRESH_TOKEN	gdwtO5PNruGY_lIwS0BZmZAJpNwrqAOWVjNDYwY2UtYTI0Ny00YWM3LTg4ZGItOTY0NDE0ODRkNjQ5
f134fd81-e20a-4b59-a034-6079205dced8	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-15 08:27:27.83117+00	2026-09-15 08:27:27.83117+00	{}	2026-09-15 08:26:57.83117+00	OPAQUE	REFRESH_TOKEN	avYhySxfdn7-l_0P01UgOtPR8JJ2KwMmVlM2QwOWQtYjVhMi00MDdiLWFmYmItMGE4MDVmNDY4Njc0
a38a7a0c-c145-4069-981b-e5da7d764422	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-15 08:27:28.215598+00	2026-09-15 08:27:28.215598+00	{}	2026-09-15 08:26:58.215598+00	OPAQUE	REFRESH_TOKEN	Vwb3Y7qqUtGTKXF7x8JI0nzeQX5iXwMDBhNDE1MTEtMzVhYy00MzM4LWEyZjEtNTAxNzgyNjFhZGY4
14197ec9-8f07-4e86-b51c-6f1f8d8b787c	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-15 08:27:28.557491+00	2026-09-15 08:27:28.557491+00	{}	2026-09-15 08:26:58.557491+00	OPAQUE	REFRESH_TOKEN	y2S8CVvPx_TJUuz4BDrVBDp2hwjaKgNDUzMmMzYmItYWQ5Ni00NGQwLWFlNjUtN2QzNDQ2MDBiMDVm
6255a3aa-6a48-43bb-a728-572c9bf78989	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-15 08:27:30.039711+00	2026-09-15 08:27:30.039711+00	{}	2026-09-15 08:27:00.039711+00	OPAQUE	REFRESH_TOKEN	BpgHkz4fGn0QFh0zQsqgrbwjqwZYEwZDNjZDA4NTctOWMyNS00YTU2LTkzZjItNzM5YzFkNzRkMDYw
f59e728c-7870-4eff-8235-e83217de50ec	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-15 08:58:22.546387+00	2026-09-15 08:58:22.546387+00	{}	2026-09-15 08:57:52.546387+00	OPAQUE	REFRESH_TOKEN	5nGobv5MmX9cBAFy0C-VsOecsXd-MgNjM5NThmNzktYzY3OS00NmYxLWJkMzItY2IxMWUxMjgxNGNi
97c3d0dd-a092-44ca-a810-86d9824e1c93	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-15 08:58:22.855867+00	2026-09-15 08:58:22.855867+00	{}	2026-09-15 08:57:52.855867+00	OPAQUE	REFRESH_TOKEN	BEOeqtwA9A8V4KV_LCC1FuasEstDYQY2E0MWU0YzgtNTc2Yy00NDYzLThmNWYtYTYxMjIwNmI1ZjZi
4b3005c5-8aaf-4193-b99c-0ddde71230c1	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-15 08:58:23.552028+00	2026-09-15 08:58:23.552028+00	{}	2026-09-15 08:57:53.552028+00	OPAQUE	REFRESH_TOKEN	0KmRbM3Q388pB51MranVejQo_FSyLgYThmZjNhMmMtOGRiNy00ZTZhLTlmZTUtY2MxMmVlZDRhZmYz
cbffe736-7d0d-43bf-b15b-53d5e7c8b6cf	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-15 08:58:24.464173+00	2026-09-15 08:58:24.464173+00	{}	2026-09-15 08:57:54.464173+00	OPAQUE	REFRESH_TOKEN	HtOToVHxtIS1mo3P1QX_uQZmmRYeMgMGQ4MWFkOTEtNjZmZS00YzYwLTg1OWItN2IxNThmMTQyMDU1
91ad0997-ba57-436b-a656-8cbebef50eaf	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-15 08:58:25.889684+00	2026-09-15 08:58:25.889684+00	{}	2026-09-15 08:57:55.889684+00	OPAQUE	REFRESH_TOKEN	88saVBq-RiYlXsaWOf798hkAVqaVQgZDY2OGU5NWEtYTdmOC00NDliLTlmNjYtMzQ2MDBiNDFjN2Uw
572a76d8-e256-44cf-aea4-6e7cd178ff2d	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-15 08:58:26.563172+00	2026-09-15 08:58:26.563172+00	{}	2026-09-15 08:57:56.563172+00	OPAQUE	REFRESH_TOKEN	z_UVlM3cprFdCHoya_wzeMEldL_SdQY2E5NmUzMmMtNzQ1ZC00NWY3LTljZDYtMzMyOTk4NjJhN2I5
0e714d4d-938c-4c03-aa02-6527188a56ab	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-15 08:58:26.978541+00	2026-09-15 08:58:26.978541+00	{}	2026-09-15 08:57:56.978541+00	OPAQUE	REFRESH_TOKEN	Gh1mzt1e7Q3562pDD4GZX2Eig_S8nQOWIwMjYxOTUtZWU3Mi00OTVhLThkNzctYmNjNWE1MTc4Mzc2
781aa65f-4ee0-4dcd-8987-20de0ab1a912	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-15 08:58:27.238809+00	2026-09-15 08:58:27.238809+00	{}	2026-09-15 08:57:57.238809+00	OPAQUE	REFRESH_TOKEN	JkYoSSkrD46Xd3H-PfELtCm36PWR1gYWE5YTkxZDctYWNjYS00MzIxLWIwOGMtY2ViMzA2Zjc3YjUw
15be64d6-fcbf-4836-9360-d19434e9f7a0	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-15 08:58:27.487041+00	2026-09-15 08:58:27.487041+00	{}	2026-09-15 08:57:57.487041+00	OPAQUE	REFRESH_TOKEN	qO9tyUUVwEkBEt8JjPdaWCXWex9tDQMGE0ZjUyOTEtZWI0Mi00OTE0LTg0M2ItZTRhYWUxMTFmYjZh
bf2ea26e-22a3-420c-bdbc-ab16d1703852	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-15 09:03:55.486654+00	2026-09-15 09:03:55.486654+00	{}	2026-09-15 09:03:25.486654+00	OPAQUE	REFRESH_TOKEN	t4IUK1QhoBhxTVT0VRaZHXxlGdqo0gMDY2OTYxNzUtNTI2MC00MDk3LWFhYTUtMjQyNzZhYzRmODky
eac0025a-f587-4d0e-8c33-985f2a46bc78	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-15 09:03:56.81498+00	2026-09-15 09:03:56.81498+00	{}	2026-09-15 09:03:26.81498+00	OPAQUE	REFRESH_TOKEN	5tH_Q8b6-7XLV2_sbQjqUq1Lkko61wYzNjYTRlOTUtZjAzZi00OTA0LWJlNmQtY2UzMWE1ZWU5ZjYy
d9dd8c1a-5dcf-49de-badf-9f178bbac800	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-15 09:09:03.159089+00	2026-09-15 09:09:03.159089+00	{}	2026-09-15 09:08:33.159089+00	OPAQUE	REFRESH_TOKEN	5JDGIM-kEd0B7WMiQFG2vFwhmsSU0ANDBmOWVkYTEtMjY2MC00NDU0LWIzZWItZDYwZTZmZDBiOTY2
5d2e15ba-9311-45b7-b513-ea229a902823	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 09:13:24.69008+00	2026-09-15 09:13:24.69008+00	{}	2026-09-15 09:12:54.69008+00	OPAQUE	REFRESH_TOKEN	IbvQA0imWg5o0rPTW2wXoTvVke1LHQZTExMzZjNmItMGQ5YS00OGUzLWJhNDEtNTYzOGE0YTg5YTI3
8f5f026a-dc69-4ed0-9735-630be62c38bc	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 09:13:24.905665+00	2026-09-15 09:13:24.905665+00	{}	2026-09-15 09:12:54.905665+00	OPAQUE	REFRESH_TOKEN	IWrRirABX74e7tlJK-52-fPH-Mb_WgZTFkMjA3ZjEtY2YyYy00MjQ4LWI3M2EtOTkxY2I3NWQzOGI2
9da5ec23-0f77-4659-8b7d-43a84a609a6e	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 09:13:25.400892+00	2026-09-15 09:13:25.400892+00	{}	2026-09-15 09:12:55.400892+00	OPAQUE	REFRESH_TOKEN	ag0cH8pGUZtvCFFwpRM-k9L_glLTxQMDE3MTU2OTUtNTc1Ny00MzJiLWE2OTQtNWMxMWQxODdhNjAw
c10a962f-844f-4b4e-abd3-c0b5107c0a6a	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-15 09:16:43.465797+00	2026-09-15 09:16:43.465797+00	{}	2026-09-15 09:16:13.465797+00	OPAQUE	REFRESH_TOKEN	8pd9ZSgxulVZ00C9ZuewnuN3hR92OwZGE0MTgyOWQtYTA1Yi00YmE3LTg3YjEtOTRjNTllNjc2NTM2
acafc083-42d3-4dde-8692-5c9281cfcbdd	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-15 09:16:43.76782+00	2026-09-15 09:16:43.76782+00	{}	2026-09-15 09:16:13.76782+00	OPAQUE	REFRESH_TOKEN	EuZtCAGwFuGILLqRZ-v7IWF4hkU6lgZTI1M2I2YTEtMjFhOS00Y2QxLTlmYmItNzE1M2UzZTI5M2Jk
47370b74-e8b2-4717-b960-ab5bacca534b	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-15 09:16:44.067259+00	2026-09-15 09:16:44.067259+00	{}	2026-09-15 09:16:14.067259+00	OPAQUE	REFRESH_TOKEN	rNgtujkB2wMhTaYRuVsjOZ-kMxUAzwNDliMTA5ODktMGFkNC00MzhlLWFhZWUtNDlhYWI3N2U4NGY0
4506d3fe-274d-4504-a63e-8fd3e334fafa	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-15 09:16:44.345599+00	2026-09-15 09:16:44.345599+00	{}	2026-09-15 09:16:14.345599+00	OPAQUE	REFRESH_TOKEN	kA_QSSReg5G4UqMyH38SmPYi_7VD3QZjQyNTQyN2YtM2IyZi00ZGRjLWExNTEtZjlhOGMzZmNiZjVh
a9df5a34-2801-49e8-8ecb-bf051dbbf582	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 09:21:17.166956+00	2026-09-15 09:21:17.166956+00	{}	2026-09-15 09:20:47.166956+00	OPAQUE	REFRESH_TOKEN	O8wfKCiNtbJ7eg1rmNgpIcrDq8h6PgOWY0Mzg2ZjQtMmFlNi00NDAzLWIzNjEtZWQ2NDMwMDg3ZWMw
e9ac779c-6685-41f2-812b-1801bbc57b96	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 09:27:10.073182+00	2026-09-15 09:27:10.073182+00	{}	2026-09-15 09:26:40.073182+00	OPAQUE	REFRESH_TOKEN	M8bXFXkDHG59YTzRBnpdiH0LhKMrHAZmVhNjU3NGQtYTg2Ny00MGE1LTkyZTQtNDQ5NmEyOTgyMDI0
f6213039-ca71-4f13-9962-6e3a968c61d9	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 09:29:52.301328+00	2026-09-15 09:29:52.301328+00	{}	2026-09-15 09:29:22.301328+00	OPAQUE	REFRESH_TOKEN	bJVuKHWJfkkEeRm_TsZhhcjgS2FX2AM2E4NTc4M2MtZWM1YS00Yzk4LWJlMGEtYTM5MWFiNzZkY2M2
6ece3936-c6bc-4e3a-93cb-c85cc599642b	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 09:33:32.807944+00	2026-09-15 09:33:32.807944+00	{}	2026-09-15 09:33:02.807944+00	OPAQUE	REFRESH_TOKEN	qHCkyAQcVye4knp-rk4rAbiFJupGwgN2QzNjc0ZTEtM2RjZC00Zjg4LTlmZDMtMDFjM2VkMGQzODQ3
fe26e4ba-ce53-434f-bd6c-841996689569	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 09:39:15.529179+00	2026-09-15 09:39:15.529179+00	{}	2026-09-15 09:38:45.529179+00	OPAQUE	REFRESH_TOKEN	mtjPlryN5oE-6vSFEIXEjakyuQNymQMjlhMzRiNjktNmFlOC00NDZjLWFhOTktZmM4Nzg3OThlNzBk
9fe3dcab-bd77-4013-bd8a-ebee00f301cb	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 09:39:16.420183+00	2026-09-15 09:39:16.420183+00	{}	2026-09-15 09:38:46.420183+00	OPAQUE	REFRESH_TOKEN	gtJv_VrUifEQllhvfEDlPeO702rCBwNzAxYmYwMzEtNjA3Zi00NGIxLWFmMzUtMmViY2QwNzBlYTAw
6082f61d-2c03-429d-8cd6-45efe6dcc710	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 09:44:35.03332+00	2026-09-15 09:44:35.03332+00	{}	2026-09-15 09:44:05.03332+00	OPAQUE	REFRESH_TOKEN	kxeDbovp8MjIIrAX7usdinpmbGDTnAYTNjNjk0ZDktZDE1Ni00NGQ0LWFlNjgtOTQxZTFmYzdjMmU3
d06898f7-7dee-4606-9b8b-ff91b0cd01e5	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 09:55:17.400248+00	2026-09-15 09:55:17.400248+00	{}	2026-09-15 09:54:47.400248+00	OPAQUE	REFRESH_TOKEN	qlVSMx3Drp4TN43oFA_M0SiD0OxMKgNDAzZTdhNDgtNDU5Mi00MWQ1LTgyN2MtNjUyMDgxMWY0NWY5
ede96bbd-b597-4145-b3e2-9932eace4014	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 09:55:17.596746+00	2026-09-15 09:55:17.596746+00	{}	2026-09-15 09:54:47.596746+00	OPAQUE	REFRESH_TOKEN	3rMxmZzYx7rRbl5LGE3xy0vgKlcKxAZjkyYjk2OGEtZmU5YS00MjBmLWE2MGUtMzAyNmY4OTYwYzM2
0d05dec2-c04b-414f-919c-868fc4f4810d	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 09:55:17.775387+00	2026-09-15 09:55:17.775387+00	{}	2026-09-15 09:54:47.775387+00	OPAQUE	REFRESH_TOKEN	Rgl50vfpdK-SnWCcvZ99QDImaNJn7wN2Y4NzkyYjItNTA5My00YTNlLWExYTUtZjhkMTkwOTdjMjJh
6de4a2f7-8862-4ee3-af3f-90b0f7db74e7	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 09:55:17.965073+00	2026-09-15 09:55:17.965073+00	{}	2026-09-15 09:54:47.965073+00	OPAQUE	REFRESH_TOKEN	pNp4RVwFKdJLg3GTlsYx1nmggpsOKwNjg0NjA3OWQtZTFlZi00MTA0LTllNjQtNjA0NWUyODU0ODJh
e028733f-ea39-448c-86ad-b108d37c1b82	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 09:55:18.142187+00	2026-09-15 09:55:18.142187+00	{}	2026-09-15 09:54:48.142187+00	OPAQUE	REFRESH_TOKEN	rVmtjumyTzANkLE5qozRBH5O5THuKQZmRkOGRlMzEtODg3Mi00ZjA5LWE5NTUtYzEzMmRlYjNmYzM0
3f3dd789-100e-4973-ad60-ee4f0b659cc4	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 10:01:42.467524+00	2026-09-15 10:01:42.467524+00	{}	2026-09-15 10:01:12.467524+00	OPAQUE	REFRESH_TOKEN	T9Inb-peEVRxcn7yiGF0oXCDMRihcAMDNjNDFiYzAtZWI2MS00ZDVlLWFlMTktNzA4OWRhZTYzOGVl
1a7551b0-0101-48d6-a50b-731beaa5bfe9	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 10:01:42.655329+00	2026-09-15 10:01:42.655329+00	{}	2026-09-15 10:01:12.655329+00	OPAQUE	REFRESH_TOKEN	X4U2VGGIRb5w6XfIlSV3cLzESUD8FAOGVlNDQ5YmEtZDIyOC00MWQwLWE3ZjMtNGJhN2U5OWM0M2Yx
046619a7-daa5-41c1-bccb-422c3a01ccf9	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 10:01:42.827224+00	2026-09-15 10:01:42.827224+00	{}	2026-09-15 10:01:12.827224+00	OPAQUE	REFRESH_TOKEN	Lztq4HgD0XU9zeYECa_oCQ0yXOg8SQZmMxYzcxMTUtMjg5OC00Y2QzLTk2NDUtMDAwNjQ1OTIwZTBm
bc3698fc-576e-4022-a667-5f29705d6ac3	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 10:01:42.99917+00	2026-09-15 10:01:42.99917+00	{}	2026-09-15 10:01:12.99917+00	OPAQUE	REFRESH_TOKEN	jzBv18jRh34I-b50Y19UlTRFowejdwOGVlMTNlMWUtNjgxNi00YzY5LWJjMjctMzZmOThkZTg2Y2I3
b3d9e108-449b-405e-ba9e-23035327ad42	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 10:01:43.171705+00	2026-09-15 10:01:43.171705+00	{}	2026-09-15 10:01:13.171705+00	OPAQUE	REFRESH_TOKEN	yvg76sdHj0heFCmrmrPknGDacF-fCwYWJiMmU2YWEtZDVmMS00MGE3LTkwNmQtYWI2MjIxMWMxM2Rh
65d27504-f311-49de-9018-dc1504beca3c	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 10:01:43.351151+00	2026-09-15 10:01:43.351151+00	{}	2026-09-15 10:01:13.351151+00	OPAQUE	REFRESH_TOKEN	retg2KKX8qYJPEPiGgDFrvgHuzyTbANTU1ZGFkYjYtZDgzYS00YjZhLTg3NzMtNmZhMGNkNDIyY2Nm
8ecf6dec-3d92-457b-aad4-588336a01ec6	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 10:01:43.525649+00	2026-09-15 10:01:43.525649+00	{}	2026-09-15 10:01:13.525649+00	OPAQUE	REFRESH_TOKEN	S1foBHMdFhIAmDDKRmVWC4AC33YT6QZTBhM2RmNDAtMDQ4NC00M2M0LTgyZDEtY2YxN2M2Zjc3MDg5
bc5a40bb-be59-4c58-b971-2fa821fc338d	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 10:01:43.700783+00	2026-09-15 10:01:43.700783+00	{}	2026-09-15 10:01:13.700783+00	OPAQUE	REFRESH_TOKEN	6P1lF3whQ3rk3YKIVOpEpOnw9gxcMwZGViMzk2NmYtODkwZC00NDdlLThjY2QtODBmZDY5ZGE1ZjFj
46d515e9-ca1b-4d7a-b0d5-2a54cff78df0	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 10:01:43.874501+00	2026-09-15 10:01:43.874501+00	{}	2026-09-15 10:01:13.874501+00	OPAQUE	REFRESH_TOKEN	5SCWEqJvYxAmr0sms1T3rYNV1VbLawOTFmMmUxYzktNTU3Ni00ZTJiLWFkNWItNTU5MTZmZjllOTI4
475d3631-f513-4fca-8356-1f35ab692d54	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 10:01:44.049392+00	2026-09-15 10:01:44.049392+00	{}	2026-09-15 10:01:14.049392+00	OPAQUE	REFRESH_TOKEN	SoH-MBEI_hoXPEdYHoxkK7tPuw11kgOWE1ZDRlZWItZjQxNi00NzA2LTgxZjgtZjVkZTQ5NjUxOTZi
121f9681-de1d-40ee-a540-559cc3aaecc4	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 10:02:03.390013+00	2026-09-15 10:02:03.390013+00	{}	2026-09-15 10:01:33.390013+00	OPAQUE	REFRESH_TOKEN	wb_3N3q1sI_t1SOGOefQy-TYkotDOgMjQ1Njc5YjgtOGYwMC00MDhjLWFkODEtODZkNTY1MDZjODI5
d70ffe24-1886-4120-bfdd-2f2522282d52	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-15 10:06:08.428124+00	2026-09-15 10:06:08.428124+00	{}	2026-09-15 10:05:38.428124+00	OPAQUE	REFRESH_TOKEN	E0pX6S6WCF1xA7G3kOkd99CV0u0LBwMjNiYzA5MDQtMmZlYy00ZWYxLThlMDgtMTgyNGNkOThmY2Y3
a8b0000f-c85a-4a4b-af71-0322b4135ed8	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-15 10:06:10.459806+00	2026-09-15 10:06:10.459806+00	{}	2026-09-15 10:05:40.459806+00	OPAQUE	REFRESH_TOKEN	QaKIEWqY4WpWwTnmc-2pIRKAjzYU0QMWE1MjFkYjItNzE3OC00ZDg1LWEyOWYtYThlMjRmODcyMTQ4
a93b83e0-0207-4bf6-833d-e9e19ce3a26f	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-15 10:06:10.729564+00	2026-09-15 10:06:10.729564+00	{}	2026-09-15 10:05:40.729564+00	OPAQUE	REFRESH_TOKEN	NF7QVHkMOWdmpHQpt-RFo-O8uvT00gZTEwY2NhZTgtMzliNy00NzIyLWIxZTAtZTNjMTI4ZGY1MTEz
8ae483d4-7744-46ea-893d-514b153d53f7	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-15 10:06:11.014715+00	2026-09-15 10:06:11.014715+00	{}	2026-09-15 10:05:41.014715+00	OPAQUE	REFRESH_TOKEN	byrN1HnA7Ir8d6xzgqOEaXkGma2psAYWJjNmZiNzQtMzE4Ni00MzVjLWFjOWMtNjNhYTUwMjRiNmU3
0b7c99cd-3896-4732-850e-0043a2c1d9ea	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-15 10:06:11.30999+00	2026-09-15 10:06:11.30999+00	{}	2026-09-15 10:05:41.30999+00	OPAQUE	REFRESH_TOKEN	iwiAj-g9_wGtGeOBRStEKu9fZ0z2dwMTEzNDFkZDktMmM1ZC00NTA1LTg5MzMtODMwYzFjMDk3MDNk
b58f1c14-8037-42f1-aaab-3a190a754742	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-15 10:06:11.589023+00	2026-09-15 10:06:11.589023+00	{}	2026-09-15 10:05:41.589023+00	OPAQUE	REFRESH_TOKEN	AeMnm3s18sBGfkGfrS8zs9dMm2MOHQMmY5MmVmYTEtMGQ0OC00NDUzLWI1MjYtMjhiZmNjMjkzYzFm
94903c52-738e-439d-9044-7d32f68aad38	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-15 10:06:11.879057+00	2026-09-15 10:06:11.879057+00	{}	2026-09-15 10:05:41.879057+00	OPAQUE	REFRESH_TOKEN	Zp0M5LFDlz4LidbuoqWlNIc2freXxwYTk0ZTgyMWMtMDRjNy00ZmM0LTk2NjAtNTA0YjBiZGZhZjk4
8337a3d1-9e64-4d34-8db7-479ddebdf862	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-15 10:06:11.879572+00	2026-09-15 10:06:11.879572+00	{}	2026-09-15 10:05:41.879572+00	OPAQUE	REFRESH_TOKEN	_j0Xzaq69d4qPv_2fvQV94guxKXlUwOTdkOWUwNzMtM2I2Ny00YjJmLWJkZTQtM2Q4NmE5NTBiNjBj
cb2d6f48-c7cc-4b0f-8e09-b21799d2cda9	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-15 10:06:12.163828+00	2026-09-15 10:06:12.163828+00	{}	2026-09-15 10:05:42.163828+00	OPAQUE	REFRESH_TOKEN	kI1K5LPPqRvXIV9YRilQCfQCJbO5dgYjY1ZTMwNWMtZmEwOS00MjI4LWE1MGQtZjI2NjBkMTZiMjk4
33c5cb08-1e45-4703-8c24-27307762437b	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-15 10:06:12.408947+00	2026-09-15 10:06:12.408947+00	{}	2026-09-15 10:05:42.408947+00	OPAQUE	REFRESH_TOKEN	PbSVN-aIkQnqXU1Pg-ct2ytWUCLHBgYTc1MTgyMTctODYyMi00NmUwLWI1NjAtMjFkN2RhOWJjODRl
527ba645-8874-4c4e-b9dd-78108b92ed47	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 10:07:09.689692+00	2026-09-15 10:07:09.689692+00	{}	2026-09-15 10:06:39.689692+00	OPAQUE	REFRESH_TOKEN	4JRI0RvjDeUeB1Ie4LL9mrFlkumiuAMTA2OWE2NzEtYmMxNy00ZTRkLWE2YmItM2NkYzc5MTYxMjBk
efbc7883-22b6-4b5b-9a01-61291da0dd89	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 10:07:09.877161+00	2026-09-15 10:07:09.877161+00	{}	2026-09-15 10:06:39.877161+00	OPAQUE	REFRESH_TOKEN	USMaffyI8F1jrnm73UTPHkQ1UYmEAgMDVmZWQzM2UtNGYzNC00YzJiLTk5M2UtZWE4YTY3NDA2YTA4
e00e5e84-7e39-45aa-b3ab-c5fc8b14c194	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 10:07:10.060645+00	2026-09-15 10:07:10.060645+00	{}	2026-09-15 10:06:40.060645+00	OPAQUE	REFRESH_TOKEN	ypnS-LCpK5S_3FBwYwr8iqg8IlPfYQOTdlYmYyM2QtMTg5OC00NjVjLWI3MWQtZjE4N2Y0OTRiNzc3
7cfb696b-0aa4-48f7-88bd-7fb0ac5a4429	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 10:07:10.39787+00	2026-09-15 10:07:10.39787+00	{}	2026-09-15 10:06:40.39787+00	OPAQUE	REFRESH_TOKEN	lPvpvghS4V_2twyDxqF2Flh1wWitawNzAwZTQxNTYtMDE1ZS00ZWIwLTlkZTQtYzE4NzcyZDBhNjZk
46d5301c-88bd-4b00-b47d-d83c3bba77ec	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 10:11:11.046986+00	2026-09-15 10:11:11.046986+00	{}	2026-09-15 10:10:41.046986+00	OPAQUE	REFRESH_TOKEN	75Z0JyNcX-hmzdJ3t8yNcdtijpEFnQMGQ5NDcwYTMtOTI5Yi00ODhiLWE3ZWYtMWIzNjk1MGFlMGQ5
b63909b6-1598-4b4e-8767-044f5a0b6ed3	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-15 10:13:46.272786+00	2026-09-15 10:13:46.272786+00	{}	2026-09-15 10:13:16.272786+00	OPAQUE	REFRESH_TOKEN	1ItNz2d7kO0Fw7_pccXwsVJ5Lxm0kAYTM5ZmZlZDAtNjk1Ni00ZTkzLThlNWQtYTA0Y2UyYzUwMDEw
c8c816c0-3321-40c4-9cd7-ac104df8ea1d	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-15 10:13:46.560495+00	2026-09-15 10:13:46.560495+00	{}	2026-09-15 10:13:16.560495+00	OPAQUE	REFRESH_TOKEN	43UuS-eAXqCnOR1JMES_WFBk3XxDcgZjY2Zjk1MTItZGY4MS00NmE4LTgzNGItNjQ2MTQ5NGZkZTQ4
edb5987a-5382-4e93-9a1a-451e5cc2ebe7	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-15 10:13:46.819612+00	2026-09-15 10:13:46.819612+00	{}	2026-09-15 10:13:16.819612+00	OPAQUE	REFRESH_TOKEN	ln8KEH2Q6F5CCrnTfQcFY4ixj8cOrwOTM5NTg4MTEtMDZmMi00ZjMwLWI5NjMtMDZkMDIyYzQ1OTM3
97438a0c-e305-4ff8-98c9-97130e1378e1	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-15 10:13:47.065934+00	2026-09-15 10:13:47.065934+00	{}	2026-09-15 10:13:17.065934+00	OPAQUE	REFRESH_TOKEN	hopTcupWLIkTQftwiFg3ZWE-sQy2_wMTcxMzBiNjktMDJmYy00MDE3LTlhYmQtMjM2MTk0Njc3ZTA5
2842f9cd-7740-451b-8af5-4a568d307940	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 10:16:03.464879+00	2026-09-15 10:16:03.464879+00	{}	2026-09-15 10:15:33.464879+00	OPAQUE	REFRESH_TOKEN	XtEbHUAR1KkfMn5Q-D8eZU1-x2-FSwNmZlZjA4MWMtOWE5Yi00ZDk4LWFkMWMtNTY5ZTQzODQ3OWE3
351d14a8-dd9a-4994-b527-b30f5ea19e0e	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 10:17:59.515364+00	2026-09-15 10:17:59.515364+00	{}	2026-09-15 10:17:29.515364+00	OPAQUE	REFRESH_TOKEN	DRGKWPVzEttvKAihelVM4QuDgEUruwZDcyY2VhZTQtODhlNi00YzcyLWIzMTMtM2RhYTk1MzJjM2M0
8ce3f92d-5eed-4c9d-be08-099b6cc3359c	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 10:18:32.983129+00	2026-09-15 10:18:32.983129+00	{}	2026-09-15 10:18:02.983129+00	OPAQUE	REFRESH_TOKEN	YqLICKAJthXXKLgT0yiID2bO56mp7ANjFhNWZhNTAtZDI1NS00MDI4LWEzYTUtOGEyYjRlYWZkMzQ5
5104fdff-a404-427d-bec4-ad3be936dc10	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-15 10:20:58.478114+00	2026-09-15 10:20:58.478114+00	{}	2026-09-15 10:20:28.478114+00	OPAQUE	REFRESH_TOKEN	rQejY8mGb7uQ1Q6w5CSSnEid_UmSuQZGMxZDhmYWYtOTExYS00ZTZlLWE3OTEtMmFjNDFjYjg5NTlk
ab36080a-e8cf-4665-a392-d27207780508	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-15 10:20:58.750042+00	2026-09-15 10:20:58.750042+00	{}	2026-09-15 10:20:28.750042+00	OPAQUE	REFRESH_TOKEN	epc_q06kaHRRqsGKakKPlyGAW3_XggNWU4N2U3ZjYtYmMxMy00ZGJhLThkNjgtNzlkNTE0Y2JiYmY1
ae430cb6-8f8d-4db5-9636-449bba4a12c8	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-15 10:20:59.010892+00	2026-09-15 10:20:59.010892+00	{}	2026-09-15 10:20:29.010892+00	OPAQUE	REFRESH_TOKEN	Bke0Mn0XTXcYXLTxz0YTrpwYDz_MqAMmU3YzA2MjItMWEyNy00M2Y4LThlYTMtZjdlNDU0YzZkMjJj
fcd78211-67a8-4ca0-a34c-a3c808f7b5f0	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-15 10:20:59.301401+00	2026-09-15 10:20:59.301401+00	{}	2026-09-15 10:20:29.301401+00	OPAQUE	REFRESH_TOKEN	O62Tu5JapkE-9yaAjBCFWBlrkcgJpgZGYxZTU1OWMtYTBjNC00MTA3LWJhMDQtZjhiYzlkZjdiZjc1
0ac0e389-6846-453e-ba00-9377a61f81ab	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 10:24:44.137159+00	2026-09-15 10:24:44.137159+00	{}	2026-09-15 10:24:14.137159+00	OPAQUE	REFRESH_TOKEN	1wZL9n7SS7HCIOOK1fuzJmJf6QJIYwZjljNjNkMmYtYTM4NC00Mzc4LWE3MmItOTJjYjBjYWU2Yjc4
f97f325b-88b7-44a8-b74c-0e57aba82321	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 10:24:44.325413+00	2026-09-15 10:24:44.325413+00	{}	2026-09-15 10:24:14.325413+00	OPAQUE	REFRESH_TOKEN	x_XLvdxNuuOGkEXFR7nfY_OCwo3VYQNWY3MTAxM2MtZWY1Mi00Y2UxLTgwMTUtMmZjZTE4MjZkYmU3
f239d314-fde5-4008-9c55-c04794a1bed1	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 10:24:44.498619+00	2026-09-15 10:24:44.498619+00	{}	2026-09-15 10:24:14.498619+00	OPAQUE	REFRESH_TOKEN	AJJMYEokQY6In2pDb_kq6TA2Tnq3VANjA2OTNjYzYtMjQwNS00MDY3LThlMmUtN2IyNzMwZjA5NmY0
8049da94-2aad-4315-91f3-d14a82541ec3	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 10:24:44.676158+00	2026-09-15 10:24:44.676158+00	{}	2026-09-15 10:24:14.676158+00	OPAQUE	REFRESH_TOKEN	LhVB9AtB4XUQenEFvaIevU5rPaPsPwMmFhZDNhNzctMDQ3MC00YjM1LWE5OWYtOTFhMzZhODYyMmJj
2a6586fb-24eb-4034-97e5-b190edae17c2	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 10:24:44.841904+00	2026-09-15 10:24:44.841904+00	{}	2026-09-15 10:24:14.841904+00	OPAQUE	REFRESH_TOKEN	QklLdScJXXGDquzp0eXIrYky0taQpwMjVmZTlhNzEtM2U1ZS00OTJiLTliZDctYjZmMDViZjZmNmY4
354fdfe8-ff7b-4736-b355-82aeee68a7df	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 10:24:45.012119+00	2026-09-15 10:24:45.012119+00	{}	2026-09-15 10:24:15.012119+00	OPAQUE	REFRESH_TOKEN	v9vA3mxEL6qfAFDDR4Iam9BzRcrKUgM2NkZTE3MWQtM2NlMi00YjcwLThkOTYtMDRiZmZkZjg2YTg0
c5b018a9-3c6f-477d-9d1b-3422a3387d7f	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-15 10:26:21.046384+00	2026-09-15 10:26:21.046384+00	{}	2026-09-15 10:25:51.046384+00	OPAQUE	REFRESH_TOKEN	zecYFmWyiqR9tPanbLoelQt63ivP8wM2RlMDY2MjAtNWZmOC00MzU4LTk0N2UtNzI3Mjc5YzE5NzI5
6e046f66-aa8d-43c3-836a-849a714121f4	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-15 10:26:26.391261+00	2026-09-15 10:26:26.391261+00	{}	2026-09-15 10:25:56.391261+00	OPAQUE	REFRESH_TOKEN	RKJ5WAQsOUZWOW4IWijjTczju4Z_lwNDI1YTAyNzktMzZlZC00ZDg2LWJlYmQtOGVmZDhiNGJhMTMx
0b7b9bb9-39bd-4851-a767-706dfc9c47c6	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-15 10:26:29.112301+00	2026-09-15 10:26:29.112301+00	{}	2026-09-15 10:25:59.112301+00	OPAQUE	REFRESH_TOKEN	Gz702E5fzrvufnTkCY833tvgWEP7RANDJmMWNkNGUtNmIwMy00NGI2LTgwODctYzRlMzA1MzJkMWQ4
0f4436f6-a643-45f2-be11-11014217edcc	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789209531, "session_id": "b54661e8-f49f-407b-8b2e-bc90cc0acbe4", "session_exp": 1799577531}	2026-10-15 10:26:30.101039+00	2026-09-15 10:26:30.101039+00	{}	2026-09-15 10:26:00.101039+00	OPAQUE	REFRESH_TOKEN	7kCsGguX2U07o9u9u6AX8pmAHgeDFQZjRiNzc4YzMtMTU5OC00NzNmLThhNmUtMzg3ZTUyZGM5OWYx
6d80e65d-d540-4b3d-a08a-b19e7590b6bf	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 10:30:04.629393+00	2026-09-15 10:30:04.629393+00	{}	2026-09-15 10:29:34.629393+00	OPAQUE	REFRESH_TOKEN	jLVyCael1sqvNzW3aXYfU1Ds-DLZcgNDRhNTI5NGYtY2ZmMy00YWQ1LWJkZjAtNzA2NDBiZjlmNzhm
cbf2828d-7e48-43af-9b2d-1a792ab582de	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 10:30:04.845268+00	2026-09-15 10:30:04.845268+00	{}	2026-09-15 10:29:34.845268+00	OPAQUE	REFRESH_TOKEN	gZC6WoKkY4AtSSph3E1LVnEZ-fpm6ANjZiOWEzNTktNDJmMy00Y2RiLThkZWYtZDdkOTEwOTg0OGVj
d8d3f447-22c0-4083-8302-1394d787066b	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 10:30:05.028163+00	2026-09-15 10:30:05.028163+00	{}	2026-09-15 10:29:35.028163+00	OPAQUE	REFRESH_TOKEN	kzzF7JZPy8hdxUnjIn0g6LZC7UHYUgMTkzZmFlMTItODJkYi00MDlhLWFlOTItYmQ2M2FjYzY3MDdi
d09c2c4a-6cac-4335-8e6c-6bdd4bd74bd2	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 10:30:05.226429+00	2026-09-15 10:30:05.226429+00	{}	2026-09-15 10:29:35.226429+00	OPAQUE	REFRESH_TOKEN	lSI_FjMDtfvHQ69qTFphnXMKw4tumAM2YzOTNlMzAtN2U2Ny00MzJmLTljZTMtMjU2MzVhNzYxMWRl
b6aaf0be-0e61-4c23-b612-71aa849205aa	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 10:30:05.424634+00	2026-09-15 10:30:05.424634+00	{}	2026-09-15 10:29:35.424634+00	OPAQUE	REFRESH_TOKEN	OJIfc9Re5Ht6lIxTBBBJSC5YzMlV0QNDM5OWM4MWEtODU4OC00NGU5LWJmYTctYzZhOTVmMTlmNDEy
fbb1af93-e459-49e9-8324-032239688579	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 10:30:05.820708+00	2026-09-15 10:30:05.820708+00	{}	2026-09-15 10:29:35.820708+00	OPAQUE	REFRESH_TOKEN	U01bkwqy2mwzNvejscibTNj0UW5KhAYTY2MTBkOGYtYjRhNC00OWM4LTg2ZGYtMjgxZDNhMmM5NTE5
829201c8-f8ae-4b3e-a714-e935d1656def	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 10:31:51.692604+00	2026-09-15 10:31:51.692604+00	{}	2026-09-15 10:31:21.692604+00	OPAQUE	REFRESH_TOKEN	UiQ3uH9Xdbveu8dacARID0FPRDhwHQMGY0NzlhODUtODY4OS00Nzk1LTlhNGItZWZjZTYzY2YyMGIw
ab90ff68-eb68-4960-8e1a-e17000636211	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789468393, "session_id": "4038e500-a5ac-4338-bd2f-f447d8512125", "session_exp": 1799836393}	2026-10-15 10:33:13.462704+00	2026-09-15 10:33:13.462704+00	{}	2026-09-15 10:32:43.462704+00	OPAQUE	REFRESH_TOKEN	k44GUxRISpvPoAvGl6Es189gTFs3ZgZjIxYTM5NGQtMTUyNi00Y2ZjLThjN2EtM2IwNWU3YmVlMjYz
8ef05931-d090-4775-a570-407b189bc9fb	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789468393, "session_id": "4038e500-a5ac-4338-bd2f-f447d8512125", "session_exp": 1799836393}	2026-10-15 10:33:15.775712+00	2026-09-15 10:33:15.775712+00	{}	2026-09-15 10:32:45.775712+00	OPAQUE	REFRESH_TOKEN	_GPruInD1Ns9sCxZXH_b06IAGxIHugYTljNTkyMmUtNjE5Ni00Mzk3LThiZjgtZGIwYzgxOGFhNTdk
2524c9c7-151e-42db-9c9d-14baef6c6de0	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789468393, "session_id": "4038e500-a5ac-4338-bd2f-f447d8512125", "session_exp": 1799836393}	2026-10-15 10:38:32.123459+00	2026-09-15 10:38:32.123459+00	{}	2026-09-15 10:38:02.123459+00	OPAQUE	REFRESH_TOKEN	7qEzxTI_FBs8DSxvwZjVgTpGQFJaCAYmNkZmNmNGYtNTU4Ny00YzAwLWI5NWUtZjYxMDkxNTZhOTA3
cf84a5e3-6436-4225-ba18-47b45849edaf	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789468393, "session_id": "4038e500-a5ac-4338-bd2f-f447d8512125", "session_exp": 1799836393}	2026-10-15 10:40:22.692654+00	2026-09-15 10:40:22.692654+00	{}	2026-09-15 10:39:52.692654+00	OPAQUE	REFRESH_TOKEN	h_8ieG_wp2vpT-QdqlaOcUT5afBN3ANGIyMWQzMDItNDAyMC00OWM0LWEwYWEtZDM0NzEwZWY5YTgy
dedb5b52-4e6b-4c79-a8e1-df7a45c78b01	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 10:40:49.845942+00	2026-09-15 10:40:49.845942+00	{}	2026-09-15 10:40:19.845942+00	OPAQUE	REFRESH_TOKEN	CnTRtZMaQoxUFe33BwlUUasdZ7RxugMGE5MjZjNjQtOTk1Yy00OTdlLTgzMDYtZTI4MjA2ZjBlYmUx
38825969-252a-408c-82a0-fd6bbfb87a14	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 10:40:50.03972+00	2026-09-15 10:40:50.03972+00	{}	2026-09-15 10:40:20.03972+00	OPAQUE	REFRESH_TOKEN	n69o-TIeQCiijaH5CEfZlOj8lcjBiAYmIzNTY1YWEtMGE5NC00MDExLTgxYTEtYjhkMTMwYjU0NDRl
c29a88a4-fcd0-472b-8376-9db3549a9ec5	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 10:40:50.224145+00	2026-09-15 10:40:50.224145+00	{}	2026-09-15 10:40:20.224145+00	OPAQUE	REFRESH_TOKEN	aLw2aT0mSa2RM2JgCsXxVVX9eIx-PAYTZlYzEyNzAtYWQ2My00NDNkLTlmNGYtYjhjNTAzMDdhMDE4
5780f987-073e-4fa5-8ee0-efd2a1168972	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 10:40:50.406448+00	2026-09-15 10:40:50.406448+00	{}	2026-09-15 10:40:20.406448+00	OPAQUE	REFRESH_TOKEN	Xvq6B1CXkOTh4WFDW3bZcE2M9fYkXAYTk2NDM4YzYtZDFmOC00ZDQ1LTk1YjItZmU1NzViODQ0YWVi
8d7e4fe6-bfff-4775-ae37-59d86d5c0556	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 10:40:50.58465+00	2026-09-15 10:40:50.58465+00	{}	2026-09-15 10:40:20.58465+00	OPAQUE	REFRESH_TOKEN	jzYnrYKUl2J9yzydIEYZeSZ49kfXngOWZlMGJjY2MtZGQ3NS00YzExLWE3MzgtZDhiMDEwNDM2Y2Vi
a38444cb-4fca-40ed-8119-99132d2324ec	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 10:40:50.769548+00	2026-09-15 10:40:50.769548+00	{}	2026-09-15 10:40:20.769548+00	OPAQUE	REFRESH_TOKEN	e-u-A7-DA06k1_2Q8_FXoD3RLHrJSwMTA2YTA5YTEtN2Y1MS00MWYwLWIzZjktNmMzNTc4NzM4ZWMw
555431fb-d43f-492d-82f6-853fdc18ac3f	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 10:40:50.94542+00	2026-09-15 10:40:50.94542+00	{}	2026-09-15 10:40:20.94542+00	OPAQUE	REFRESH_TOKEN	sQ_krpEJNL-8wfMVN-2uf_FxLx1jAgY2M1YjEzMTItNzQxNC00YmM0LTgwMTUtMTRjODYzYTdmZmU0
b2d420c9-38d0-4882-a6d8-9568e9a01c81	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789468393, "session_id": "4038e500-a5ac-4338-bd2f-f447d8512125", "session_exp": 1799836393}	2026-10-15 10:46:56.024743+00	2026-09-15 10:46:56.024743+00	{}	2026-09-15 10:46:26.024743+00	OPAQUE	REFRESH_TOKEN	g_UkVWDtDSXjlsgh5hNkenD0vmnKhQZTJhNzkyNzItY2YyMi00ZGQ1LTgwMDQtOTY1NWFhOWYxMGU3
1c06bdeb-cc47-4759-9d07-9d3257334b35	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789468393, "session_id": "4038e500-a5ac-4338-bd2f-f447d8512125", "session_exp": 1799836393}	2026-10-15 10:57:42.307334+00	2026-09-15 10:57:42.307334+00	{}	2026-09-15 10:57:12.307334+00	OPAQUE	REFRESH_TOKEN	5jNrEbgASC47cLgtZs8GH_POP1dU5AM2NiNzY1ZTctYTkzOC00YmE1LThiNDEtNWU0OTViOTg1MDMw
0f12c18f-f57a-42ab-be4a-8d434df2e9dd	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789468393, "session_id": "4038e500-a5ac-4338-bd2f-f447d8512125", "session_exp": 1799836393}	2026-10-15 10:57:45.112315+00	2026-09-15 10:57:45.112315+00	{}	2026-09-15 10:57:15.112315+00	OPAQUE	REFRESH_TOKEN	fYgdlPJKDxQYN07ugq16YbDTo8IrhwNDZlNzJiNTAtMDhiMy00MWNlLThiMWEtZjBiZTE3ZDJhZWZl
ba420ac7-cd6f-4a31-a230-afc9ffb428a7	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789468393, "session_id": "4038e500-a5ac-4338-bd2f-f447d8512125", "session_exp": 1799836393}	2026-10-15 10:57:46.362384+00	2026-09-15 10:57:46.362384+00	{}	2026-09-15 10:57:16.362384+00	OPAQUE	REFRESH_TOKEN	V5yfKAfXgCOSv-FqwzrlqqKl2aE8GAZjMwMTIwYWQtMTYxMC00OTJhLWJkMzAtNDk4MmI4NDQ5ODky
96ef8566-7979-4ca4-ba70-fbfd82f1d53e	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789468393, "session_id": "4038e500-a5ac-4338-bd2f-f447d8512125", "session_exp": 1799836393}	2026-10-15 10:57:46.900337+00	2026-09-15 10:57:46.900337+00	{}	2026-09-15 10:57:16.900337+00	OPAQUE	REFRESH_TOKEN	MR2SL-vs5mOkEAnSCQeRRow7TB1eUANGIyNDIxNGQtOGQyNi00YzgwLTg1OTctNzYzNTM4OTk5MWRj
1c39a1bc-3417-40a3-b01b-77b8ee2f0b8f	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789468393, "session_id": "4038e500-a5ac-4338-bd2f-f447d8512125", "session_exp": 1799836393}	2026-10-15 11:26:01.803834+00	2026-09-15 11:26:01.803834+00	{}	2026-09-15 11:25:31.803834+00	OPAQUE	REFRESH_TOKEN	Oge5xXfB9Cnn1ujkdxLyyUtasXxvZAOWU0YWNjN2ItM2RkMy00ZDA2LWJjYjctOTA0ZTdhM2IwOGYz
612675a6-e41b-42a1-b440-97cc7d6f1d28	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789468393, "session_id": "4038e500-a5ac-4338-bd2f-f447d8512125", "session_exp": 1799836393}	2026-10-15 11:26:03.022676+00	2026-09-15 11:26:03.022676+00	{}	2026-09-15 11:25:33.022676+00	OPAQUE	REFRESH_TOKEN	E0q_faoli3YuQrMw0HVGkHFxqs0ODAYjdkZDg4MzItZTI2NC00ZDhiLTg0OTktYWE5M2NjNzcxZjk3
0aaedaf9-6dc4-4ca8-a90c-707c167d5094	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789468393, "session_id": "4038e500-a5ac-4338-bd2f-f447d8512125", "session_exp": 1799836393}	2026-10-15 11:26:03.338976+00	2026-09-15 11:26:03.338976+00	{}	2026-09-15 11:25:33.338976+00	OPAQUE	REFRESH_TOKEN	Gp-VALYEzu-7cWlqBYq4gqMavS0jJQY2VlMGQ2NTctNGJhNS00ZjUwLTgxNTYtNjQ0NTgyNWI3Yzg4
9463bd6e-7ad9-431c-97ef-24b88e145d4a	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789468393, "session_id": "4038e500-a5ac-4338-bd2f-f447d8512125", "session_exp": 1799836393}	2026-10-15 11:26:04.029829+00	2026-09-15 11:26:04.029829+00	{}	2026-09-15 11:25:34.029829+00	OPAQUE	REFRESH_TOKEN	rL3-lwK0d1gCSdN6bsaO6N7Yl4v77gMGMyNTI2MzYtYzU0Yy00OGJkLTlkNGItYTJmOWI5NjgyMjAx
ca313ace-9a2b-4eed-839d-70f51e48ab26	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789468393, "session_id": "4038e500-a5ac-4338-bd2f-f447d8512125", "session_exp": 1799836393}	2026-10-15 11:26:05.023454+00	2026-09-15 11:26:05.023454+00	{}	2026-09-15 11:25:35.023454+00	OPAQUE	REFRESH_TOKEN	NvGdTldeQ4lTRinrbgaFMBytfEKh8gOWQyYWRjM2QtMjU5Zi00NjRlLThhMmEtMjkzYmZhZThhMzcx
9836fbb6-03c7-4c85-9551-84b684a3ef21	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 12:56:56.995414+00	2026-09-15 12:56:56.995414+00	{}	2026-09-15 12:56:26.995414+00	OPAQUE	REFRESH_TOKEN	JOuZpytoNxXASBQBVFMLzPEtB8rzGwOTVhY2EwZGYtNGZmMS00ZDM5LWJmYmUtNTdkZDk5MDU4OGU5
9e67c38c-2cc4-415f-b21c-3a5484d7fc3f	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 12:56:57.273505+00	2026-09-15 12:56:57.273505+00	{}	2026-09-15 12:56:27.273505+00	OPAQUE	REFRESH_TOKEN	SA2udAPdDGSI4dQHiOkDTgt-78PFrAMWUxOWQ3OWQtNzMzOC00YzU1LTgyNjctOTY0NTkwMDczNjQ2
bfd4490d-77d3-468b-9147-a052e2d81ca2	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 12:56:57.558513+00	2026-09-15 12:56:57.558513+00	{}	2026-09-15 12:56:27.558513+00	OPAQUE	REFRESH_TOKEN	0kp_fWiZK-3XeYG6tK4EJ1FIQ3uT6AZWZjNDc0ZGItOWNiNC00NjgzLWEyZmEtZWE1MThhZWExYTYw
cdeae4b1-114c-4011-810a-7ac0525573a0	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 12:56:57.941195+00	2026-09-15 12:56:57.941195+00	{}	2026-09-15 12:56:27.941195+00	OPAQUE	REFRESH_TOKEN	03naXpMdLEJ73WxEjaGApquSXyakWgZDY2MTA2NGUtY2I2OS00NGFkLWJhZGItMzc0Yzg5ZGFiZTI1
04472521-fdba-4114-95b9-e170394034ae	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 13:17:44.222737+00	2026-09-15 13:17:44.222737+00	{}	2026-09-15 13:17:14.222737+00	OPAQUE	REFRESH_TOKEN	336Be60LvniwGHeLYomnZLBXEFpclAOWYzMDVmMmUtMTZiZS00Zjk3LWE1M2QtZjI3N2I1MmZmNTk0
0118c5f9-1415-4e18-96c2-43aff5e146ff	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 13:17:44.549409+00	2026-09-15 13:17:44.549409+00	{}	2026-09-15 13:17:14.549409+00	OPAQUE	REFRESH_TOKEN	ZjqZRapYAuaB1oc4vczdlk9uIQotvgMTk5NmE0YzgtZjM2MC00YmIzLWE4N2EtZGM3ODJlNGJjNjE4
691baf5c-ade3-47a2-acde-f63a54f7351e	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 13:17:44.795031+00	2026-09-15 13:17:44.795031+00	{}	2026-09-15 13:17:14.795031+00	OPAQUE	REFRESH_TOKEN	StbVC9uaV6vjtDpegZxa9Y_iALJBcwYWI3MzM3MTEtOWQ2Yy00YTUxLThkZDMtZTg4YjE0OWYwNmVi
1211106a-940c-40de-ad78-0ed5de6d672e	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 13:17:45.036282+00	2026-09-15 13:17:45.036282+00	{}	2026-09-15 13:17:15.036282+00	OPAQUE	REFRESH_TOKEN	aXzusrXdgmftpBby9mz6TSnPuTNVtAODljMTY1Y2MtNzk1YS00YTYyLWFmNWYtZDkxNGE5YWIzZDkz
7d550fe7-f20c-442c-97bb-e51804d3df91	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789468393, "session_id": "4038e500-a5ac-4338-bd2f-f447d8512125", "session_exp": 1799836393}	2026-10-15 13:33:30.239187+00	2026-09-15 13:33:30.239187+00	{}	2026-09-15 13:33:00.239187+00	OPAQUE	REFRESH_TOKEN	tC9C9sdYM3ZeCr3kR5DwUfrHWMw8xwMmJkMzY2N2ItNTNmZS00NmFiLTkwNzItZDc3OTE5ZGVhZjEy
dcc55b6b-c18c-46cd-aa21-f743790a32d3	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789468393, "session_id": "4038e500-a5ac-4338-bd2f-f447d8512125", "session_exp": 1799836393}	2026-10-15 13:33:31.463494+00	2026-09-15 13:33:31.463494+00	{}	2026-09-15 13:33:01.463494+00	OPAQUE	REFRESH_TOKEN	EH1bo4gwt4VWMhsdmG-FsYEE7nKZUgM2ZhMjM5NTMtMDQ0Ny00NGMwLWFlOTMtYjJhZDczZTE5ZDkw
18873e32-058f-48ff-af35-2d1a59cc75a2	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789468393, "session_id": "4038e500-a5ac-4338-bd2f-f447d8512125", "session_exp": 1799836393}	2026-10-15 13:33:32.423783+00	2026-09-15 13:33:32.423783+00	{}	2026-09-15 13:33:02.423783+00	OPAQUE	REFRESH_TOKEN	m-YEHyDQdgkBTZPvuQGaRiF0CQCnYAM2Q4N2RiNDgtNzY4Ni00YWQxLWJjOTEtZWY4NDFmNWYxYThm
513a6667-ddb3-489f-b7a5-b892e554c8bb	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789468393, "session_id": "4038e500-a5ac-4338-bd2f-f447d8512125", "session_exp": 1799836393}	2026-10-15 13:33:33.660141+00	2026-09-15 13:33:33.660141+00	{}	2026-09-15 13:33:03.660141+00	OPAQUE	REFRESH_TOKEN	3LJsTl4h3P_yIIkXub32liNxeJ47rQODc1NTBkMmQtYjdkOC00YjA1LWFiN2MtNGZiYWM1ZmJiNmI4
dfafebd3-11be-4753-8258-0749fd6d0c18	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789468393, "session_id": "4038e500-a5ac-4338-bd2f-f447d8512125", "session_exp": 1799836393}	2026-10-15 13:33:33.675702+00	2026-09-15 13:33:33.675702+00	{}	2026-09-15 13:33:03.675702+00	OPAQUE	REFRESH_TOKEN	XuH8hdXCkcRalcPE4DdeLcrm9S7FpwZTk1OTRiMTktNjFlMi00YjVmLTljMmUtOWU5YzlkYzI2MDUy
ce5dd6ed-324f-43b9-b778-a26b55eb3603	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789468393, "session_id": "4038e500-a5ac-4338-bd2f-f447d8512125", "session_exp": 1799836393}	2026-10-15 13:33:35.08999+00	2026-09-15 13:33:35.08999+00	{}	2026-09-15 13:33:05.08999+00	OPAQUE	REFRESH_TOKEN	TxNj7XEF4cgQ5wmeEVCAAPu8nfP7dgYTBkZTYzZDgtODc1MC00NTJkLWFhZTktOTU2OTNjYWJlNmVi
0edc94d2-f3ea-4e85-87a7-91c9c4691be9	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789468393, "session_id": "4038e500-a5ac-4338-bd2f-f447d8512125", "session_exp": 1799836393}	2026-10-15 13:40:58.864653+00	2026-09-15 13:40:58.864653+00	{}	2026-09-15 13:40:28.864653+00	OPAQUE	REFRESH_TOKEN	FV74mosto6qjePo37ToagCA2ezkh-ANDZmODlmZWYtMDY4OS00NjQ1LTk1OGQtNDRmZmZhYWM4YjZm
d8640e7c-77a1-4fbc-b4f8-52f1a59a601b	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789468393, "session_id": "4038e500-a5ac-4338-bd2f-f447d8512125", "session_exp": 1799836393}	2026-10-15 13:40:59.163547+00	2026-09-15 13:40:59.163547+00	{}	2026-09-15 13:40:29.163547+00	OPAQUE	REFRESH_TOKEN	Q-nin2HtrP3eLrkqWpdLjA7NddvynQNGVkMjEzNjMtZjI2Ni00NTk0LWIxNjctNDQ5MzVjNTk0ZWRj
fd9d205f-b945-4768-8ec2-77b68f1bafc1	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789468393, "session_id": "4038e500-a5ac-4338-bd2f-f447d8512125", "session_exp": 1799836393}	2026-10-15 13:40:59.566047+00	2026-09-15 13:40:59.566047+00	{}	2026-09-15 13:40:29.566047+00	OPAQUE	REFRESH_TOKEN	5zmRi9W8kgRqv2kTKhEUb73PtJeHGANjcwZTFjYTItNTRmZS00ZjY4LWFkODgtZDEzYTZkNzcwNTBk
96942ea1-1606-4e5f-bacc-bde892d8b485	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789468393, "session_id": "4038e500-a5ac-4338-bd2f-f447d8512125", "session_exp": 1799836393}	2026-10-15 13:47:36.367071+00	2026-09-15 13:47:36.367071+00	{}	2026-09-15 13:47:06.367071+00	OPAQUE	REFRESH_TOKEN	pj9cMRbY6EmJ6My7jn0ToQBJW9B3agZTM3ZmE0MWEtMzE5ZS00MWFkLWFhYzktZDJlNTgyOTNiYjg2
feaf47ab-079c-48b6-91df-d2399d179e01	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789468393, "session_id": "4038e500-a5ac-4338-bd2f-f447d8512125", "session_exp": 1799836393}	2026-10-15 13:58:39.628412+00	2026-09-15 13:58:39.628412+00	{}	2026-09-15 13:58:09.628412+00	OPAQUE	REFRESH_TOKEN	KileqpNDp8Acs9y5TkWbN1qz5IWC_gZWE3MjQxMTgtYjljNC00ZmVmLTk3NzAtYzE1YmNkMmEwM2Nl
6e571a07-a96e-4912-a1d8-d18c3efc167d	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789223159, "session_id": "66f77e1e-76bd-4915-be32-7829276f5157", "session_exp": 1799591159}	2026-10-15 14:18:17.425054+00	2026-09-15 14:18:17.425054+00	{}	2026-09-15 14:17:47.425054+00	OPAQUE	REFRESH_TOKEN	n6NxRdKT_ITDsx_t6CW9U_vBLIEBwAN2Q4ZGE0NWUtZTMxYy00ZDAxLWFkYTctNGY2MDI2MWVkMDM3
b2ce20fc-a217-4921-9ba5-edfebe036fc0	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789468393, "session_id": "4038e500-a5ac-4338-bd2f-f447d8512125", "session_exp": 1799836393}	2026-10-15 14:28:31.837947+00	2026-09-15 14:28:31.837947+00	{}	2026-09-15 14:28:01.837947+00	OPAQUE	REFRESH_TOKEN	O8Sm4qQtsph3m0iF9B1gP8XId0IH2wZWM3NDdiZWEtYWIwYy00NzM0LTliNWMtNWRiNGQyYWQ3ZTY3
08815df5-4f09-40d9-950a-1bddbd669e4b	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789468393, "session_id": "4038e500-a5ac-4338-bd2f-f447d8512125", "session_exp": 1799836393}	2026-10-15 14:28:32.142706+00	2026-09-15 14:28:32.142706+00	{}	2026-09-15 14:28:02.142706+00	OPAQUE	REFRESH_TOKEN	u6yVJEm1UzR4i53dMshejPmY79qxpQYmE5MDE4NDctZmFlZC00YTMwLWI0OTctMzdlM2UwYjNlODhh
83f57dff-510f-4698-b8c9-9b9156fcef9e	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789468393, "session_id": "4038e500-a5ac-4338-bd2f-f447d8512125", "session_exp": 1799836393}	2026-10-15 14:28:34.482313+00	2026-09-15 14:28:34.482313+00	{}	2026-09-15 14:28:04.482313+00	OPAQUE	REFRESH_TOKEN	6PZ6gPJw4SgJ3RqXK_rJG86e8ay0rgMGE3M2ZiNTktMWVlOC00Yzk5LThmZjEtOGY1MDgxZjhhM2Fi
d93f2901-87f5-4f9c-a11e-1ab6b5fe2581	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789468393, "session_id": "4038e500-a5ac-4338-bd2f-f447d8512125", "session_exp": 1799836393}	2026-10-15 14:28:35.358638+00	2026-09-15 14:28:35.358638+00	{}	2026-09-15 14:28:05.358638+00	OPAQUE	REFRESH_TOKEN	Rce0GDmML4q9-2rCNEAqW9gLBi5fYwODhjYTJmNDMtNDZmMy00Y2I4LThkNjItZjMxZTUyYTdjYzYw
94259b76-47c5-4d53-90fb-26447707c717	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789468393, "session_id": "4038e500-a5ac-4338-bd2f-f447d8512125", "session_exp": 1799836393}	2026-10-15 14:51:31.540763+00	2026-09-15 14:51:31.540763+00	{}	2026-09-15 14:51:01.540763+00	OPAQUE	REFRESH_TOKEN	g-aS4_Sce8Cw1tZi7T3UkM7SWT-xwgOTE4YjVlNjAtNmVlMy00NjYzLWJjYTMtNDk0OWZkZDE3MzVk
41224a57-11f8-4d40-8d09-e96d0f07ff2c	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789468393, "session_id": "4038e500-a5ac-4338-bd2f-f447d8512125", "session_exp": 1799836393}	2026-10-15 14:51:31.856306+00	2026-09-15 14:51:31.856306+00	{}	2026-09-15 14:51:01.856306+00	OPAQUE	REFRESH_TOKEN	Usqj0ptZhw7eDA6PxOekitSnqjt38gNzI0ODFhOTgtNjRmYy00YjEzLTgyYzctNzYxMjA2OWQ1MzEx
7ca99d23-374e-4d80-a476-031dadd5176b	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789468393, "session_id": "4038e500-a5ac-4338-bd2f-f447d8512125", "session_exp": 1799836393}	2026-10-15 14:51:34.093867+00	2026-09-15 14:51:34.093867+00	{}	2026-09-15 14:51:04.093867+00	OPAQUE	REFRESH_TOKEN	kfuMaTFUr5O90YX93ScExZj7l9Q21AYjA5MWZiZmEtNTExMi00NzZkLTgwMTAtZWIwMmExMzgxMmRm
f84c38b7-14fe-46e5-af3a-ec787b986a9d	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789468393, "session_id": "4038e500-a5ac-4338-bd2f-f447d8512125", "session_exp": 1799836393}	2026-10-15 14:51:34.890441+00	2026-09-15 14:51:34.890441+00	{}	2026-09-15 14:51:04.890441+00	OPAQUE	REFRESH_TOKEN	2T6O_dhmH6y_lq_oBC9wEAKbPd0evgYzhjODEyMDItMjYwNy00YjgwLTliMjMtMDY2N2U4NmJmOWMw
79763430-cf96-4ff7-a2ba-f958b09e7fe9	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789468393, "session_id": "4038e500-a5ac-4338-bd2f-f447d8512125", "session_exp": 1799836393}	2026-10-15 15:06:47.958516+00	2026-09-15 15:06:47.958516+00	{}	2026-09-15 15:06:17.958516+00	OPAQUE	REFRESH_TOKEN	RA4lFhVqCCGbHZt0VEhsNxSqRmT56QNTJiZjY4NWQtYzc3Ny00ZWI2LTlkMTAtM2NjZTMwMjIzN2Ex
17a178e4-668f-4a94-aa80-6a2b808eff8a	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789468393, "session_id": "4038e500-a5ac-4338-bd2f-f447d8512125", "session_exp": 1799836393}	2026-10-15 15:06:48.263389+00	2026-09-15 15:06:48.263389+00	{}	2026-09-15 15:06:18.263389+00	OPAQUE	REFRESH_TOKEN	sRHABnjOoRI36MBtJk_uXWm13x-eHAMGRkYmIzOGYtMjllZi00ZjQwLWE3ZjAtOTFkMmM4ZmY5MjAy
2b6bbdfc-3ade-487e-a48f-86b672c21573	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789468393, "session_id": "4038e500-a5ac-4338-bd2f-f447d8512125", "session_exp": 1799836393}	2026-10-15 15:06:51.751946+00	2026-09-15 15:06:51.751946+00	{}	2026-09-15 15:06:21.751946+00	OPAQUE	REFRESH_TOKEN	7kZD-K0nEBrjGptvgnA1_cyHLafJIgZDJlNDhmODEtMTBjMy00YjU3LTk3ZDktMzNkOGRmNmFjZDEx
c7ef056e-6a66-4f04-a8f3-9df95d458d64	t	{"acr": ["urn:africonnect:common:iap:basic"], "sub": "3c4fbffc-b5bf-4e90-992b-e1c916503d93", "device": "3a948356a0bc688904454e44cebe39592f99cb37f8daac152e3c0f118972f59c", "username": "cteuboutonzonggmail.com", "auth_time": 1789468393, "session_id": "4038e500-a5ac-4338-bd2f-f447d8512125", "session_exp": 1799836393}	2026-10-15 15:06:53.063171+00	2026-09-15 15:06:53.063171+00	{}	2026-09-15 15:06:23.063171+00	OPAQUE	REFRESH_TOKEN	uptabhTNw4q_edwwMiRuF_awh5z33QMWQwMGIwYWYtZGVkNy00MTE0LWEyZWQtNGI3OGFiZDYwZmJh
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, address, created_at, email, email_verified, email_verified_at, first_name, gender, last_login, last_name, org_id, phone, phone_verified, phone_verified_at, roles, status, type, updated_at, user_security, username) FROM stdin;
79397ae7-db25-4553-a4f2-df3a607da5e3	\N	2026-09-12 19:53:12.068847+00	fantazymachine@gmail.com	t	2026-09-12 19:53:12.068753+00	Armani	\N	\N	Takam	96101814-b255-4348-bb24-d5a963439148	\N	f	\N	{USER}	ENABLED	MANAGED	2026-09-12 19:53:12.068848+00	{"totp": null, "lockUntil": null, "credentials": {"passwordHash": "$2a$10$DZhNOsFacKurwmVrUhzyY.sCIc82mqdS5Maq3ABv4NkHxgP3.IhTm", "hashAlgorithm": "bcrypt", "passwordExpiredAt": null, "passwordUpdatedAt": 1789242792.068810464, "requirePasswordUpdate": true}, "schemaVersion": 1, "failedAttempts": 0, "lastFailedAttemptAt": null, "multifactorialEnabled": false, "multifactorialEnabledAt": null}	bb788d50-f3d8-4b9a-b54e-2fcc530465b2
77363c25-ecbc-4a67-a3bb-21546a9d0a80	\N	2026-09-10 15:56:58.867495+00	\N	f	\N	admin	\N	2026-09-11 07:55:53.408221+00	admin	\N	\N	f	\N	{SUPER_ADMIN,USER,ADMIN}	ENABLED	UNMANAGED	2026-09-10 15:56:58.867496+00	{"totp": null, "lockUntil": null, "credentials": {"passwordHash": "$2a$10$wpvkapjUiybuWpbTwDAiWe9QK.2Zvtc.qNc9c9pN1TtqP/jdMbJCO", "hashAlgorithm": "bcrypt", "passwordExpiredAt": null, "passwordUpdatedAt": 1789055818.867464142, "requirePasswordUpdate": false}, "schemaVersion": 1, "failedAttempts": 0, "lastFailedAttemptAt": null, "multifactorialEnabled": false, "multifactorialEnabledAt": null}	admin
3c4fbffc-b5bf-4e90-992b-e1c916503d93	\N	2026-09-10 17:34:04.353346+00	cteuboutonzong@gmail.com	t	2026-09-10 17:34:45.529829+00	Christian	\N	2026-09-15 10:33:13.433918+00	Teubou	\N	\N	f	\N	{USER}	ENABLED	UNMANAGED	2026-09-10 17:34:45.529839+00	{"totp": null, "lockUntil": null, "credentials": {"passwordHash": "$2a$10$k4FG/0CGFUl91uGMav9P/uezpkfUuzPmJYBzW9Sm4kE6KKZCkMUKi", "hashAlgorithm": "bcrypt", "passwordExpiredAt": null, "passwordUpdatedAt": 1789061644.353338025, "requirePasswordUpdate": false}, "schemaVersion": 1, "failedAttempts": 0, "lastFailedAttemptAt": null, "multifactorialEnabled": false, "multifactorialEnabledAt": null}	cteuboutonzonggmail.com
\.


--
-- Data for Name: BLOBS; Type: BLOBS; Schema: -; Owner: -
--

BEGIN;

SELECT pg_catalog.lo_open('17577', 131072);
SELECT pg_catalog.lowrite(0, '\x30820122300d06092a864886f70d01010105000382010f003082010a0282010100a8625157b1c580033557ffd030269abdcaa73048f83ef2d5a6c343ac474b3370251ae06a092004365f7e5a52111e10acf4b54a1c9e87190c062e29fecc7279e0986d10d2a59fe484caba7be0a8c46674c64794b9340c1db255932cde28ee69a08d71d34b3f87109dcf86769361bd444cf93214101cf63b18bf53bd4c14d0ecf00645a7dc013a718932d24cec46b51ee30ab359c24b48ea3658f3fef51178356ed180616b67daa8581afb431f8c18b539153cbe1cb60c5fd4d638111652d77e74cca5eaf1e7d98e6b72ae5647379d2d4e18637d7b9b3539599c95a8fddf279295d6c83f587c50fad91a0237e13d59be6ce49d09fa5743dae9ff74ec0a6c90a6370203010001');
SELECT pg_catalog.lo_close(0);

SELECT pg_catalog.lo_open('21378', 131072);
SELECT pg_catalog.lowrite(0, '\x30820122300d06092a864886f70d01010105000382010f003082010a0282010100b6f9f162c022a20a088599b5ab893a31dc07bae497be3c82bac0c226ad2a1d88035503edbdb9156d08646487f8a424af16a8eefe9220a2e8deb2cbf5d5e89673e9995ad7c3f67a1450aa36de3ff42f8d7521b5ff0e7fe4602442882d4f88f05f63bf4dc71ae194e5bd5c8857c8aa603bce35de3e2cd282c834a0914142463bf32fa6b2b5ac9bc4df15d46ef65d85c777a74598c8d4f6ca77c34d7c06e2bec15b68a5e554297f28a39586e29e4049ec329fc218be1629a43338d147f8032e3dcf5e26839da62bc0ee3386c073e2e77dbb02ccba06031ea3c0ad7591226bbd96222a3342f78fca0d9dd3867a5c1454118d0097fa34529d6cb4f2acfa8e655fa8290203010001');
SELECT pg_catalog.lo_close(0);

SELECT pg_catalog.lo_open('21379', 131072);
SELECT pg_catalog.lowrite(0, '\x30820122300d06092a864886f70d01010105000382010f003082010a0282010100aea1aa45b4c645ca2bd7740b61d152d23645fd85e006426a82c907c9e7e3dc014842feeda0d07612dc9857e223d3f881e34f4f4feb42c54a0deada5a11d9db74dc0b4bd7ace599d7b3e4a7f6c18774696c277eeaa40865d32b7c66230ca67d4d2812d10ea6876eb2fc5adb6a118c304fa75b57a5a82daf45b6b5ad2a958b4bec825d9f894cf6ee2e57244bc074fc1dcc8b7369ac2e27cd53b2d143d447c6005ec14afa574be10f161a4211be69143885637b4c6245335815fc20df8a00cb5db2e98f7990303b88f44b3df0a9412845303c73b27366a35454b740faf99568e311a808584f65c955a60896f87453035c1a51f8c07226a2ef4d3aa3bc5e517d1f750203010001');
SELECT pg_catalog.lo_close(0);

SELECT pg_catalog.lo_open('21380', 131072);
SELECT pg_catalog.lowrite(0, '\x30820122300d06092a864886f70d01010105000382010f003082010a028201010099cb5f09ca4c3d33f666afacb75a7cdb502d2dde6b23df69aaa1c58ca27b1a2e096b1b8a0ac70bf604ac13b44b1f85bbedbf2c643a0f4c2d6f0dc4d95f211032b3aa53421be81222d323d16df44b38224f2da9987a5e8509fa9279b71aaee27e710aa20b1d04b8e4e98245700f0f832b5f47e1ef5dc722c6672e29c656130842e3065481d60ad8663e7b07a0f8fe34fdf42ce2926352f670053e269a5ad00d6042794a7f636bceaa185055e9d5c5700cf7c605eef4b449c29f33051c45a632f0e7eed92faa4d71fa67634adca63b410303f82faf9e88b408da27f50c3f42654ce6946ea61e36613c501eaa7740ecf1c70810ea22eebdc083ec5ab12392912edb0203010001');
SELECT pg_catalog.lo_close(0);

SELECT pg_catalog.lo_open('21401', 131072);
SELECT pg_catalog.lowrite(0, '\x30820122300d06092a864886f70d01010105000382010f003082010a02820101009ac68e5290bdc8614d13074ab643ac2a075116243a169083c561684518ea3382b776cdbe3b9352853e68494c00f46cd9e890775b5e0431d64bc23d60acb49d21f587cb54d38d39ac3e4ae9ea6de740517f76975280e7aded2d12a210d6d8c7928a70959d8609c8c88fe27020e8108001c68814838bb73fe7c0cc9702a4e8195741ab1fb630822c615c8eed5a693d883988fe2fdbde89bbdf502c0de5ba62cef692dc2ac59549ba5c7db947f77d028f4f28a8132d1db693e16794911e460796871ee7a7fa79844b94cc2b8bfcbde7f5222e33403f93ef3a0ba2a011799fa90afb6b4524a90b6baaab147bc0eeb0c59a75d3cd3ea72cf7521a4799e6403e9848cf0203010001');
SELECT pg_catalog.lo_close(0);

SELECT pg_catalog.lo_open('21402', 131072);
SELECT pg_catalog.lowrite(0, '\x30820122300d06092a864886f70d01010105000382010f003082010a0282010100c73422ec6f025882ecf9ec6ba115d9fd6c9bdfbe7a59df7f8a9167797b42393b5202361d82ec3fd86f6106d5dbad3d9ec7662a59829065c868804a44a530a8ddfc1dd86f106acad902fb6cbff3073a1847c1498323ecc51402c5f105ee87d1ace0ae0ff5100a2197f0af82bdf3fdec46c3dd04ef6fc323857c12023346b4298a346bb4cddfd529b32b2477c23068c82e440bcd0337a6bfff6481fd2f7a6cf7411982397a4e5a6facfe320c2462b48ea7dada9503eee8f5892da4bf029cfca64e247d7797a851aff50100ec5c571d3adc43f358472d54571dab5f3314eb84725b8c52cc2a6a8ca01b5d8cc108c20e2e8c98f1362412abbfc74dca91fb182d04bf0203010001');
SELECT pg_catalog.lo_close(0);

SELECT pg_catalog.lo_open('21543', 131072);
SELECT pg_catalog.lowrite(0, '\x30820122300d06092a864886f70d01010105000382010f003082010a0282010100c27ab275e64018f1a4f8d33ded1893a715896ed3bc6f16860d629919325191b5c8697b81ca7359ad03b4406853a583898aff423f898a1a82185bc765473b4a7fdee8b871409c34076ee347836fe610613459f57df62e824e62be03087818df6c86f068fc69a7c1ff94382bdc1a1c70d952839ba7b29f631398f2b0a5568c7f07dec0a4a116d032b6f8d8a0725088c430db1fe25b4e663372fcece51419634d79f26b8023d75bad84f75991818df441f79720c072daa1412f7bfd0d07d78bf6a8d0ebf07b31a9162b91b7429c3c0067f575967c909d2fd9ff86b016d890b35a9ed8dcc8e9b96d4e66ef1a1677dda9fc70866ad07d43fb39758f43d3411e18dbd90203010001');
SELECT pg_catalog.lo_close(0);

SELECT pg_catalog.lo_open('21564', 131072);
SELECT pg_catalog.lowrite(0, '\x30820122300d06092a864886f70d01010105000382010f003082010a0282010100c242016948c4548529ba71577c3ca05297350f716d98a3d68210d2f4790260837192e66d272d9362290bd56e1134e8dd1192b3ec141df0ab29c222311e927f9b9e70c9861069165e50acc8de1938ee6499c9483b4289d2a469e46872b58fde2c5f8698987b38c64e747c79464f22c1aec1edbe815b19a4eefb489f71141d63f5cfe6636f06959ebfac7e3142004ddf0d4de34abda2eb605889f892604e2827b02d78f9641cf217d2bbd8c09bc6113bb7f580e6835b15df86a1b73261ae79a3e2e71b13da5b121fab1dcde5a4061d045df2731d8e56c5be8b9311b9071e8f1bf576a39e2284f51d2cc4d4c7a66332ccf509c643c8883bb422d56fda648b2ea37b0203010001');
SELECT pg_catalog.lo_close(0);

SELECT pg_catalog.lo_open('21585', 131072);
SELECT pg_catalog.lowrite(0, '\x30820122300d06092a864886f70d01010105000382010f003082010a0282010100a9b32bdf23645294e921cbec143b1040a69cc843c3bd2dbbfb4036e431a9c0cb2a6c5f86e0b67d2f77389d0c919c6abe234641a10a5a330a17d9081ddb48809d6276439a9c4eaca9064e51eb922cb48fb445171d500d6097fd2cdfc51001c4d58104a6678f11f35085d5d1bd6df4fb18a5dedb19863632d91f47724358384d6be8aef2bbe5a1fa7d3c4fc8a3e29af52cbd059238e1f6b207217f13b3e7ca47b11cd447d78d2d45699d6ed3dffd6dd54ce624d56318fdd2fd6078b9b7cc8e9ce21081f40de70929e1578a3bf0c05108f3fc558cd08b9d7b8e5f2026c890c2183c6a550e17e8aba37158fde0438324981bb940f809a42d73f1a8b4a35ed36a40bf0203010001');
SELECT pg_catalog.lo_close(0);

SELECT pg_catalog.lo_open('21586', 131072);
SELECT pg_catalog.lowrite(0, '\x30820122300d06092a864886f70d01010105000382010f003082010a0282010100a9470de070a16b4ceffc0e48cb43c08e4e44104f6aa01249130f6a9d26b639c60ef7981c8cd84a7c5f4cfdcc65e843c9b7ac139c6b15165d039b155ced5a1b4572dbcd4c060b190e3216a7c62faa2f1a4946738981799f0ca9fc6bf2847681fd8c16906c609e93a11764c0cf2a87a7656bb67da9ebd4ef48b7165b3b56c7531fb53fb02180f2bfee22bb5aa7a037fadbfa8a0792d0b17817ae130b988df8b106a00d5b2610d22e52299617c5911ff1182eee85dca91d84d02294f8203a2e2ee842f761299aae9a5ad9f48416a64f24a02c24a5a4f7674daaa7c9f68749a77e82866a3102b74968c3ad297a1904ca4990b4d50c00fc7b8224839875791155fad10203010001');
SELECT pg_catalog.lo_close(0);

SELECT pg_catalog.lo_open('22128', 131072);
SELECT pg_catalog.lowrite(0, '\x30820122300d06092a864886f70d01010105000382010f003082010a0282010100b1c142dd1ff6144680b2e315dc227306caf5fcb204af02b0cc88fa629f0e81ac74a21d65f295791d276dd8fc97c753ca768369dc2fbc7e721592afc557cef8777c19ae55a5140e6c1f86820788b73eebf17aa0e3e643b786a067bf83c80269e46645f8d7fb805f59d36838de5a8ec58789a2395d01dd43632fb56a0c18be751288305c362e0111c2f24dbc92af42ea48617163340abdf09d039948486c35aa3ac90f7215ad806f0cbd67eedd43b87d98aa1b64973c3c3615a738a81c2d2495a8aac54c54c39a024fefb42b603d82057f2cf75a1d0ba0034212f9535aed6dc7dd631f0c29785653664d1c0eb5bcaa76f485bc6c7e67ac61d845677406efcf287b0203010001');
SELECT pg_catalog.lo_close(0);

SELECT pg_catalog.lo_open('22546', 131072);
SELECT pg_catalog.lowrite(0, '\x30820122300d06092a864886f70d01010105000382010f003082010a0282010100b5a111812e67531d714a53a692d9cecfaed8501de60173a04d98f5f417baf88432df6348b288f63b62cc0cafd3f79111301e866cd90c43a0eced062adadfc898b40dc793c158f6a43690f7475a8a0e7506301635de10790634b10b312acf0bc5bf6b95c594087bc3a7f14cc4340590b5cf044d9ab4868e699e9709f412956ecca68f27962b0314ef2d27c86823c0b64db75e09909843d75d52bfff4d2f93df81d261f1e1fffae303b64702cbe842b9736bc4b2af415694cb62fc99d5d9969351ed361059c0ef9bf325ab8fda6c5bc1ce684227ffc211be2359a169f9603793ef6ed63c1265ea6c8fb3457670bc835f5875c6d877c4dbbf81ced55f7b7c527f9f0203010001');
SELECT pg_catalog.lo_close(0);

SELECT pg_catalog.lo_open('28167', 131072);
SELECT pg_catalog.lowrite(0, '\x30820122300d06092a864886f70d01010105000382010f003082010a0282010100a2002296545d64765f99b1aae2921f1bd7da8a721bbe29697da7e46f4cd88fc173a641a38178ff37e08d74f8bc30096c23760cc5c60f20f50db78cfa2041c1b16a76c712c06418ae218d2c65ad0cd08f90cdc81b857f08aa6ef9d6e302ae37c4473fb255bdf7a82d223f78106f9cebcf5974230fcf82e2e16bf9288f1853c0c2a683ae8b078d10e9279bd9803d2560515de3b9b57015cec826dc54b7302910f0187cc9c055c98026ae1faefb41af747bd813817cf0fa9f9b889d068632b474f871a5a47bfa5047e96a1eeec3d617babd0ff4e94307e1c339fb0883f592f5731c831bd70fd9740cd7c8573e0bc0fde57706bdb5a50b4283f420310ce8647b64d70203010001');
SELECT pg_catalog.lo_close(0);

SELECT pg_catalog.lo_open('28208', 131072);
SELECT pg_catalog.lowrite(0, '\x30820122300d06092a864886f70d01010105000382010f003082010a0282010100a9d6237c56e4b4cc6326d04c04cbb9211c192e0df865a5d99167956e7aeafe825f36e80e8c9d1f369f14618036bf7d5125da4aed9a1e25e539e7444aab0ca936eafc44bb74cdb939aefb1bdc44cd1955f129caa610e63d297426861d3477ba5b9db6b2a7ee624563451d88b3d24792b9fa2db499ba194e725f31b670d56bfaed5e299a5da3c4cc0e3e4cededf041cac1790d91f7cb8998f4ebd4158c0b33831280d5ce13b5178989e437299ef8f0b5edc4fd69c053a15a80b16a89376849be10354d913eaf3810e82d2f295718e0ea62f36bcc2445c5fbe6b06b53e351daeafcd8fbb2a22395052ef04b3a99809f199bfcc5161175e314654281c64c14d655010203010001');
SELECT pg_catalog.lo_close(0);

SELECT pg_catalog.lo_open('30638', 131072);
SELECT pg_catalog.lowrite(0, '\x30820122300d06092a864886f70d01010105000382010f003082010a02820101008ddc0ecccb5968906dc6651bbd1419605f71de100d5f1364c7404e4852cdce97cfd57d9f1f76c76c909f4728b7138ada5bdf0c936a1fcdef85f5887221f1326fc40157f8fa05c13d41e2d89ebb4c3f4e95e9348ccd806b94392b789eecdaade21cea6ea65ccc9d04b86a3343cbf8c38766c6a2f5527ae0ffb20af7863335eb585eb697903ceaa2f7d3cc6059347e244bde741a61a17a3b734ba4873a82c1706a163f7b2e10993f671f1979438cc06f7a5486e153f53c4590172c5f2f771080c38c618b78c52436dfe579ff23c53e9df8a3fefa6c7296ee7639bd31cc3b645b575ac90f92efce6aaf9405a40681274b055eec5ecc9265067a52b071a1d24d47bf0203010001');
SELECT pg_catalog.lo_close(0);

SELECT pg_catalog.lo_open('30940', 131072);
SELECT pg_catalog.lowrite(0, '\x30820122300d06092a864886f70d01010105000382010f003082010a0282010100c2815cf6a734d1db49f44ad9a78445d8e125737aac9d0f0f062a470952d0d7eb14c19af3a944eacad340f227124092910fa332f3cda86b7c72caca1a8344b61dc754e5f2bcad0ac395f7d7f8a87fa86e8a5c83063c46466d1f5ca4664bc2610a38922d7fcbfda9682160e75eba587dea6046559cbed08ec12267c8eda4167e6a6afaabec2df720fcbb4959b9671df1327c689d93eeb79eabe3711fc343965fa8cf4a08dfdedb362a3cbd9f7b94415ac92e9935ad0ceac43d7f1e7c8b04d45c3357438c098f0df5367607e5bccb885d323ae20a8b16e8d56e71f29bf024b79345d1e6674e56af24fabe3dae399a31c95ee5f91c1f6da482e7f990fc6e14e375990203010001');
SELECT pg_catalog.lo_close(0);

SELECT pg_catalog.lo_open('31021', 131072);
SELECT pg_catalog.lowrite(0, '\x30820122300d06092a864886f70d01010105000382010f003082010a0282010100875f5ae294ac01a4b11e95a4f5e6924f8f1689173b8a9a085e271f59b9b3a99e17bbab8a88bd23ba4fe354e05d9c21db4592ddbfe0c0ea42a98472d36dbea3ec9774d2653ed61f0f1b3ae05683a09602e39a069dda8241b528d6aa555356fe834490cecd515f6b223247e0dc513cafaa5f8ffdf090f37e3a27cd550046c8c2c33f947bef7017da7db7720f1dc29e00981111a383cb97f8704a5fc2a53805d644d9b0ff3b3757eb630ff6873929c547e8982db8dd4adde5635edcc8fa2674c77cf9fad0ab6a913f71fdc9383cb645dcb50d2ec5e48ed98abbbcfda0c3009423a9ce85fc7692f90242839a0397fa67091d1faf131f992f0648878bf4da4b505f3d0203010001');
SELECT pg_catalog.lo_close(0);

SELECT pg_catalog.lo_open('31062', 131072);
SELECT pg_catalog.lowrite(0, '\x30820122300d06092a864886f70d01010105000382010f003082010a0282010100ee06aa659ee1694014500433aa5ba99b0bb128f039cbf8589cc580dd9e325eee64b6e22241a928ab6d5732e8e16e93e323fcdbc909151bc69943ef1b0447708952cc2b8fc9cf9370e9215dc479978f65c581cd19c601fec4c7980fc7a432dc9164901c9d3b4342fa8ba8c9ae4377e196bd38948e853dc21598866c4c44ed15eb084a8cd4bf30714b79b0a48a13167802e509a9e910767385592aad1249a5793925d2cd1615e257cf11c86fadca975fbca5dd2495244f502b93d092fcd9c19dcd1e356b637e5a17b98f4877db630c4ec0b55674231756a10e398289221ae912ba3de969cab5ee44e02de91ad49dd7732e440e6d8e871dd6853d122dafcb4276450203010001');
SELECT pg_catalog.lo_close(0);

SELECT pg_catalog.lo_open('31483', 131072);
SELECT pg_catalog.lowrite(0, '\x30820122300d06092a864886f70d01010105000382010f003082010a0282010100caf64cf76309f07e5aa6aa49353ef9afde765a68f4267ad27c5c5a50a9ea171de24af0797f43f48385903246d3b9509013842be781f8b0d92e20949f2770370bb82acd29aca44c47830f4ea28a54dd576845eb97cbbb4c8bc2c7a62ce2b149f19f7378c2319425b552f82dc2e6621d5a690781666c795aa60ddccfaec848e09cce9cd3c47c2e61afdb63db3e494e0fed9fea8ca1045e5d4703a9557b17dd637db18e269927061119dbf9926195f86da1b326f7082c779bb0d41a949b5641fcba17d29f80a29fe01796e94c084d2aaf56dd3305a9849b77c9cf8023351919b9d1232541085135b40c8d1f21a6e95fab74136056c1ceaf8b6ec86138e5d92586e50203010001');
SELECT pg_catalog.lo_close(0);

SELECT pg_catalog.lo_open('31524', 131072);
SELECT pg_catalog.lowrite(0, '\x30820122300d06092a864886f70d01010105000382010f003082010a0282010100ab239092b0dee3b8604dd7e4def45d5d360293592f1ac550c29b98522e185d845dd2e2141ae81adcabeb3c92940fb7f48b38c1f77bdb12d7ccc6c34266a179345f117c55e4d9150507cc489e2bee45edd597f9e8a3072e4eb5f3738021176a79265676ae9a71be9209aa5f6d4c3683627a8eb5e3afc8690e7313e8993f41afa57e87a60fec35d07e47f9943807742c336733cf1cda07506ddcc50baa6e34a80a0b4c351bd13c986f32e09734608aed840ab6ba05756906a19818e86f25515dbdd8ea6456292bc0ef7a06302534a934d41797e60929ebb4be12f26cc2d842a6d9d076f553f6309ec55c67b180bc7d077b0e234a4e78f31fa3019c7ea5240a98170203010001');
SELECT pg_catalog.lo_close(0);

SELECT pg_catalog.lo_open('31585', 131072);
SELECT pg_catalog.lowrite(0, '\x30820122300d06092a864886f70d01010105000382010f003082010a0282010100bf3fa06933a02ee078ea8f5f2f30958d414dcc3b65f3efd7cfed5494f4a2b41f281ca1cd6882427c0c543868a474b7d2698fa0e832266cf899263b1cb1aff964ebcc266062b3a38c52dfde6cedea46415a32588357b3682659fa5477a24f7fc6061f866e543b747c449513fdb1c75af3f2154171d127459600f45388fe3eb61a0322f94b3c122357ffffb1afde65ccb4f02917f02444e47dde60cf6b600e7f3fe2bf11087427df1d0aaa9e349bf666acc80f8c90f5af5496623f191635c5a63f64c3d8296a8961d48ad5ea071c18066bb5e9cec14d19c301637c99bf1ea013f45d4bef73c7a7f50037a7e061e3f702acfcd3d7e9308799ff9a78096a9e88a9b50203010001');
SELECT pg_catalog.lo_close(0);

SELECT pg_catalog.lo_open('31966', 131072);
SELECT pg_catalog.lowrite(0, '\x30820122300d06092a864886f70d01010105000382010f003082010a0282010100ca1df4112103351f6efa1903bbf1cf34e60eec75720ab69c76335c0670bfd48d94ca3ca395291d5d3bc01f810fbe57525a07c54e96c437175a0f7a438fd94b461acf5049e33349173b5e3c19d911e7462212f8e8f3986e78e34d7b572435ebafe3a84abd62a2145cd1e037bd31f89065418f13869cc0b9f0e5b39e0663efc5b7a463af5bd7fd1d3acee7c380ae084071db53818a42adf2e1d614dd229a8a8a323fcf5f353a432a3a376d76b54cfaed84e398850e088cf401b13e95499d668db2b44e569cd2362414898479a581d30481f5bf770da7456d6f46096c8cbee36267aeec06d60d19395f385cc220518d9a8cad4b72f56e9e2a0220719f44d6e5b44d0203010001');
SELECT pg_catalog.lo_close(0);

SELECT pg_catalog.lo_open('32187', 131072);
SELECT pg_catalog.lowrite(0, '\x30820122300d06092a864886f70d01010105000382010f003082010a0282010100ac9d62653950901575a3927eb07eef402ec4e3ffe4328d25567bf92910f03443bf884b5a68ec883d1881bf010ddc60ff304fe9e002805cd78ea2d38bed1c59546e68f2d0e5e146586710d53de274add7df22bb9f8879be7ac6b3561c253b9ccd977e68d6c13f3742805a3d4b46650c1dd5473c8feebfc916f80b50c722d802d07ab6fd43d9938d250430a4f2e13846a0b7f537bfd47c088f3210b3657bdf3b625321123344c3189a7e0c50e8220e39d761e65f52ca3a85c1438f0c23980d98a95ed579f09d55179e56700c70da3f0bca17bd0398500a15d824fd0134e32a9627e6f7117cbd363e225227eb6dcbbfe1b2ab2e37319b49a44e4552cbb0d44379f10203010001');
SELECT pg_catalog.lo_close(0);

SELECT pg_catalog.lo_open('32428', 131072);
SELECT pg_catalog.lowrite(0, '\x30820122300d06092a864886f70d01010105000382010f003082010a0282010100d63478c7e2c7b530de87d49c90bafddb428f6af0c2339617862aceb2cd87313b95bc8597244114f68079d7596c0eae9d185e1e31fff860aa496875f13499853ef8abf3b1fbddba60ed6426df99327b38c14173687a38918c963980e952aae4f37f307c52c96956750286c4e8a9934f57029830a86482848ad6751f697750d907dfd292f93eaae52c6c5691a7227ca3e273efd4553263c65965232d03aa26399e9d4fbee2bd4871f69bcbe3855e2ea635a86d15fa1668cc31b26770b2cee837cc91f6c6f1ffb137867f6a0d5967dcae30ba639be4d013faad774aea5b7b7955b09d7dd2f8076f2f4d5ca4bb015734fc515e162906581a28a8f5709e989bfe434b0203010001');
SELECT pg_catalog.lo_close(0);

SELECT pg_catalog.lo_open('32989', 131072);
SELECT pg_catalog.lowrite(0, '\x30820122300d06092a864886f70d01010105000382010f003082010a0282010100b8a23fad6d848585f1f66578eaabc1270cd65d8a40bac9dd827eabb28d5ec116bcd9da9ca3a02cbe51e7b30695c5481e535ee5335e31dd15204749c292a3ec3be3aee46c8753c7950137c5e8f38e3832ef0da91c2f471372b24c30fd18e3da404451bdea4c3bfef4bf3bd42aa60abaa55a8e5a8ef275d45ad74d75184c76395c8f76c5351d441749eca9ec9471363edeb467686dbe92225c5c504218d04c25551727f70eea87a69c21390608dd8546727cb2341b6532dcc46a67bc8715d8e3ca0afcedd0d1d293da74e2d48afc29280e5eddfa10d1f560f169830ac38843f17b1901fb1ec0e630635b1995e26dda47e7192e5633e1a62a31ff5019bfb7b8f9170203010001');
SELECT pg_catalog.lo_close(0);

SELECT pg_catalog.lo_open('33750', 131072);
SELECT pg_catalog.lowrite(0, '\x30820122300d06092a864886f70d01010105000382010f003082010a0282010100a7f612166694ddd22aca4769c97ccb65c9b068300d73b9517be9227a557df4c6258a8807672e4a6be12d12d2696e1b16c17ca6027b98b10a24a5b3c568c5bc460332b48f061df99a32ab2ea577af6317e3a9e190791154e10b68b3130809a49657e24d3f764f9b271781dcfb003dcea5d4bd103e32785573b4401a65d41f82dd7b1efc162be5fecd75a502c8e98fe69c6e6a2f3f48a48dcf3b1b21f3ac2e12aac56504bafb51d707f4804b2622b44408d3329b9faccf1cd0d3773bc9ddd09999f9c28089a1730c346f0e61a857315c236ca895d24aae7b795c948f9dfc80e525eff750da7de5ae8331f89f0c5425ed5d1e5da14b652f4e4250feb0b8ad0c961d0203010001');
SELECT pg_catalog.lo_close(0);

SELECT pg_catalog.lo_open('34631', 131072);
SELECT pg_catalog.lowrite(0, '\x30820122300d06092a864886f70d01010105000382010f003082010a0282010100a3a6299f9ed7de322fa517ca87c91f63f03da8508188a8a4f03c4206f0e6405f5b3dd1a41cd3556b8c51e8785596e9b0fea99b3c5f1bda34ba3672ee3b592e625859527e91c3db2e0cd37ce5611cb71b3c3627878139416a78f526e005e381a1dc0568048ec80be08ce7c883857f4ac5aa344020228b15f13584c8ce9ee80ceff2ec548c1838fbe4e88eaa13d5d9684a64e1e89be6a1e6b6ebc8b2fcfc615142acda98ec9dbe85f88283f5413571f504f84b80aeb9ab30bb99c5f4fdf6e42d4e7f04dd801396817dc54aed965723e31d212c3e8adc95eaba022a5a9554b906d8b895cc5b5e32efae24028e6b52a7e42fb1e4f1da4a138e169ca4eef2c79bbe910203010001');
SELECT pg_catalog.lo_close(0);

SELECT pg_catalog.lo_open('34912', 131072);
SELECT pg_catalog.lowrite(0, '\x30820122300d06092a864886f70d01010105000382010f003082010a0282010100c330354f6c7e5ea30f7a23135fd2bd303e3665e9898a32e09a9cbe2e71c53c7f0761509f6aaeb507f03c2659bb5e257c9eac2f48d391c5551a8e5740d62412790491080f05939683714d036d032929c71c75352033721251c2e0ba67d3b6a679d630a303cbdbd7672cb45806ed6a6b785ad91b83faac53f9931256d99fb24971687098c2c3722866fddc8429657618b761664f534b3d9ea8be6d0749e8f90f81cc0c6e67058fdaa4dffa6e03fa47acab668dd3aa9d2549ed3e37b1ad6d78a5d7c4f5b5808f43366205e70af4720444e0eb723630fa312f31336845f52c619178926221ef165c1faad8d18aced2a4920080544d3dbfb8972dc8dd3f2bfd9c679f0203010001');
SELECT pg_catalog.lo_close(0);

SELECT pg_catalog.lo_open('35473', 131072);
SELECT pg_catalog.lowrite(0, '\x30820122300d06092a864886f70d01010105000382010f003082010a02820101008a9a91c3d97a2e77f0174872b2aec96f02942555f1eba9b06acc5227fcd825176679a8d976d59e0adc6120d127ade5ca43d3778c2ab0365c31080031c0446d891c86275f269a052214c0fe2a34200812aa453d7015efd3a2602dbe3f4a75870bdc8385b4f42d02924531b50d48352ed3d93fd02006da98e9beb32985d3ef378fc3c6d62963aa902e3a33380d010dd40fdc92fc09af589b900871fe7757f3900571862482b362a3eb0245045eecd825d4e285143a2876230daa71fc9326eb132a458a8cd9daa00ae0a26e0b5d3fec210373934326d2b3ba06bc2000466f50fe5df8727b684278169e0c100417d5b0b9c1a0dc9e5c86ca3b755569db79bfc253db0203010001');
SELECT pg_catalog.lo_close(0);

SELECT pg_catalog.lo_open('35734', 131072);
SELECT pg_catalog.lowrite(0, '\x30820122300d06092a864886f70d01010105000382010f003082010a0282010100e3d42e4e3e88c978c45addc58ca9d73faf06019f08a2584c99ed2addabf2d73b9a870b293c3c7dc604e0e1de754da3e503a969286531e0b6d8ae0d004eb8f9a13ad40f391c63b42e728b61dab86c200b143844dd51b375984e0efb6fedf4ef225f54ae779efe091e0dd1aac40ef0cfd2be1b30f9758b7ec3677ca50bdf101476ca465eba8d069c59b557e6f70a6d328ecb610f306b3a4fbfc8202f40d93bf9ffd4940afedf1d00e72c93e01e4c2e61307eaf44cdfb446f37829c8f7d4ae3ddeb3e474ddf1063cf49741d334f31d5e81611dbb76f2c1fa1aa297419e5ca6cb46beb201552a01ca8f85968a185708c18a6861b63cf4af161a3e5105e29994abec70203010001');
SELECT pg_catalog.lo_close(0);

SELECT pg_catalog.lo_open('54935', 131072);
SELECT pg_catalog.lowrite(0, '\x30820122300d06092a864886f70d01010105000382010f003082010a028201010094c6f877ec7e3ec4379db2f157a305754f2b209d25fa4105b55f67a40385e58b32c1029bd2dd06c9e48278df608ef203f72c51a3c3f6731db1a7fb65fcfb3f7c11dbe3e09004625202a1afde599ec241945f082dc426d11664bc4837e5c327dceefdc8d4f1584cf3ffbcba082ea17e1fc279923fbb04d189028f02167ce7749e4c4b07e85d6a3286fc7dcc90c515652c1c73f0ae9e29bd4bcefd9b61d14358e22f739de9d79107c750a861b4177e593a1078ec8bffb22cc3b6568f6bb3335b5e38d9904bd3a8d92c7299b8f5dbf8801637d718ca507f4ee81e68e60a673fcddcf635fff76eec11a87cfb9aa57c31f6ee1fd77f1e2aaa2a0e0eaec28104994f490203010001');
SELECT pg_catalog.lo_close(0);

SELECT pg_catalog.lo_open('55296', 131072);
SELECT pg_catalog.lowrite(0, '\x30820122300d06092a864886f70d01010105000382010f003082010a0282010100aa3ab3532ced1cd6b49bf069adae4fe58ffa5ac3852d7c68b28bd6335bdefe7ccf8e186ff9a35019045d9b77e68eb613ea4ff15578243896718f4067f0606134a8bb46a3fb3b85e0c96e67ffa05938aa31c3d7ee3cc4d9abbbebeac7808c2bf15719dc52f3a8143d38bb177be34be98bdc16a4d71c2c1f937615f8cfbc06e4bcf2881153f9bf87d9ceb663b77a9c5a90b26a9e1646787f0dc067fe5694daf20adb400ef08c15974f3cef60463f0e2af74dc35133490212e1672c452fc9d2512ae1659af6e92c00e601c9ecf6357cc8221938d5ddbbd5628a929dbe672959c0085926490ed869ee8175097d8fcd18bff1a483bb4f60c0f71e5b45f8adf6266c550203010001');
SELECT pg_catalog.lo_close(0);

SELECT pg_catalog.lo_open('57922', 131072);
SELECT pg_catalog.lowrite(0, '\x30820122300d06092a864886f70d01010105000382010f003082010a0282010100f490cae89d72ca4d88a830a325b4b60905e275d141c19f83800095d729e2346a8dbf6657e116c6a552f7b611f6b55160b119e461c9d7022c4c639a2b93fcb56f012a436a6b67f0f5fccadb712b1b8472faf85dc70a79aed219eecf50a1ebc1847214104935847d36472ed33d4362bc88b9ceb1f8c7330c274143622d13d99f60c2a380e63b6d0a9d7eba711153d3bb0a50231494c66dcbe9330f61e9afae80929b94c6fe266f7629221aef709675d9300ca3747be296e3b01d1a21d34479581e6c1805577d64bef0c71a299479994ae8b1542fdd8db166bfa07a04f699cfabb30266f43a7e7969542c74845144fa61d7a97efb5a76a0477979c544947416a45f0203010001');
SELECT pg_catalog.lo_close(0);

SELECT pg_catalog.lo_open('58443', 131072);
SELECT pg_catalog.lowrite(0, '\x30820122300d06092a864886f70d01010105000382010f003082010a028201010099e2d7b92af8adb33db81645fca762596a7d5e27aaa7c792b865221a37e2705800df0d7c3133e231aa8898770a67ce3fa2d4045eedd0b772c52b4ec0195506cd8ef0266f5853ed24e10fa6a4d09b8be3d18138700900bbbcf36ad8afd9bef73ecbe1c24aaca513d8279bc1bc52a5794dc9039e17c8e5056f6e7d94bae6c9d3da1c38dd73fa01b7a7a8a0ddffae640ba6088db999309037ae8646a17027b817ec3ff4eb9a22fd783664eaa77c1dbe727c7967ef83a299ae603d82b5839c332a2868ed0ca3ae30dcdd6d47c4bd5481111530b83fb0cb0ba83962cf10fd88711795a847ccdbd9cb291bac0b4ce087143cede694a680e79ad8d989e3e9a15ce299950203010001');
SELECT pg_catalog.lo_close(0);

SELECT pg_catalog.lo_open('60804', 131072);
SELECT pg_catalog.lowrite(0, '\x30820122300d06092a864886f70d01010105000382010f003082010a0282010100a93d594e7c2f9006f956f3e0a6fe132b78d4fd1c8e34d7c497bf480eced1f40ed39f864d5d02255e5fe1f5b3e864212c5c419d9f3bf81be4c8b8e0ae29eccd7453a8cbd7094c046f432ab8ed45b4e7b0bab85ed712bb033c3cf7f68cebe6e1cad95bf56ff5e1914717f0085f4143c07cb19657ac3ec77bbd67747fb6f03260c7d9f4455c67873df0d9ef47a2b3f728f14b412dcaf28401e4de3db63f562f159d9a1a702d5566fc71acbe551836280ef829442757c74d6ac6d4fb26d6196d312bf7bdbf8969712e75bccd4eeef9b66a9eef507ac073850c798bdfb8d51b3b226000a29cb0b02cd9ec5ce8cc7a90433da51ebef2d976a289dfd685a7148b0dbbcf0203010001');
SELECT pg_catalog.lo_close(0);

SELECT pg_catalog.lo_open('69805', 131072);
SELECT pg_catalog.lowrite(0, '\x30820122300d06092a864886f70d01010105000382010f003082010a0282010100c607b9f31532709d2d0630c0cbfb408cc565bcbfa9fdbc4a1de4aa990de97639597154897a7679e487cb3591057ef33d9efb9799da05f7e194e3d838fdaffc3dbf900ba547a331ae2dd2566eead48f9c9bd0ea29bb5eaa19526edb4985a23e648acab78e5be2543a5a88da2391262074ab799e8927fe3e671648cbb8c5e19a94c4a45ae4f70bfc52285f1ca34a0c8cd3ae04f19c2fd6cf7434483c99f335ddda635e8adfc2703553d17b4d10c6bedaa69be4858eddda439a686ba77ebcd459f6635fe6ab31d54c3aaacd8ec10a02c467a4ccfbe08202067e0c1f70b5253f7cd7346063443e5a30a6171830a2a0cab7ccc18ab22483f170ad692fa9cd7fe4279f0203010001');
SELECT pg_catalog.lo_close(0);

SELECT pg_catalog.lo_open('69909', 131072);
SELECT pg_catalog.lowrite(0, '\x30820122300d06092a864886f70d01010105000382010f003082010a0282010100b4f3eac3898985d600420cbb7f1758a10be20fa8714db6663ad93d49b5d588c05ab3a00e4341ebfbb331b04912a0907c0efd14cfc1f29b0e577f5951b583c5c5b3e63e6f7f2c02c855f51ee0b0357e6a8cc4de95474a8791aae9656d7d3f6cffffabc8bd0eafe73a74b2b915edd11cab1186f4aa628f7730e3e13e1a37d787afdcfb9492def695e87689a2fb51b5037e10153c1ad997079c94fb1a092d14e60bea7205ecf0380d93cf3add702e0d52720e78018d7c730bb189fdd27591ca036f8eeae97307f3ec26d4e92ccd9a00e40074b14614ecaeccd540ee4d05d7095e95207ac17399fbc7f156a5408fee02840940dd0e5a1dca79663e5d216d15e9bcdb0203010001');
SELECT pg_catalog.lo_close(0);

SELECT pg_catalog.lo_open('70670', 131072);
SELECT pg_catalog.lowrite(0, '\x30820122300d06092a864886f70d01010105000382010f003082010a0282010100e55d83e6ccd8ecabf8d7595b519a2b52b367d2673e90b5996774c7574b393a1cf7592be61f934f5172bb190c0a55cb62fee611f51a8df32cd4aacd0f20f3700ae9810e8418be817f2d9a985f7123703daedfa8084846c0411b495be54ef9c5a8f2d1485a395ead06c563d4c4a2b550c037e3c2fc72ce48af12d3461feeb77931bbdb6ad31aea5b3b8bc8243946dfa0b60659ed4ee95c44f6b07ca755ba095998f8c74984d2ffecceeb371da0b8fcbf7bfb84e32cd3226d0e010bdcd1633434e73186f374910350d9fa45f8ca6203c160b8d49f5c3d4691d42a34da58be9ead566a67fcf20886d5c9145caa3a4922e67e2118437c46c7f94607bac489de2f61c10203010001');
SELECT pg_catalog.lo_close(0);

SELECT pg_catalog.lo_open('99240', 131072);
SELECT pg_catalog.lowrite(0, '\x30820122300d06092a864886f70d01010105000382010f003082010a0282010100ee843a25ff0fdcf807880fe68c91a4c01ec186ad936125c0e35c86d353e83a1a1773bca8e6c32c3f442f2709f9e9a7d74e98e0834a988eeeb1264d78746bd281469cef42c27773b35f5ec4c13f88e6874b5aac8e452da48dbdc793dd8e58c018934905359d417f5a88b87bf4ae69644d3e7519aeaea3dcfe138d2d59920cc4c72bab5d06fddaff09dad9ba486229b71fb1800204400ea1470bf69290fb43dd3fbc50275e9164c565c448197c41112726ab0f9a724ab721a25e13f60c22bfe8b0023bf6017885cc69447d991dd44785a7710ffd31ee3cace9f3e24124d6e749ad837fcbd8ecb439d7d8f28f41039308669e7eb92051b8e5f3cb187acbedece0990203010001');
SELECT pg_catalog.lo_close(0);

SELECT pg_catalog.lo_open('120705', 131072);
SELECT pg_catalog.lowrite(0, '\x30820122300d06092a864886f70d01010105000382010f003082010a0282010100cfba57a5466072429f997e8e418a7f25c1ca0f777d7cecfe689d1d4d32f81f8f1dbf0a8fd54417cb260a14a1cfaa1cd7281db959dd0fb3810bac0470019447d43b529d19927261dfde6f49921865f8e72074e8da1ec9708a815c61ed3655a9dfcf51072a5d8d99c987ee76a4df15e0b273a792cd52a71101e95a5fd8c5d9e4da1a4a827702ca35cf8374566f048b54f94c0ecfbed7290cec9b7b9aa4aa874a7015109aec2ef09b98e4bbb6fd166772d9a7c712a866256e257976a99ec031f493870f6c3d1d63130fb4bfbbbd2c58eeed49dacff97b7130ab470d5d3e583605ff2b8f979336a86375f07b86d4d6ee2066fd99715296ad7582b801b41ad741c6430203010001');
SELECT pg_catalog.lo_close(0);

SELECT pg_catalog.lo_open('120746', 131072);
SELECT pg_catalog.lowrite(0, '\x30820122300d06092a864886f70d01010105000382010f003082010a0282010100f33a04652e69c7a52921eecd1d283f43fb005b2da864381b283f15ae5b8c8caba6ad00bc1bef2824895c237296f3ebb45f77ce43da28aeafd3dddfb1fb5ef151953e2e4103187fe6de6765a0228129b21d65761b85ec8802d180e14e668f82e4c7e5e86f19f78e52540fdd70bb5209766a625eb4c943fabe4db1dbea9b571dff4c64fad70696f5a475798c24215ab31322d680a9669344de2bea99386ffc5d8f430e0a3aecc7f37a0e36aab00c20724219411602bfbacacc6cfe9ff0386cffeff9bca9b57ba21c6fd15822c3e0613a37e9cc21727494a624c7d64f21bc7aa9e102e1bac992967f4d403cec27f2ac3dc95c139e8076ab4c34dc71e9eee3aa6fa90203010001');
SELECT pg_catalog.lo_close(0);

SELECT pg_catalog.lo_open('122547', 131072);
SELECT pg_catalog.lowrite(0, '\x30820122300d06092a864886f70d01010105000382010f003082010a0282010100c0833a7ca6bfe06a1dd07951e240e532b78a0343d69cf54287920100b5596c4edb5d4507b892fa1b78a86a2e04e1ea58e1b813ad87e3a12997c3fa4c73b1e8f34fd9346c8c348010d7718045d97f794cdfa4a698c6fbd610ea4ba2f76876fcf3e216afbb72b407d98ebb8325f69e879f046856b302a2617502967cc9d264e1c55b7ac4c5a8753565d111004ea88a7fb3146f9ec77e5c45fbf5b7616b4672128f85395d6f20a2acb8de19d5070b557c7d5d743096fced80d4f5afb7a5d0a2fa69ac4c84cd3654c0496b7944dc007194cf2817db4f1d759b54730d86cd0c91813b386d229d10b079e53221aa5b719b915d556269c67cdb35564cefd9c983b811e30203010001');
SELECT pg_catalog.lo_close(0);

SELECT pg_catalog.lo_open('131648', 131072);
SELECT pg_catalog.lowrite(0, '\x30820122300d06092a864886f70d01010105000382010f003082010a0282010100bab31d66d281cb7f92a9ce2c46825db00390b2f6b9f552581f447359c11a5ed26a85fc7a76e09575cb88ab9653fd75f16821447645d9908cc20d4c07d678c4a5ea3dc1acd30698fd915f22dcd301e5d1a544d9424f777d364bd132a6f210a9824140b19369bf7088a9f9b211b1560c869e5967356e7bd44fa2ed77eb36af5b86b6459cea53a688838fc3f4612a8164c902acbb510e9c60ae902fb03829612fbe8cbbb9178d2d6b0d202b355e49e9939a684a2ea9bb17a6c3f0a8e5f305696f5b60987066d03b0e8d7fd24d7350c3e9f46e4fad9a20444935d520ae5044b91b3ccf1a1675c4ddc496f06aa679d0b6a1cf968dc6132d9edfff9ee2e76ffd2c98730203010001');
SELECT pg_catalog.lo_close(0);

SELECT pg_catalog.lo_open('131649', 131072);
SELECT pg_catalog.lowrite(0, '\x30820122300d06092a864886f70d01010105000382010f003082010a0282010100b5bdd4606203a1f7b060a9f4bed2d7219a4853e4d01a5f968f4faa45e0d7f0d2a9d481c1a21491619c241ee28cc1c40d9e3b0c536ce8d74f5a8f08eb4c348c00fad32e6b62d8413ddc8a1420c8b23dc81f066da27d027aec64bae2523fd66bc6adfb23e0093b4fe7645ef4dd1cd89c690ebeeb05b246cccd4d3a12525bc748753dd8cbe159fee06f84d1ec140654551022061a38529c09caab9c71345ebb566063b20f1f6af29d5598dab35567d698ae9455ab49b2ee69140008b5bb3a1389e920216915976115a2b4937fa68442cadde45c67e5553d28b8e2877556f7a5c93622f086b97a2d7c5a8ce25d857d37bf38adb16d066de998b350265cbda8e6bc450203010001');
SELECT pg_catalog.lo_close(0);

SELECT pg_catalog.lo_open('131670', 131072);
SELECT pg_catalog.lowrite(0, '\x30820122300d06092a864886f70d01010105000382010f003082010a0282010100c6e61d63204d517d35c3f11d1069cca6d4ddacee9267da2323f111d23d55938a5607db8dd0f3d53a13ba2e8895376bc2b072025bfd22698218c6e3dd641c1b15cb94593266b1d03865db52873b2b52c530a4fc76416f638f9527a82d9f39c378f7c1d019f335295018d726079cdce425d8554b90b9f8c13f1b081b8a4201bc007f2085acd5fcf5570835a472ec90b3af5097753a271641583f422c0b99914d6b4a85adab2ddda4cf52751f8ae1072d0cf823362ef35999452ed93d0609a9f1840cf0e8c8516538b427b9f520552d679c4f83651257109c1e140174f74e65450a9d1c7d111e1cc94641dd7c8f980e7441b14cbf77690348c7395beb09fc7f317f0203010001');
SELECT pg_catalog.lo_close(0);

SELECT pg_catalog.lo_open('296182', 131072);
SELECT pg_catalog.lowrite(0, '\x30820122300d06092a864886f70d01010105000382010f003082010a0282010100b9ba10c72875493664cbc2d98891cf071db339eaacbba9ced10d6d597b7ea2983d3d0d9bd89f279ff073086fcd7ed3cef392c619210a17cef2d4a6b366afb38d684b4a9678bb9b24ca76b2ff80db94779089d18c73fb5363d202de9b8d080d317f617aa9e52c98af53ece2a07451c7e286997fac59546a6a9bc5501af16a961a7c83576df4358d64d716b577e4028596281659e69f37bc9b135959f47d75127930ff4e41c670506ad9e48697ae7600caf9fbf3c206901fa36ed028c50b5289fc21f29b50e8a39cff95e5dba367481eb6c01ed18e5e8256b97047a9e65cdd51b11a22781b33290ed570a78fbb7c794aba9403beacece15f65989b4e2aab9e23a50203010001');
SELECT pg_catalog.lo_close(0);

COMMIT;

--
-- Name: activity_groups activity_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activity_groups
    ADD CONSTRAINT activity_groups_pkey PRIMARY KEY (id);


--
-- Name: authorization_grants authorization_grants_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.authorization_grants
    ADD CONSTRAINT authorization_grants_pkey PRIMARY KEY (id);


--
-- Name: authorization_resource_policies authorization_resource_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.authorization_resource_policies
    ADD CONSTRAINT authorization_resource_policies_pkey PRIMARY KEY (id);


--
-- Name: authorization_resources authorization_resources_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.authorization_resources
    ADD CONSTRAINT authorization_resources_pkey PRIMARY KEY (id);


--
-- Name: challenge challenge_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.challenge
    ADD CONSTRAINT challenge_pkey PRIMARY KEY (id);


--
-- Name: clients clients_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_pkey PRIMARY KEY (id);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: images images_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.images
    ADD CONSTRAINT images_pkey PRIMARY KEY (id);


--
-- Name: keys keys_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.keys
    ADD CONSTRAINT keys_pkey PRIMARY KEY (id);


--
-- Name: login_events login_events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.login_events
    ADD CONSTRAINT login_events_pkey PRIMARY KEY (id);


--
-- Name: organization_access_approval_circuits organization_access_approval_circuits_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organization_access_approval_circuits
    ADD CONSTRAINT organization_access_approval_circuits_pkey PRIMARY KEY (circuit_id, org_id);


--
-- Name: organization_access_catalog organization_access_catalog_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organization_access_catalog
    ADD CONSTRAINT organization_access_catalog_pkey PRIMARY KEY (entry_id, org_id);


--
-- Name: organization_access_certification_campaigns organization_access_certification_campaigns_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organization_access_certification_campaigns
    ADD CONSTRAINT organization_access_certification_campaigns_pkey PRIMARY KEY (campaign_id, org_id);


--
-- Name: organization_access_certification_items organization_access_certification_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organization_access_certification_items
    ADD CONSTRAINT organization_access_certification_items_pkey PRIMARY KEY (item_id);


--
-- Name: organization_access_request_decisions organization_access_request_decisions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organization_access_request_decisions
    ADD CONSTRAINT organization_access_request_decisions_pkey PRIMARY KEY (request_id, decision_order);


--
-- Name: organization_access_request_items organization_access_request_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organization_access_request_items
    ADD CONSTRAINT organization_access_request_items_pkey PRIMARY KEY (request_id, entry_id, target_id, type);


--
-- Name: organization_access_requests organization_access_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organization_access_requests
    ADD CONSTRAINT organization_access_requests_pkey PRIMARY KEY (request_id);


--
-- Name: organization_activities organization_activities_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organization_activities
    ADD CONSTRAINT organization_activities_pkey PRIMARY KEY (id);


--
-- Name: organization_groups organization_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organization_groups
    ADD CONSTRAINT organization_groups_pkey PRIMARY KEY (group_id, org_id);


--
-- Name: organization_invitations organization_invitations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organization_invitations
    ADD CONSTRAINT organization_invitations_pkey PRIMARY KEY (id);


--
-- Name: organization_member_group_assignments organization_member_group_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organization_member_group_assignments
    ADD CONSTRAINT organization_member_group_assignments_pkey PRIMARY KEY (organization_member_entity_org_id, organization_member_entity_user_id, assigned_at, group_id, source);


--
-- Name: organization_member_profiles organization_member_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organization_member_profiles
    ADD CONSTRAINT organization_member_profiles_pkey PRIMARY KEY (org_id, profile_id);


--
-- Name: organization_member_role_assignments organization_member_role_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organization_member_role_assignments
    ADD CONSTRAINT organization_member_role_assignments_pkey PRIMARY KEY (organization_member_entity_org_id, organization_member_entity_user_id, assigned_at, role_id);


--
-- Name: organization_permission_usages organization_permission_usages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organization_permission_usages
    ADD CONSTRAINT organization_permission_usages_pkey PRIMARY KEY (org_id, permission, user_id);


--
-- Name: organization_role_delegations organization_role_delegations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organization_role_delegations
    ADD CONSTRAINT organization_role_delegations_pkey PRIMARY KEY (delegation_id, org_id);


--
-- Name: organization_roles organization_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organization_roles
    ADD CONSTRAINT organization_roles_pkey PRIMARY KEY (org_id, role_id);


--
-- Name: organization_security_policies organization_security_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organization_security_policies
    ADD CONSTRAINT organization_security_policies_pkey PRIMARY KEY (org_id);


--
-- Name: organization_segregation_rules organization_segregation_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organization_segregation_rules
    ADD CONSTRAINT organization_segregation_rules_pkey PRIMARY KEY (org_id, rule_id);


--
-- Name: organization_segregation_violations organization_segregation_violations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organization_segregation_violations
    ADD CONSTRAINT organization_segregation_violations_pkey PRIMARY KEY (org_id, violation_id);


--
-- Name: organization_system_role_definitions organization_system_role_definitions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organization_system_role_definitions
    ADD CONSTRAINT organization_system_role_definitions_pkey PRIMARY KEY (role_id);


--
-- Name: organization_temporary_access_grants organization_temporary_access_grants_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organization_temporary_access_grants
    ADD CONSTRAINT organization_temporary_access_grants_pkey PRIMARY KEY (grant_id);


--
-- Name: organizations organizations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT organizations_pkey PRIMARY KEY (id);


--
-- Name: resource_policy_entity_authorized_actions resource_policy_entity_authorized_actions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.resource_policy_entity_authorized_actions
    ADD CONSTRAINT resource_policy_entity_authorized_actions_pkey PRIMARY KEY (resource_policy_entity_id, authorized_actions);


--
-- Name: resource_servers resource_servers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.resource_servers
    ADD CONSTRAINT resource_servers_pkey PRIMARY KEY (id);


--
-- Name: resource_types resource_types_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.resource_types
    ADD CONSTRAINT resource_types_pkey PRIMARY KEY (id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: scopes scopes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.scopes
    ADD CONSTRAINT scopes_pkey PRIMARY KEY (id);


--
-- Name: tokens tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tokens
    ADD CONSTRAINT tokens_pkey PRIMARY KEY (id);


--
-- Name: organization_groups uc_organization_group_external_ref; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organization_groups
    ADD CONSTRAINT uc_organization_group_external_ref UNIQUE (org_id, external_source, external_ref);


--
-- Name: organization_member_roles uc_organization_member_user_id; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organization_member_roles
    ADD CONSTRAINT uc_organization_member_user_id PRIMARY KEY (org_id, user_id);


--
-- Name: organization_segregation_violations uc_segregation_violation_rule_user; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organization_segregation_violations
    ADD CONSTRAINT uc_segregation_violation_rule_user UNIQUE (org_id, rule_id, user_id);


--
-- Name: organizations ukav94yn427pkrad38vrbwf589f; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT ukav94yn427pkrad38vrbwf589f UNIQUE (login_code);


--
-- Name: activity_groups uq_activity_group_name; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activity_groups
    ADD CONSTRAINT uq_activity_group_name UNIQUE (name);


--
-- Name: organization_activities uq_organization_activity_name; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organization_activities
    ADD CONSTRAINT uq_organization_activity_name UNIQUE (name);


--
-- Name: authorization_resources uq_resource_realm_server_type_name; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.authorization_resources
    ADD CONSTRAINT uq_resource_realm_server_type_name UNIQUE (realm, server_name, resource_type_name, name);


--
-- Name: resource_servers uq_resource_server_name; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.resource_servers
    ADD CONSTRAINT uq_resource_server_name UNIQUE (name);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: idx_access_catalog_enabled; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_access_catalog_enabled ON public.organization_access_catalog USING btree (org_id, enabled);


--
-- Name: idx_access_catalog_org; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_access_catalog_org ON public.organization_access_catalog USING btree (org_id);


--
-- Name: idx_access_catalog_target; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_access_catalog_target ON public.organization_access_catalog USING btree (org_id, type, target_id);


--
-- Name: idx_access_request_beneficiary; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_access_request_beneficiary ON public.organization_access_requests USING btree (org_id, beneficiary_id);


--
-- Name: idx_access_request_circuit; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_access_request_circuit ON public.organization_access_requests USING btree (org_id, circuit_id);


--
-- Name: idx_access_request_org; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_access_request_org ON public.organization_access_requests USING btree (org_id);


--
-- Name: idx_access_request_requester; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_access_request_requester ON public.organization_access_requests USING btree (org_id, requester_id);


--
-- Name: idx_access_request_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_access_request_status ON public.organization_access_requests USING btree (org_id, status);


--
-- Name: idx_activity_group_order; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_activity_group_order ON public.activity_groups USING btree (display_order);


--
-- Name: idx_approval_circuit_enabled; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_approval_circuit_enabled ON public.organization_access_approval_circuits USING btree (org_id, enabled, priority);


--
-- Name: idx_approval_circuit_org; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_approval_circuit_org ON public.organization_access_approval_circuits USING btree (org_id);


--
-- Name: idx_authorization_grant_subject_client; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_authorization_grant_subject_client ON public.authorization_grants USING btree (realm, subject, authorized_client_id);


--
-- Name: idx_certification_campaign_due; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_certification_campaign_due ON public.organization_access_certification_campaigns USING btree (status, due_at);


--
-- Name: idx_certification_campaign_org; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_certification_campaign_org ON public.organization_access_certification_campaigns USING btree (org_id);


--
-- Name: idx_certification_item_campaign; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_certification_item_campaign ON public.organization_access_certification_items USING btree (campaign_id);


--
-- Name: idx_certification_item_decision; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_certification_item_decision ON public.organization_access_certification_items USING btree (campaign_id, decision);


--
-- Name: idx_certification_item_reviewer; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_certification_item_reviewer ON public.organization_access_certification_items USING btree (campaign_id, reviewer_id);


--
-- Name: idx_certification_item_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_certification_item_user ON public.organization_access_certification_items USING btree (org_id, user_id);


--
-- Name: idx_client_org_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_client_org_id ON public.clients USING btree (org_id);


--
-- Name: idx_client_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_client_status ON public.clients USING btree (status);


--
-- Name: idx_client_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_client_type ON public.clients USING btree (type);


--
-- Name: idx_delegation_delegate; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_delegation_delegate ON public.organization_role_delegations USING btree (org_id, delegate_id, status);


--
-- Name: idx_delegation_delegator; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_delegation_delegator ON public.organization_role_delegations USING btree (org_id, delegator_id);


--
-- Name: idx_delegation_org; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_delegation_org ON public.organization_role_delegations USING btree (org_id);


--
-- Name: idx_delegation_window; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_delegation_window ON public.organization_role_delegations USING btree (status, valid_until);


--
-- Name: idx_key_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_key_name ON public.keys USING btree (name);


--
-- Name: idx_key_org_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_key_org_id ON public.keys USING btree (org_id);


--
-- Name: idx_login_event_occurred_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_login_event_occurred_at ON public.login_events USING btree (occurred_at);


--
-- Name: idx_login_event_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_login_event_user_id ON public.login_events USING btree (user_id);


--
-- Name: idx_mv_daily_login_counts_day; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_mv_daily_login_counts_day ON public.mv_daily_login_counts USING btree (day);


--
-- Name: idx_mv_daily_new_user_counts_day; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_mv_daily_new_user_counts_day ON public.mv_daily_new_user_counts USING btree (day);


--
-- Name: idx_organization_group_external; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_organization_group_external ON public.organization_groups USING btree (org_id, external_source, external_ref);


--
-- Name: idx_organization_group_org; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_organization_group_org ON public.organization_groups USING btree (org_id);


--
-- Name: idx_organization_group_parent; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_organization_group_parent ON public.organization_groups USING btree (org_id, parent_id);


--
-- Name: idx_organization_invitation_org; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_organization_invitation_org ON public.organization_invitations USING btree (org_id);


--
-- Name: idx_organization_invitation_sent_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_organization_invitation_sent_at ON public.organization_invitations USING btree (sent_at);


--
-- Name: idx_organization_login_code; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_organization_login_code ON public.organizations USING btree (login_code);


--
-- Name: idx_organization_member_org; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_organization_member_org ON public.organization_member_roles USING btree (org_id);


--
-- Name: idx_organization_profile_org; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_organization_profile_org ON public.organization_member_profiles USING btree (org_id);


--
-- Name: idx_organization_role_org; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_organization_role_org ON public.organization_roles USING btree (org_id);


--
-- Name: idx_permission_usage_last_used; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_permission_usage_last_used ON public.organization_permission_usages USING btree (last_used_at);


--
-- Name: idx_permission_usage_org_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_permission_usage_org_user ON public.organization_permission_usages USING btree (org_id, user_id);


--
-- Name: idx_resource_policy_realm_owner; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_resource_policy_realm_owner ON public.authorization_resource_policies USING btree (realm, owner);


--
-- Name: idx_resource_policy_related_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_resource_policy_related_type ON public.authorization_resource_policies USING btree (related_resource_type);


--
-- Name: idx_scope_resource_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_scope_resource_type ON public.scopes USING btree (resource_type);


--
-- Name: idx_scope_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_scope_type ON public.scopes USING btree (type);


--
-- Name: idx_segregation_rule_enabled; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_segregation_rule_enabled ON public.organization_segregation_rules USING btree (org_id, enabled);


--
-- Name: idx_segregation_rule_org; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_segregation_rule_org ON public.organization_segregation_rules USING btree (org_id);


--
-- Name: idx_segregation_violation_org; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_segregation_violation_org ON public.organization_segregation_violations USING btree (org_id);


--
-- Name: idx_segregation_violation_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_segregation_violation_status ON public.organization_segregation_violations USING btree (org_id, status);


--
-- Name: idx_segregation_violation_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_segregation_violation_user ON public.organization_segregation_violations USING btree (org_id, user_id);


--
-- Name: idx_temp_access_emergency; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_temp_access_emergency ON public.organization_temporary_access_grants USING btree (org_id, emergency, reviewed_at);


--
-- Name: idx_temp_access_org_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_temp_access_org_user ON public.organization_temporary_access_grants USING btree (org_id, user_id);


--
-- Name: idx_temp_access_request; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_temp_access_request ON public.organization_temporary_access_grants USING btree (request_id);


--
-- Name: idx_temp_access_status_until; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_temp_access_status_until ON public.organization_temporary_access_grants USING btree (status, valid_until);


--
-- Name: idx_user_org; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_org ON public.users USING btree (org_id);


--
-- Name: idx_user_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_type ON public.users USING btree (type);


--
-- Name: idxkoervu3p7gii0clr7jd6awfe5; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idxkoervu3p7gii0clr7jd6awfe5 ON public.challenge USING btree (reason);


--
-- Name: client_entity_scopes fk2v71d8dggqrwauovdcxy8hb5m; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client_entity_scopes
    ADD CONSTRAINT fk2v71d8dggqrwauovdcxy8hb5m FOREIGN KEY (client_entity_id) REFERENCES public.clients(id);


--
-- Name: organization_access_request_items fk4ta8cubj2fo0lc0kqxs2w48f8; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organization_access_request_items
    ADD CONSTRAINT fk4ta8cubj2fo0lc0kqxs2w48f8 FOREIGN KEY (request_id) REFERENCES public.organization_access_requests(request_id);


--
-- Name: organization_member_role_assignments fk74t1hy1gu5gm77bmoofofhufv; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organization_member_role_assignments
    ADD CONSTRAINT fk74t1hy1gu5gm77bmoofofhufv FOREIGN KEY (organization_member_entity_org_id, organization_member_entity_user_id) REFERENCES public.organization_member_roles(org_id, user_id);


--
-- Name: resource_policy_entity_authorized_actions fkbct54a0x62sxi48dhynbtp4fr; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.resource_policy_entity_authorized_actions
    ADD CONSTRAINT fkbct54a0x62sxi48dhynbtp4fr FOREIGN KEY (resource_policy_entity_id) REFERENCES public.authorization_resource_policies(id);


--
-- Name: organization_access_request_decisions fkbjsmlob8aetykcvooragi1c0p; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organization_access_request_decisions
    ADD CONSTRAINT fkbjsmlob8aetykcvooragi1c0p FOREIGN KEY (request_id) REFERENCES public.organization_access_requests(request_id);


--
-- Name: organization_access_request_resources fkj1mi0phswvweh8373naq80mv2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organization_access_request_resources
    ADD CONSTRAINT fkj1mi0phswvweh8373naq80mv2 FOREIGN KEY (request_id) REFERENCES public.organization_access_requests(request_id);


--
-- Name: resource_policy_entity_related_resources fkk6qboowkilro6b2jn3keqk9uc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.resource_policy_entity_related_resources
    ADD CONSTRAINT fkk6qboowkilro6b2jn3keqk9uc FOREIGN KEY (resource_policy_entity_id) REFERENCES public.authorization_resource_policies(id);


--
-- Name: organization_member_group_assignments fkrfag7oocsfctdp8ge2wvng83; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organization_member_group_assignments
    ADD CONSTRAINT fkrfag7oocsfctdp8ge2wvng83 FOREIGN KEY (organization_member_entity_org_id, organization_member_entity_user_id) REFERENCES public.organization_member_roles(org_id, user_id);


--
-- Name: mv_daily_login_counts; Type: MATERIALIZED VIEW DATA; Schema: public; Owner: postgres
--

REFRESH MATERIALIZED VIEW public.mv_daily_login_counts;


--
-- Name: mv_daily_new_user_counts; Type: MATERIALIZED VIEW DATA; Schema: public; Owner: postgres
--

REFRESH MATERIALIZED VIEW public.mv_daily_new_user_counts;


--
-- PostgreSQL database dump complete
--

\unrestrict d75zRmrYMnds81u67EnonHi29Dnn08ThfONPFozosvok9yHtcTqDspCI2FZnijn

