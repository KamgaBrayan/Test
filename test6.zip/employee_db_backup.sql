--
-- PostgreSQL database dump
--

\restrict M6vCGWI06tICEOD9yZpMmXLNz7TBq9ehZfE5FDMpB7mch3bUSE4s8TkBoBTUjkF

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: dependents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dependents (
    dependent_id character varying(255) NOT NULL,
    employee_id character varying(255) NOT NULL,
    company_id character varying(255) NOT NULL,
    first_name character varying(255),
    last_name character varying(255),
    birth_date date,
    gender character varying(255),
    relationship character varying(255),
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    CONSTRAINT ck_dependent_gender CHECK (((gender)::text = ANY ((ARRAY['MALE'::character varying, 'FEMALE'::character varying])::text[]))),
    CONSTRAINT ck_dependent_relationship CHECK (((relationship)::text = ANY ((ARRAY['SPOUSE'::character varying, 'CHILD'::character varying, 'PARENT'::character varying, 'SIBLING'::character varying, 'OTHER'::character varying])::text[])))
);


ALTER TABLE public.dependents OWNER TO postgres;

--
-- Name: employee_affiliations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employee_affiliations (
    company_id character varying(255) NOT NULL,
    affiliation_id character varying(255) NOT NULL,
    employee_id character varying(255) NOT NULL,
    organism_type character varying(40) NOT NULL,
    organism_code character varying(255) NOT NULL,
    organism_name character varying(255),
    membership_number character varying(64),
    contribution_category character varying(255),
    employee_rate numeric(6,3),
    employer_rate numeric(6,3),
    status character varying(16) NOT NULL,
    affiliated_on date,
    terminated_on date,
    termination_reason character varying(500),
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone,
    CONSTRAINT ck_affiliation_membership_number CHECK ((((status)::text <> 'ACTIVE'::text) OR ((organism_type)::text <> ALL ((ARRAY['SOCIAL_SECURITY'::character varying, 'PENSION_FUND'::character varying])::text[])) OR ((membership_number IS NOT NULL) AND (length(TRIM(BOTH FROM membership_number)) > 0)))),
    CONSTRAINT ck_affiliation_organism_type CHECK (((organism_type)::text = ANY ((ARRAY['SOCIAL_SECURITY'::character varying, 'HEALTH_INSURANCE'::character varying, 'PENSION_FUND'::character varying, 'UNION'::character varying, 'PROFESSIONAL_BODY'::character varying, 'OTHER'::character varying])::text[]))),
    CONSTRAINT ck_affiliation_period CHECK (((affiliated_on IS NULL) OR (terminated_on IS NULL) OR (terminated_on >= affiliated_on))),
    CONSTRAINT ck_affiliation_rates CHECK ((((employee_rate IS NULL) OR ((employee_rate >= (0)::numeric) AND (employee_rate <= (100)::numeric))) AND ((employer_rate IS NULL) OR ((employer_rate >= (0)::numeric) AND (employer_rate <= (100)::numeric))))),
    CONSTRAINT ck_affiliation_status CHECK (((status)::text = ANY ((ARRAY['PENDING'::character varying, 'ACTIVE'::character varying, 'SUSPENDED'::character varying, 'TERMINATED'::character varying])::text[]))),
    CONSTRAINT ck_affiliation_terminated_date CHECK ((((status)::text <> 'TERMINATED'::text) OR (terminated_on IS NOT NULL)))
);


ALTER TABLE public.employee_affiliations OWNER TO postgres;

--
-- Name: employee_career_records; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employee_career_records (
    company_id character varying(255) NOT NULL,
    record_id character varying(255) NOT NULL,
    employee_id character varying(255) NOT NULL,
    record_type character varying(16) NOT NULL,
    experience_kind character varying(20),
    organization character varying(255),
    title character varying(255),
    description character varying(2000),
    start_date date,
    end_date date,
    level_code character varying(255),
    credential character varying(255),
    institution character varying(255),
    study_field character varying(255),
    graduation_year integer,
    obtained_on date,
    language_code character varying(16),
    proficiency_code character varying(16),
    primary_language boolean DEFAULT false NOT NULL,
    assessed_at timestamp(6) with time zone,
    verified boolean DEFAULT false NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone,
    CONSTRAINT ck_career_record_experience_kind CHECK (((experience_kind IS NULL) OR ((experience_kind)::text = ANY ((ARRAY['EMPLOYMENT'::character varying, 'INTERNSHIP'::character varying, 'APPRENTICESHIP'::character varying, 'VOLUNTEERING'::character varying])::text[])))),
    CONSTRAINT ck_career_record_graduation_year CHECK (((graduation_year IS NULL) OR ((graduation_year >= 1900) AND (graduation_year <= 2999)))),
    CONSTRAINT ck_career_record_period CHECK (((start_date IS NULL) OR (end_date IS NULL) OR (end_date >= start_date))),
    CONSTRAINT ck_career_record_required_fields CHECK (((((record_type)::text = 'EXPERIENCE'::text) AND (organization IS NOT NULL) AND (length(TRIM(BOTH FROM organization)) > 0)) OR (((record_type)::text = 'LANGUAGE'::text) AND (language_code IS NOT NULL) AND (length(TRIM(BOTH FROM language_code)) > 0)) OR (((record_type)::text = 'EDUCATION'::text) AND (((credential IS NOT NULL) AND (length(TRIM(BOTH FROM credential)) > 0)) OR ((level_code IS NOT NULL) AND (length(TRIM(BOTH FROM level_code)) > 0)))))),
    CONSTRAINT ck_career_record_type CHECK (((record_type)::text = ANY ((ARRAY['EXPERIENCE'::character varying, 'EDUCATION'::character varying, 'LANGUAGE'::character varying])::text[])))
);


ALTER TABLE public.employee_career_records OWNER TO postgres;

--
-- Name: employee_identities; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employee_identities (
    company_id character varying(255) NOT NULL,
    employee_id character varying(255) NOT NULL,
    type character varying(64) NOT NULL,
    value character varying(255) NOT NULL,
    issued_at date,
    expires_at date,
    issuing_country character varying(2),
    issuing_authority character varying(255),
    CONSTRAINT ck_employee_identity_type CHECK (((type)::text = ANY ((ARRAY['NATIONAL_ID'::character varying, 'PASSPORT'::character varying, 'RESIDENCE_PERMIT'::character varying, 'RECEIPT'::character varying, 'DRIVING_LICENSE'::character varying, 'VOTER_CARD'::character varying, 'BIRTH_CERTIFICATE'::character varying, 'MILITARY_ID'::character varying, 'RESIDENCE_CERTIFICATE'::character varying, 'OTHER'::character varying])::text[])))
);


ALTER TABLE public.employee_identities OWNER TO postgres;

--
-- Name: employee_payment_accounts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employee_payment_accounts (
    company_id character varying(255) NOT NULL,
    account_id character varying(255) NOT NULL,
    employee_id character varying(255) NOT NULL,
    method character varying(32) NOT NULL,
    label character varying(255),
    account_reference character varying(64) NOT NULL,
    institution_code character varying(255),
    provider_code character varying(255),
    currency_code character varying(8),
    primary_account boolean DEFAULT false NOT NULL,
    primary_employee_key character varying(255),
    status character varying(24) NOT NULL,
    effective_from date,
    effective_to date,
    proof_document_id character varying(255),
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone,
    CONSTRAINT ck_payment_account_period CHECK (((effective_from IS NULL) OR (effective_to IS NULL) OR (effective_to >= effective_from))),
    CONSTRAINT ck_payment_account_primary_key CHECK (((primary_account AND ((primary_employee_key)::text = (employee_id)::text)) OR ((NOT primary_account) AND (primary_employee_key IS NULL)))),
    CONSTRAINT ck_payment_account_primary_verified CHECK (((NOT primary_account) OR ((status)::text = 'VERIFIED'::text))),
    CONSTRAINT ck_payment_account_status CHECK (((status)::text = ANY ((ARRAY['PENDING_VERIFICATION'::character varying, 'VERIFIED'::character varying, 'REJECTED'::character varying, 'CLOSED'::character varying])::text[])))
);


ALTER TABLE public.employee_payment_accounts OWNER TO postgres;

--
-- Name: employee_profile_schemas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employee_profile_schemas (
    company_id character varying(255) NOT NULL,
    code character varying(255) NOT NULL,
    version character varying(255) NOT NULL,
    name character varying(255),
    description character varying(255),
    sections jsonb,
    active boolean,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


ALTER TABLE public.employee_profile_schemas OWNER TO postgres;

--
-- Name: employees; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employees (
    company_id character varying(255) NOT NULL,
    employee_id character varying(255) NOT NULL,
    user_id character varying(255),
    first_name character varying(255) NOT NULL,
    last_name character varying(255) NOT NULL,
    birthdate date,
    birth_location character varying(255),
    nationality character varying(255) NOT NULL,
    gender character varying(255),
    marital_status character varying(255),
    status character varying(255),
    social_security_number character varying(255),
    national_id character varying(255),
    tax_id character varying(255),
    personal_address jsonb,
    emergency_contacts jsonb,
    photo jsonb,
    registration_number character varying(64),
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    contact_phone character varying(32),
    contact_email character varying(255),
    CONSTRAINT ck_employee_gender CHECK (((gender)::text = ANY ((ARRAY['MALE'::character varying, 'FEMALE'::character varying])::text[]))),
    CONSTRAINT ck_employee_marital_status CHECK (((marital_status)::text = ANY ((ARRAY['SINGLE'::character varying, 'MARRIED'::character varying, 'DIVORCED'::character varying, 'WIDOWED'::character varying, 'OTHER'::character varying])::text[]))),
    CONSTRAINT ck_employee_status CHECK (((status)::text = ANY ((ARRAY['ACTIVE'::character varying, 'INACTIVE'::character varying, 'TERMINATED'::character varying, 'PENDING'::character varying])::text[])))
);


ALTER TABLE public.employees OWNER TO postgres;

--
-- Name: flyway_schema_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.flyway_schema_history (
    installed_rank integer NOT NULL,
    version character varying(50),
    description character varying(200) NOT NULL,
    type character varying(20) NOT NULL,
    script character varying(1000) NOT NULL,
    checksum integer,
    installed_by character varying(100) NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


ALTER TABLE public.flyway_schema_history OWNER TO postgres;

--
-- Name: registration_number_assignments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.registration_number_assignments (
    company_id character varying(255) NOT NULL,
    assignment_id character varying(255) NOT NULL,
    employee_id character varying(255) NOT NULL,
    registration_number character varying(64) NOT NULL,
    active_number_key character varying(64),
    legal_entity_code character varying(255),
    sequence_code character varying(255),
    format_code character varying(255),
    mode character varying(16) NOT NULL,
    status character varying(16) NOT NULL,
    assigned_at timestamp(6) with time zone NOT NULL,
    assigned_by character varying(255),
    reason character varying(500),
    replaced_at timestamp(6) with time zone,
    CONSTRAINT ck_registration_assignment_active_key CHECK (((((status)::text = 'ACTIVE'::text) AND ((active_number_key)::text = (registration_number)::text)) OR (((status)::text = 'REPLACED'::text) AND (active_number_key IS NULL)))),
    CONSTRAINT ck_registration_assignment_manual_reason CHECK ((((mode)::text <> 'MANUAL'::text) OR ((reason IS NOT NULL) AND (length(TRIM(BOTH FROM reason)) > 0)))),
    CONSTRAINT ck_registration_assignment_mode CHECK (((mode)::text = ANY ((ARRAY['AUTOMATIC'::character varying, 'MANUAL'::character varying, 'IMPORTED'::character varying])::text[]))),
    CONSTRAINT ck_registration_assignment_replaced_at CHECK ((((status)::text <> 'REPLACED'::text) OR (replaced_at IS NOT NULL))),
    CONSTRAINT ck_registration_assignment_status CHECK (((status)::text = ANY ((ARRAY['ACTIVE'::character varying, 'REPLACED'::character varying])::text[])))
);


ALTER TABLE public.registration_number_assignments OWNER TO postgres;

--
-- Name: registration_number_formats; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.registration_number_formats (
    company_id character varying(255) NOT NULL,
    code character varying(255) NOT NULL,
    name character varying(255),
    pattern character varying(200) NOT NULL,
    expected_length integer,
    letter_case character varying(10) NOT NULL,
    check_digit character varying(10) NOT NULL,
    active boolean NOT NULL,
    CONSTRAINT ck_registration_format_check_digit CHECK (((check_digit)::text = ANY ((ARRAY['NONE'::character varying, 'MOD97'::character varying])::text[]))),
    CONSTRAINT ck_registration_format_letter_case CHECK (((letter_case)::text = ANY ((ARRAY['AS_IS'::character varying, 'UPPER'::character varying, 'LOWER'::character varying])::text[])))
);


ALTER TABLE public.registration_number_formats OWNER TO postgres;

--
-- Name: registration_number_sequences; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.registration_number_sequences (
    company_id character varying(255) NOT NULL,
    code character varying(255) NOT NULL,
    name character varying(255),
    selector_entity_code character varying(255),
    selector_category_code character varying(255),
    selector_site_code character varying(255),
    selector_priority integer DEFAULT 0 NOT NULL,
    format_code character varying(255) NOT NULL,
    start_value bigint DEFAULT 1 NOT NULL,
    step bigint DEFAULT 1 NOT NULL,
    current_value bigint,
    reset_policy character varying(10) NOT NULL,
    last_reset_year integer,
    active boolean NOT NULL,
    CONSTRAINT ck_registration_sequence_reset_policy CHECK (((reset_policy)::text = ANY ((ARRAY['NEVER'::character varying, 'YEARLY'::character varying])::text[]))),
    CONSTRAINT ck_registration_sequence_start CHECK ((start_value >= 0)),
    CONSTRAINT ck_registration_sequence_step CHECK ((step > 0))
);


ALTER TABLE public.registration_number_sequences OWNER TO postgres;

--
-- Name: resource_assignments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.resource_assignments (
    assignment_id character varying(255) NOT NULL,
    company_id character varying(255) NOT NULL,
    resource_id character varying(255) NOT NULL,
    employee_id character varying(255) NOT NULL,
    status character varying(255) NOT NULL,
    assigned_date date NOT NULL,
    expected_return_date date,
    actual_return_date date,
    condition_at_assignment character varying(255),
    condition_at_return character varying(255),
    assigned_by character varying(255),
    return_processed_by character varying(255),
    transferred_to character varying(255),
    assignment_notes character varying(255),
    return_notes character varying(255),
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    CONSTRAINT ck_assignment_condition_at_assignment CHECK (((condition_at_assignment)::text = ANY ((ARRAY['NEW'::character varying, 'GOOD'::character varying, 'FAIR'::character varying, 'POOR'::character varying, 'DAMAGED'::character varying])::text[]))),
    CONSTRAINT ck_assignment_condition_at_return CHECK (((condition_at_return)::text = ANY ((ARRAY['NEW'::character varying, 'GOOD'::character varying, 'FAIR'::character varying, 'POOR'::character varying, 'DAMAGED'::character varying])::text[]))),
    CONSTRAINT ck_assignment_status CHECK (((status)::text = ANY ((ARRAY['ACTIVE'::character varying, 'RETURNED'::character varying, 'OVERDUE'::character varying, 'LOST'::character varying, 'TRANSFERRED'::character varying])::text[])))
);


ALTER TABLE public.resource_assignments OWNER TO postgres;

--
-- Name: resource_categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.resource_categories (
    category_id character varying(255) NOT NULL,
    company_id character varying(255) NOT NULL,
    type character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    description character varying(255),
    requires_return boolean,
    requires_condition_check boolean,
    default_return_days integer,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    CONSTRAINT ck_resource_category_type CHECK (((type)::text = ANY ((ARRAY['WORKSTATION'::character varying, 'COMPUTER'::character varying, 'MONITOR'::character varying, 'PHONE'::character varying, 'VEHICLE'::character varying, 'BADGE'::character varying, 'LOCKER'::character varying, 'PARKING_SPOT'::character varying, 'SOFTWARE_LICENSE'::character varying, 'EQUIPMENT'::character varying, 'OTHER'::character varying])::text[])))
);


ALTER TABLE public.resource_categories OWNER TO postgres;

--
-- Name: resource_maintenance_records; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.resource_maintenance_records (
    maintenance_id character varying(255) NOT NULL,
    company_id character varying(255) NOT NULL,
    resource_id character varying(255) NOT NULL,
    type character varying(255) NOT NULL,
    description character varying(255),
    provider character varying(255),
    scheduled_date date,
    completed_date date,
    condition_before character varying(255),
    condition_after character varying(255),
    cost_amount numeric(19,4),
    cost_currency character varying(255),
    technician_notes character varying(255),
    recorded_by character varying(255),
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone,
    CONSTRAINT ck_maintenance_condition_after CHECK (((condition_after)::text = ANY ((ARRAY['NEW'::character varying, 'GOOD'::character varying, 'FAIR'::character varying, 'POOR'::character varying, 'DAMAGED'::character varying])::text[]))),
    CONSTRAINT ck_maintenance_condition_before CHECK (((condition_before)::text = ANY ((ARRAY['NEW'::character varying, 'GOOD'::character varying, 'FAIR'::character varying, 'POOR'::character varying, 'DAMAGED'::character varying])::text[]))),
    CONSTRAINT ck_maintenance_type CHECK (((type)::text = ANY ((ARRAY['PREVENTIVE'::character varying, 'CORRECTIVE'::character varying, 'INSPECTION'::character varying, 'UPGRADE'::character varying, 'REPAIR'::character varying])::text[])))
);


ALTER TABLE public.resource_maintenance_records OWNER TO postgres;

--
-- Name: resources; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.resources (
    resource_id character varying(255) NOT NULL,
    company_id character varying(255) NOT NULL,
    category_id character varying(255) NOT NULL,
    type character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    description character varying(255),
    serial_number character varying(255),
    asset_tag character varying(255),
    brand character varying(255),
    model character varying(255),
    attributes jsonb,
    status character varying(255) NOT NULL,
    condition character varying(255),
    location character varying(255),
    location_code character varying(255),
    purchase_price_amount numeric(19,4),
    purchase_price_currency character varying(255),
    purchase_date date,
    warranty_expiry date,
    expected_retirement_date date,
    document_ids jsonb,
    notes character varying(255),
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    CONSTRAINT ck_resource_condition CHECK (((condition)::text = ANY ((ARRAY['NEW'::character varying, 'GOOD'::character varying, 'FAIR'::character varying, 'POOR'::character varying, 'DAMAGED'::character varying])::text[]))),
    CONSTRAINT ck_resource_status CHECK (((status)::text = ANY ((ARRAY['AVAILABLE'::character varying, 'ASSIGNED'::character varying, 'RESERVED'::character varying, 'UNDER_MAINTENANCE'::character varying, 'RETIRED'::character varying, 'LOST'::character varying, 'DAMAGED'::character varying])::text[]))),
    CONSTRAINT ck_resource_type CHECK (((type)::text = ANY ((ARRAY['WORKSTATION'::character varying, 'COMPUTER'::character varying, 'MONITOR'::character varying, 'PHONE'::character varying, 'VEHICLE'::character varying, 'BADGE'::character varying, 'LOCKER'::character varying, 'PARKING_SPOT'::character varying, 'SOFTWARE_LICENSE'::character varying, 'EQUIPMENT'::character varying, 'OTHER'::character varying])::text[])))
);


ALTER TABLE public.resources OWNER TO postgres;

--
-- Name: secondary_identifiers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.secondary_identifiers (
    company_id character varying(255) NOT NULL,
    identifier_id character varying(255) NOT NULL,
    employee_id character varying(255) NOT NULL,
    type character varying(40) NOT NULL,
    value character varying(64) NOT NULL,
    issued_by character varying(255),
    valid_from date,
    valid_to date,
    CONSTRAINT ck_secondary_identifier_issuer CHECK ((((type)::text <> 'EXTERNAL_SYSTEM'::text) OR ((issued_by IS NOT NULL) AND (length(TRIM(BOTH FROM issued_by)) > 0)))),
    CONSTRAINT ck_secondary_identifier_type CHECK (((type)::text = ANY ((ARRAY['PREVIOUS_REGISTRATION_NUMBER'::character varying, 'ORIGIN_REGISTRATION_NUMBER'::character varying, 'EXTERNAL_SYSTEM'::character varying])::text[]))),
    CONSTRAINT ck_secondary_identifier_validity CHECK (((valid_from IS NULL) OR (valid_to IS NULL) OR (valid_to >= valid_from)))
);


ALTER TABLE public.secondary_identifiers OWNER TO postgres;

--
-- Data for Name: dependents; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dependents (dependent_id, employee_id, company_id, first_name, last_name, birth_date, gender, relationship, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: employee_affiliations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employee_affiliations (company_id, affiliation_id, employee_id, organism_type, organism_code, organism_name, membership_number, contribution_category, employee_rate, employer_rate, status, affiliated_on, terminated_on, termination_reason, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: employee_career_records; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employee_career_records (company_id, record_id, employee_id, record_type, experience_kind, organization, title, description, start_date, end_date, level_code, credential, institution, study_field, graduation_year, obtained_on, language_code, proficiency_code, primary_language, assessed_at, verified, created_at, updated_at) FROM stdin;
96101814-b255-4348-bb24-d5a963439148	97c57c4d-b9e3-4796-9ba2-766856dce494	bb788d50-f3d8-4b9a-b54e-2fcc530465b2	LANGUAGE	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	fr	C1	t	2026-09-13 12:07:43.611608+00	f	2026-09-13 12:07:43.611608+00	2026-09-13 12:10:32.606645+00
96101814-b255-4348-bb24-d5a963439148	b17e48a8-66b9-4f4e-8bfd-618d34cf1a07	bb788d50-f3d8-4b9a-b54e-2fcc530465b2	EXPERIENCE	INTERNSHIP	Digital House International	Mobile App Developer	Mobile app developer working with react native, kotlin and more	2025-09-18	2026-07-08	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	t	2026-09-13 12:11:35.488453+00	2026-09-13 12:12:48.214837+00
96101814-b255-4348-bb24-d5a963439148	9a448bbc-d961-4465-956c-d9ea7f3e83da	bb788d50-f3d8-4b9a-b54e-2fcc530465b2	EDUCATION	\N	\N	\N	\N	\N	\N	Bachelor's Degree	Software Engineering	University of Douala	Faculty of Science	2024	2024-09-12	\N	\N	f	\N	t	2026-09-13 12:16:05.890597+00	2026-09-13 12:16:12.206957+00
\.


--
-- Data for Name: employee_identities; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employee_identities (company_id, employee_id, type, value, issued_at, expires_at, issuing_country, issuing_authority) FROM stdin;
96101814-b255-4348-bb24-d5a963439148	bb788d50-f3d8-4b9a-b54e-2fcc530465b2	NATIONAL_ID	1111111111111233	2026-09-14	2036-09-14	CM	DGSN
\.


--
-- Data for Name: employee_payment_accounts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employee_payment_accounts (company_id, account_id, employee_id, method, label, account_reference, institution_code, provider_code, currency_code, primary_account, primary_employee_key, status, effective_from, effective_to, proof_document_id, created_at, updated_at) FROM stdin;
96101814-b255-4348-bb24-d5a963439148	71d39b36-2667-43be-ae04-d6cde9310de1	bb788d50-f3d8-4b9a-b54e-2fcc530465b2	MOBILE_MONEY	MTN Payment	651204966	\N	MTN	XAF	f	\N	PENDING_VERIFICATION	2026-09-12	\N	\N	2026-09-12 19:32:17.07978+00	2026-09-12 19:32:17.07978+00
\.


--
-- Data for Name: employee_profile_schemas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employee_profile_schemas (company_id, code, version, name, description, sections, active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: employees; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employees (company_id, employee_id, user_id, first_name, last_name, birthdate, birth_location, nationality, gender, marital_status, status, social_security_number, national_id, tax_id, personal_address, emergency_contacts, photo, registration_number, created_at, updated_at, contact_phone, contact_email) FROM stdin;
96101814-b255-4348-bb24-d5a963439148	bb788d50-f3d8-4b9a-b54e-2fcc530465b2	79397ae7-db25-4553-a4f2-df3a607da5e3	Armani	Takam	2000-01-13	Yaoundé	Cameroon	MALE	SINGLE	ACTIVE	\N	1111111111111233	\N	{"city": "Douala", "state": "Littoral", "street": "Rue Xxxxx", "country": "Cameroon", "countryCode": "CM"}	\N	\N	OPUS-2026-0001	2026-09-12 08:57:50.832732+00	2026-09-14 14:11:50.461236+00	+237678252276	fantazymachine@gmail.com
\.


--
-- Data for Name: flyway_schema_history; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.flyway_schema_history (installed_rank, version, description, type, script, checksum, installed_by, installed_on, execution_time, success) FROM stdin;
1	1	init	SQL	V1__init.sql	-95398848	postgres	2026-09-10 15:23:21.685629	197	t
2	2	employee identities	SQL	V2__employee_identities.sql	-870288648	postgres	2026-09-10 15:23:21.951667	48	t
3	3	registration numbers and flat contact	SQL	V3__registration_numbers_and_flat_contact.sql	1837537340	postgres	2026-09-10 15:23:22.033163	99	t
4	4	affiliations career records payment accounts	SQL	V4__affiliations_career_records_payment_accounts.sql	500379351	postgres	2026-09-10 15:23:22.148178	86	t
\.


--
-- Data for Name: registration_number_assignments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.registration_number_assignments (company_id, assignment_id, employee_id, registration_number, active_number_key, legal_entity_code, sequence_code, format_code, mode, status, assigned_at, assigned_by, reason, replaced_at) FROM stdin;
96101814-b255-4348-bb24-d5a963439148	b6ebd819-5817-4c72-94cb-0c46b2057256	bb788d50-f3d8-4b9a-b54e-2fcc530465b2	OPUS-2026-0001	\N	\N	SEQ-CADRES	CADRES	AUTOMATIC	REPLACED	2026-09-12 08:57:50.909661+00	\N	\N	2026-09-13 17:14:32.261303+00
96101814-b255-4348-bb24-d5a963439148	269f0871-927f-4c2f-91b7-bd8c06871f0c	bb788d50-f3d8-4b9a-b54e-2fcc530465b2	OPUS-2026-0002	OPUS-2026-0002	\N	SEQ-CADRES	CADRES	AUTOMATIC	ACTIVE	2026-09-13 17:14:32.261303+00	\N	This is a test assignment	\N
\.


--
-- Data for Name: registration_number_formats; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.registration_number_formats (company_id, code, name, pattern, expected_length, letter_case, check_digit, active) FROM stdin;
96101814-b255-4348-bb24-d5a963439148	CADRES	Matricule Cadres	OPUS-{YEAR:4}-{SEQ:4}	\N	UPPER	NONE	t
\.


--
-- Data for Name: registration_number_sequences; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.registration_number_sequences (company_id, code, name, selector_entity_code, selector_category_code, selector_site_code, selector_priority, format_code, start_value, step, current_value, reset_policy, last_reset_year, active) FROM stdin;
96101814-b255-4348-bb24-d5a963439148	SEQ-CADRES	Séquence Cadre	\N	\N	\N	0	CADRES	1	1	2	YEARLY	2026	t
\.


--
-- Data for Name: resource_assignments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.resource_assignments (assignment_id, company_id, resource_id, employee_id, status, assigned_date, expected_return_date, actual_return_date, condition_at_assignment, condition_at_return, assigned_by, return_processed_by, transferred_to, assignment_notes, return_notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: resource_categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.resource_categories (category_id, company_id, type, name, description, requires_return, requires_condition_check, default_return_days, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: resource_maintenance_records; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.resource_maintenance_records (maintenance_id, company_id, resource_id, type, description, provider, scheduled_date, completed_date, condition_before, condition_after, cost_amount, cost_currency, technician_notes, recorded_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: resources; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.resources (resource_id, company_id, category_id, type, name, description, serial_number, asset_tag, brand, model, attributes, status, condition, location, location_code, purchase_price_amount, purchase_price_currency, purchase_date, warranty_expiry, expected_retirement_date, document_ids, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: secondary_identifiers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.secondary_identifiers (company_id, identifier_id, employee_id, type, value, issued_by, valid_from, valid_to) FROM stdin;
96101814-b255-4348-bb24-d5a963439148	6e1a72e2-efd7-42ff-8304-f23026e7ee23	bb788d50-f3d8-4b9a-b54e-2fcc530465b2	ORIGIN_REGISTRATION_NUMBER	OPUS-2026-0001	\N	2026-09-12	2026-09-13
\.


--
-- Name: dependents dependents_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dependents
    ADD CONSTRAINT dependents_pkey PRIMARY KEY (company_id, dependent_id, employee_id);


--
-- Name: employee_affiliations employee_affiliations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_affiliations
    ADD CONSTRAINT employee_affiliations_pkey PRIMARY KEY (company_id, affiliation_id);


--
-- Name: employee_career_records employee_career_records_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_career_records
    ADD CONSTRAINT employee_career_records_pkey PRIMARY KEY (company_id, record_id);


--
-- Name: employee_identities employee_identities_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_identities
    ADD CONSTRAINT employee_identities_pkey PRIMARY KEY (company_id, employee_id, type, value);


--
-- Name: employee_payment_accounts employee_payment_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_payment_accounts
    ADD CONSTRAINT employee_payment_accounts_pkey PRIMARY KEY (company_id, account_id);


--
-- Name: employee_profile_schemas employee_profile_schemas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_profile_schemas
    ADD CONSTRAINT employee_profile_schemas_pkey PRIMARY KEY (code, company_id, version);


--
-- Name: employees employees_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_pkey PRIMARY KEY (company_id, employee_id);


--
-- Name: flyway_schema_history flyway_schema_history_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flyway_schema_history
    ADD CONSTRAINT flyway_schema_history_pk PRIMARY KEY (installed_rank);


--
-- Name: resources idx_resource_asset_tag; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.resources
    ADD CONSTRAINT idx_resource_asset_tag UNIQUE (company_id, asset_tag);


--
-- Name: registration_number_assignments registration_number_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.registration_number_assignments
    ADD CONSTRAINT registration_number_assignments_pkey PRIMARY KEY (company_id, assignment_id);


--
-- Name: registration_number_formats registration_number_formats_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.registration_number_formats
    ADD CONSTRAINT registration_number_formats_pkey PRIMARY KEY (company_id, code);


--
-- Name: registration_number_sequences registration_number_sequences_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.registration_number_sequences
    ADD CONSTRAINT registration_number_sequences_pkey PRIMARY KEY (company_id, code);


--
-- Name: resource_assignments resource_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.resource_assignments
    ADD CONSTRAINT resource_assignments_pkey PRIMARY KEY (assignment_id, company_id);


--
-- Name: resource_categories resource_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.resource_categories
    ADD CONSTRAINT resource_categories_pkey PRIMARY KEY (category_id, company_id);


--
-- Name: resource_maintenance_records resource_maintenance_records_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.resource_maintenance_records
    ADD CONSTRAINT resource_maintenance_records_pkey PRIMARY KEY (company_id, maintenance_id);


--
-- Name: resources resources_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.resources
    ADD CONSTRAINT resources_pkey PRIMARY KEY (company_id, resource_id);


--
-- Name: secondary_identifiers secondary_identifiers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.secondary_identifiers
    ADD CONSTRAINT secondary_identifiers_pkey PRIMARY KEY (company_id, identifier_id);


--
-- Name: employee_payment_accounts uk_payment_account_primary; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_payment_accounts
    ADD CONSTRAINT uk_payment_account_primary UNIQUE (company_id, primary_employee_key);


--
-- Name: registration_number_assignments uk_registration_number_active; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.registration_number_assignments
    ADD CONSTRAINT uk_registration_number_active UNIQUE (company_id, active_number_key);


--
-- Name: flyway_schema_history_s_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX flyway_schema_history_s_idx ON public.flyway_schema_history USING btree (success);


--
-- Name: idx_affiliation_employee; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_affiliation_employee ON public.employee_affiliations USING btree (company_id, employee_id);


--
-- Name: idx_affiliation_membership; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_affiliation_membership ON public.employee_affiliations USING btree (company_id, organism_type, membership_number) WHERE (membership_number IS NOT NULL);


--
-- Name: idx_affiliation_organism; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_affiliation_organism ON public.employee_affiliations USING btree (company_id, employee_id, organism_code);


--
-- Name: idx_assignment_company; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_assignment_company ON public.resource_assignments USING btree (company_id);


--
-- Name: idx_assignment_employee; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_assignment_employee ON public.resource_assignments USING btree (company_id, employee_id);


--
-- Name: idx_assignment_resource; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_assignment_resource ON public.resource_assignments USING btree (company_id, resource_id);


--
-- Name: idx_assignment_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_assignment_status ON public.resource_assignments USING btree (company_id, status);


--
-- Name: idx_career_record_employee; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_career_record_employee ON public.employee_career_records USING btree (company_id, employee_id, record_type);


--
-- Name: idx_dependent_empl; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_dependent_empl ON public.dependents USING btree (company_id, employee_id);


--
-- Name: idx_employee_company_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_employee_company_id ON public.employees USING btree (company_id);


--
-- Name: idx_employee_contact_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_employee_contact_email ON public.employees USING btree (company_id, contact_email) WHERE (contact_email IS NOT NULL);


--
-- Name: idx_employee_contact_phone; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_employee_contact_phone ON public.employees USING btree (company_id, contact_phone) WHERE (contact_phone IS NOT NULL);


--
-- Name: idx_employee_identities_employee; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_employee_identities_employee ON public.employee_identities USING btree (company_id, employee_id);


--
-- Name: idx_employee_identities_expiry; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_employee_identities_expiry ON public.employee_identities USING btree (company_id, expires_at) WHERE (expires_at IS NOT NULL);


--
-- Name: idx_employee_identities_value; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_employee_identities_value ON public.employee_identities USING btree (company_id, type, value);


--
-- Name: idx_employee_profile_schema_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_employee_profile_schema_active ON public.employee_profile_schemas USING btree (company_id, active);


--
-- Name: idx_employee_profile_schema_company; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_employee_profile_schema_company ON public.employee_profile_schemas USING btree (company_id);


--
-- Name: idx_maint_company; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_maint_company ON public.resource_maintenance_records USING btree (company_id);


--
-- Name: idx_maint_pending; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_maint_pending ON public.resource_maintenance_records USING btree (company_id, completed_date);


--
-- Name: idx_maint_resource; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_maint_resource ON public.resource_maintenance_records USING btree (company_id, resource_id);


--
-- Name: idx_payment_account_employee; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_payment_account_employee ON public.employee_payment_accounts USING btree (company_id, employee_id);


--
-- Name: idx_registration_assignment_employee; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_registration_assignment_employee ON public.registration_number_assignments USING btree (company_id, employee_id);


--
-- Name: idx_registration_assignment_number; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_registration_assignment_number ON public.registration_number_assignments USING btree (company_id, registration_number);


--
-- Name: idx_registration_sequence_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_registration_sequence_active ON public.registration_number_sequences USING btree (company_id, active);


--
-- Name: idx_res_cat_company; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_res_cat_company ON public.resource_categories USING btree (company_id);


--
-- Name: idx_res_cat_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_res_cat_type ON public.resource_categories USING btree (company_id, type);


--
-- Name: idx_resource_category; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_resource_category ON public.resources USING btree (company_id, category_id);


--
-- Name: idx_resource_company; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_resource_company ON public.resources USING btree (company_id);


--
-- Name: idx_resource_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_resource_status ON public.resources USING btree (company_id, status);


--
-- Name: idx_resource_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_resource_type ON public.resources USING btree (company_id, type);


--
-- Name: idx_secondary_identifier_employee; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_secondary_identifier_employee ON public.secondary_identifiers USING btree (company_id, employee_id);


--
-- Name: idx_secondary_identifier_value; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_secondary_identifier_value ON public.secondary_identifiers USING btree (company_id, value);


--
-- Name: uk_career_record_primary_language; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX uk_career_record_primary_language ON public.employee_career_records USING btree (company_id, employee_id) WHERE (((record_type)::text = 'LANGUAGE'::text) AND primary_language);


--
-- Name: employee_affiliations fk_affiliation_employee; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_affiliations
    ADD CONSTRAINT fk_affiliation_employee FOREIGN KEY (company_id, employee_id) REFERENCES public.employees(company_id, employee_id) ON DELETE CASCADE;


--
-- Name: employee_career_records fk_career_record_employee; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_career_records
    ADD CONSTRAINT fk_career_record_employee FOREIGN KEY (company_id, employee_id) REFERENCES public.employees(company_id, employee_id) ON DELETE CASCADE;


--
-- Name: employee_identities fk_employee_identities_employee; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_identities
    ADD CONSTRAINT fk_employee_identities_employee FOREIGN KEY (company_id, employee_id) REFERENCES public.employees(company_id, employee_id) ON DELETE CASCADE;


--
-- Name: employee_payment_accounts fk_payment_account_employee; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_payment_accounts
    ADD CONSTRAINT fk_payment_account_employee FOREIGN KEY (company_id, employee_id) REFERENCES public.employees(company_id, employee_id) ON DELETE CASCADE;


--
-- Name: registration_number_assignments fk_registration_assignment_employee; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.registration_number_assignments
    ADD CONSTRAINT fk_registration_assignment_employee FOREIGN KEY (company_id, employee_id) REFERENCES public.employees(company_id, employee_id) ON DELETE CASCADE;


--
-- Name: registration_number_sequences fk_registration_sequence_format; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.registration_number_sequences
    ADD CONSTRAINT fk_registration_sequence_format FOREIGN KEY (company_id, format_code) REFERENCES public.registration_number_formats(company_id, code);


--
-- Name: secondary_identifiers fk_secondary_identifier_employee; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.secondary_identifiers
    ADD CONSTRAINT fk_secondary_identifier_employee FOREIGN KEY (company_id, employee_id) REFERENCES public.employees(company_id, employee_id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict M6vCGWI06tICEOD9yZpMmXLNz7TBq9ehZfE5FDMpB7mch3bUSE4s8TkBoBTUjkF

