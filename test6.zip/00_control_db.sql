-- =====================================================================
--  BASE DE CONTRÔLE DE LA MIGRATION  (à créer une fois, dans pgAdmin)
--  Nom suggéré : fluxoon_migration_ctl
--  Rôle : table de correspondance des clés (crosswalk) + journalisation.
--  NB : la création de cette base est de l'infrastructure ; ensuite, TOUTES
--  les écritures de données passeront par Talend.
-- =====================================================================

CREATE SCHEMA IF NOT EXISTS migration;

-- 1) Correspondance clé source (Amplitude) -> clé cible (Fluxoon)
--    Indispensable car il n'y a pas de FK entre les bases microservices.
CREATE TABLE IF NOT EXISTS migration.id_crosswalk (
    entity       varchar(64)  NOT NULL,   -- 'organization','company','legal_entity','site','employee',...
    source_key   varchar(255) NOT NULL,   -- ex: '001' (dossier), '001|00960' (cdos|nmat), 'HOLDING'
    target_db    varchar(64)  NOT NULL,   -- 'auth','organization','employee','employment'
    target_table varchar(128) NOT NULL,
    target_key   varchar(255) NOT NULL,   -- l'UUID/clé générée côté Fluxoon
    created_at   timestamptz  NOT NULL DEFAULT now(),
    PRIMARY KEY (entity, source_key)
);
CREATE INDEX IF NOT EXISTS ix_xwalk_target
    ON migration.id_crosswalk (target_db, target_table, target_key);

-- 2) Journal des exécutions de jobs (1 ligne par run de job)
CREATE TABLE IF NOT EXISTS migration.migration_run (
    run_id       varchar(64) PRIMARY KEY,
    job_name     varchar(128) NOT NULL,
    started_at   timestamptz NOT NULL DEFAULT now(),
    ended_at     timestamptz,
    rows_read    bigint DEFAULT 0,
    rows_written bigint DEFAULT 0,
    rows_rejected bigint DEFAULT 0,
    status       varchar(32)              -- RUNNING | OK | ANOMALIES | FAILED
);

-- 3) Erreurs détaillées (1 ligne par rejet)
CREATE TABLE IF NOT EXISTS migration.migration_error (
    id           bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    run_id       varchar(64),
    job_name     varchar(128),
    phase        varchar(32),             -- extract|transform|validate|load
    code         varchar(64),
    message      text,
    source_table varchar(128),
    source_key   varchar(255),
    target_table varchar(128),
    target_column varchar(128),
    raw_value    text,
    created_at   timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_err_run ON migration.migration_error (run_id);
