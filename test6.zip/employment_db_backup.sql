--
-- PostgreSQL database dump
--

\restrict JTjXbFIZQBLr9OjtKLE0kqWiEkSNY3vyIF0XyFrAR1AOf8bFUC5cr7FzCmXhE0J

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: companies_job_families; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.companies_job_families (
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    code character varying(255) NOT NULL,
    company_id character varying(255) NOT NULL,
    description character varying(255),
    localized_descriptions jsonb,
    localized_names jsonb,
    name character varying(255) NOT NULL
);


ALTER TABLE public.companies_job_families OWNER TO postgres;

--
-- Name: companies_qualifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.companies_qualifications (
    archived boolean,
    archived_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    company_id character varying(255) NOT NULL,
    description character varying(255),
    job_family character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    qualification_id character varying(255) NOT NULL,
    type character varying(255) NOT NULL,
    code character varying(100) NOT NULL,
    version bigint NOT NULL,
    education_level character varying(255),
    institution character varying(255),
    skill_links jsonb,
    status character varying(20) NOT NULL,
    CONSTRAINT companies_qualifications_type_check CHECK (((type)::text = ANY ((ARRAY['DIPLOMA'::character varying, 'CERTIFICATION'::character varying, 'TITLE'::character varying, 'EXPERIENCE'::character varying, 'AUTHORIZATION'::character varying])::text[])))
);


ALTER TABLE public.companies_qualifications OWNER TO postgres;

--
-- Name: companies_skills; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.companies_skills (
    archived boolean,
    critical boolean,
    is_obsolete boolean,
    archived_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    aliases text,
    company_id character varying(255) NOT NULL,
    description character varying(255),
    name character varying(255) NOT NULL,
    skill_id character varying(255) NOT NULL,
    type character varying(255) NOT NULL,
    level_descriptors jsonb,
    code character varying(100) NOT NULL,
    version bigint NOT NULL,
    category_id character varying(255),
    scale_id character varying(255) NOT NULL,
    requires_evidence boolean,
    obsolescence jsonb,
    status character varying(20) NOT NULL,
    deprecated_at timestamp(6) with time zone,
    localized_names jsonb,
    localized_descriptions jsonb,
    CONSTRAINT companies_skills_status_check CHECK (((status)::text = ANY ((ARRAY['DRAFT'::character varying, 'ACTIVE'::character varying, 'DEPRECATED'::character varying, 'ARCHIVED'::character varying])::text[]))),
    CONSTRAINT companies_skills_type_check CHECK (((type)::text = ANY ((ARRAY['TECHNICAL'::character varying, 'FUNCTIONAL'::character varying, 'MANAGERIAL'::character varying, 'LEADERSHIP'::character varying, 'BEHAVIORAL'::character varying, 'DIGITAL'::character varying, 'REGULATORY'::character varying, 'CREATIVITY'::character varying, 'PROBLEM_SOLVING'::character varying, 'COMMUNICATION'::character varying, 'LANGUAGE'::character varying, 'OTHER'::character varying])::text[])))
);


ALTER TABLE public.companies_skills OWNER TO postgres;

--
-- Name: company_conventions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.company_conventions (
    effective_from date NOT NULL,
    effective_to date,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone,
    company_id character varying(255) NOT NULL,
    convention_id character varying(255) NOT NULL,
    reason text
);


ALTER TABLE public.company_conventions OWNER TO postgres;

--
-- Name: company_skill_relations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.company_skill_relations (
    company_id character varying(255) NOT NULL,
    skill_source character varying(100) NOT NULL,
    skill_target character varying(100) NOT NULL,
    type character varying(30) NOT NULL,
    implied_level_code character varying(100),
    minimum_level_code character varying(100),
    effective_from timestamp(6) with time zone NOT NULL,
    effective_to timestamp(6) with time zone,
    strength double precision NOT NULL,
    CONSTRAINT company_skill_relations_check CHECK (((skill_source)::text <> (skill_target)::text)),
    CONSTRAINT company_skill_relations_check1 CHECK (((effective_to IS NULL) OR (effective_to >= effective_from))),
    CONSTRAINT company_skill_relations_strength_check CHECK (((strength >= (0.0)::double precision) AND (strength <= (1.0)::double precision)))
);


ALTER TABLE public.company_skill_relations OWNER TO postgres;

--
-- Name: company_titles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.company_titles (
    title_rank integer,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone,
    abbreviation character varying(255),
    code character varying(255) NOT NULL,
    company_id character varying(255) NOT NULL,
    description text,
    label jsonb,
    status character varying(255) NOT NULL,
    CONSTRAINT company_titles_status_check CHECK (((status)::text = ANY ((ARRAY['ACTIVE'::character varying, 'ARCHIVED'::character varying])::text[])))
);


ALTER TABLE public.company_titles OWNER TO postgres;

--
-- Name: convention_classifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.convention_classifications (
    maximum_salary numeric(38,2),
    minimum_salary numeric(38,2),
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    category_code character varying(255) NOT NULL,
    convention_id character varying(255) NOT NULL,
    grade_code character varying(255) NOT NULL,
    label character varying(255),
    localized_labels jsonb
);


ALTER TABLE public.convention_classifications OWNER TO postgres;

--
-- Name: convention_grades; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.convention_grades (
    rank integer NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    code character varying(255) NOT NULL,
    convention_id character varying(255) NOT NULL,
    label character varying(255) NOT NULL,
    localized_labels jsonb
);


ALTER TABLE public.convention_grades OWNER TO postgres;

--
-- Name: convention_job_categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.convention_job_categories (
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    category character varying(255) NOT NULL,
    code character varying(255) NOT NULL,
    convention_id character varying(255) NOT NULL,
    description character varying(255),
    label character varying(255) NOT NULL,
    localized_descriptions jsonb,
    localized_labels jsonb,
    example_jobs jsonb,
    CONSTRAINT convention_job_categories_category_check CHECK (((category)::text = ANY ((ARRAY['WORKER'::character varying, 'EMPLOYEE'::character varying, 'TECHNICIAN'::character varying, 'EXECUTIVE'::character varying, 'SENIOR_EXECUTIVE'::character varying])::text[])))
);


ALTER TABLE public.convention_job_categories OWNER TO postgres;

--
-- Name: conventions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.conventions (
    effective_from date NOT NULL,
    effective_to date,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone,
    code character varying(255) NOT NULL,
    country_code character varying(255) NOT NULL,
    description character varying(255),
    id character varying(255) NOT NULL,
    legal_reference jsonb,
    name character varying(255) NOT NULL,
    sector character varying(255),
    status character varying(255) NOT NULL,
    version character varying(255) NOT NULL,
    contract_policies jsonb,
    CONSTRAINT conventions_status_check CHECK (((status)::text = ANY ((ARRAY['DRAFT'::character varying, 'ACTIVE'::character varying, 'EXPIRED'::character varying])::text[])))
);


ALTER TABLE public.conventions OWNER TO postgres;

--
-- Name: employee_engagements; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employee_engagements (
    company_id character varying(255) NOT NULL,
    engagement_id character varying(255) NOT NULL,
    employee_id character varying(255) NOT NULL,
    version bigint NOT NULL,
    entry_date date NOT NULL,
    origin jsonb,
    probation_start_date date,
    probation_end_date date,
    confirmation_date date,
    exit_date date,
    probation_extensions jsonb NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    CONSTRAINT employee_engagements_check CHECK (((probation_start_date IS NULL) = (probation_end_date IS NULL))),
    CONSTRAINT employee_engagements_check1 CHECK (((probation_start_date >= entry_date) AND (probation_end_date >= probation_start_date))),
    CONSTRAINT employee_engagements_check2 CHECK ((confirmation_date >= entry_date)),
    CONSTRAINT employee_engagements_check3 CHECK ((confirmation_date >= probation_start_date)),
    CONSTRAINT employee_engagements_check4 CHECK (((exit_date >= entry_date) AND (exit_date >= confirmation_date)))
);


ALTER TABLE public.employee_engagements OWNER TO postgres;

--
-- Name: employment_movements; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employment_movements (
    effective_on date NOT NULL,
    seniority_from date,
    recorded_at timestamp(6) with time zone NOT NULL,
    company_id character varying(255) NOT NULL,
    decided_by character varying(255),
    employee_id character varying(255) NOT NULL,
    from_classification jsonb,
    from_legal_entity_id character varying(255),
    from_employment_id character varying(255),
    from_position jsonb,
    movement_id character varying(255) NOT NULL,
    reason text,
    reason_code character varying(255),
    to_classification jsonb,
    to_legal_entity_id character varying(255),
    to_employment_id character varying(255),
    to_position jsonb,
    type character varying(255) NOT NULL,
    CONSTRAINT employment_movements_type_check CHECK (((type)::text = ANY ((ARRAY['HIRING'::character varying, 'ADDITIONAL_ASSIGNMENT'::character varying, 'PRIMARY_CHANGE'::character varying, 'ACTIVATION'::character varying, 'PROMOTION'::character varying, 'DEMOTION'::character varying, 'TRANSFER'::character varying, 'RECLASSIFICATION'::character varying, 'TITLE_CHANGE'::character varying, 'SECONDMENT'::character varying, 'SUSPENSION'::character varying, 'REINSTATEMENT'::character varying, 'ASSIGNMENT_DEACTIVATION'::character varying, 'ASSIGNMENT_REACTIVATION'::character varying, 'ASSIGNMENT_END'::character varying, 'COMPANY_TRANSFER'::character varying, 'EXIT'::character varying])::text[])))
);


ALTER TABLE public.employment_movements OWNER TO postgres;

--
-- Name: employments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employments (
    engagement_id character varying(255) NOT NULL,
    is_primary boolean NOT NULL,
    job_description_version integer,
    activated_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone NOT NULL,
    end_date timestamp(6) with time zone,
    start_date timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    version bigint NOT NULL,
    category_code character varying(255),
    category_nature character varying(255),
    company_id character varying(255) NOT NULL,
    company_unit_id character varying(255) NOT NULL,
    employee_id character varying(255) NOT NULL,
    employment_id character varying(255) NOT NULL,
    grade_code character varying(255),
    job_description_id character varying(255),
    job_family_code character varying(255),
    job_level character varying(255),
    job_title text,
    position_id character varying(255) NOT NULL,
    reason character varying(255),
    site_id character varying(255),
    status character varying(255) NOT NULL,
    title_code character varying(255),
    type character varying(255) NOT NULL,
    legal_entity_id character varying(255) NOT NULL,
    member_profile_id character varying(255),
    allocation_fte numeric(5,4) DEFAULT 1 NOT NULL,
    replaced_assignment_id character varying(255),
    activity_status character varying(20) NOT NULL,
    inactivity_reason character varying(500),
    closure_reason character varying(500),
    inactivated_at timestamp(6) with time zone,
    closed_at timestamp(6) with time zone,
    CONSTRAINT chk_employment_allocation_fte CHECK (((allocation_fte > (0)::numeric) AND (allocation_fte <= (1)::numeric))),
    CONSTRAINT employments_activity_status_check CHECK (((activity_status)::text = ANY ((ARRAY['ACTIVE'::character varying, 'INACTIVE'::character varying])::text[]))),
    CONSTRAINT employments_category_nature_check CHECK (((category_nature)::text = ANY ((ARRAY['WORKER'::character varying, 'EMPLOYEE'::character varying, 'TECHNICIAN'::character varying, 'EXECUTIVE'::character varying, 'SENIOR_EXECUTIVE'::character varying])::text[]))),
    CONSTRAINT employments_job_level_check CHECK (((job_level)::text = ANY ((ARRAY['JUNIOR'::character varying, 'MID'::character varying, 'SENIOR'::character varying, 'EXPERT'::character varying])::text[]))),
    CONSTRAINT employments_reason_check CHECK (((reason)::text = ANY ((ARRAY['HIRING'::character varying, 'ADDITIONAL_ASSIGNMENT'::character varying, 'PRIMARY_CHANGE'::character varying, 'ACTIVATION'::character varying, 'PROMOTION'::character varying, 'DEMOTION'::character varying, 'TRANSFER'::character varying, 'RECLASSIFICATION'::character varying, 'TITLE_CHANGE'::character varying, 'SECONDMENT'::character varying, 'SUSPENSION'::character varying, 'REINSTATEMENT'::character varying, 'COMPANY_TRANSFER'::character varying, 'EXIT'::character varying])::text[]))),
    CONSTRAINT employments_status_check CHECK (((status)::text = ANY ((ARRAY['PLANNED'::character varying, 'ACTIVE'::character varying, 'CLOSED'::character varying])::text[]))),
    CONSTRAINT employments_type_check CHECK (((type)::text = ANY ((ARRAY['PERMANENT'::character varying, 'TEMPORARY'::character varying, 'INTERIM'::character varying, 'PROJECT'::character varying])::text[])))
);


ALTER TABLE public.employments OWNER TO postgres;

--
-- Name: flyway_schema_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.flyway_schema_history (
    installed_rank integer NOT NULL,
    version character varying(50),
    description character varying(200) NOT NULL,
    type character varying(20) NOT NULL,
    script character varying(1000) NOT NULL,
    checksum integer,
    installed_by character varying(100) NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


ALTER TABLE public.flyway_schema_history OWNER TO postgres;

--
-- Name: graph_build_state_entity; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.graph_build_state_entity (
    current_depth integer NOT NULL,
    started_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    version bigint NOT NULL,
    company_id character varying(255) NOT NULL,
    state_id character varying(255) NOT NULL,
    status character varying(255) NOT NULL,
    pending_unit_ids jsonb,
    unit_ancestors jsonb,
    CONSTRAINT graph_build_state_entity_status_check CHECK (((status)::text = ANY ((ARRAY['PENDING'::character varying, 'IN_PROGRESS'::character varying, 'DEPTH_COMPLETE'::character varying, 'COMPLETE'::character varying, 'FAILED'::character varying])::text[])))
);


ALTER TABLE public.graph_build_state_entity OWNER TO postgres;

--
-- Name: graph_edges; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.graph_edges (
    depth integer NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    effective_since timestamp(6) with time zone NOT NULL,
    version bigint NOT NULL,
    company_id character varying(255) NOT NULL,
    manager_id character varying(255) NOT NULL,
    priority character varying(255) NOT NULL,
    source character varying(255) NOT NULL,
    subordinate_id character varying(255) NOT NULL,
    type character varying(255) NOT NULL,
    CONSTRAINT graph_edges_priority_check CHECK (((priority)::text = ANY ((ARRAY['PRIMARY'::character varying, 'SECONDARY'::character varying])::text[]))),
    CONSTRAINT graph_edges_source_check CHECK (((source)::text = ANY ((ARRAY['EXPLICIT_RELATION'::character varying, 'UNIT_DESIGNATION'::character varying])::text[]))),
    CONSTRAINT graph_edges_type_check CHECK (((type)::text = ANY ((ARRAY['HIERARCHICAL'::character varying, 'FUNCTIONAL'::character varying, 'HR'::character varying, 'PROJECT'::character varying])::text[])))
);


ALTER TABLE public.graph_edges OWNER TO postgres;

--
-- Name: graph_node_ancestor_units; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.graph_node_ancestor_units (
    version bigint NOT NULL,
    ancestor_unit_id character varying(255),
    company_id character varying(255) NOT NULL,
    employee_id character varying(255) NOT NULL
);


ALTER TABLE public.graph_node_ancestor_units OWNER TO postgres;

--
-- Name: graph_nodes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.graph_nodes (
    depth integer NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    version bigint NOT NULL,
    company_id character varying(255) NOT NULL,
    company_unit_id character varying(255) NOT NULL,
    employee_id character varying(255) NOT NULL,
    site_id character varying(255) NOT NULL,
    unit_peers jsonb NOT NULL,
    legal_entity_id character varying(255)
);


ALTER TABLE public.graph_nodes OWNER TO postgres;

--
-- Name: headcount_gap_snapshots; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.headcount_gap_snapshots (
    company_id character varying(255) NOT NULL,
    snapshot_id character varying(255) NOT NULL,
    plan_id character varying(255) NOT NULL,
    plan_version_number integer NOT NULL,
    company_unit_id character varying(255) NOT NULL,
    job_description_id character varying(255) NOT NULL,
    target_fte numeric(12,4) NOT NULL,
    actual_fte numeric(12,4) NOT NULL,
    gap numeric(12,4) NOT NULL,
    captured_at timestamp(6) with time zone NOT NULL
);


ALTER TABLE public.headcount_gap_snapshots OWNER TO postgres;

--
-- Name: job_descriptions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.job_descriptions (
    version integer NOT NULL,
    archived_at timestamp(6) with time zone,
    closed_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone,
    validated_at timestamp(6) with time zone,
    company_id character varying(255) NOT NULL,
    description text,
    job_family character varying(255) NOT NULL,
    level character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    qualifications jsonb,
    responsibilities jsonb NOT NULL,
    skills jsonb NOT NULL,
    slug character varying(255) NOT NULL,
    status character varying(255) NOT NULL,
    purpose text,
    occupational_constraints jsonb DEFAULT '{"rhythms": [], "exposures": [], "travelInherent": false, "drivingRequired": false, "physicalDemands": [], "mandatoryMedicalAptitudes": []}'::jsonb NOT NULL,
    performance_dimensions jsonb DEFAULT '[]'::jsonb NOT NULL,
    typical_experience_months integer,
    validated_by character varying(255),
    created_by character varying(255),
    change_log text,
    derived_from character varying(255),
    review_cycle character varying(255),
    next_review_due_at timestamp with time zone,
    inbound_paths jsonb DEFAULT '[]'::jsonb NOT NULL,
    outbound_paths jsonb DEFAULT '[]'::jsonb NOT NULL,
    CONSTRAINT chk_job_description_experience CHECK (((typical_experience_months IS NULL) OR (typical_experience_months >= 0))),
    CONSTRAINT job_descriptions_level_check CHECK (((level)::text = ANY ((ARRAY['JUNIOR'::character varying, 'MID'::character varying, 'SENIOR'::character varying, 'EXPERT'::character varying])::text[]))),
    CONSTRAINT job_descriptions_status_check CHECK (((status)::text = ANY ((ARRAY['DRAFT'::character varying, 'VALIDATED'::character varying, 'CLOSED'::character varying, 'ARCHIVED'::character varying])::text[])))
);


ALTER TABLE public.job_descriptions OWNER TO postgres;

--
-- Name: job_families; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.job_families (
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    description character varying(255),
    id character varying(255) NOT NULL,
    localized_descriptions jsonb,
    localized_names jsonb,
    name character varying(255) NOT NULL
);


ALTER TABLE public.job_families OWNER TO postgres;

--
-- Name: job_positions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.job_positions (
    end_date date,
    job_description_version integer NOT NULL,
    start_date date NOT NULL,
    archived_at timestamp(6) with time zone,
    closed_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone NOT NULL,
    frozen_at timestamp(6) with time zone,
    opened_at timestamp(6) with time zone,
    updated_at timestamp(6) with time zone NOT NULL,
    title character varying(700) NOT NULL,
    mission_summary character varying(2000),
    category_code character varying(255) NOT NULL,
    category_nature character varying(255),
    company_id character varying(255) NOT NULL,
    company_unit_id character varying(255) NOT NULL,
    criticality_level character varying(255) NOT NULL,
    job_description_id character varying(255) NOT NULL,
    position_id character varying(255) NOT NULL,
    reports_to_position_id character varying(255),
    site_id character varying(255) NOT NULL,
    status character varying(255) NOT NULL,
    team_context text,
    type character varying(255) NOT NULL,
    working_condition jsonb,
    budget jsonb,
    desired_grade_codes jsonb,
    requirements jsonb,
    legal_entity_id character varying(255) NOT NULL,
    member_profile_id character varying(255),
    allocated_fte numeric(5,4) NOT NULL,
    headcount integer NOT NULL,
    skills jsonb DEFAULT '[]'::jsonb NOT NULL,
    CONSTRAINT chk_job_position_allocated_fte CHECK (((allocated_fte >= (0)::numeric) AND (allocated_fte <= (1)::numeric))),
    CONSTRAINT chk_job_position_capacity_consistency CHECK ((((headcount = 0) AND (allocated_fte = (0)::numeric)) OR ((headcount > 0) AND (allocated_fte > (0)::numeric)))),
    CONSTRAINT chk_job_position_headcount CHECK ((headcount >= 0)),
    CONSTRAINT job_positions_category_nature_check CHECK (((category_nature)::text = ANY ((ARRAY['WORKER'::character varying, 'EMPLOYEE'::character varying, 'TECHNICIAN'::character varying, 'EXECUTIVE'::character varying, 'SENIOR_EXECUTIVE'::character varying])::text[]))),
    CONSTRAINT job_positions_criticality_level_check CHECK (((criticality_level)::text = ANY ((ARRAY['LOW'::character varying, 'NORMAL'::character varying, 'MEDIUM'::character varying, 'HIGH'::character varying])::text[]))),
    CONSTRAINT job_positions_status_check CHECK (((status)::text = ANY ((ARRAY['OPEN'::character varying, 'PLANNED'::character varying, 'FROZEN'::character varying, 'CLOSED'::character varying, 'ARCHIVED'::character varying])::text[]))),
    CONSTRAINT job_positions_type_check CHECK (((type)::text = ANY ((ARRAY['PERMANENT'::character varying, 'FIXED_TERM'::character varying, 'PROJECT_BASED'::character varying, 'CONTINGENT'::character varying])::text[])))
);


ALTER TABLE public.job_positions OWNER TO postgres;

--
-- Name: management_relations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.management_relations (
    created_at timestamp(6) with time zone NOT NULL,
    end_date timestamp(6) with time zone,
    start_date timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    status character varying(15) NOT NULL,
    company_id character varying(255) NOT NULL,
    management_type character varying(255) NOT NULL,
    manager_id character varying(255) NOT NULL,
    priority character varying(255) NOT NULL,
    relation_id character varying(255) NOT NULL,
    subordinate_id character varying(255) NOT NULL,
    CONSTRAINT management_relations_management_type_check CHECK (((management_type)::text = ANY ((ARRAY['HIERARCHICAL'::character varying, 'FUNCTIONAL'::character varying, 'HR'::character varying, 'PROJECT'::character varying])::text[]))),
    CONSTRAINT management_relations_priority_check CHECK (((priority)::text = ANY ((ARRAY['PRIMARY'::character varying, 'SECONDARY'::character varying])::text[]))),
    CONSTRAINT management_relations_status_check CHECK (((status)::text = ANY ((ARRAY['ACTIVE'::character varying, 'ENDED'::character varying])::text[])))
);


ALTER TABLE public.management_relations OWNER TO postgres;

--
-- Name: movement_reasons; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.movement_reasons (
    display_order integer,
    is_standard boolean NOT NULL,
    requires_comment boolean NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone,
    applicable_types jsonb,
    code character varying(255) NOT NULL,
    company_id character varying(255) NOT NULL,
    description text,
    label jsonb,
    status character varying(255) NOT NULL,
    CONSTRAINT movement_reasons_status_check CHECK (((status)::text = ANY ((ARRAY['ACTIVE'::character varying, 'ARCHIVED'::character varying])::text[])))
);


ALTER TABLE public.movement_reasons OWNER TO postgres;

--
-- Name: position_graph_build_states; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.position_graph_build_states (
    positions_processed integer,
    completed_at timestamp(6) with time zone,
    graph_version bigint NOT NULL,
    started_at timestamp(6) with time zone,
    company_id character varying(255) NOT NULL,
    failure_reason text,
    status character varying(255) NOT NULL,
    CONSTRAINT position_graph_build_states_status_check CHECK (((status)::text = ANY ((ARRAY['PENDING'::character varying, 'IN_PROGRESS'::character varying, 'COMPLETE'::character varying, 'FAILED'::character varying])::text[])))
);


ALTER TABLE public.position_graph_build_states OWNER TO postgres;

--
-- Name: position_graph_nodes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.position_graph_nodes (
    depth integer NOT NULL,
    occupied_employees integer,
    required_employees integer,
    subtree_occupied_employees integer,
    subtree_required_employees integer,
    created_at timestamp(6) with time zone NOT NULL,
    graph_version bigint NOT NULL,
    ancestors jsonb,
    company_id character varying(255) NOT NULL,
    company_unit_id character varying(255),
    direct_reports jsonb,
    job_title character varying(255),
    parent_position_id character varying(255),
    position_id character varying(255) NOT NULL,
    site_id character varying(255)
);


ALTER TABLE public.position_graph_nodes OWNER TO postgres;

--
-- Name: proficiency_scales; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.proficiency_scales (
    company_id character varying(255) NOT NULL,
    scale_id character varying(255) NOT NULL,
    code character varying(100) NOT NULL,
    type character varying(30) NOT NULL,
    label character varying(255) NOT NULL,
    labels jsonb NOT NULL,
    levels jsonb NOT NULL,
    CONSTRAINT proficiency_scale_type_check CHECK (((type)::text = ANY ((ARRAY['ORDINAL'::character varying, 'BINARY'::character varying, 'CONTINUOUS'::character varying])::text[])))
);


ALTER TABLE public.proficiency_scales OWNER TO postgres;

--
-- Name: workforce_plans; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.workforce_plans (
    company_id character varying(255) NOT NULL,
    plan_id character varying(255) NOT NULL,
    company_unit_id character varying(255) NOT NULL,
    version_number integer NOT NULL,
    expected_start_date date NOT NULL,
    expected_end_date date,
    effective_start_date date,
    effective_end_date date,
    created_at timestamp(6) with time zone NOT NULL,
    approved_at timestamp(6) with time zone,
    status character varying(30) NOT NULL,
    approval_workflow_ref character varying(255),
    targets jsonb NOT NULL,
    version bigint NOT NULL,
    CONSTRAINT chk_workforce_plan_version_number CHECK ((version_number >= 0)),
    CONSTRAINT workforce_plan_status_check CHECK (((status)::text = ANY ((ARRAY['DRAFT'::character varying, 'APPROVED'::character varying, 'SUPERSEDED'::character varying, 'CLOSED'::character varying])::text[])))
);


ALTER TABLE public.workforce_plans OWNER TO postgres;

--
-- Data for Name: companies_job_families; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.companies_job_families (created_at, updated_at, code, company_id, description, localized_descriptions, localized_names, name) FROM stdin;
\.


--
-- Data for Name: companies_qualifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.companies_qualifications (archived, archived_at, created_at, updated_at, company_id, description, job_family, name, qualification_id, type, code, version, education_level, institution, skill_links, status) FROM stdin;
\.


--
-- Data for Name: companies_skills; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.companies_skills (archived, critical, is_obsolete, archived_at, created_at, updated_at, aliases, company_id, description, name, skill_id, type, level_descriptors, code, version, category_id, scale_id, requires_evidence, obsolescence, status, deprecated_at, localized_names, localized_descriptions) FROM stdin;
\.


--
-- Data for Name: company_conventions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.company_conventions (effective_from, effective_to, created_at, updated_at, company_id, convention_id, reason) FROM stdin;
\.


--
-- Data for Name: company_skill_relations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.company_skill_relations (company_id, skill_source, skill_target, type, implied_level_code, minimum_level_code, effective_from, effective_to, strength) FROM stdin;
\.


--
-- Data for Name: company_titles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.company_titles (title_rank, created_at, updated_at, abbreviation, code, company_id, description, label, status) FROM stdin;
\.


--
-- Data for Name: convention_classifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.convention_classifications (maximum_salary, minimum_salary, created_at, updated_at, category_code, convention_id, grade_code, label, localized_labels) FROM stdin;
\.


--
-- Data for Name: convention_grades; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.convention_grades (rank, created_at, updated_at, code, convention_id, label, localized_labels) FROM stdin;
\.


--
-- Data for Name: convention_job_categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.convention_job_categories (created_at, updated_at, category, code, convention_id, description, label, localized_descriptions, localized_labels, example_jobs) FROM stdin;
\.


--
-- Data for Name: conventions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.conventions (effective_from, effective_to, created_at, updated_at, code, country_code, description, id, legal_reference, name, sector, status, version, contract_policies) FROM stdin;
\.


--
-- Data for Name: employee_engagements; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employee_engagements (company_id, engagement_id, employee_id, version, entry_date, origin, probation_start_date, probation_end_date, confirmation_date, exit_date, probation_extensions, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: employment_movements; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employment_movements (effective_on, seniority_from, recorded_at, company_id, decided_by, employee_id, from_classification, from_legal_entity_id, from_employment_id, from_position, movement_id, reason, reason_code, to_classification, to_legal_entity_id, to_employment_id, to_position, type) FROM stdin;
\.


--
-- Data for Name: employments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employments (engagement_id, is_primary, job_description_version, activated_at, created_at, end_date, start_date, updated_at, version, category_code, category_nature, company_id, company_unit_id, employee_id, employment_id, grade_code, job_description_id, job_family_code, job_level, job_title, position_id, reason, site_id, status, title_code, type, legal_entity_id, member_profile_id, allocation_fte, replaced_assignment_id, activity_status, inactivity_reason, closure_reason, inactivated_at, closed_at) FROM stdin;
\.


--
-- Data for Name: flyway_schema_history; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.flyway_schema_history (installed_rank, version, description, type, script, checksum, installed_by, installed_on, execution_time, success) FROM stdin;
1	1	initial schema	SQL	V1__initial_schema.sql	793919498	postgres	2026-09-14 22:11:23.819833	698	t
2	2	legal entity and member profile	SQL	V2__legal_entity_and_member_profile.sql	-2143591710	postgres	2026-09-14 22:11:24.559191	31	t
3	3	versioned company skills	SQL	V3__versioned_company_skills.sql	-126453564	postgres	2026-09-14 22:11:24.604679	144	t
\.


--
-- Data for Name: graph_build_state_entity; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.graph_build_state_entity (current_depth, started_at, updated_at, version, company_id, state_id, status, pending_unit_ids, unit_ancestors) FROM stdin;
\.


--
-- Data for Name: graph_edges; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.graph_edges (depth, created_at, effective_since, version, company_id, manager_id, priority, source, subordinate_id, type) FROM stdin;
\.


--
-- Data for Name: graph_node_ancestor_units; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.graph_node_ancestor_units (version, ancestor_unit_id, company_id, employee_id) FROM stdin;
\.


--
-- Data for Name: graph_nodes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.graph_nodes (depth, created_at, version, company_id, company_unit_id, employee_id, site_id, unit_peers, legal_entity_id) FROM stdin;
\.


--
-- Data for Name: headcount_gap_snapshots; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.headcount_gap_snapshots (company_id, snapshot_id, plan_id, plan_version_number, company_unit_id, job_description_id, target_fte, actual_fte, gap, captured_at) FROM stdin;
\.


--
-- Data for Name: job_descriptions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.job_descriptions (version, archived_at, closed_at, created_at, updated_at, validated_at, company_id, description, job_family, level, name, qualifications, responsibilities, skills, slug, status, purpose, occupational_constraints, performance_dimensions, typical_experience_months, validated_by, created_by, change_log, derived_from, review_cycle, next_review_due_at, inbound_paths, outbound_paths) FROM stdin;
\.


--
-- Data for Name: job_families; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.job_families (created_at, updated_at, description, id, localized_descriptions, localized_names, name) FROM stdin;
\.


--
-- Data for Name: job_positions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.job_positions (end_date, job_description_version, start_date, archived_at, closed_at, created_at, frozen_at, opened_at, updated_at, title, mission_summary, category_code, category_nature, company_id, company_unit_id, criticality_level, job_description_id, position_id, reports_to_position_id, site_id, status, team_context, type, working_condition, budget, desired_grade_codes, requirements, legal_entity_id, member_profile_id, allocated_fte, headcount, skills) FROM stdin;
\.


--
-- Data for Name: management_relations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.management_relations (created_at, end_date, start_date, updated_at, status, company_id, management_type, manager_id, priority, relation_id, subordinate_id) FROM stdin;
\.


--
-- Data for Name: movement_reasons; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.movement_reasons (display_order, is_standard, requires_comment, created_at, updated_at, applicable_types, code, company_id, description, label, status) FROM stdin;
\.


--
-- Data for Name: position_graph_build_states; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.position_graph_build_states (positions_processed, completed_at, graph_version, started_at, company_id, failure_reason, status) FROM stdin;
\.


--
-- Data for Name: position_graph_nodes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.position_graph_nodes (depth, occupied_employees, required_employees, subtree_occupied_employees, subtree_required_employees, created_at, graph_version, ancestors, company_id, company_unit_id, direct_reports, job_title, parent_position_id, position_id, site_id) FROM stdin;
\.


--
-- Data for Name: proficiency_scales; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.proficiency_scales (company_id, scale_id, code, type, label, labels, levels) FROM stdin;
\.


--
-- Data for Name: workforce_plans; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.workforce_plans (company_id, plan_id, company_unit_id, version_number, expected_start_date, expected_end_date, effective_start_date, effective_end_date, created_at, approved_at, status, approval_workflow_ref, targets, version) FROM stdin;
\.


--
-- Name: companies_job_families companies_job_families_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.companies_job_families
    ADD CONSTRAINT companies_job_families_pkey PRIMARY KEY (code, company_id);


--
-- Name: companies_qualifications companies_qualifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.companies_qualifications
    ADD CONSTRAINT companies_qualifications_pkey PRIMARY KEY (company_id, qualification_id);


--
-- Name: companies_skills companies_skills_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.companies_skills
    ADD CONSTRAINT companies_skills_pkey PRIMARY KEY (company_id, skill_id);


--
-- Name: company_conventions company_conventions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.company_conventions
    ADD CONSTRAINT company_conventions_pkey PRIMARY KEY (effective_from, company_id, convention_id);


--
-- Name: company_skill_relations company_skill_relations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.company_skill_relations
    ADD CONSTRAINT company_skill_relations_pkey PRIMARY KEY (company_id, skill_source, skill_target, type, effective_from);


--
-- Name: company_titles company_titles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.company_titles
    ADD CONSTRAINT company_titles_pkey PRIMARY KEY (code, company_id);


--
-- Name: convention_classifications convention_classifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.convention_classifications
    ADD CONSTRAINT convention_classifications_pkey PRIMARY KEY (category_code, convention_id, grade_code);


--
-- Name: convention_grades convention_grades_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.convention_grades
    ADD CONSTRAINT convention_grades_pkey PRIMARY KEY (code, convention_id);


--
-- Name: convention_job_categories convention_job_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.convention_job_categories
    ADD CONSTRAINT convention_job_categories_pkey PRIMARY KEY (code, convention_id);


--
-- Name: conventions conventions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conventions
    ADD CONSTRAINT conventions_pkey PRIMARY KEY (id);


--
-- Name: employee_engagements employee_engagements_company_id_employee_id_engagement_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_engagements
    ADD CONSTRAINT employee_engagements_company_id_employee_id_engagement_id_key UNIQUE (company_id, employee_id, engagement_id);


--
-- Name: employee_engagements employee_engagements_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_engagements
    ADD CONSTRAINT employee_engagements_pkey PRIMARY KEY (company_id, engagement_id);


--
-- Name: employment_movements employment_movements_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employment_movements
    ADD CONSTRAINT employment_movements_pkey PRIMARY KEY (company_id, movement_id);


--
-- Name: employments employments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employments
    ADD CONSTRAINT employments_pkey PRIMARY KEY (company_id, employment_id);


--
-- Name: flyway_schema_history flyway_schema_history_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flyway_schema_history
    ADD CONSTRAINT flyway_schema_history_pk PRIMARY KEY (installed_rank);


--
-- Name: graph_build_state_entity graph_build_state_entity_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.graph_build_state_entity
    ADD CONSTRAINT graph_build_state_entity_pkey PRIMARY KEY (company_id, state_id);


--
-- Name: graph_edges graph_edges_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.graph_edges
    ADD CONSTRAINT graph_edges_pkey PRIMARY KEY (version, company_id, manager_id, subordinate_id);


--
-- Name: graph_nodes graph_nodes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.graph_nodes
    ADD CONSTRAINT graph_nodes_pkey PRIMARY KEY (version, company_id, employee_id);


--
-- Name: headcount_gap_snapshots headcount_gap_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.headcount_gap_snapshots
    ADD CONSTRAINT headcount_gap_snapshots_pkey PRIMARY KEY (company_id, snapshot_id);


--
-- Name: graph_build_state_entity idx_graphbuildstate_version_unq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.graph_build_state_entity
    ADD CONSTRAINT idx_graphbuildstate_version_unq UNIQUE (company_id, version);


--
-- Name: job_descriptions job_descriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.job_descriptions
    ADD CONSTRAINT job_descriptions_pkey PRIMARY KEY (version, company_id, slug);


--
-- Name: job_families job_families_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.job_families
    ADD CONSTRAINT job_families_pkey PRIMARY KEY (id);


--
-- Name: job_positions job_positions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.job_positions
    ADD CONSTRAINT job_positions_pkey PRIMARY KEY (company_id, position_id);


--
-- Name: management_relations management_relations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.management_relations
    ADD CONSTRAINT management_relations_pkey PRIMARY KEY (company_id, relation_id);


--
-- Name: movement_reasons movement_reasons_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.movement_reasons
    ADD CONSTRAINT movement_reasons_pkey PRIMARY KEY (code, company_id);


--
-- Name: position_graph_build_states position_graph_build_states_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.position_graph_build_states
    ADD CONSTRAINT position_graph_build_states_pkey PRIMARY KEY (company_id);


--
-- Name: position_graph_nodes position_graph_nodes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.position_graph_nodes
    ADD CONSTRAINT position_graph_nodes_pkey PRIMARY KEY (graph_version, company_id, position_id);


--
-- Name: proficiency_scales proficiency_scales_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.proficiency_scales
    ADD CONSTRAINT proficiency_scales_pkey PRIMARY KEY (company_id, scale_id);


--
-- Name: conventions uc_collective_convention_code_version; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conventions
    ADD CONSTRAINT uc_collective_convention_code_version UNIQUE (code, country_code, version);


--
-- Name: convention_grades uc_grade_rank; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.convention_grades
    ADD CONSTRAINT uc_grade_rank UNIQUE (convention_id, rank);


--
-- Name: proficiency_scales uk_proficiency_scale_company_code; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.proficiency_scales
    ADD CONSTRAINT uk_proficiency_scale_company_code UNIQUE (company_id, code);


--
-- Name: workforce_plans workforce_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workforce_plans
    ADD CONSTRAINT workforce_plans_pkey PRIMARY KEY (company_id, plan_id, version_number);


--
-- Name: ancestor_unit_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ancestor_unit_id_idx ON public.graph_node_ancestor_units USING btree (ancestor_unit_id);


--
-- Name: flyway_schema_history_s_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX flyway_schema_history_s_idx ON public.flyway_schema_history USING btree (success);


--
-- Name: idx_classification_convention; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_classification_convention ON public.convention_classifications USING btree (convention_id);


--
-- Name: idx_collective_convention_country; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_collective_convention_country ON public.conventions USING btree (country_code);


--
-- Name: idx_company_category_convention_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_company_category_convention_id ON public.convention_job_categories USING btree (convention_id);


--
-- Name: idx_company_convention_company; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_company_convention_company ON public.company_conventions USING btree (company_id, effective_from);


--
-- Name: idx_company_convention_convention; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_company_convention_convention ON public.company_conventions USING btree (convention_id);


--
-- Name: idx_company_grad_convention_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_company_grad_convention_id ON public.convention_grades USING btree (convention_id);


--
-- Name: idx_company_qualification_code_version; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_company_qualification_code_version ON public.companies_qualifications USING btree (company_id, code, version DESC);


--
-- Name: idx_company_qualification_company_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_company_qualification_company_id ON public.companies_qualifications USING btree (company_id);


--
-- Name: idx_company_skill_code_version; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_company_skill_code_version ON public.companies_skills USING btree (company_id, code, version DESC);


--
-- Name: idx_company_skill_company_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_company_skill_company_id ON public.companies_skills USING btree (company_id);


--
-- Name: idx_company_skill_relations_source; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_company_skill_relations_source ON public.company_skill_relations USING btree (company_id, skill_source);


--
-- Name: idx_company_skill_relations_target; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_company_skill_relations_target ON public.company_skill_relations USING btree (company_id, skill_target);


--
-- Name: idx_company_title_company; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_company_title_company ON public.company_titles USING btree (company_id);


--
-- Name: idx_company_title_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_company_title_status ON public.company_titles USING btree (company_id, status);


--
-- Name: idx_employment_employee; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_employment_employee ON public.employments USING btree (company_id, employee_id);


--
-- Name: idx_employment_engagement; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_employment_engagement ON public.employments USING btree (company_id, engagement_id);


--
-- Name: idx_employment_legal_entity; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_employment_legal_entity ON public.employments USING btree (company_id, legal_entity_id);


--
-- Name: idx_employment_position; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_employment_position ON public.employments USING btree (company_id, position_id);


--
-- Name: idx_employment_search_classification; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_employment_search_classification ON public.employments USING btree (company_id, grade_code, category_code, title_code);


--
-- Name: idx_employment_search_dates; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_employment_search_dates ON public.employments USING btree (company_id, start_date, end_date);


--
-- Name: idx_employment_search_primary; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_employment_search_primary ON public.employments USING btree (company_id, is_primary, status);


--
-- Name: idx_employment_site; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_employment_site ON public.employments USING btree (company_id, site_id);


--
-- Name: idx_employment_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_employment_status ON public.employments USING btree (company_id, status);


--
-- Name: idx_employment_unit; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_employment_unit ON public.employments USING btree (company_id, company_unit_id);


--
-- Name: idx_engagement_employee; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_engagement_employee ON public.employee_engagements USING btree (company_id, employee_id, entry_date);


--
-- Name: idx_graph_node_legal_entity; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_graph_node_legal_entity ON public.graph_nodes USING btree (company_id, version, legal_entity_id);


--
-- Name: idx_graph_node_site; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_graph_node_site ON public.graph_nodes USING btree (company_id, version, site_id);


--
-- Name: idx_graph_node_unit; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_graph_node_unit ON public.graph_nodes USING btree (company_id, version, company_unit_id);


--
-- Name: idx_headcount_gap_snapshot_plan; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_headcount_gap_snapshot_plan ON public.headcount_gap_snapshots USING btree (company_id, plan_id, captured_at DESC);


--
-- Name: idx_headcount_gap_snapshot_unit_job; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_headcount_gap_snapshot_unit_job ON public.headcount_gap_snapshots USING btree (company_unit_id, job_description_id, captured_at);


--
-- Name: idx_job_description_company; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_job_description_company ON public.job_descriptions USING btree (company_id);


--
-- Name: idx_job_description_family; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_job_description_family ON public.job_descriptions USING btree (job_family);


--
-- Name: idx_job_description_next_review; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_job_description_next_review ON public.job_descriptions USING btree (company_id, next_review_due_at) WHERE ((status)::text = 'VALIDATED'::text);


--
-- Name: idx_job_position_company; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_job_position_company ON public.job_positions USING btree (company_id);


--
-- Name: idx_job_position_company_unit; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_job_position_company_unit ON public.job_positions USING btree (company_unit_id);


--
-- Name: idx_job_position_description; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_job_position_description ON public.job_positions USING btree (job_description_id);


--
-- Name: idx_job_position_legal_entity; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_job_position_legal_entity ON public.job_positions USING btree (company_id, legal_entity_id);


--
-- Name: idx_job_position_reports_to; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_job_position_reports_to ON public.job_positions USING btree (company_id, reports_to_position_id);


--
-- Name: idx_jobdesc_skills_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_jobdesc_skills_gin ON public.job_descriptions USING gin (skills jsonb_path_ops);


--
-- Name: idx_mgmt_rel_active_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_mgmt_rel_active_date ON public.management_relations USING btree (company_id, status, start_date, end_date);


--
-- Name: idx_mgmt_rel_manager; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_mgmt_rel_manager ON public.management_relations USING btree (company_id, manager_id, status);


--
-- Name: idx_movement_employee; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_movement_employee ON public.employment_movements USING btree (company_id, employee_id, effective_on);


--
-- Name: idx_movement_employment_from; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_movement_employment_from ON public.employment_movements USING btree (company_id, from_employment_id);


--
-- Name: idx_movement_employment_to; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_movement_employment_to ON public.employment_movements USING btree (company_id, to_employment_id);


--
-- Name: idx_movement_reason_code; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_movement_reason_code ON public.employment_movements USING btree (company_id, reason_code);


--
-- Name: idx_movement_reason_company; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_movement_reason_company ON public.movement_reasons USING btree (company_id);


--
-- Name: idx_movement_reason_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_movement_reason_status ON public.movement_reasons USING btree (company_id, status);


--
-- Name: idx_movement_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_movement_type ON public.employment_movements USING btree (company_id, type);


--
-- Name: idx_position_node_depth; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_position_node_depth ON public.position_graph_nodes USING btree (company_id, graph_version, depth);


--
-- Name: idx_position_node_parent; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_position_node_parent ON public.position_graph_nodes USING btree (company_id, graph_version, parent_position_id);


--
-- Name: idx_position_node_version; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_position_node_version ON public.position_graph_nodes USING btree (company_id, graph_version);


--
-- Name: idx_proficiency_scale_company; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_proficiency_scale_company ON public.proficiency_scales USING btree (company_id);


--
-- Name: idx_workforce_plan_company_unit; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_workforce_plan_company_unit ON public.workforce_plans USING btree (company_id, company_unit_id);


--
-- Name: idx_workforce_plan_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_workforce_plan_status ON public.workforce_plans USING btree (company_id, status);


--
-- Name: uq_company_qualification_code_version; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX uq_company_qualification_code_version ON public.companies_qualifications USING btree (company_id, code, version);


--
-- Name: uq_company_skill_code_version; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX uq_company_skill_code_version ON public.companies_skills USING btree (company_id, code, version);


--
-- Name: uq_employee_open_engagement; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX uq_employee_open_engagement ON public.employee_engagements USING btree (company_id, employee_id) WHERE (exit_date IS NULL);


--
-- Name: uq_employment_open_position_employee; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX uq_employment_open_position_employee ON public.employments USING btree (company_id, employee_id, position_id) WHERE ((status)::text = ANY ((ARRAY['PLANNED'::character varying, 'ACTIVE'::character varying, 'SUSPENDED'::character varying])::text[]));


--
-- Name: uq_employment_open_primary; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX uq_employment_open_primary ON public.employments USING btree (company_id, employee_id) WHERE (is_primary AND ((status)::text = ANY ((ARRAY['PLANNED'::character varying, 'ACTIVE'::character varying, 'SUSPENDED'::character varying])::text[])));


--
-- Name: employments fk_employment_engagement; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employments
    ADD CONSTRAINT fk_employment_engagement FOREIGN KEY (company_id, employee_id, engagement_id) REFERENCES public.employee_engagements(company_id, employee_id, engagement_id);


--
-- Name: graph_node_ancestor_units fkhduy9oqjcrib8xqico0aagk67; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.graph_node_ancestor_units
    ADD CONSTRAINT fkhduy9oqjcrib8xqico0aagk67 FOREIGN KEY (version, company_id, employee_id) REFERENCES public.graph_nodes(version, company_id, employee_id);


--
-- PostgreSQL database dump complete
--

\unrestrict JTjXbFIZQBLr9OjtKLE0kqWiEkSNY3vyIF0XyFrAR1AOf8bFUC5cr7FzCmXhE0J

