# Export des bases Fluxoon locales → scripts SQL rejouables

`export_migration.py` lit **toutes les tables** des bases Fluxoon locales et produit, pour chaque base, un fichier SQL
qui, exécuté sur une autre base **de même schéma**, y fait réapparaître exactement les mêmes lignes.

Bases exportées par défaut, dans cet ordre (chronologie des ETL) :

| Fichier produit | Base locale | Contenu |
| --- | --- | --- |
| `01_employee_fluxoon_employee.sql` | fluxoon_employee | formats de matricule, salariés, identités, comptes, parcours, affiliations… |
| `02_employment_fluxoon_employment.sql` | fluxoon_employment | conventions, postes, engagements, emplois, mouvements, graphes… |
| `03_career_fluxoon_carriere.sql` | fluxoon_carrière | sanctions, formations, entretiens, objectifs… |
| `04_compensation_fluxoon_compensation.sql` | fluxoon_compensation | catalogue, packages, droits, avantages… |

Le nom `fluxoon_carrière` est aussi trouvé s'il s'écrit sans accent (`fluxoon_carriere`) ou `fluxoon_career`.

## 1. Préparer l'environnement (une seule fois)

Python 3.10 ou plus récent. Un environnement virtuel isole la bibliothèque PostgreSQL du reste du poste.

**Windows (PowerShell)**, dans le dossier du script :

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
# si PowerShell refuse l'activation : Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass  puis relancer la ligne précédente
python -m pip install --upgrade pip
pip install -r requirements.txt
```

**Linux / macOS** :

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

Les fois suivantes, il suffit de réactiver l'environnement (`.\.venv\Scripts\Activate.ps1` ou `source .venv/bin/activate`).

## 2. Lancer l'export

```powershell
python export_migration.py --host localhost --port 5432 --user postgres --password 'motdepasse' --out .\export
```

- Sans `--password`, le mot de passe est demandé au clavier (ou lu dans la variable `PGPASSWORD`).
- `--list-dbs` affiche les bases du serveur (utile pour vérifier les noms).
- Autres noms de bases, ou bases supplémentaires (organisation, authentification…) : répéter `--db LIBELLE=NOM`
  dans l'ordre de rejeu voulu, par exemple
  `--db employee=fluxoon_employee --db employment=fluxoon_employment --db career=fluxoon_carriere --db compensation=fluxoon_compensation --db organization=fluxoon_organization`.
- `--company <id>` : n'exporter qu'une entreprise (tables ayant une colonne company_id ; les autres sont exportées en entier).
- `--exclude <table>` : ne pas exporter une table (répétable).

Le dossier de sortie contient un fichier SQL par base et `MANIFEST.txt` (lignes par table, empreinte SHA-256 de chaque fichier,
points d'attention).

**Erreur `UnicodeDecodeError: 'utf-8' codec can't decode byte 0xe9`** (ancienne version du script) : le serveur PostgreSQL
Windows répondait en français (« la base de données … n'existe pas », « authentification par mot de passe échouée »)
et psycopg2 ne savait pas décoder le message. Le script affiche désormais le vrai message et la piste à suivre.
Dans votre cas, la cause était presque sûrement le nom des bases : l'ancienne version cherchait `employee_db`, `employment_db`…

## 3. Rejouer sur la base cible

Sur le serveur cible, après **sauvegarde** des bases, dans l'ordre des numéros :

```bash
psql -v ON_ERROR_STOP=1 -d <base_employee_cible>     -f 01_employee_fluxoon_employee.sql
psql -v ON_ERROR_STOP=1 -d <base_employment_cible>   -f 02_employment_fluxoon_employment.sql
psql -v ON_ERROR_STOP=1 -d <base_career_cible>       -f 03_career_fluxoon_carriere.sql
psql -v ON_ERROR_STOP=1 -d <base_compensation_cible> -f 04_compensation_fluxoon_compensation.sql
```

Structure de chaque fichier :

1. **Garde-fou de schéma** : compare l'historique Flyway de la base cible à celui de la base source ; s'il diffère
   (migration en plus, en moins ou modifiée), arrêt immédiat, rien n'est écrit.
2. Table de contrôle temporaire.
3. **Données, table par table**, parents avant enfants (ordre calculé sur les clés étrangères, puis chronologie des ETL) ;
   dans une table qui se référence elle-même (`previous_version_id`, `successor_id`…), la ligne parente passe avant l'enfant.
   - table avec clé primaire : `INSERT … ON CONFLICT (clé) DO UPDATE` (la ligne de la cible prend les valeurs de la source) ;
   - table sans clé primaire (collections : notes d'incident, membres de jury, ancêtres de graphe) : les lignes des parents
     exportés sont supprimées puis réinsérées à l'identique.
4. **Séquences** : portées au moins à la valeur de la source, jamais reculées.
5. **Contrôle bloquant** : chaque lot a compté les lignes réellement écrites ; au moindre écart, toute la transaction est annulée.
6. `COMMIT`, puis un rapport « lignes en base / lignes exportées » à renvoyer à DHI.

Le fichier est une seule transaction : en cas d'erreur, rien n'est modifié ; corriger puis relancer. Un second passage
donne exactement le même résultat (testé : deux rejeux successifs sur des bases vides de même schéma redonnent des
données identiques à la source, séquences comprises).

## 4. Ce que le script garantit, et ses limites

- **Garanti** : toutes les lignes de toutes les tables des bases exportées (hors `flyway_schema_history`) se retrouvent
  dans la cible avec les mêmes valeurs (texte, dates, montants, JSON, tableaux), dans un ordre qui respecte les clés étrangères.
- **Lignes déjà présentes dans la cible et absentes de la source** : conservées (le script ajoute et met à jour, il ne
  supprime pas, sauf dans les collections sans clé primaire des parents exportés).
- **Même donnée métier sous un autre identifiant dans la cible** (ex. un poste recréé à la main avec le même code) :
  la contrainte d'unicité de la cible arrête le script et indique la ligne en cause ; la transaction est annulée.
- **Références entre bases** (poste → unité et site de l'organisation, salarié → utilisateur) : ce ne sont pas des clés
  étrangères PostgreSQL. Les bases organisation et authentification de la cible doivent contenir les mêmes données
  (seeders 01 et 02), ou être exportées aussi avec `--db`.
- **compensation_events** : journal d'événements. Faire confirmer par l'éditeur qu'aucun service ne relit et republie ces
  lignes après rejeu ; sinon l'exclure avec `--exclude compensation_events`.

## 5. Protection des données

Les fichiers contiennent des données personnelles et sensibles (identité, pièces, comptes bancaires, salaires, sanctions).
Les transmettre chiffrés (archive protégée par un mot de passe communiqué par un autre canal, ou espace de dépôt sécurisé),
vérifier les empreintes SHA-256 du MANIFEST à réception, puis supprimer les copies intermédiaires.
