#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Export intégral des bases Fluxoon LOCALES en scripts SQL rejouables (un fichier par base).

Le script lit TOUTES les tables de chaque base (sauf l'historique Flyway, qui sert seulement de garde-fou),
les range dans un ordre compatible avec les clés étrangères (parents avant enfants, puis chronologie des ETL),
et écrit pour chaque base un fichier SQL qui, rejoué sur une base de même schéma, y fait réapparaître
exactement les mêmes lignes.

Garanties du fichier produit :
- une seule transaction : tout passe ou rien ne change ;
- rejouable : clé primaire -> INSERT ... ON CONFLICT DO UPDATE ; table sans clé primaire (collection) ->
  les lignes des parents exportés sont remplacées ; deux passages donnent le même résultat ;
- vérifié : chaque lot compte les lignes réellement écrites ; un écart annule toute la transaction ;
- garde-fou de schéma : si l'historique Flyway de la base cible diffère de celui de la base source, arrêt immédiat ;
- séquences et colonnes d'identité recalées (jamais reculées).

Usage : voir README.md
  python export_migration.py --password xxx
  python export_migration.py --host localhost --port 5432 --user postgres --password xxx --out ./export ^
      --db employee=fluxoon_employee --db employment=fluxoon_employment ^
      --db career=fluxoon_carriere --db compensation=fluxoon_compensation
"""
import argparse, datetime, getpass, hashlib, json, os, secrets, sys, unicodedata
from collections import defaultdict

try:
    import psycopg2
except ImportError:
    sys.exit("psycopg2 n'est pas installé : activez l'environnement virtuel puis  pip install -r requirements.txt")

BATCH = 500
SYSTEM_SCHEMAS = ('pg_catalog', 'information_schema', 'pg_toast')
EXCLUDED_ALWAYS = {'flyway_schema_history'}   # métadonnées de schéma : propres à chaque base, servent au garde-fou

# Bases par défaut (libellé -> nom de la base locale), dans l'ordre de chronologie des ETL
DEFAULT_DBS = [('employee', 'fluxoon_employee'), ('employment', 'fluxoon_employment'),
               ('career', 'fluxoon_carrière'), ('compensation', 'fluxoon_compensation')]

# Chronologie des ETL et des seeders : départage les tables quand les clés étrangères laissent le choix.
# Une table absente de ces listes vient après, par ordre alphabétique ; les clés étrangères priment toujours.
CHRONO = {
    'employee': ['registration_number_formats', 'registration_number_sequences', 'employee_profile_schemas',
                 'employees', 'registration_number_assignments', 'employee_identities', 'secondary_identifiers',
                 'dependents', 'employee_payment_accounts', 'employee_career_records', 'employee_affiliations',
                 'employee_scheme_classifications', 'resource_categories', 'resources', 'resource_assignments',
                 'resource_maintenance_records'],
    'employment': ['conventions', 'convention_job_categories', 'convention_grades', 'convention_classifications',
                   'legal_entity_conventions', 'classification_policies', 'contract_policies', 'company_titles',
                   'movement_types', 'movement_reasons', 'job_families', 'companies_job_families',
                   'proficiency_scales', 'companies_skills', 'company_skill_relations', 'companies_qualifications',
                   'job_descriptions', 'job_positions', 'workforce_plans', 'headcount_gap_snapshots',
                   'employee_engagements', 'employments', 'employment_movements', 'management_relations',
                   'position_graph_build_states', 'position_graph_nodes', 'graph_build_state_entity',
                   'graph_nodes', 'graph_node_ancestor_units', 'graph_edges', 'graph_violations'],
    'career': ['incident_action_types', 'interview_types', 'performance_scoring_policies',
               'recruitment_workflow_templates', 'onboarding_flows', 'career_incidents', 'incident_members',
               'incident_actions', 'incident_notes', 'trainings', 'training_sessions', 'training_participants',
               'training_requests', 'training_request_audiences', 'interview_templates', 'interview_campaigns',
               'interviews', 'interview_panel_members', 'employee_objectives', 'objective_key_results',
               'interview_objectives', 'interviews_reviewed_objectives'],
    'compensation': ['compensation_catalog', 'remuneration_element', 'input_definition', 'benefit_asset_kind',
                     'proration_policies', 'remuneration_rule', 'input_rule', 'benefit_asset_rule',
                     'compensation_packages', 'eligibility_policy', 'incentive_plans',
                     'employee_package_assignment', 'compensation_requirement', 'employee_incentive_assignments',
                     'compensation_awards', 'employee_compensations', 'employee_benefit_assignments',
                     'employee_parameter_assignments', 'employee_compensation_suspensions', 'kpi_measurements',
                     'resolution_reminder_schedules', 'resolution_alerts', 'compensation_events'],
}
# Tables à signaler à l'éditeur avant rejeu (journal d'événements susceptible d'être relu par d'autres services)
WATCH = {'compensation_events': "journal d'événements : faire confirmer par l'éditeur qu'aucun service ne republie ces lignes"}


# ---------------------------------------------------------------------------------------------- connexion
def _readable(err):
    """Message d'erreur PostgreSQL lisible même quand le serveur répond en Windows-1252 (serveur Windows en français)."""
    if isinstance(err, UnicodeDecodeError):
        raw = err.object if isinstance(err.object, (bytes, bytearray)) else b''
        for enc in ('cp1252', 'latin-1'):
            try:
                return raw.decode(enc).strip()
            except Exception:
                pass
    return str(err).strip()


def connect(a, dbname):
    try:
        conn = psycopg2.connect(host=a.host, port=a.port, user=a.user, password=a.password, dbname=dbname,
                                client_encoding='UTF8', connect_timeout=15)
    except (psycopg2.Error, UnicodeDecodeError) as e:
        msg = _readable(e)
        low = msg.lower()
        hint = ''
        if 'password' in low or 'mot de passe' in low:
            hint = "\n  -> Mot de passe refusé : vérifier --password (dans PowerShell, l'écrire entre apostrophes)."
        elif 'does not exist' in low or "n'existe pas" in low:
            hint = "\n  -> Base introuvable : vérifier le nom avec --db (liste des bases : option --list-dbs)."
        elif 'refused' in low or 'refus' in low or 'timeout' in low:
            hint = "\n  -> Serveur injoignable : vérifier --host / --port et que le service PostgreSQL est démarré."
        sys.exit(f"Connexion impossible à la base « {dbname} » ({a.host}:{a.port}, utilisateur {a.user}) :\n  {msg}{hint}")
    conn.set_session(isolation_level='REPEATABLE READ', readonly=True, autocommit=False)
    with conn.cursor() as c:
        c.execute("SET TIME ZONE 'UTC'; SET IntervalStyle = 'postgres'; SET extra_float_digits = 3; SET DateStyle = 'ISO, YMD'")
    return conn


def _fold(s):
    s = unicodedata.normalize('NFKD', s.lower())
    return ''.join(ch for ch in s if not unicodedata.combining(ch))


def resolve_db_names(a, wanted):
    """Vérifie que chaque base existe ; tolère un accent ou la variante career/carriere."""
    conn = connect(a, a.maintenance_db)
    with conn.cursor() as c:
        c.execute("select datname from pg_database where not datistemplate")
        existing = [r[0] for r in c.fetchall()]
    conn.close()
    resolved = []
    for label, name in wanted:
        if name in existing:
            resolved.append((label, name)); continue
        cands = [d for d in existing if _fold(d) == _fold(name)]
        if not cands and label == 'career':
            cands = [d for d in existing if _fold(d) in ('fluxoon_career', 'fluxoon_carriere')]
        if len(cands) == 1:
            print(f"  base « {name} » introuvable, utilisation de « {cands[0]} »")
            resolved.append((label, cands[0])); continue
        sys.exit(f"Base « {name} » introuvable. Bases présentes : {', '.join(sorted(existing))}\n"
                 f"  -> préciser le nom exact avec --db {label}=<nom>")
    return resolved


# ---------------------------------------------------------------------------------------------- catalogue
def qi(name):
    return '"' + name.replace('"', '""') + '"'


def load_catalog(conn):
    cur = conn.cursor()
    cur.execute("""
        select c.oid, n.nspname, c.relname
        from pg_class c join pg_namespace n on n.oid = c.relnamespace
        where c.relkind in ('r', 'p') and not c.relispartition
          and n.nspname not in %s and n.nspname not like 'pg_temp%%' and n.nspname not like 'pg_toast%%'
        order by n.nspname, c.relname""", (SYSTEM_SCHEMAS,))
    tables = {r[0]: {'oid': r[0], 'schema': r[1], 'name': r[2]} for r in cur.fetchall()}
    for oid, t in tables.items():
        cur.execute("""select a.attname, a.attgenerated, a.attidentity
                       from pg_attribute a where a.attrelid = %s and a.attnum > 0 and not a.attisdropped
                       order by a.attnum""", (oid,))
        cols = cur.fetchall()
        t['all_cols'] = [c[0] for c in cols]
        t['cols'] = [c[0] for c in cols if c[1] == '']             # colonnes générées : recalculées par la cible
        t['identity_always'] = any(c[2] == 'a' for c in cols)
        cur.execute("""select array(select a.attname from unnest(con.conkey) with ordinality k(n, o)
                                    join pg_attribute a on a.attrelid = con.conrelid and a.attnum = k.n order by k.o)
                       from pg_constraint con where con.conrelid = %s and con.contype = 'p'""", (oid,))
        r = cur.fetchone()
        t['pk'] = list(r[0]) if r else []
        t['fks'] = []
    cur.execute("""
        select con.conrelid, con.confrelid,
               array(select a.attname from unnest(con.conkey) with ordinality k(n, o)
                     join pg_attribute a on a.attrelid = con.conrelid and a.attnum = k.n order by k.o),
               array(select a.attname from unnest(con.confkey) with ordinality k(n, o)
                     join pg_attribute a on a.attrelid = con.confrelid and a.attnum = k.n order by k.o)
        from pg_constraint con where con.contype = 'f' order by con.conname""")
    for child, parent, ccols, pcols in cur.fetchall():
        if child in tables and parent in tables:
            tables[child]['fks'].append({'parent': parent, 'cols': list(ccols), 'ref': list(pcols)})
    cur.execute("""select schemaname, sequencename, last_value from pg_sequences
                   where schemaname not in %s order by 1, 2""", (SYSTEM_SCHEMAS,))
    seqs = cur.fetchall()
    flyway = None
    for t in tables.values():
        if t['name'] == 'flyway_schema_history':
            cur.execute(f"select version, coalesce(checksum, 0) from {qi(t['schema'])}.flyway_schema_history "
                        "where success and version is not null order by installed_rank")
            flyway = (t['schema'], cur.fetchall())
    cur.close()
    return tables, seqs, flyway


def order_tables(tables, label, excluded):
    """Tri topologique par clés étrangères (parents d'abord) ; à égalité, chronologie des ETL puis ordre alphabétique."""
    prio = {n: i for i, n in enumerate(CHRONO.get(label, []))}
    keep = {oid for oid, t in tables.items() if t['name'] not in excluded}
    deps = {oid: {fk['parent'] for fk in tables[oid]['fks'] if fk['parent'] != oid and fk['parent'] in keep}
            for oid in keep}
    rank = lambda oid: (prio.get(tables[oid]['name'], 10_000), tables[oid]['schema'], tables[oid]['name'])
    done, order, cycles = set(), [], []
    while len(done) < len(keep):
        ready = sorted((o for o in keep - done if deps[o] <= done), key=rank)
        if not ready:   # cycle entre tables : on le casse au plus prioritaire et on le signale
            o = sorted(keep - done, key=rank)[0]
            cycles.append(tables[o]['name']); ready = [o]
        done.add(ready[0]); order.append(ready[0])
    return order, cycles


def sort_self_referencing(rows, t, oid):
    """Table qui se référence elle-même (ex. previous_version_id) : la ligne parente est écrite avant l'enfant.
    rows = liste de (dict décodé, texte JSON d'origine). Retourne (lignes triées, nombre de cycles cassés)."""
    self_fks = [fk for fk in t['fks'] if fk['parent'] == oid]
    if not self_fks or len(rows) < 2:
        return rows, 0
    index = {}
    for i, (r, _) in enumerate(rows):
        for fk in self_fks:
            index[(tuple(fk['ref']), tuple(r.get(c) for c in fk['ref']))] = i
    deps = defaultdict(set)
    for i, (r, _) in enumerate(rows):
        for fk in self_fks:
            key = tuple(r.get(c) for c in fk['cols'])
            if all(v is None for v in key):
                continue
            j = index.get((tuple(fk['ref']), key))
            if j is not None and j != i:
                deps[i].add(j)
    out, placed, broken, pending = [], set(), 0, list(range(len(rows)))
    while pending:
        nxt = [i for i in pending if deps[i] <= placed]
        if not nxt:
            nxt = [pending[0]]; broken += 1
        placed.update(nxt); out.extend(nxt)
        s = set(nxt)
        pending = [i for i in pending if i not in s]
    return [rows[i] for i in out], broken


# ---------------------------------------------------------------------------------------------- écriture
def dollar_tag(text):
    tag = '$cca$'
    while tag in text:
        tag = f'$cca{secrets.token_hex(3)}$'
    return tag


def lit(s):
    return "'" + s.replace("'", "''") + "'"


def write_db(a, label, dbname, idx, stamp):
    conn = connect(a, dbname)
    tables, seqs, flyway = load_catalog(conn)
    excluded = EXCLUDED_ALWAYS | set(a.exclude)
    order, cycles = order_tables(tables, label, excluded)
    fname = os.path.join(a.out, f"{idx:02d}_{label}_{_fold(dbname).replace(' ', '_')}.sql")
    stats, warnings = [], []
    if cycles:
        warnings.append(f"cycle de clés étrangères entre tables autour de : {', '.join(cycles)}")
    cur = conn.cursor()
    with open(fname, 'w', encoding='utf-8', newline='\n') as f:
        w = f.write
        w("-- ============================================================================\n"
          f"-- Données Fluxoon : base « {dbname} » ({label})\n"
          f"-- Généré le {stamp} par export_migration.py depuis {a.host}:{a.port}/{dbname}\n"
          + (f"-- Périmètre : entreprise {a.company}\n" if a.company else "-- Périmètre : toutes les lignes de toutes les tables\n") +
          "-- Exécution sur la base cible (même schéma) :\n"
          f"--   psql -v ON_ERROR_STOP=1 -d <base_cible> -f {os.path.basename(fname)}\n"
          "-- Une seule transaction ; rejouable ; annulation complète au moindre écart.\n"
          "-- ============================================================================\n"
          "SET client_encoding = 'UTF8';\nSET client_min_messages = warning;\nSET TIME ZONE 'UTC';\n"
          "SET IntervalStyle = 'postgres';\nSET DateStyle = 'ISO, YMD';\nSET statement_timeout = 0;\n"
          "SET lock_timeout = '60s';\n\nBEGIN;\n\n")

        # 1. garde-fou de schéma
        if flyway and not a.no_schema_guard:
            schema, hist = flyway
            src = lit(json.dumps([[v, c] for v, c in hist]))
            tgt = (f"SELECT version, coalesce(checksum, 0) AS checksum FROM {qi(schema)}.flyway_schema_history "
                   "WHERE success AND version IS NOT NULL")
            srcq = f"SELECT x->>0 AS version, (x->>1)::int AS checksum FROM jsonb_array_elements({src}::jsonb) x"
            w("-- 1. Garde-fou : la base cible doit avoir exactement les mêmes migrations Flyway que la source\n"
              "DO $guard$\nDECLARE manquantes text; en_trop text;\nBEGIN\n"
              f"  SELECT string_agg(version, ', ') INTO manquantes FROM ({srcq} EXCEPT {tgt}) d;\n"
              f"  SELECT string_agg(version, ', ') INTO en_trop FROM ({tgt} EXCEPT {srcq}) d;\n"
              "  IF manquantes IS NOT NULL OR en_trop IS NOT NULL THEN\n"
              f"    RAISE EXCEPTION 'Schéma de la base cible différent de la source {dbname} : migrations absentes de la cible [%], "
              "migrations en plus ou modifiées dans la cible [%]', coalesce(manquantes, '-'), coalesce(en_trop, '-');\n"
              "  END IF;\nEND $guard$;\n\n")
        elif not flyway:
            warnings.append("pas d'historique Flyway : garde-fou de schéma absent")

        w("-- 2. Contrôle d'écriture : chaque lot note le nombre de lignes attendu et réellement écrit\n"
          "CREATE TEMP TABLE _cca_controle (table_name text, attendu int, ecrit int) ON COMMIT DROP;\n\n"
          "-- 3. Données, parents avant enfants\n")

        for n, oid in enumerate(order, 1):
            t = tables[oid]
            full = f"{qi(t['schema'])}.{qi(t['name'])}"
            where, args = '', []
            if a.company and 'company_id' in t['all_cols']:
                where, args = 'where t.company_id = %s', [a.company]
            order_cols = (['created_at'] if 'created_at' in t['all_cols'] else []) + (t['pk'] or t['cols'])
            cur.execute(f"select row_to_json(t)::text from {full} t {where} order by "
                        + ', '.join('t.' + qi(c) for c in order_cols), args)
            rows = [(json.loads(r[0]), r[0]) for r in cur.fetchall()]
            rows, broken = sort_self_referencing(rows, t, oid)
            if broken:
                warnings.append(f"{t['name']} : références circulaires entre lignes ({broken})")
            raw = [r for _, r in rows]

            kind = 'clé primaire ' + ', '.join(t['pk']) if t['pk'] else 'sans clé primaire'
            w(f"\n-- 3.{n} {full} : {len(raw)} ligne(s) ({kind})"
              + (f"\n--   ATTENTION : {WATCH[t['name']]}" if t['name'] in WATCH else '') + "\n")
            if t['name'] in WATCH and raw:
                warnings.append(f"{t['name']} : {WATCH[t['name']]}")
            stats.append((t['schema'], t['name'], len(raw), bool(t['pk']), 'company_id' in t['all_cols']))
            if not raw:
                continue
            cols = t['cols']
            collist = ', '.join(qi(c) for c in cols)
            overriding = ' OVERRIDING SYSTEM VALUE' if t['identity_always'] else ''

            if not t['pk']:
                fk = t['fks'][0] if t['fks'] else None
                if fk:
                    # Collection rattachée à un parent : les lignes des parents exportés sont remplacées à l'identique
                    keys = sorted({json.dumps([r.get(c) for c in fk['cols']], ensure_ascii=False) for r, _ in rows})
                    body = '[' + ','.join(keys) + ']'
                    tag = dollar_tag(body)
                    cond = ' AND '.join(f"t.{qi(c)}::text IS NOT DISTINCT FROM (k->>{i})" for i, c in enumerate(fk['cols']))
                    w(f"DELETE FROM {full} t USING jsonb_array_elements({tag}{body}{tag}::jsonb) k WHERE {cond};\n")
                for s in range(0, len(raw), BATCH):
                    chunk = raw[s:s + BATCH]
                    body = '[\n' + ',\n'.join(chunk) + '\n]'
                    tag = dollar_tag(body)
                    src = f"json_populate_recordset(NULL::{full}, {tag}{body}{tag}::json)"
                    if fk:
                        w(f"WITH ins AS (\n  INSERT INTO {full} ({collist}){overriding}\n  SELECT {collist} FROM {src}\n  RETURNING 1)\n"
                          f"INSERT INTO _cca_controle SELECT {lit(t['name'])}, {len(chunk)}, count(*) FROM ins;\n")
                    else:
                        # Sans parent : on n'ajoute que les lignes absentes à l'identique
                        same = ' AND '.join(f"x.{qi(c)}::text IS NOT DISTINCT FROM s.{qi(c)}::text" for c in cols)
                        w(f"WITH s AS (SELECT {collist} FROM {src}),\n"
                          f"ins AS (\n  INSERT INTO {full} ({collist}){overriding}\n"
                          f"  SELECT {collist} FROM s WHERE NOT EXISTS (SELECT 1 FROM {full} x WHERE {same})\n  RETURNING 1)\n"
                          f"INSERT INTO _cca_controle SELECT {lit(t['name'])}, {len(chunk)}, "
                          f"(SELECT count(*) FROM s WHERE EXISTS (SELECT 1 FROM {full} x WHERE {same})) + (SELECT count(*) FROM ins);\n")
                continue

            pk = t['pk']
            upd = [c for c in cols if c not in pk]
            set_clause = ', '.join(f"{qi(c)} = EXCLUDED.{qi(c)}" for c in upd) if upd \
                else f"{qi(pk[0])} = EXCLUDED.{qi(pk[0])}"
            for s in range(0, len(raw), BATCH):
                chunk = raw[s:s + BATCH]
                body = '[\n' + ',\n'.join(chunk) + '\n]'
                tag = dollar_tag(body)
                w(f"WITH ins AS (\n  INSERT INTO {full} ({collist}){overriding}\n"
                  f"  SELECT {collist} FROM json_populate_recordset(NULL::{full}, {tag}{body}{tag}::json)\n"
                  f"  ON CONFLICT ({', '.join(qi(c) for c in pk)}) DO UPDATE SET {set_clause}\n  RETURNING 1)\n"
                  f"INSERT INTO _cca_controle SELECT {lit(t['name'])}, {len(chunk)}, count(*) FROM ins;\n")

        # 4. séquences
        live = [(s, nm, v) for s, nm, v in seqs if v is not None]
        if live:
            w("\n-- 4. Séquences : portées au moins à la valeur de la source (jamais reculées)\n")
            for s, nm, v in live:
                fq = f"{qi(s)}.{qi(nm)}"
                w(f"SELECT setval({lit(fq)}, greatest((SELECT last_value FROM {fq}), {v}), true);\n")

        # 5. contrôle bloquant
        w("\n-- 5. Contrôle bloquant : toute ligne exportée doit avoir été écrite, sinon tout est annulé\n"
          "DO $ctrl$\nDECLARE r record;\nBEGIN\n"
          "  FOR r IN SELECT table_name, sum(attendu) AS a, sum(ecrit) AS e FROM _cca_controle\n"
          "           GROUP BY 1 HAVING sum(attendu) <> sum(ecrit) LOOP\n"
          "    RAISE EXCEPTION 'Table % : % ligne(s) attendue(s), % écrite(s). Transaction annulée.', r.table_name, r.a, r.e;\n"
          "  END LOOP;\nEND $ctrl$;\n\nCOMMIT;\n\n")

        # 6. rapport
        w("-- 6. Rapport (après validation) : lignes présentes dans la base cible / lignes exportées\n")
        parts = []
        for sch, name, nb, _, has_company in stats:
            cond = f" WHERE company_id = {lit(a.company)}" if a.company and has_company else ''
            parts.append(f"SELECT {lit(name)} AS table_name, (SELECT count(*) FROM {qi(sch)}.{qi(name)}{cond}) AS en_base, {nb} AS exportees")
        if parts:
            w('\nUNION ALL '.join(parts) + ';\n')
    cur.close()
    conn.close()
    sha = hashlib.sha256(open(fname, 'rb').read()).hexdigest()
    skipped = sorted(t['name'] for t in tables.values() if t['name'] in excluded)
    return fname, stats, sha, skipped, warnings


def main():
    ap = argparse.ArgumentParser(description="Export des bases Fluxoon locales en scripts SQL rejouables")
    ap.add_argument('--host', default=os.environ.get('PGHOST', 'localhost'))
    ap.add_argument('--port', default=os.environ.get('PGPORT', '5432'))
    ap.add_argument('--user', default=os.environ.get('PGUSER', 'postgres'))
    ap.add_argument('--password', default=os.environ.get('PGPASSWORD'),
                    help="mot de passe (sinon variable PGPASSWORD, sinon demandé au clavier)")
    ap.add_argument('--out', default='./export')
    ap.add_argument('--db', action='append', default=[], metavar='LIBELLE=NOM',
                    help="base à exporter, dans l'ordre de rejeu (option répétable). Défaut : employee=fluxoon_employee, "
                         "employment=fluxoon_employment, career=fluxoon_carrière, compensation=fluxoon_compensation")
    ap.add_argument('--company', default='', help="n'exporter que cette entreprise (tables ayant une colonne company_id)")
    ap.add_argument('--exclude', action='append', default=[], metavar='TABLE', help="table à ne pas exporter (répétable)")
    ap.add_argument('--no-schema-guard', action='store_true', help="ne pas vérifier l'historique Flyway de la cible (déconseillé)")
    ap.add_argument('--maintenance-db', default='postgres', help="base servant à lister les bases (défaut : postgres)")
    ap.add_argument('--list-dbs', action='store_true', help="afficher les bases du serveur et s'arrêter")
    a = ap.parse_args()
    if a.password is None:
        a.password = getpass.getpass(f"Mot de passe PostgreSQL de {a.user}@{a.host} : ")

    if a.list_dbs:
        conn = connect(a, a.maintenance_db)
        with conn.cursor() as c:
            c.execute("select datname from pg_database where not datistemplate order by 1")
            print('\n'.join(r[0] for r in c.fetchall()))
        return

    wanted = []
    for spec in a.db:
        if '=' not in spec:
            sys.exit(f"--db attend LIBELLE=NOM (reçu : {spec})")
        lab, name = spec.split('=', 1)
        wanted.append((lab.strip(), name.strip()))
    dbs = resolve_db_names(a, wanted or DEFAULT_DBS)

    os.makedirs(a.out, exist_ok=True)
    stamp = datetime.datetime.now().strftime('%Y-%m-%d %H:%M')
    results = []
    for i, (label, dbname) in enumerate(dbs, 1):
        print(f"[{i}/{len(dbs)}] {dbname} ...", flush=True)
        results.append((label, dbname) + write_db(a, label, dbname, i, stamp))

    man = os.path.join(a.out, 'MANIFEST.txt')
    with open(man, 'w', encoding='utf-8') as m:
        m.write(f"Export Fluxoon du {stamp} ({a.host}:{a.port})\n"
                f"Périmètre : {'entreprise ' + a.company if a.company else 'toutes les lignes de toutes les tables'}\n"
                "Ordre de rejeu : celui des numéros de fichiers.\n")
        for label, dbname, fname, stats, sha, skipped, warnings in results:
            total = sum(s[2] for s in stats)
            m.write(f"\n{os.path.basename(fname)}  ({dbname} : {len(stats)} tables, {total} lignes)\n  sha256={sha}\n")
            for _, name, nb, has_pk, _ in stats:
                m.write(f"  {name:45s} {nb:>8d}{'' if has_pk else '   (sans clé primaire)'}\n")
            if skipped:
                m.write(f"  non exportées : {', '.join(skipped)}\n")
            for wmsg in warnings:
                m.write(f"  ATTENTION : {wmsg}\n")
    print(open(man, encoding='utf-8').read())


if __name__ == '__main__':
    main()
