# Reprise des paies CCA (Amplitude, janvier → septembre 2026) — dossier de test en production

Ce dossier rejoue en production ce qui a été validé en dev sur **CCA-IMPORT-21**. Tout passe par les fronts
(admin-dashboard, web-organization) et par les imports. Il n'y a aucun appel d'API direct et aucune retouche en base.
Le pas à pas complet est dans `procedure-reprise-paie-cca.md`.

## Contenu

| Dossier | Ce qu'il contient | Où il s'utilise |
|---|---|---|
| `0-config/` | Catalogue CM v23, normes v23 (puis grille de juillet), **moteur CM 2.7.22** et ses contrats de déclaration, exportés de dev (`LISEZMOI.md` du dossier) | admin-dashboard |
| `1-donnees/` | Le paquet de reprise : employés, postes, embauches, rémunérations, reclassements, acomptes, adhésions, absences, cumuls 2025, entrées de paie, sorties, mises en disponibilité, rémunérations saisies | web-organization → Reprise d'une société |
| `2-controle/` | `attendus.csv` (brut, ancienneté, logement d'Amplitude), `rubriques-amplitude.csv` (correspondance rubrique ↔ élément), `comparer_net.py` et `ecarts_rubriques.py` (comparaison rubrique par rubrique, sur le modèle du fichier d'écarts de l'expert) | contrôle de chaque mois |

## Avant de commencer : versions à déployer en production

| Service | Version | Ce qu'elle apporte à la reprise |
|---|---|---|
| payroll-service | master `cf153ac9` (avec `b4e4996d`, `94c89aa8`, `e7742261`) | absences partagées entre les versions d'une rubrique ; cotisations de plan bornées par le net ; émission groupée sur 3 fils ; un bulletin dont l'émission plante compte en échec ; suppression d'une campagne non validée, retrait d'une affectation de moteur |
| compensation-service | `ad19fef` | fériés d'entrée dans les politiques de prorata |
| employment-service | `983e631` | import des mises en disponibilité (suspensions) |
| employee-benefits-service | `eef5aac` | libellé des acomptes (4070 / 4080) |
| fluxxon-web-organization | master `52c35674` | étape « Mises en disponibilité » de la reprise, colonne libellé des acomptes |
| fluxoon-admin-dashboard | `c8b95f1` | fériés d'entrée dans les politiques de prorata |

## Noms à respecter

Les fichiers nomment l'entité **CCA-IMPORT-21**, les matricules **I21-MatXXX** et les plans **I21_MUTUELLE**,
**I21_RETRAITE** et **I21_SUPPLEMENT**. Créez l'entité et les plans sous ces codes. Pour un autre code d'entité en
production, le paquet se régénère avec ce code : il suffit de le donner.

## Ordre

1. **Pays** (admin-dashboard) : `0-config`, dans l'ordre de son LISEZMOI. Avant d'importer le moteur 2.7.22, vérifier
   que les politiques de prorata sont celles du §1 de la procédure.
2. **Société** (web-organization) : entité, convention, grille, temps (calendrier depuis décembre 2025, congé annuel
   jours fériés compris), paie (moteur **2.7.22 au 1er janvier**, périodes de janvier à septembre, fenêtres de saisie
   prolongées), plans de couverture.
3. **Données** : les étapes de la Reprise d'une société, dans l'ordre du §3 de la procédure. Les absences passent
   **avant** les sorties, et les mises en disponibilité juste avant les sorties.
4. **Chaque mois**, l'un après l'autre : préparation, campagne, calcul, comparaison, contrôle, validation, bulletins,
   émission. Un mois n'est émis qu'à 0 écart. **Vérifier que l'émission est complète** (émis = total, 0 échec) avant
   de calculer le mois suivant : les cumuls ne sont postés qu'à l'émission.

## Comparer un mois

Exporter les calculs de la campagne en CSV, nommé `calculs-AAAA-MM.csv`, dans `2-controle/`. Puis :

```
python comparer_net.py 2026-06        # net à payer Fluxoon contre le 9500 d'Amplitude
python ecarts_rubriques.py 2026-06    # chaque rubrique Amplitude contre sa colonne Fluxoon (7800 et 8500 exclues)
```

Les scripts lisent sur le Bureau les fichiers d'Amplitude : `TEST RECAP Détail Bulletin 2026_01_09.XLS`,
`TEST Variables Bulletin 2026_01_09.XLS` et `ECARTS A CORRIGER JAN_MARS.xlsx`. Les cotisations, les impôts, les charges
patronales et les droits à congé (7000 à 7075, 8000 à 8030, 3350, 3450, 3460) ne se comparent pas : il manque l'état de
paie complet de chaque mois.

## Corrections intégrées depuis CCA-IMPORT-19

**Moteur** (2.7.17 → 2.7.22)
- Solde des droits à congé précédent (3450) ; 3370 et 3372 séparés.
- Pas de régularisation d'IRPP sans brut.
- Indemnité de licenciement 3035 non imposable et hors CNPS, comme Amplitude. L'expert la tient pour imposable (étude 34).
- Plus d'indemnité compensatrice de congé inventée : à la sortie, le solde des droits est versé en 3360, 3370 et 3372.
- Droits consommés jamais supérieurs aux droits disponibles.
- Contrat de bulletin aux **numéros Amplitude**, pour la comptabilité.
- Pas d'allocation de sortie quand le congé payé court au-delà de la sortie.

**Paquet**
- Lignes décalées du fichier « 30 jours » d'avril (sortants).
- Congé commencé le 1er du mois : allocation sur les droits de fin du mois précédent.
- Fin d'un congé ou d'une maternité recalée sur les jours payés : reprise anticipée, maternité rappelée.
- Absences non payées recalées sur les jours de congé.
- Absences après la sortie retirées.
- Reprise négative récurrente en rémunération saisie acceptée.
- Mises en disponibilité importées.
- Adhésion retraite dès que la part patronale 7016 est versée.
- Sortie pendant un congé payé (`CM_ANNUAL_LEAVE_DAYS_UPCOMING`).

**Paie** : voir le tableau des versions.

## Où en est la validation en dev (CCA-IMPORT-21)

| Mois | Résultat |
|---|---|
| Janvier → mai | **0 écart sur le brut, le net et les 66 rubriques comparées ; émis** |
| Juin | 0 écart, sauf Mat708. Son bulletin d'avril a été perdu par l'émission groupée, défaut corrigé dans payroll `cf153ac9`. Juin n'est pas émis : la reprise négative de Mat557 était dans Compensation, ce que le paquet corrige désormais |
| Juillet → septembre | Pas encore passés dans Fluxoon avec ce paquet. Les règles ci-dessus les couvrent, et les mois restent à vérifier un par un |

## Points ouverts (sans effet sur le net)

- La retenue de préavis **4080** passe par la même retenue que l'acompte 4070. Elle s'affiche sous son libellé, mais
  un type de retenue dédié serait plus propre pour la comptabilité.
- Taxe d'apprentissage **8040** : Fluxoon n'a pas cette ligne.
- Deux absences sans effet sont refusées à l'import : Mat465 (mai 2025, avant le calendrier) et Mat429 (jour déjà
  couvert par un congé).
