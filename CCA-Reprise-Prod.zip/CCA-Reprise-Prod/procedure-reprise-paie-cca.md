# Procédure de reprise de la paie CCA (Amplitude → Fluxoon), pour la production

Rejoue en production ce qui a été validé en dev sur l'entité **CCA-IMPORT-20** (reprise depuis janvier ; CCA-IMPORT-19 avant elle) : janvier 2026 identique à Amplitude
pour les **940 salariés** (brut, ancienneté, logement et **net à payer** : 0 écart), installée **uniquement par les fronts
et les imports**.

**Règle : rien d'autre que les fronts.** Pas d'appel d'API direct, pas de SQL, pas de geste de rattrapage salarié par
salarié. Tout passe par :
- **admin-dashboard** pour le pays : catalogue, politiques de prorata, grilles, moteur ;
- **web-organization** pour la société et ses données, par l'écran « Reprise d'une société ».

Quand un geste manque à un front, on l'ajoute au code et on déploie. On ne contourne pas. Les manques encore ouverts
sont au §7.

Le paquet de données est produit par le générateur `paquet_i19.py` (puis `maternites.py --merge`) à partir de trois
fichiers de l'expert :
- **« TEST RECAP Détail Bulletin 2026_01_09 »** : les bulletins réels, rubrique par rubrique ;
- **« Détail Bulletins 30Jrs 2026_01_09 »** : le montant plein mois de chaque rubrique récurrente ;
- **« TEST Variables Bulletin 2026_01_09 »** : jours travaillés, acomptes, retraite et supplément, préavis.

Il s'appuie aussi sur les formules d'Amplitude (`formules_constantes_amplitude.zip`), qui disent pour chaque rubrique si
elle est saisie en élément variable et si elle est proratisée. Résultat : le dossier `CCA-Import-19/tout-en-un/`, un
fichier par import (§3).

---

## 0. Versions à déployer d'abord

| Service | Commit minimal | Ce qu'il apporte à la reprise |
|---|---|---|
| employment-service | `26f7ff3` | Reclassement daté, import des reclassements, import des sorties (`0733344`). |
| employee-service | `d581093` | Routes internes `payment-accounts` et `dependents`. |
| compensation-service | `1062164` | Entrées communes de retenue après le net, exemption de prorata par convention, retrait d'une politique jusqu'à n'avoir jamais valu. Un import de rémunérations avec des lignes refusées se termine (migration V18). |
| payroll-service | `c31670ca` | **Acompte retenu en entier, hors quotité**, sans net négatif. **Condition de versement** d'une rubrique (migration V39). **Montant de rubrique négatif accepté.** **Import des rémunérations saisies** de la préparation. Émission, contrôle et préparation des versions précédentes. |
| employee-benefits-service | `897545c` | **Acomptes repris** (import, versement constaté hors Fluxoon, contrat apprécié à la date du versement). Adhésion obligatoire reculée retrouvée par la paie (migration V5). **Correction d'une règle de cotisation** à sa date d'effet. **Import des adhésions avec leurs changements datés.** |
| fluxxon-web-organization | `eebf3aef` (master) | Étapes d'import « Adhésions », « Acomptes repris », « Rémunérations saisies ». Correction d'une règle de cotisation. Émissions paginées, écarter les brouillons. ⚠ Le serveur déploie `master`. |
| fluxoon-admin-dashboard | `cc75fe8` (main) | **Condition de versement** des règles de rubrique (colonne « Paid when », champ à la création et à la modification). ⚠ Le serveur déploie `main`. |

Les déploiements suivent DEPLOYMENT.md. Ne taguer qu'après vérification en dev.

## 1. Pays (admin-dashboard)

Les fichiers sont dans `CCA-Import-20/0-config` (voir son `LISEZMOI.md`) : catalogue v23, normes (puis grille de
juillet), moteur 2.7.22 et contrats de déclaration, exportés de dev. Dans l'ordre :

1. **Catalogue de rémunération CM** (Compensation → catalogue), avec les entrées communes de retenue après le net
   (`ACOMPTE_RECOVERY`, `ADVANCE_INSTALLMENT`, `LOAN_INSTALLMENT`), valides dès le 2026-01-01 (« Common entries valid from »).
2. **Politiques de prorata** (Compensation → proration policies). Elles suivent l'option « prorata » des formules
   Amplitude :
   - **pays** : ancienneté 301, logement 502, complément de salaire 152, ancienneté gelée 354 et panier 560 en `DEFAULT`
     (prorata d'entrée et de sortie, `CALENDAR_DAYS`), qu'une convention peut écarter ;
   - **convention CCA-CC-2026, sans prorata ni retenue d'absence** : 301 et 502 (Amplitude 1121 et 3125), 354 (1110),
     152 (1030) et **560 (panier 3040, élément variable du mois)** ;
   - **convention CCA-CC-2026, proratisés** (trentièmes, retenue du congé, de la maternité et de l'absence non payée) :
     les autres rubriques récurrentes (Amplitude « prorata = O »).
   - Une politique erronée se **retire**, puis son retrait **s'avance à la veille de son début** (elle n'a jamais
     valu), et la bonne se crée et s'active au 2026-01-01. Ne pas réviser : une révision commence après la version en
     place.
3. **Grille CCA** : la grille de base, complétée de la case 11D (701 147 au 1er janvier), puis la révision au
   1er juillet (+5 %).
4. **Moteur CM 2.7.22** (Paie → moteurs). Importer le paquet exporté de dev (`GET /payroll/engines/{id}/exports`,
   format 1.1), ou le construire depuis la version précédente par « nouvelle version », avec :
   - base **CCFS** (crédit foncier salarié, Amplitude 7030) : `if(STBM <= 58333) {return 0;} return round(0.01 * STBM, 0);`
     (Amplitude 7006 ramène la base à 0 jusqu'à 58 333) ;
   - rubrique **SENIORITY_BONUS** : nulle seulement quand la **maternité** couvre le mois
     (`if((CM_MATERNITY_LEAVE_ABSENCE_DAYS ?? 0) >= 30) {return 0;} return gridMin(101) * seniorityRate(SENIORITY_YEARS ?? 0);`) ;
     une absence non payée garde l'ancienneté ;
   - rubrique **HOUSING_ALLOWANCE** : condition de versement `(CM_MATERNITY_LEAVE_ABSENCE_DAYS ?? 0) < 30`
     (pas de logement pour un mois entier de maternité, logement entier sinon) ;
   - base **LEAVE_RIGHTS_PREVIOUS** (solde des droits à congé précédent, Amplitude 3450), et **LEAVE_RIGHTS** = ce solde
     + la base de congé du mois ;
   - **LEAVE_ALLOWANCE** : un congé commencé dans une période close (saisi après sa paie) se paie sur les droits à son
     départ, sans la base du mois ; signalé par l'entrée `CM_ANNUAL_LEAVE_STARTED_EARLIER` = 1 (catalogue v23), que le
     paquet pose dans les entrées de paie ;
   - congés supplémentaires séparés : **LEAVE_ALLOWANCE_SENIORITY** (3370) et **LEAVE_ALLOWANCE_MOTHER** (3372),
     LEAVE_ALLOWANCE_EXTRA en est la somme ;
   - **IRPP_REGUL** nulle un mois sans salaire brut (Amplitude ne fait pas de bulletin) ;
   - indemnités de rupture traitées comme Amplitude (formules 2800, 3340, 6580) : **SEVERANCE_PAY** (licenciement, 3035)
     non imposable et hors CNPS ; **END_OF_CAREER_ALLOWANCE** (fin de carrière, 3025) non imposable mais cotisable.
     Choix de reproduction validé le 20/10/2026 alors que l'expert tient l'indemnité de licenciement pour imposable ;
   - **congé payé à la sortie** (2.7.19) : plus de rubrique LEAVE_COMPENSATION inventée ; le solde des droits se verse
     comme Amplitude, LEAVE_ALLOWANCE = `round(LEAVE_RIGHTS / 16)` (3360) et les congés supplémentaires (3370/3372) ;
   - **droits pris** (2.7.20) : LEAVE_RIGHTS_TAKEN = `min(16 * LEAVE_ALLOWANCE, max(0, LEAVE_RIGHTS))`, jamais un solde
     négatif (petits écarts 3450/3460 relevés par l'expert) ;
   - **contrat de bulletin aux numéros Amplitude** (2.7.21), pour la comptabilité : CCF 8010, CFNE 8015, PF 8020,
     AT 8030, retraite complémentaire patronale 7016, supplément 7017, acompte 4070, avance 4000, prêt 4640, fin de
     carrière 3025, prime de séparation 2085, 13e mois 2710, performance 3045, personnel domestique 3142, prime annuelle
     2040, indemnité compensatrice de congé 3375 ; les lignes jamais servies sont retirées (104 → 63 lignes) ;
   - **sortie pendant un congé déjà payé** (2.7.22) : quand le congé court au-delà de la sortie (entrée
     `CM_ANNUAL_LEAVE_DAYS_UPCOMING` > 0, posée par le paquet), pas d'allocation de sortie (Amplitude, Mat168 en mars) ;
   - contrat de bulletin complet, contrats de déclaration repris de la version précédente, puis **activer**.
   - Avant d'activer : simulation sur le moteur (Paie → simulations), et le rejeu Python
     (`docs/simulation-paie-cm/moteur.py`) pour une correction de formule.
5. **Modèle de bulletin « Bulletin CCA (Amplitude) »** : « Reporter sur une autre version » vers 2.7.22, puis publier.

## 2. Société (web-organization)

1. **Entité juridique**, affiliations employeur (RCCM, NIU, CNPS), unité (siège).
2. **Convention** CCA-CC-2026 rattachée à l'entité au 2026-01-01.
3. **Grille de l'entité** (v1 au 1er janvier, v2 au 1er juillet).
4. **Temps.**
   - Calendrier de travail approuvé et assigné à l'entité, couvrant **décembre 2025** (des maternités commencent en
     décembre).
   - Types d'absence actifs : congé annuel (**jours fériés comptés comme congé**, comme Amplitude), congé
     complémentaire, maternité, absence non payée.
   - Politique de suivi du temps active.
5. **Paie.**
   - Configuration paie de l'entité, cycle mensuel ancré au 1er désigné par défaut, puis activation.
   - Affecter le moteur 2.7.22 au 2026-01-01, l'activer, matérialiser les périodes de janvier à septembre.
   - **Prolonger la fenêtre de saisie** de chaque période passée (motif « Reprise des paies Amplitude 2026 ») avant
     les imports qui écrivent dans la paie (entrées, rémunérations saisies).
6. **Plans de couverture** (Avantages), au 2026-01-01, avec des **codes propres à l'entité** (un code de plan est
   unique dans le groupe) :
   - **Mutuelle**, obligatoire, formule par défaut STANDARD : part salariale `BASE_SALARY * 0.05` (5 % de la base
     **payée** du mois), part patronale `0`. Les salariés y sont affiliés d'office à la préparation.
   - **Retraite complémentaire**, facultative : CADRES `30000` / `30000 * 0.4`, MAITRISE `20000` / `20000 * 0.4`,
     EMPLOYES `10000` / `10000 * 0.4`.
   - **Supplément retraite**, facultatif, type OTHER : LIBRE `CHOSEN_AMOUNT` / `0`.
   - Une formule saisie fausse se **corrige à sa date d'effet** (« corriger la règle qui prend déjà effet »).

## 3. Données (web-organization → Reprise d'une société)

Chaque fichier se **contrôle** d'abord, sans rien écrire, puis s'importe. Un fichier rejoué ne crée pas de doublon.

| # | Étape | Fichier | Remarques |
|---|---|---|---|
| 1 | Employés | `1-employes.csv` | Le matricule est la clé des étapes suivantes. |
| 2 | Postes | `2-postes.csv` | |
| 3 | Embauches | `3-embauches.csv` | |
| 4 | Rémunérations | `4-remunerations.csv` puis `4-ponctuels.csv` | En tâche de fond : attendre que les imports soient terminés (aucun « en cours ») avant la paie. Voir §5 pour leur construction. |
| 5 | Reclassements | `5-classifications.csv` | Appliqués par date d'effet croissante. |
| 6 | Acomptes repris | `10b-acomptes.csv` | Acomptes 4070 versés le 15 du mois (au plus tard au dernier jour d'un sortant), récupérés le mois même ; retenues de préavis 4080 (§5). Récupérés **en entier, hors quotité**, sans rendre le net négatif. |
| 7 | Adhésions | `11-adhesions.csv` | Retraite (formule selon 7015 : 10 000 EMPLOYES, 20 000 MAITRISE, 30 000 CADRES) et supplément (montant 7017). Les **changements datés** suivent dans le même fichier : une ligne plus tardive change la formule, ou le montant choisi. |
| 8 | Absences | `7-absences.csv` puis `7-absences-non-payees-reconstituees.csv` | Congés, maternités (dont celles en cours au 1er janvier), absences non payées reconstituées. |
| 9 | Reprise des cumuls | `0-reprise-cumuls-2025-12.json` | Cumuls à fin 2025 (base congés), sur la période de janvier. |
| 10 | Entrées de paie | `8-entrees-paie.csv` | Une importation par mois. Une entrée importée **l'emporte** sur la valeur du service temps (Mat180, §5). |
| 11 | Sorties | `6-sorties.csv` | 77 sorties. |
| 11b | Mises en disponibilité | `13-mises-en-disponibilite.csv` | Suspensions de contrat (Amplitude, motifs d'arrêt de paie) : du… au…, aucun élément versé pendant la suspension. Avant les sorties. |
| 12 | Rémunérations saisies | `12-remunerations-saisies.csv` | Reprises négatives d'Amplitude (Mat493 en janvier, Mat303 en mars) : saisies dans la préparation, **acceptées** avec le message de la colonne `negativeAcceptance`, validées. Jamais dans Compensation. |

Écarts sans effet connus : l'absence de Mat465 (mai 2025) précède le calendrier ; celle de Mat429 du 30/01 tombe dans
un congé déjà importé.

## 4. Cycle de chaque mois (web-organization → Paie), de janvier à septembre, **un mois après l'autre**

Les cumuls ne sont postés qu'à l'**émission** : un mois doit être émis avant de calculer le suivant.

1. **Préparation** : Rafraîchir, attendre que tous les dossiers soient prêts. **Aucun dossier ne s'exclut** : un
   dossier bloqué révèle un défaut du paquet ou du paramétrage, à corriger d'abord (sur CCA-IMPORT-19, janvier :
   940 dossiers prêts, 0 bloqué).
2. **Campagne** : créer la campagne principale du mois (siège, actifs), la démarrer, **calculer**. Si une préparation
   a changé depuis : **Adopter la préparation actuelle**, puis recalculer.
3. **Comparaison avec Amplitude**, rubrique par rubrique comme le fichier d'écarts de l'expert (toutes les rubriques des
   bulletins RECAP et Variables, 7800 et 8500 exclus), en plus du brut, de l'ancienneté, du logement et du net : exporter les calculs, comparer le brut (3800), l'ancienneté (1121), le logement
   (3125) au fichier `attendus.csv`, et le **net à payer** au 9500 du fichier « Variables ». Objectif : **0 écart**.
   Tout écart arrête la procédure.
4. **Contrôle** : les rémunérations négatives acceptées y apparaissent en information. Puis **Valider** et **Générer
   les bulletins** (le PDF est indispensable à l'émission).
5. **Émettre** tous les bulletins. Une émission interrompue se reprend (« Reprendre tout ») ; les brouillons laissés
   derrière un bulletin émis s'écartent (« Écarter les brouillons »).

**Changer de moteur, ou recommencer un mois.** Le moteur d'une campagne est fixé à sa création, et la préparation doit
être faite sur le même moteur (sinon « prepare again ») : après un changement d'affectation, **re-préparer** avant
de démarrer la campagne.
- Une campagne **non validée** se supprime ; une campagne validée, jamais.
- Une affectation de moteur sans campagne validée se **retire** (après suppression de ses campagnes non validées,
  que le refus énumère), ce qui permet d'en créer une nouvelle, même à une date d'effet antérieure. Une affectation
  déjà servie par une paie validée **se termine** au lieu de se retirer.

## 5. Comment le paquet reproduit Amplitude (décisions)

- **Rémunérations récurrentes** : le montant plein mois du fichier « 30 jours », en segments à valeur constante, sauf :
  - **salarié présent tout le mois** (0900 = 30) : les montants de **son bulletin** font foi (prime démarrée en cours
    de mois, Mat046) ;
  - **feuille en retard d'un mois sur les promotions** (janvier : 51 salariés, février : 101) : la feuille du mois
    suivant porte la situation que le bulletin applique déjà ;
  - **complément de salaire 1030** (non proratisé, saisissable) : le montant du bulletin du mois ;
  - **sortants** : chaque segment se termine au dernier jour (sinon l'emploi et la rémunération divergent).
- **Lignes décalées du fichier « 30 jours »** (avril : les 19 sortants n'ont pas la cellule « date de RA-MU-RE », toutes
  les valeurs sont une colonne à gauche, 0900 porte le salaire de base) : le générateur relit ces lignes une colonne plus à
  gauche. Sans cela, avril prenait sursalaire et ancienneté gelée inventés (13 nets faux sur CCA-IMPORT-20).
- **Panier 3040** : élément variable du mois, un segment mensuel au montant du bulletin, sans prorata (politique CCA).
- **Ancienneté et logement** : calculés par la paie, versés en entier, sauf mois entier de maternité.
- **Maternités en cours au 1er janvier** : un salarié à 0 jour travaillé en janvier (hors congé annuel) est en
  maternité depuis 2025. Elle court 98 jours jusqu'à la veille de sa reprise, au plus tôt le 01/12/2025 (Mat406, 426,
  489, 723, 773).
- **Maternité appliquée en retard par Amplitude** : quand les premiers mois ont été payés en entier, la maternité
  commence au premier mois réellement réduit (Mat511 au 01/03, Mat388 au 01/02).
- **Allocation de congé versée après le congé** (Mat180 : congé du 02/01 au 29/01, allocation payée en février) :
  deux entrées de paie, `CM_ANNUAL_LEAVE_DAYS_STARTING` = 0 en janvier et = 28 en février.
- **Retenue d'indemnité de préavis 4080** (salarié qui n'effectue pas son préavis) : retenue après le net, comme un
  acompte, au mois de la sortie ; Amplitude retient tout le net (Mat167, Mat227 en janvier).
- **Reprises négatives** (Mat493 : prime 2095 −169 448 en janvier ; Mat303 : 3155 −60 056 en mars) : rémunérations
  saisies négatives, acceptées, jamais des avances.
- **Mutuelle** : 5 % de la base payée du mois (Amplitude), et non de la grille.
- **Cotisations de plan sans net** (payroll `94c89aa`) : la part salariale ne retient que ce que le net laisse, la part
  patronale reste due ; l'adhésion retraite court dès le premier mois où 7015 **ou** 7016 est versé (Mat489 au 01/01).
- **Congé commencé le 1er du mois** : allocation sur les droits de fin du mois précédent, sans la base du mois (Amplitude,
  au franc près) ; le paquet pose `CM_ANNUAL_LEAVE_STARTED_EARLIER` = 1 ce mois-là (22 congés d'avril à septembre).
- **Fin d'un congé ou d'une maternité recalée sur les jours payés** : un mois payé en entier après le départ (rappels
  compris) la termine la veille (Mat524) ; le mois où elle finit, Amplitude retient 30 − jours payés − autres absences
  (reprise plus tôt que le registre : Mat033 le 19/05 et non le 26/05). Une maternité appliquée en retard (mois de départ
  payé en entier) n'est pas touchée.
- **Absence non payée reconstituée un mois de congé** : 30 − jours payés − jours de congé du mois (Mat478 : 5 et non 6),
  hors février et mois de sortie.
- **Absence qui commence après la sortie** (congé prévu jamais pris, Mat655) : retirée du paquet.
- **Montant récurrent négatif** (Mat557 : complément 1030 à −56 957 de juin à août) : rémunération saisie négative et
  acceptée chaque mois, jamais dans Compensation (une version en vigueur ne s'y retire plus).
- **Sortie pendant un congé payé** : le paquet pose `CM_ANNUAL_LEAVE_DAYS_UPCOMING` (jours ouvrables du congé après la
  sortie) le mois de la sortie.
- **Congé commencé dans une période close** : entrée `CM_ANNUAL_LEAVE_STARTED_EARLIER` = 1 le mois du paiement.
- **Sortie sans jour travaillé** : régularisation par rémunérations saisies négatives, sauf si une absence couvre un
  jour ouvré.
- **Mises en disponibilité** : détectées au paquet (mois sans bulletin entre deux mois payés, hors maternité),
  importées en suspensions.
- **Corrections ponctuelles** d'Amplitude (ex. Mat528 : ancienneté +6 810 en mars) : rémunérations saisies.
- **Indemnité de licenciement 3035** : non imposable comme Amplitude (étude 34 : l'expert la tient pour imposable).

- **Paie** (payroll `b4e4996d`, `cf153ac9`) : les versions successives d'une rubrique dans le mois (sortie le 30 : du 1er au
  29, puis le 30) se partagent les jours d'absence ; un bulletin dont l'émission plante (mémoire) compte en échec, et
  une émission incomplète arrête la chaîne : ses cumuls manqueraient au mois suivant.

## 6. Résultat en dev

| Entité | Brut identique | Net identique | Remarque |
|---|---|---|---|
| CCA-IMPORT-16 | 852 / 937 | 0 → 851 / 937 | mutuelle et acomptes corrigés en cours de route |
| CCA-IMPORT-17 | 930 / 936 | 930 / 936 | 4 salariés non calculés |
| CCA-IMPORT-18 | 937 / 940 | 935 / 940 | premier essai par les seuls imports |
| CCA-IMPORT-19 | 940 / 940 | 940 / 940 | janvier, février : 0 écart ; mars 967 / 968 |
| **CCA-IMPORT-21** | **janvier → mai : 0 écart** | **émis** | **toutes rubriques comparées ; juin : 0 écart hors Mat708 (émission d'avril perdue, corrigée dans la paie) ; juin non émis (reprise négative de Mat557 dans Compensation, corrigée dans le paquet)** |
| CCA-IMPORT-20 | **940 / 940** | **940 / 940** | **reprise depuis janvier (2.7.20, puis 2.7.21 au 1er février) ; janvier et février (962 / 962) émis ; mars 968 / 968 (2.7.22) émis ; avril arrêté : paquet décalé** |

## 7. Manques à lever avant la production

1. **Libellé de la retenue de préavis** : elle passe par l'acompte repris et s'affiche « Récupération d'acompte ». Un
   type de retenue dédié dans employee-benefits donnerait le bon libellé.
2. **Transfert de la configuration** : moteur 2.7.22 (export / import), politiques de prorata (export du catalogue de
   Compensation), plans de couverture (à recréer par le front).
3. **Février à septembre** : à valider mois par mois avec le même paquet (cumuls postés par l'émission du mois
   précédent).
4. **Reprise des prêts** en cours, sur le modèle des avances.
