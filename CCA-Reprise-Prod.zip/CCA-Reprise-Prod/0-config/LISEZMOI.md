# 0-config — configuration validée de la reprise CCA-IMPORT-19

Exportée de dev le 20/10/2026, c'est la configuration qui donne 0 écart en janvier et en février : catalogue CM v23, moteur CM 2.7.22.
Elle s'importe uniquement par l'admin-dashboard, dans cet ordre.

| # | Fichier | Où l'importer (admin-dashboard) | Contenu |
|---|---|---|---|
| 1 | `1-CM-catalogue-v23.json` | Compensation → catalogue CM → Import (sur une version en brouillon), puis publier | Éléments, entrées communes de retenue (ACOMPTE_RECOVERY, ADVANCE_INSTALLMENT, LOAN_INSTALLMENT), intrants |
| 2 | `2-CM-normes-v23.json` | Compensation → catalogue CM → Import des normes | 53 politiques de prorata (pays + convention CCA-CC-2026) et la grille de convention au 01/01/2026. Les 17 politiques en trentièmes de la convention portent les jours fériés d'Amplitude (table 199 : 01-01, 02-11, 05-01, 05-20, 08-15, 12-25) qui ne comptent pas comme absence avant une entrée en cours de mois |
| 2b | `2b-CM-normes-v23-grille-juillet.json` | Même écran, après le fichier 2 | Révision de la grille de convention au 01/07/2026 (+5 %) |
| 3 | `3-moteur-CM-2.7.22.json` | Paie → moteurs → Import package (format 1.1), puis activer | Moteur 2.7.22 : CCFS (base 0 jusqu'à 58 333), ancienneté nulle si maternité ≥ 30 j, condition de versement du logement `(CM_MATERNITY_LEAVE_ABSENCE_DAYS ?? 0) < 30` ; solde des droits à congé précédent ; allocation d'un congé saisi après sa paie sur les droits à son départ (`CM_ANNUAL_LEAVE_STARTED_EARLIER`) ; 3370 et 3372 séparés ; pas de régularisation d'IRPP sans brut ; indemnité de licenciement (3035) non imposable et hors CNPS, fin de carrière (3025) non imposable et cotisable, comme dans Amplitude ; contrat de bulletin aux numéros Amplitude (depuis 2.7.21) ; pas d'allocation de sortie quand le congé payé court au-delà de la sortie (`CM_ANNUAL_LEAVE_DAYS_UPCOMING`, 2.7.22) |
| 4 | `4-contrats-declaration-CM-2.7.22.json` | Moteur importé → onglet Déclarations → Import | Les 9 contrats de déclaration |

Le fichier 2 ne porte que la dernière version de chaque politique ou grille : c'est pour cela que la grille de juillet est
dans un fichier à part, à importer après. La politique pays **101** (salaire de base) a été révisée sur dev au
01/11/2026, et seule sa source a changé. Elle est ici datée du **01/01/2026** pour couvrir toute la reprise.

## Ensuite, côté société (web-organization), avant les imports de `tout-en-un`

- **Grille de l'entité** : `../0-grille/grille-salaire-base-2026-01.csv` (v1 au 01/01, avec la case 11D) et
  `grille-salaire-base-2026-07.csv` (v2 au 01/07).
- **Modèle de bulletin** « Bulletin CCA (Amplitude) » : « Reporter sur une autre version » vers 2.7.22, puis publier.
- **Plans de couverture** (Avantages, au 01/01/2026, codes propres à l'entité, par exemple I19_*) :
  - Mutuelle obligatoire : STANDARD, part salariale `BASE_SALARY * 0.05`, part patronale `0`.
  - Retraite complémentaire facultative :
    - CADRES `30000` / `30000 * 0.4` ;
    - MAITRISE `20000` / `20000 * 0.4` ;
    - EMPLOYES `10000` / `10000 * 0.4`.
  - Supplément retraite facultatif : LIBRE `CHOSEN_AMOUNT` / `0`.
- Le reste suit `docs/procedure-reprise-paie-cca.md` §2 : convention, temps, configuration paie, moteur affecté au
  01/01/2026, fenêtres de saisie prolongées.
