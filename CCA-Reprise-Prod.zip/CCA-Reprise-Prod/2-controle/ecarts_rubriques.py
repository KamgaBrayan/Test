# -*- coding: utf-8 -*-
"""Écarts rubrique par rubrique, sur le modèle du fichier de l'expert (ECARTS A CORRIGER JAN_MARS.xlsx) :
chaque rubrique Amplitude contre sa colonne Fluxoon, 7800 et 8500 ignorés (consigne de l'expert).
Amplitude : TEST RECAP + TEST Variables (les seuls bulletins définitifs).
usage : python ecarts_expert.py 2026-02"""
import csv, os, re, sys, collections, openpyxl, pandas as pd
ym = sys.argv[1]
D = r"C:\Users\USER\Desktop\\"
IGNORE = {"7800", "8500"}
# rubrique Amplitude -> colonne(s) Fluxoon (code entre parenthèses de l'export), d'après la ligne 2 du fichier expert,
# corrigée des rubriques que l'expert n'avait pas rapprochées et de la renumérotation 2.7.21
EXTRA = {"2085": ["SEPARATION_BONUS"], "2711": ["THIRTEENTH_MONTH_ON_DISMISSAL"],
         "3035": ["SEVERANCE_PAY"], "3025": ["END_OF_CAREER_ALLOWANCE"], "3045": ["PERFORMANCE_BONUS"],
         "3375": ["PAID_LEAVE_COMPENSATION"], "3370": ["LEAVE_ALLOWANCE_SENIORITY"], "3372": ["LEAVE_ALLOWANCE_MOTHER"],
         "2040": ["ANNUAL_BONUS"], "3142": ["DOMESTIC_STAFF_ALLOWANCE"],
         "4070": ["POST_NET:Acompte sur salaire", "POST_NET:Récupération d'acompte"],
         "4080": ["POST_NET:Indemnité compensatrice de préavis"],
         "3145": ["NON_TAXABLE_ADJUSTMENT"], "2065": ["TAXABLE_ADJUSTMENT"], "2066": ["TAXABLE_OVERPAYMENT"],
         "7016": ["SUPPLEMENTARY_PENSION_PATRONAL"], "7017": ["OTHER_SALARIAL"], "9500": ["NET_PAYABLE"]}
wb = openpyxl.load_workbook(D + "ECARTS A CORRIGER JAN_MARS.xlsx", read_only=True)
hdr = list(wb["MARS"].iter_rows(min_row=2, max_row=3, values_only=True))
MAP = {}
for fx, am in zip(hdr[0][3:], hdr[1][3:]):
    if not am: continue
    code = str(am)[:4]
    if code in IGNORE: continue
    m = re.search(r"\(([^()]+)\)$", str(fx or ""))
    MAP[code] = [m.group(1)] if m else []
# correspondance du paquet (rubriques-amplitude.csv) : l'élément Fluxoon de chaque rubrique reprise
for r in csv.DictReader(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "rubriques-amplitude.csv"), encoding="utf-8-sig"), delimiter=";"):
    if r["elementFluxoon"] and not MAP.get(r["rubrique"]): MAP[r["rubrique"]] = [r["elementFluxoon"]]
MAP.update(EXTRA)
MAP.pop("7800", None); MAP.pop("8500", None)

def sheet(path, header):
    xl = pd.ExcelFile(path)
    s = [s for s in xl.sheet_names if s.endswith(ym.replace("-", "_"))]
    if not s: return {}
    d = next(t for t in (xl.parse(s[0], header=h) for h in range(6)) if "Nom" in t.columns)
    return {str(r["Nom"]).strip(): {str(c)[:4]: r[c] for c in d.columns if re.match(r"^\d{4}", str(c))}
            for _, r in d.iterrows() if str(r["Nom"]).startswith("Mat")}
amp = collections.defaultdict(dict)
for src, h in ((D + "TEST RECAP Détail Bulletin 2026_01_09.XLS", 0), (D + "TEST Variables Bulletin 2026_01_09.XLS", 2)):
    for mat, v in sheet(src, h).items(): amp[mat].update(v)
# « ETAT PAIE CCA » de janvier (PAIE AVEC ECARTS) est une paie provisoire : 199 nets diffèrent du bulletin final, écarté
num = lambda v: 0.0 if v in (None, "") or (isinstance(v, float) and v != v) else float(str(v).replace(" ", "").replace(",", "."))
rows = list(csv.reader(open(f"calculs-{ym}.csv", encoding="utf-8-sig"), delimiter=";"))
col = {}
for i, h in enumerate(rows[0]):
    m = re.search(r"\(([^()]+)\)$", h)
    if m: col[m.group(1)] = i
    m = re.search(r"\((PLAN:[^:]+_SUPPLEMENT:EMPLOYEE)\)$", h)
avail = sorted({c for v in amp.values() for c in v})
compared = [c for c in MAP if c in avail]
absent = [c for c in MAP if c not in avail]
out = []; per = collections.Counter(); ok = 0
for r in rows[1:]:
    mat = r[0].split("-")[-1]; a = amp.get(mat)
    if a is None: continue
    bad = False
    for code in compared:
        fx = sum(num(r[col[k]]) for k in MAP[code] if k in col)
        am = num(a.get(code))
        if abs(fx - am) > 1:
            out.append((mat, code, fx, am, fx - am)); per[code] += 1; bad = True
    ok += not bad
with open(f"ecarts-expert-{ym}.csv", "w", encoding="utf-8-sig", newline="") as f:
    w = csv.writer(f, delimiter=";"); w.writerow(["matricule", "rubrique", "fluxoon", "amplitude", "ecart"]); w.writerows(out)
print(f"{ym} : {len(compared)} rubriques comparées, salariés sans aucun écart {ok} / {len(rows)-1}, écarts {len(out)}")
print("   écarts par rubrique :", dict(per))
print("   sans valeur Amplitude ce mois (non comparables) :", absent)
for o in out[:40]: print("  ", o)
