# -*- coding: utf-8 -*-
"""Net à payer Fluxoon (export des calculs) contre le 9500 d'Amplitude (« TEST Variables Bulletin »).
usage : python comparer_net.py 2026-01 [2026-02 ...]"""
import csv, sys, collections, pandas as pd
SRC = r"C:\Users\USER\Desktop\TEST Variables Bulletin 2026_01_09.XLS"
xl = pd.ExcelFile(SRC)
for ym in sys.argv[1:]:
    sheet = [s for s in xl.sheet_names if s.endswith(ym.replace("-", "_"))][0]
    d = xl.parse(sheet, header=2)
    amp = {str(r["Nom"]).strip(): r for _, r in d.iterrows() if str(r["Nom"]).startswith("Mat")}
    rows = list(csv.DictReader(open(f"calculs-{ym}.csv", encoding="utf-8-sig"), delimiter=";"))
    col = next(c for c in rows[0] if "(NET_PAYABLE)" in c)
    num = lambda v: float(str(v).replace(" ", "").replace(",", ".") or 0)
    same = 0; gaps = []
    for r in rows:
        mat = r["Matricule"].split("-")[-1]
        a = amp.get(mat)
        if a is None: continue
        fx, am = num(r[col]), float(a["9500-NET A PAYER"] or 0)
        if abs(fx - am) <= 1: same += 1
        else: gaps.append((mat, fx, am, fx - am, float(a.get("4070-ACOMPTE SUR SALAIRE") or 0), float(a.get("7015-RET. RETRAITE COMPLEMENTAIRE") or 0) + float(a.get("7017-RET. SUPPLT RETRAITE COMPLEMENTAIRE") or 0)))
    print(f"{ym} : {len(rows)} calculs, net identique {same}, écarts {len(gaps)}")
    buckets = collections.Counter()
    for g in gaps:
        buckets["acompte" if g[4] else "retraite" if g[5] else "autre"] += 1
    print("   écarts avec acompte Amplitude / retraite complémentaire / autres :", dict(buckets))
    with open(f"ecarts-net-{ym}.csv", "w", encoding="utf-8-sig", newline="") as fh:
        w = csv.writer(fh, delimiter=";"); w.writerow(["matricule", "net_fluxoon", "net_amplitude", "ecart", "acompte_4070", "retraite_7015_7017"])
        w.writerows(sorted(gaps, key=lambda g: -abs(g[3])))
    for g in sorted(gaps, key=lambda g: -abs(g[3]))[:8]: print("  ", g)
