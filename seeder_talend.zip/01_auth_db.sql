-- ============================================================================
-- Seeder CCA : auth_db
-- Tenant CCA : organisation, rôles et groupes d'organisation (+ catalogue système en garde-fou)

-- Idempotent : chaque INSERT se termine par ON CONFLICT ; le fichier peut être rejoué.
-- Exécution : psql -v ON_ERROR_STOP=1 -d auth_db -f <ce fichier>
-- ============================================================================
-- Contenu :
--   1. Catalogue système Fluxoon (resource servers, types, scopes, rôles plateforme, définitions de rôles d'organisation).
--      Normalement créé au démarrage de Fluxoon : inséré ici en DO NOTHING, jamais modifié.
--   2. Organisation CCA (tenant), ses 5 rôles d'organisation, ses 2 groupes d'entités juridiques.
--   3. (Optionnel, commenté) rattachement du premier administrateur : l'utilisateur doit d'abord exister dans Fluxoon.
-- Exclus volontairement : users, tokens, keys, clients, challenges, login_events (secrets et données de session).
SET client_encoding = 'UTF8';
SET client_min_messages = warning;
BEGIN;

-- ----------------------------------------------------------------------------
-- 1. Catalogue système (garde-fou, DO NOTHING)
-- ----------------------------------------------------------------------------
INSERT INTO public.resource_servers ("id", "created_at", "description", "display_name", "name", "updated_at")
SELECT "id", "created_at", "description", "display_name", "name", "updated_at" FROM jsonb_populate_recordset(NULL::public.resource_servers, $JSON$[
{"id": "default", "created_at": "2026-09-10T15:56:58.570948+00:00", "description": "Serveur de ressources par défaut, réutilisé par tout ResourceType/Action qui ne précise pas de serverName.", "display_name": "Default", "name": "default", "updated_at": "2026-09-10T15:56:58.570948+00:00"}
]$JSON$::jsonb)
ON CONFLICT ("id") DO NOTHING;
INSERT INTO public.resource_types ("id", "created_at", "default_policy_specs", "description", "display_name", "localized_descriptions", "localized_display_names", "realm", "server_name", "updated_at")
SELECT "id", "created_at", "default_policy_specs", "description", "display_name", "localized_descriptions", "localized_display_names", "realm", "server_name", "updated_at" FROM jsonb_populate_recordset(NULL::public.resource_types, $JSON$[
{"id": "authorization", "created_at": "2026-09-10T15:56:58.603139+00:00", "default_policy_specs": null, "description": "APIs internes de contrôle d'accès et de résolution des permissions.", "display_name": "Autorisation", "localized_descriptions": {}, "localized_display_names": {}, "realm": "default", "server_name": "default", "updated_at": "2026-09-10T15:56:58.603139+00:00"},
{"id": "client", "created_at": "2026-09-10T15:56:58.707374+00:00", "default_policy_specs": null, "description": "Client OAuth2/OIDC (application) - gestion des clients.", "display_name": "Client", "localized_descriptions": {}, "localized_display_names": {}, "realm": "default", "server_name": "default", "updated_at": "2026-09-10T15:56:58.707374+00:00"},
{"id": "openid-connect", "created_at": "2026-09-10T15:56:58.675130+00:00", "default_policy_specs": null, "description": "Scopes OIDC standard, indépendants de tout catalogue métier.", "display_name": "OpenID Connect", "localized_descriptions": {}, "localized_display_names": {}, "realm": "default", "server_name": "default", "updated_at": "2026-09-10T15:56:58.675130+00:00"},
{"id": "organization", "created_at": "2026-09-10T15:56:58.713802+00:00", "default_policy_specs": null, "description": "Organisation (compte multi-utilisateurs) - gestion des organisations.", "display_name": "Organisation", "localized_descriptions": {}, "localized_display_names": {}, "realm": "default", "server_name": "default", "updated_at": "2026-09-10T15:56:58.713802+00:00"},
{"id": "user", "created_at": "2026-09-10T15:56:58.699024+00:00", "default_policy_specs": null, "description": "Compte utilisateur (profil, préférences) - APIs self-service /me.", "display_name": "Utilisateur", "localized_descriptions": {}, "localized_display_names": {}, "realm": "default", "server_name": "default", "updated_at": "2026-09-10T15:56:58.699024+00:00"}
]$JSON$::jsonb)
ON CONFLICT ("id") DO NOTHING;
INSERT INTO public.scopes ("id", "created_at", "deprecated", "description", "display_name", "localized_descriptions", "localized_display_names", "managed", "realm", "resource_type", "server_name", "type", "updated_at")
SELECT "id", "created_at", "deprecated", "description", "display_name", "localized_descriptions", "localized_display_names", "managed", "realm", "resource_type", "server_name", "type", "updated_at" FROM jsonb_populate_recordset(NULL::public.scopes, $JSON$[
{"id": "address", "created_at": "2026-09-10T15:56:58.684266+00:00", "deprecated": false, "description": "Accès aux informations d'adresse de l'utilisateur.", "display_name": "Adresse", "localized_descriptions": {}, "localized_display_names": {}, "managed": false, "realm": "default", "resource_type": "openid-connect", "server_name": "default", "type": "HUMAN", "updated_at": "2026-09-10T15:56:58.684266+00:00"},
{"id": "auth.authorization.check", "created_at": "2026-09-10T15:56:58.654956+00:00", "deprecated": false, "description": "Autorise un resource server à appeler les APIs internes d'autorisation.", "display_name": "Vérifier les autorisations", "localized_descriptions": {}, "localized_display_names": {}, "managed": false, "realm": "default", "resource_type": "authorization", "server_name": "default", "type": "MACHINE", "updated_at": "2026-09-10T15:56:58.654956+00:00"},
{"id": "auth.authorization.policies.manage", "created_at": "2026-09-10T15:56:58.673371+00:00", "deprecated": false, "description": "Autorise un resource server à créer des ResourcePolicy pour les resources qu'il gère.", "display_name": "Gérer les policies", "localized_descriptions": {}, "localized_display_names": {}, "managed": false, "realm": "default", "resource_type": "authorization", "server_name": "default", "type": "MACHINE", "updated_at": "2026-09-10T15:56:58.673371+00:00"},
{"id": "client.read", "created_at": "2026-09-10T15:56:58.710171+00:00", "deprecated": false, "description": "Autorise la consultation des clients OAuth2/OIDC.", "display_name": "Lire les clients", "localized_descriptions": {}, "localized_display_names": {}, "managed": false, "realm": "default", "resource_type": "client", "server_name": "default", "type": "MACHINE", "updated_at": "2026-09-10T15:56:58.710171+00:00"},
{"id": "client.write", "created_at": "2026-09-10T15:56:58.711964+00:00", "deprecated": false, "description": "Autorise la création, modification et suppression des clients OAuth2/OIDC.", "display_name": "Gérer les clients", "localized_descriptions": {}, "localized_display_names": {}, "managed": false, "realm": "default", "resource_type": "client", "server_name": "default", "type": "MACHINE", "updated_at": "2026-09-10T15:56:58.711964+00:00"},
{"id": "email", "created_at": "2026-09-10T15:56:58.679241+00:00", "deprecated": false, "description": "Accès à l'adresse email de l'utilisateur et son statut de vérification.", "display_name": "Email", "localized_descriptions": {}, "localized_display_names": {}, "managed": false, "realm": "default", "resource_type": "openid-connect", "server_name": "default", "type": "HUMAN", "updated_at": "2026-09-10T15:56:58.679241+00:00"},
{"id": "offline_access", "created_at": "2026-09-10T15:56:58.685492+00:00", "deprecated": false, "description": "Autorise l'émission et l'utilisation d'un refresh token.", "display_name": "Accès hors ligne", "localized_descriptions": {}, "localized_display_names": {}, "managed": false, "realm": "default", "resource_type": "openid-connect", "server_name": "default", "type": "HUMAN", "updated_at": "2026-09-10T15:56:58.685492+00:00"},
{"id": "openid", "created_at": "2026-09-10T15:56:58.677587+00:00", "deprecated": false, "description": "Requis pour toute requête OIDC : identifie l'utilisateur (claim sub).", "display_name": "OpenID", "localized_descriptions": {}, "localized_display_names": {}, "managed": false, "realm": "default", "resource_type": "openid-connect", "server_name": "default", "type": "HUMAN", "updated_at": "2026-09-10T15:56:58.677587+00:00"},
{"id": "organization.read", "created_at": "2026-09-10T15:56:58.716547+00:00", "deprecated": false, "description": "Autorise la consultation des organisations.", "display_name": "Lire les organisations", "localized_descriptions": {}, "localized_display_names": {}, "managed": false, "realm": "default", "resource_type": "organization", "server_name": "default", "type": "HUMAN", "updated_at": "2026-09-10T15:56:58.716547+00:00"},
{"id": "organization.write", "created_at": "2026-09-10T15:56:58.717875+00:00", "deprecated": false, "description": "Autorise la création, modification et suppression des organisations.", "display_name": "Gérer les organisations", "localized_descriptions": {}, "localized_display_names": {}, "managed": false, "realm": "default", "resource_type": "organization", "server_name": "default", "type": "HUMAN", "updated_at": "2026-09-10T15:56:58.717875+00:00"},
{"id": "phone", "created_at": "2026-09-10T15:56:58.680857+00:00", "deprecated": false, "description": "Accès au numéro de téléphone de l'utilisateur et son statut de vérification.", "display_name": "Téléphone", "localized_descriptions": {}, "localized_display_names": {}, "managed": false, "realm": "default", "resource_type": "openid-connect", "server_name": "default", "type": "HUMAN", "updated_at": "2026-09-10T15:56:58.680857+00:00"},
{"id": "profile", "created_at": "2026-09-10T15:56:58.682880+00:00", "deprecated": false, "description": "Accès aux informations de profil de base de l'utilisateur.", "display_name": "Profil", "localized_descriptions": {}, "localized_display_names": {}, "managed": false, "realm": "default", "resource_type": "openid-connect", "server_name": "default", "type": "HUMAN", "updated_at": "2026-09-10T15:56:58.682880+00:00"},
{"id": "user.read", "created_at": "2026-09-10T15:56:58.701630+00:00", "deprecated": false, "description": "Autorise la lecture des informations de son propre compte utilisateur.", "display_name": "Lire son profil", "localized_descriptions": {}, "localized_display_names": {}, "managed": false, "realm": "default", "resource_type": "user", "server_name": "default", "type": "ANY", "updated_at": "2026-09-10T15:56:58.701630+00:00"},
{"id": "user.write", "created_at": "2026-09-10T15:56:58.704476+00:00", "deprecated": false, "description": "Autorise la modification des informations de son propre compte utilisateur.", "display_name": "Modifier son profil", "localized_descriptions": {}, "localized_display_names": {}, "managed": false, "realm": "default", "resource_type": "user", "server_name": "default", "type": "ANY", "updated_at": "2026-09-10T15:56:58.704476+00:00"}
]$JSON$::jsonb)
ON CONFLICT ("id") DO NOTHING;
INSERT INTO public.roles ("id", "created_at", "deprecated", "description", "display_name", "managed", "parents", "updated_at")
SELECT "id", "created_at", "deprecated", "description", "display_name", "managed", "parents", "updated_at" FROM jsonb_populate_recordset(NULL::public.roles, $JSON$[
{"id": "admin", "created_at": "2026-09-10T15:56:58.738846+00:00", "deprecated": false, "description": "Droits d'administration de la plateforme.", "display_name": "Administrateur", "managed": false, "parents": [], "updated_at": "2026-09-10T15:56:58.738846+00:00"},
{"id": "iam_admin", "created_at": "2026-09-10T15:56:58.740443+00:00", "deprecated": false, "description": "Droits d'administration des users, orgs, roles, policies.", "display_name": "Administrateur IAM", "managed": false, "parents": [], "updated_at": "2026-09-10T15:56:58.740443+00:00"},
{"id": "super_admin", "created_at": "2026-09-10T15:56:58.741807+00:00", "deprecated": false, "description": "Contrôle total de la plateforme.", "display_name": "Super administrateur", "managed": false, "parents": [], "updated_at": "2026-09-10T15:56:58.741807+00:00"},
{"id": "user", "created_at": "2026-09-10T15:56:58.721451+00:00", "deprecated": false, "description": "Utilisateur standard, sans droit d'administration.", "display_name": "Utilisateur", "managed": false, "parents": [], "updated_at": "2026-09-10T15:56:58.721451+00:00"}
]$JSON$::jsonb)
ON CONFLICT ("id") DO NOTHING;
INSERT INTO public.organization_system_role_definitions ("role_id", "activities", "created_at", "description", "name", "updated_at")
SELECT "role_id", "activities", "created_at", "description", "name", "updated_at" FROM jsonb_populate_recordset(NULL::public.organization_system_role_definitions, $JSON$[
{"role_id": "admin", "activities": [], "created_at": "2026-09-10T15:56:58.742889+00:00", "description": "Dispose des droits complets de gestion des données et opérations de l'organisation.", "name": "Administrator", "updated_at": "2026-09-10T15:56:58.742890+00:00"},
{"role_id": "dev", "activities": [], "created_at": "2026-09-10T15:56:58.742900+00:00", "description": "Accès aux ressources de développement, gestion des clients d'intégration et des configs.", "name": "Developer", "updated_at": "2026-09-10T15:56:58.742900+00:00"},
{"role_id": "guest", "activities": [], "created_at": "2026-09-10T15:56:58.742893+00:00", "description": "Rôle de base en lecture seule, sans accès prédéfini.", "name": "Guest", "updated_at": "2026-09-10T15:56:58.742893+00:00"},
{"role_id": "iam_admin", "activities": [], "created_at": "2026-09-10T15:56:58.742897+00:00", "description": "Gère les identités, les accès, les rôles et les membres de l'organisation (IAM).", "name": "IAM Administrator", "updated_at": "2026-09-10T15:56:58.742897+00:00"},
{"role_id": "super_admin", "activities": [], "created_at": "2026-09-10T15:56:58.742877+00:00", "description": "Propriétaire du compte. Détient le contrôle total de toutes les ressources et configurations.", "name": "Super Administrator", "updated_at": "2026-09-10T15:56:58.742877+00:00"}
]$JSON$::jsonb)
ON CONFLICT ("role_id") DO NOTHING;

-- ----------------------------------------------------------------------------
-- 2. Organisation CCA
-- ----------------------------------------------------------------------------
INSERT INTO public.organizations ("id", "created_at", "description", "login_code", "logo", "name", "rich_description", "status", "updated_at", "website_url")
SELECT "id", "created_at", "description", "login_code", "logo", "name", "rich_description", "status", "updated_at", "website_url" FROM jsonb_populate_recordset(NULL::public.organizations, $JSON$[
{"id": "0a2cc461-2674-4861-912a-0c624953ef64", "created_at": "2026-09-28T11:39:12.916299+00:00", "description": "Groupe CCA (holding) - tenant Fluxoon de CCA Bank", "login_code": "cca-holdinga1jq", "logo": null, "name": "CCA Holding", "rich_description": null, "status": "ENABLED", "updated_at": "2026-09-28T11:39:12.916299+00:00", "website_url": null}
]$JSON$::jsonb)
ON CONFLICT ("id") DO UPDATE SET "description" = EXCLUDED."description", "login_code" = EXCLUDED."login_code", "logo" = EXCLUDED."logo", "name" = EXCLUDED."name", "rich_description" = EXCLUDED."rich_description", "status" = EXCLUDED."status", "updated_at" = EXCLUDED."updated_at", "website_url" = EXCLUDED."website_url";
INSERT INTO public.organization_roles ("org_id", "role_id", "activities", "created_at", "description", "name", "system", "updated_at")
SELECT "org_id", "role_id", "activities", "created_at", "description", "name", "system", "updated_at" FROM jsonb_populate_recordset(NULL::public.organization_roles, $JSON$[
{"org_id": "0a2cc461-2674-4861-912a-0c624953ef64", "role_id": "admin", "activities": [], "created_at": "2026-09-28T11:39:12.916685+00:00", "description": "Dispose des droits complets de gestion des données et opérations de l'organisation.", "name": "Administrator", "system": true, "updated_at": "2026-09-28T11:39:12.916685+00:00"},
{"org_id": "0a2cc461-2674-4861-912a-0c624953ef64", "role_id": "dev", "activities": [], "created_at": "2026-09-28T11:39:12.916688+00:00", "description": "Accès aux ressources de développement, gestion des clients d'intégration et des configs.", "name": "Developer", "system": true, "updated_at": "2026-09-28T11:39:12.916688+00:00"},
{"org_id": "0a2cc461-2674-4861-912a-0c624953ef64", "role_id": "guest", "activities": [], "created_at": "2026-09-28T11:39:12.916686+00:00", "description": "Rôle de base en lecture seule, sans accès prédéfini.", "name": "Guest", "system": true, "updated_at": "2026-09-28T11:39:12.916686+00:00"},
{"org_id": "0a2cc461-2674-4861-912a-0c624953ef64", "role_id": "iam_admin", "activities": [], "created_at": "2026-09-28T11:39:12.916687+00:00", "description": "Gère les identités, les accès, les rôles et les membres de l'organisation (IAM).", "name": "IAM Administrator", "system": true, "updated_at": "2026-09-28T11:39:12.916687+00:00"},
{"org_id": "0a2cc461-2674-4861-912a-0c624953ef64", "role_id": "super_admin", "activities": [], "created_at": "2026-09-28T11:39:12.916661+00:00", "description": "Propriétaire du compte. Détient le contrôle total de toutes les ressources et configurations.", "name": "Super Administrator", "system": true, "updated_at": "2026-09-28T11:39:12.916661+00:00"}
]$JSON$::jsonb)
ON CONFLICT ("org_id", "role_id") DO UPDATE SET "activities" = EXCLUDED."activities", "description" = EXCLUDED."description", "name" = EXCLUDED."name", "system" = EXCLUDED."system", "updated_at" = EXCLUDED."updated_at";
INSERT INTO public.organization_groups ("group_id", "org_id", "created_at", "description", "external_ref", "external_source", "managed", "name", "parent_id", "roles", "status", "updated_at")
SELECT "group_id", "org_id", "created_at", "description", "external_ref", "external_source", "managed", "name", "parent_id", "roles", "status", "updated_at" FROM jsonb_populate_recordset(NULL::public.organization_groups, $JSON$[
{"group_id": "organization.legal-entity:CCA-BANK-CM", "org_id": "0a2cc461-2674-4861-912a-0c624953ef64", "created_at": "2026-09-28T13:09:11.567220+00:00", "description": "Filiale de CCA Holding", "external_ref": "CCA-BANK-CM", "external_source": "organization.legal-entity", "managed": true, "name": "CCA Bank Cameroun", "parent_id": "organization.legal-entity:ac7e700f-75af-4bfd-a44e-17a987b8c2e3", "roles": [], "status": "ACTIVE", "updated_at": "2026-09-28T13:09:11.567220+00:00"},
{"group_id": "organization.legal-entity:ac7e700f-75af-4bfd-a44e-17a987b8c2e3", "org_id": "0a2cc461-2674-4861-912a-0c624953ef64", "created_at": "2026-09-28T11:39:12.947677+00:00", "description": "Holding du groupe CCA", "external_ref": "ac7e700f-75af-4bfd-a44e-17a987b8c2e3", "external_source": "organization.legal-entity", "managed": true, "name": "CCA Holding", "parent_id": null, "roles": [], "status": "ACTIVE", "updated_at": "2026-09-28T11:39:12.947677+00:00"}
]$JSON$::jsonb)
ON CONFLICT ("group_id", "org_id") DO UPDATE SET "description" = EXCLUDED."description", "external_ref" = EXCLUDED."external_ref", "external_source" = EXCLUDED."external_source", "managed" = EXCLUDED."managed", "name" = EXCLUDED."name", "parent_id" = EXCLUDED."parent_id", "roles" = EXCLUDED."roles", "status" = EXCLUDED."status", "updated_at" = EXCLUDED."updated_at";

-- ----------------------------------------------------------------------------
-- 3. Premier administrateur (optionnel) - décommenter et renseigner l'id de l'utilisateur créé dans Fluxoon
-- ----------------------------------------------------------------------------
-- Dans le dump, l'administrateur CCA est l'utilisateur 3c4fbffc-b5bf-4e90-992b-e1c916503d93 (compte plateforme DHI).
-- Sur l'environnement CCA, remplacer par l'id du compte administrateur CCA une fois créé :
-- INSERT INTO public.organization_member_roles (org_id, user_id, created_at, updated_at, member_profiles, status)
-- VALUES ('0a2cc461-2674-4861-912a-0c624953ef64', '<USER_ID_ADMIN_CCA>', now(), now(), '{}', 'ACTIVE') ON CONFLICT DO NOTHING;
-- INSERT INTO public.organization_member_role_assignments (organization_member_entity_org_id, organization_member_entity_user_id, assigned_at, role_id)
-- VALUES ('0a2cc461-2674-4861-912a-0c624953ef64', '<USER_ID_ADMIN_CCA>', now(), 'super_admin') ON CONFLICT DO NOTHING;

COMMIT;

-- Contrôles après chargement (volumes attendus pour CCA)
SELECT 'organizations' t, count(*) FROM organizations WHERE id='0a2cc461-2674-4861-912a-0c624953ef64'   -- attendu 1
UNION ALL SELECT 'organization_roles', count(*) FROM organization_roles WHERE org_id='0a2cc461-2674-4861-912a-0c624953ef64'   -- attendu 5
UNION ALL SELECT 'organization_groups', count(*) FROM organization_groups WHERE org_id='0a2cc461-2674-4861-912a-0c624953ef64';  -- attendu 2
