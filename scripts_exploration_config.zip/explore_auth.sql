-- =====================================================================
--  EXPLORATION DE LA CONFIGURATION — microservice AUTH
--  Base : fluxoon_auth
--  À exécuter (pgAdmin/psql) EN ÉTANT CONNECTÉ À CETTE BASE.
--
--  Objectif : voir, après la configuration MANUELLE, ce qui est en place
--  (comptages) puis le contenu détaillé, pour fiabiliser les variables
--  globales et enchaîner sereinement les migrations.
--
--  Deux sections :
--   1) VUE D'ENSEMBLE : comptage EXACT de chaque table (onglet « Messages »).
--   2) CONTENU DÉTAILLÉ : un SELECT par table (à exécuter individuellement,
--      ou sélectionne un bloc et exécute-le).
--
-- =====================================================================

SET client_min_messages TO NOTICE;

-- ---------------------------------------------------------------------
-- 1) VUE D'ENSEMBLE : nombre de lignes par table (résultats dans « Messages »)
-- ---------------------------------------------------------------------
DO $$
DECLARE r record; c bigint; total bigint := 0; nempty int := 0; nfilled int := 0;
BEGIN
  RAISE NOTICE '=== fluxoon_auth : comptage des tables ===';
  FOR r IN
    SELECT table_name FROM information_schema.tables
    WHERE table_schema='public' AND table_type='BASE TABLE'
      AND table_name NOT IN ('flyway_schema_history')
    ORDER BY table_name
  LOOP
    EXECUTE format('SELECT count(*) FROM public.%I', r.table_name) INTO c;
    total := total + c;
    IF c = 0 THEN nempty := nempty + 1; ELSE nfilled := nfilled + 1; END IF;
    RAISE NOTICE '% : %', rpad(r.table_name, 48), c;
  END LOOP;
  RAISE NOTICE '---------------------------------------------';
  RAISE NOTICE 'Tables peuplees : %, vides : %, lignes totales : %', nfilled, nempty, total;
END $$;

-- ---------------------------------------------------------------------
-- 2) CONTENU DÉTAILLÉ : un SELECT par table
--    (exécute chaque requête individuellement pour voir sa grille)
-- ---------------------------------------------------------------------

-- ----- activity_groups -----
SELECT * FROM public.activity_groups;

-- ----- authorization_grants -----
SELECT * FROM public.authorization_grants;

-- ----- authorization_resource_policies -----
SELECT * FROM public.authorization_resource_policies;

-- ----- authorization_resources -----
SELECT * FROM public.authorization_resources;

-- ----- challenge -----
SELECT * FROM public.challenge;

-- ----- client_entity_scopes -----
SELECT * FROM public.client_entity_scopes;

-- ----- clients -----
SELECT * FROM public.clients;

-- ----- documents -----
SELECT * FROM public.documents;

-- ----- images -----
SELECT * FROM public.images;

-- ----- keys -----
SELECT * FROM public.keys;

-- ----- login_events -----
SELECT * FROM public.login_events;

-- ----- organization_access_approval_circuits -----
SELECT * FROM public.organization_access_approval_circuits;

-- ----- organization_access_catalog -----
SELECT * FROM public.organization_access_catalog;

-- ----- organization_access_certification_campaigns -----
SELECT * FROM public.organization_access_certification_campaigns;

-- ----- organization_access_certification_items -----
SELECT * FROM public.organization_access_certification_items;

-- ----- organization_access_request_decisions -----
SELECT * FROM public.organization_access_request_decisions;

-- ----- organization_access_request_items -----
SELECT * FROM public.organization_access_request_items;

-- ----- organization_access_request_resources -----
SELECT * FROM public.organization_access_request_resources;

-- ----- organization_access_requests -----
SELECT * FROM public.organization_access_requests;

-- ----- organization_activities -----
SELECT * FROM public.organization_activities;

-- ----- organization_groups -----
SELECT * FROM public.organization_groups;

-- ----- organization_invitations -----
SELECT * FROM public.organization_invitations;

-- ----- organization_member_group_assignments -----
SELECT * FROM public.organization_member_group_assignments;

-- ----- organization_member_profiles -----
SELECT * FROM public.organization_member_profiles;

-- ----- organization_member_role_assignments -----
SELECT * FROM public.organization_member_role_assignments;

-- ----- organization_member_roles -----
SELECT * FROM public.organization_member_roles;

-- ----- organization_permission_usages -----
SELECT * FROM public.organization_permission_usages;

-- ----- organization_role_delegations -----
SELECT * FROM public.organization_role_delegations;

-- ----- organization_roles -----
SELECT * FROM public.organization_roles;

-- ----- organization_security_policies -----
SELECT * FROM public.organization_security_policies;

-- ----- organization_segregation_rules -----
SELECT * FROM public.organization_segregation_rules;

-- ----- organization_segregation_violations -----
SELECT * FROM public.organization_segregation_violations;

-- ----- organization_system_role_definitions -----
SELECT * FROM public.organization_system_role_definitions;

-- ----- organization_temporary_access_grants -----
SELECT * FROM public.organization_temporary_access_grants;

-- ----- organizations -----
SELECT * FROM public.organizations;

-- ----- resource_policy_entity_authorized_actions -----
SELECT * FROM public.resource_policy_entity_authorized_actions;

-- ----- resource_policy_entity_related_resources -----
SELECT * FROM public.resource_policy_entity_related_resources;

-- ----- resource_servers -----
SELECT * FROM public.resource_servers;

-- ----- resource_types -----
SELECT * FROM public.resource_types;

-- ----- roles -----
SELECT * FROM public.roles;

-- ----- scopes -----
SELECT * FROM public.scopes;

-- ----- tokens -----
SELECT * FROM public.tokens;

-- ----- users -----
SELECT * FROM public.users;

-- ---------------------------------------------------------------------
-- (Option) Générer dynamiquement la liste des SELECT pour CE schéma réel
-- (utile si des tables diffèrent de cette version). Exécute, copie la
-- colonne, colle et exécute.
-- ---------------------------------------------------------------------
-- SELECT 'SELECT * FROM public.'||quote_ident(table_name)||';' AS requete
-- FROM information_schema.tables
-- WHERE table_schema='public' AND table_type='BASE TABLE'
--   AND table_name NOT IN ('flyway_schema_history')
-- ORDER BY table_name;
