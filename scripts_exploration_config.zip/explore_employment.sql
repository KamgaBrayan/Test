-- =====================================================================
--  EXPLORATION DE LA CONFIGURATION — microservice EMPLOYMENT
--  Base : fluxoon_employment
--  À exécuter (pgAdmin/psql) EN ÉTANT CONNECTÉ À CETTE BASE.
--
--  Objectif : voir, après la configuration MANUELLE, ce qui est en place
--  (comptages) puis le contenu détaillé, pour fiabiliser les variables
--  globales et enchaîner sereinement les migrations.
--
--  Deux sections :
--   1) VUE D'ENSEMBLE : comptage EXACT de chaque table (onglet « Messages »).
--   2) CONTENU DÉTAILLÉ : un SELECT par table (à exécuter individuellement,
--      ou sélectionne un bloc et exécute-le).
--
-- =====================================================================

SET client_min_messages TO NOTICE;

-- ---------------------------------------------------------------------
-- 1) VUE D'ENSEMBLE : nombre de lignes par table (résultats dans « Messages »)
-- ---------------------------------------------------------------------
DO $$
DECLARE r record; c bigint; total bigint := 0; nempty int := 0; nfilled int := 0;
BEGIN
  RAISE NOTICE '=== fluxoon_employment : comptage des tables ===';
  FOR r IN
    SELECT table_name FROM information_schema.tables
    WHERE table_schema='public' AND table_type='BASE TABLE'
      AND table_name NOT IN ('flyway_schema_history')
    ORDER BY table_name
  LOOP
    EXECUTE format('SELECT count(*) FROM public.%I', r.table_name) INTO c;
    total := total + c;
    IF c = 0 THEN nempty := nempty + 1; ELSE nfilled := nfilled + 1; END IF;
    RAISE NOTICE '% : %', rpad(r.table_name, 48), c;
  END LOOP;
  RAISE NOTICE '---------------------------------------------';
  RAISE NOTICE 'Tables peuplees : %, vides : %, lignes totales : %', nfilled, nempty, total;
END $$;

-- ---------------------------------------------------------------------
-- 2) CONTENU DÉTAILLÉ : un SELECT par table
--    (exécute chaque requête individuellement pour voir sa grille)
-- ---------------------------------------------------------------------

-- ----- companies_job_families -----
SELECT * FROM public.companies_job_families;

-- ----- companies_qualifications -----
SELECT * FROM public.companies_qualifications;

-- ----- companies_skills -----
SELECT * FROM public.companies_skills;

-- ----- company_conventions -----
SELECT * FROM public.company_conventions;

-- ----- company_skill_relations -----
SELECT * FROM public.company_skill_relations;

-- ----- company_titles -----
SELECT * FROM public.company_titles;

-- ----- convention_classifications -----
SELECT * FROM public.convention_classifications;

-- ----- convention_grades -----
SELECT * FROM public.convention_grades;

-- ----- convention_job_categories -----
SELECT * FROM public.convention_job_categories;

-- ----- conventions -----
SELECT * FROM public.conventions;

-- ----- employee_engagements -----
SELECT * FROM public.employee_engagements;

-- ----- employment_movements -----
SELECT * FROM public.employment_movements;

-- ----- employments -----
SELECT * FROM public.employments;

-- ----- graph_build_state_entity -----
SELECT * FROM public.graph_build_state_entity;

-- ----- graph_edges -----
SELECT * FROM public.graph_edges;

-- ----- graph_node_ancestor_units -----
SELECT * FROM public.graph_node_ancestor_units;

-- ----- graph_nodes -----
SELECT * FROM public.graph_nodes;

-- ----- headcount_gap_snapshots -----
SELECT * FROM public.headcount_gap_snapshots;

-- ----- job_descriptions -----
SELECT * FROM public.job_descriptions;

-- ----- job_families -----
SELECT * FROM public.job_families;

-- ----- job_positions -----
SELECT * FROM public.job_positions;

-- ----- management_relations -----
SELECT * FROM public.management_relations;

-- ----- movement_reasons -----
SELECT * FROM public.movement_reasons;

-- ----- position_graph_build_states -----
SELECT * FROM public.position_graph_build_states;

-- ----- position_graph_nodes -----
SELECT * FROM public.position_graph_nodes;

-- ----- proficiency_scales -----
SELECT * FROM public.proficiency_scales;

-- ----- workforce_plans -----
SELECT * FROM public.workforce_plans;

-- ---------------------------------------------------------------------
-- (Option) Générer dynamiquement la liste des SELECT pour CE schéma réel
-- (utile si des tables diffèrent de cette version). Exécute, copie la
-- colonne, colle et exécute.
-- ---------------------------------------------------------------------
-- SELECT 'SELECT * FROM public.'||quote_ident(table_name)||';' AS requete
-- FROM information_schema.tables
-- WHERE table_schema='public' AND table_type='BASE TABLE'
--   AND table_name NOT IN ('flyway_schema_history')
-- ORDER BY table_name;
