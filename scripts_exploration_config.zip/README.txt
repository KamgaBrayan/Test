SCRIPTS D'EXPLORATION DE LA CONFIGURATION FLUXOON
==================================================
Un script par microservice. À exécuter EN ÉTANT CONNECTÉ À LA BASE correspondante
(pgAdmin : ouvrir le Query Tool sur la bonne base ; psql : \c <base>).

Chaque script :
  1) VUE D'ENSEMBLE  -> bloc DO qui affiche le nb de lignes par table dans
     l'onglet « Messages » (comptage EXACT, dynamique = suit le schéma réel).
  2) CONTENU DÉTAILLÉ -> un SELECT * par table (exécuter individuellement).

Fichiers :
  explore_auth.sql          (fluxoon_auth)
  explore_organization.sql  (fluxoon_organization)
  explore_employee.sql      (fluxoon_employee) — tables de la migration employee EXCLUES
  explore_employment.sql    (fluxoon_employment)
  explore_time.sql          (fluxoon_time)      — liste issue du cluster de référence
  explore_contract.sql      (fluxoon_contract)  — idem

Le comptage (section 1) étant dynamique, il reflète TOUJOURS le schéma réellement
déployé, même si la liste des SELECT (section 2) diffère un peu. Utilise l'option
en bas de chaque script pour régénérer la liste exacte des SELECT si besoin.

Tables employee EXCLUES (déjà migrées) : employees, dependents, employee_identities,
employee_payment_accounts, employee_career_records, secondary_identifiers,
registration_number_assignments.
