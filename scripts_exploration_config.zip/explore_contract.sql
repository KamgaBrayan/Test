-- =====================================================================
--  EXPLORATION DE LA CONFIGURATION — microservice CONTRACT
--  Base : fluxoon_contract
--  À exécuter (pgAdmin/psql) EN ÉTANT CONNECTÉ À CETTE BASE.
--
--  Objectif : voir, après la configuration MANUELLE, ce qui est en place
--  (comptages) puis le contenu détaillé, pour fiabiliser les variables
--  globales et enchaîner sereinement les migrations.
--
--  Deux sections :
--   1) VUE D'ENSEMBLE : comptage EXACT de chaque table (onglet « Messages »).
--   2) CONTENU DÉTAILLÉ : un SELECT par table (à exécuter individuellement,
--      ou sélectionne un bloc et exécute-le).
--
-- =====================================================================

SET client_min_messages TO NOTICE;

-- ---------------------------------------------------------------------
-- 1) VUE D'ENSEMBLE : nombre de lignes par table (résultats dans « Messages »)
-- ---------------------------------------------------------------------
DO $$
DECLARE r record; c bigint; total bigint := 0; nempty int := 0; nfilled int := 0;
BEGIN
  RAISE NOTICE '=== fluxoon_contract : comptage des tables ===';
  FOR r IN
    SELECT table_name FROM information_schema.tables
    WHERE table_schema='public' AND table_type='BASE TABLE'
      AND table_name NOT IN ('flyway_schema_history')
    ORDER BY table_name
  LOOP
    EXECUTE format('SELECT count(*) FROM public.%I', r.table_name) INTO c;
    total := total + c;
    IF c = 0 THEN nempty := nempty + 1; ELSE nfilled := nfilled + 1; END IF;
    RAISE NOTICE '% : %', rpad(r.table_name, 48), c;
  END LOOP;
  RAISE NOTICE '---------------------------------------------';
  RAISE NOTICE 'Tables peuplees : %, vides : %, lignes totales : %', nfilled, nempty, total;
END $$;

-- ---------------------------------------------------------------------
-- 2) CONTENU DÉTAILLÉ : un SELECT par table
--    (exécute chaque requête individuellement pour voir sa grille)
-- ---------------------------------------------------------------------

-- ----- amendments -----
SELECT * FROM public.amendments;

-- ----- contract_suspensions -----
SELECT * FROM public.contract_suspensions;

-- ----- contracts -----
SELECT * FROM public.contracts;

-- ----- domain_events_outbox -----
SELECT * FROM public.domain_events_outbox;

-- ---------------------------------------------------------------------
-- (Option) Générer dynamiquement la liste des SELECT pour CE schéma réel
-- (utile si des tables diffèrent de cette version). Exécute, copie la
-- colonne, colle et exécute.
-- ---------------------------------------------------------------------
-- SELECT 'SELECT * FROM public.'||quote_ident(table_name)||';' AS requete
-- FROM information_schema.tables
-- WHERE table_schema='public' AND table_type='BASE TABLE'
--   AND table_name NOT IN ('flyway_schema_history')
-- ORDER BY table_name;
