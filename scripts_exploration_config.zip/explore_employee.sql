-- =====================================================================
--  EXPLORATION DE LA CONFIGURATION — microservice EMPLOYEE
--  Base : fluxoon_employee
--  À exécuter (pgAdmin/psql) EN ÉTANT CONNECTÉ À CETTE BASE.
--
--  Objectif : voir, après la configuration MANUELLE, ce qui est en place
--  (comptages) puis le contenu détaillé, pour fiabiliser les variables
--  globales et enchaîner sereinement les migrations.
--
--  Deux sections :
--   1) VUE D'ENSEMBLE : comptage EXACT de chaque table (onglet « Messages »).
--   2) CONTENU DÉTAILLÉ : un SELECT par table (à exécuter individuellement,
--      ou sélectionne un bloc et exécute-le).
--  NB : les tables déjà traitées par la migration employee sont EXCLUES.
-- =====================================================================

SET client_min_messages TO NOTICE;

-- ---------------------------------------------------------------------
-- 1) VUE D'ENSEMBLE : nombre de lignes par table (résultats dans « Messages »)
-- ---------------------------------------------------------------------
DO $$
DECLARE r record; c bigint; total bigint := 0; nempty int := 0; nfilled int := 0;
BEGIN
  RAISE NOTICE '=== fluxoon_employee : comptage des tables ===';
  FOR r IN
    SELECT table_name FROM information_schema.tables
    WHERE table_schema='public' AND table_type='BASE TABLE'
      AND table_name NOT IN ('dependents', 'employee_career_records', 'employee_identities', 'employee_payment_accounts', 'employees', 'flyway_schema_history', 'registration_number_assignments', 'secondary_identifiers')
    ORDER BY table_name
  LOOP
    EXECUTE format('SELECT count(*) FROM public.%I', r.table_name) INTO c;
    total := total + c;
    IF c = 0 THEN nempty := nempty + 1; ELSE nfilled := nfilled + 1; END IF;
    RAISE NOTICE '% : %', rpad(r.table_name, 48), c;
  END LOOP;
  RAISE NOTICE '---------------------------------------------';
  RAISE NOTICE 'Tables peuplees : %, vides : %, lignes totales : %', nfilled, nempty, total;
END $$;

-- ---------------------------------------------------------------------
-- 2) CONTENU DÉTAILLÉ : un SELECT par table
--    (exécute chaque requête individuellement pour voir sa grille)
-- ---------------------------------------------------------------------

-- ----- employee_affiliations -----
SELECT * FROM public.employee_affiliations;

-- ----- employee_profile_schemas -----
SELECT * FROM public.employee_profile_schemas;

-- ----- employee_scheme_classifications -----
SELECT * FROM public.employee_scheme_classifications;

-- ----- registration_number_formats -----
SELECT * FROM public.registration_number_formats;

-- ----- registration_number_sequences -----
SELECT * FROM public.registration_number_sequences;

-- ----- resource_assignments -----
SELECT * FROM public.resource_assignments;

-- ----- resource_categories -----
SELECT * FROM public.resource_categories;

-- ----- resource_maintenance_records -----
SELECT * FROM public.resource_maintenance_records;

-- ----- resources -----
SELECT * FROM public.resources;

-- ---------------------------------------------------------------------
-- (Option) Générer dynamiquement la liste des SELECT pour CE schéma réel
-- (utile si des tables diffèrent de cette version). Exécute, copie la
-- colonne, colle et exécute.
-- ---------------------------------------------------------------------
-- SELECT 'SELECT * FROM public.'||quote_ident(table_name)||';' AS requete
-- FROM information_schema.tables
-- WHERE table_schema='public' AND table_type='BASE TABLE'
--   AND table_name NOT IN ('dependents', 'employee_career_records', 'employee_identities', 'employee_payment_accounts', 'employees', 'flyway_schema_history', 'registration_number_assignments', 'secondary_identifiers')
-- ORDER BY table_name;
