-- =====================================================================
--  EXPLORATION DE LA CONFIGURATION — microservice TIME
--  Base : fluxoon_time
--  À exécuter (pgAdmin/psql) EN ÉTANT CONNECTÉ À CETTE BASE.
--
--  Objectif : voir, après la configuration MANUELLE, ce qui est en place
--  (comptages) puis le contenu détaillé, pour fiabiliser les variables
--  globales et enchaîner sereinement les migrations.
--
--  Deux sections :
--   1) VUE D'ENSEMBLE : comptage EXACT de chaque table (onglet « Messages »).
--   2) CONTENU DÉTAILLÉ : un SELECT par table (à exécuter individuellement,
--      ou sélectionne un bloc et exécute-le).
--
-- =====================================================================

SET client_min_messages TO NOTICE;

-- ---------------------------------------------------------------------
-- 1) VUE D'ENSEMBLE : nombre de lignes par table (résultats dans « Messages »)
-- ---------------------------------------------------------------------
DO $$
DECLARE r record; c bigint; total bigint := 0; nempty int := 0; nfilled int := 0;
BEGIN
  RAISE NOTICE '=== fluxoon_time : comptage des tables ===';
  FOR r IN
    SELECT table_name FROM information_schema.tables
    WHERE table_schema='public' AND table_type='BASE TABLE'
      AND table_name NOT IN ('flyway_schema_history')
    ORDER BY table_name
  LOOP
    EXECUTE format('SELECT count(*) FROM public.%I', r.table_name) INTO c;
    total := total + c;
    IF c = 0 THEN nempty := nempty + 1; ELSE nfilled := nfilled + 1; END IF;
    RAISE NOTICE '% : %', rpad(r.table_name, 48), c;
  END LOOP;
  RAISE NOTICE '---------------------------------------------';
  RAISE NOTICE 'Tables peuplees : %, vides : %, lignes totales : %', nfilled, nempty, total;
END $$;

-- ---------------------------------------------------------------------
-- 2) CONTENU DÉTAILLÉ : un SELECT par table
--    (exécute chaque requête individuellement pour voir sa grille)
-- ---------------------------------------------------------------------

-- ----- absence_exemption_policies -----
SELECT * FROM public.absence_exemption_policies;

-- ----- absence_records -----
SELECT * FROM public.absence_records;

-- ----- absence_requests -----
SELECT * FROM public.absence_requests;

-- ----- absence_types -----
SELECT * FROM public.absence_types;

-- ----- companies_holidays -----
SELECT * FROM public.companies_holidays;

-- ----- companies_movable_holidays -----
SELECT * FROM public.companies_movable_holidays;

-- ----- company_work_calendar_snapshots -----
SELECT * FROM public.company_work_calendar_snapshots;

-- ----- company_work_calendars -----
SELECT * FROM public.company_work_calendars;

-- ----- daily_time_reports -----
SELECT * FROM public.daily_time_reports;

-- ----- leave_balance_snapshots -----
SELECT * FROM public.leave_balance_snapshots;

-- ----- leave_events -----
SELECT * FROM public.leave_events;

-- ----- leave_requests -----
SELECT * FROM public.leave_requests;

-- ----- leave_type_configs -----
SELECT * FROM public.leave_type_configs;

-- ----- qrtz_blob_triggers -----
SELECT * FROM public.qrtz_blob_triggers;

-- ----- qrtz_calendars -----
SELECT * FROM public.qrtz_calendars;

-- ----- qrtz_cron_triggers -----
SELECT * FROM public.qrtz_cron_triggers;

-- ----- qrtz_fired_triggers -----
SELECT * FROM public.qrtz_fired_triggers;

-- ----- qrtz_job_details -----
SELECT * FROM public.qrtz_job_details;

-- ----- qrtz_locks -----
SELECT * FROM public.qrtz_locks;

-- ----- qrtz_paused_trigger_grps -----
SELECT * FROM public.qrtz_paused_trigger_grps;

-- ----- qrtz_scheduler_state -----
SELECT * FROM public.qrtz_scheduler_state;

-- ----- qrtz_simple_triggers -----
SELECT * FROM public.qrtz_simple_triggers;

-- ----- qrtz_simprop_triggers -----
SELECT * FROM public.qrtz_simprop_triggers;

-- ----- qrtz_triggers -----
SELECT * FROM public.qrtz_triggers;

-- ----- time_analysis_alerts -----
SELECT * FROM public.time_analysis_alerts;

-- ----- time_analysis_rule_actions -----
SELECT * FROM public.time_analysis_rule_actions;

-- ----- time_analysis_rule_entity_actions -----
SELECT * FROM public.time_analysis_rule_entity_actions;

-- ----- time_analysis_rules -----
SELECT * FROM public.time_analysis_rules;

-- ----- time_event_imports -----
SELECT * FROM public.time_event_imports;

-- ----- time_events -----
SELECT * FROM public.time_events;

-- ----- work_calendar_assignments -----
SELECT * FROM public.work_calendar_assignments;

-- ----- work_calendar_day_metadata_entity -----
SELECT * FROM public.work_calendar_day_metadata_entity;

-- ----- work_time_anomalies -----
SELECT * FROM public.work_time_anomalies;

-- ---------------------------------------------------------------------
-- (Option) Générer dynamiquement la liste des SELECT pour CE schéma réel
-- (utile si des tables diffèrent de cette version). Exécute, copie la
-- colonne, colle et exécute.
-- ---------------------------------------------------------------------
-- SELECT 'SELECT * FROM public.'||quote_ident(table_name)||';' AS requete
-- FROM information_schema.tables
-- WHERE table_schema='public' AND table_type='BASE TABLE'
--   AND table_name NOT IN ('flyway_schema_history')
-- ORDER BY table_name;
