"""Découverte automatique de la base Oracle -> classeur d'inventaire.

Découverte à DEUX NIVEAUX :
  1) SURVOL de TOUS les schémas applicatifs (hors schémas système Oracle) :
     nombre de tables par schéma + inventaire des objets par type. Léger.
  2) ANALYSE APPROFONDIE ciblée sur le(s) schéma(s) du SIRH (DELTARH par défaut,
     via ORACLE_SCHEMAS) : tables, colonnes enrichies, contraintes (dont les
     conditions CHECK = enums), FK colonne enfant->colonne parente, index et
     colonnes d'index, vues, séquences, triggers, procédures/packages,
     synonymes, dépendances, commentaires, et comptage réel des lignes.

Objectif : récupérer le maximum d'information structurelle pour préparer le
mapping et les transformations.

Robustesse : chaque volet est exécuté INDÉPENDAMMENT (un échec de droits/version
n'interrompt pas les autres) ; colonnes et contraintes tentent une version
enrichie (12c+) puis retombent sur une version de base.

Utilisation : rh-migration discover
"""
from __future__ import annotations

import logging
from pathlib import Path

from config.settings import REPORTS_DIR, settings

log = logging.getLogger("migration.discovery")

# Schémas Oracle « maintenus » à exclure de la découverte applicative.
SYSTEM_SCHEMAS = {
    "SYS", "SYSTEM", "OUTLN", "DBSNMP", "APPQOSSYS", "AUDSYS", "GSMADMIN_INTERNAL",
    "XDB", "WMSYS", "CTXSYS", "MDSYS", "ORDSYS", "ORDDATA", "ORDPLUGINS", "OLAPSYS",
    "SI_INFORMTN_SCHEMA", "LBACSYS", "DVSYS", "DVF", "OJVMSYS", "DBSFWUSER", "GGSYS",
    "ANONYMOUS", "XS$NULL", "SYSBACKUP", "SYSDG", "SYSKM", "SYSRAC", "SYS$UMF",
    "REMOTE_SCHEDULER_AGENT", "DIP", "ORACLE_OCM", "MDDATA", "SPATIAL_CSW_ADMIN_USR",
    "SPATIAL_WFS_ADMIN_USR", "GSMCATUSER", "GSMUSER", "PDBADMIN", "FLOWS_FILES",
}


def _is_application_schema(owner: str) -> bool:
    o = (owner or "").upper()
    if o in SYSTEM_SCHEMAS:
        return False
    if o.startswith("APEX_") or o.startswith("FLOWS_"):
        return False
    return True


# --- SURVOL (tous schémas) --------------------------------------------------
OBJECT_OVERVIEW = """
    SELECT owner, object_type, COUNT(*) AS object_count
    FROM all_objects WHERE owner = :owner
    GROUP BY owner, object_type ORDER BY object_type
"""

# --- APPROFONDI (schéma cible), un :owner à la fois ------------------------
DEEP_QUERIES: dict[str, str] = {
    "tables": """
        SELECT owner, table_name, num_rows, tablespace_name,
               partitioned, temporary, last_analyzed
        FROM all_tables WHERE owner = :owner ORDER BY table_name
    """,
    "foreign_keys": """
        SELECT c.owner, c.table_name AS child_table, cc.column_name AS child_column,
               cc.position, c.constraint_name,
               rc.owner AS parent_owner, rc.table_name AS parent_table,
               rcc.column_name AS parent_column, c.delete_rule
        FROM all_constraints c
        JOIN all_cons_columns cc
          ON c.owner = cc.owner AND c.constraint_name = cc.constraint_name
        JOIN all_constraints rc
          ON c.r_owner = rc.owner AND c.r_constraint_name = rc.constraint_name
        JOIN all_cons_columns rcc
          ON rc.owner = rcc.owner AND rc.constraint_name = rcc.constraint_name
         AND rcc.position = cc.position
        WHERE c.owner = :owner AND c.constraint_type = 'R'
        ORDER BY c.table_name, c.constraint_name, cc.position
    """,
    "indexes": """
        SELECT owner, index_name, table_name, uniqueness, index_type, status
        FROM all_indexes WHERE owner = :owner ORDER BY table_name, index_name
    """,
    "index_columns": """
        SELECT index_owner, index_name, table_owner, table_name,
               column_name, column_position, descend
        FROM all_ind_columns WHERE table_owner = :owner
        ORDER BY table_name, index_name, column_position
    """,
    "views": """
        SELECT owner, view_name, text_length
        FROM all_views WHERE owner = :owner ORDER BY view_name
    """,
    "sequences": """
        SELECT sequence_owner, sequence_name, min_value, max_value,
               increment_by, cycle_flag, order_flag, last_number
        FROM all_sequences WHERE sequence_owner = :owner ORDER BY sequence_name
    """,
    "triggers": """
        SELECT owner, trigger_name, table_owner, table_name,
               triggering_event, trigger_type, status
        FROM all_triggers WHERE owner = :owner ORDER BY table_name, trigger_name
    """,
    "procedures": """
        SELECT owner, object_name, procedure_name, object_type, aggregate, pipelined
        FROM all_procedures WHERE owner = :owner ORDER BY object_name, procedure_name
    """,
    "synonyms": """
        SELECT owner, synonym_name, table_owner, table_name, db_link
        FROM all_synonyms WHERE owner = :owner ORDER BY synonym_name
    """,
    "dependencies": """
        SELECT owner, name, type, referenced_owner, referenced_name, referenced_type
        FROM all_dependencies WHERE owner = :owner ORDER BY name, type
    """,
    "table_comments": """
        SELECT owner, table_name, comments
        FROM all_tab_comments WHERE owner = :owner AND comments IS NOT NULL
        ORDER BY table_name
    """,
    "column_comments": """
        SELECT owner, table_name, column_name, comments
        FROM all_col_comments WHERE owner = :owner AND comments IS NOT NULL
        ORDER BY table_name, column_name
    """,
}

# Colonnes : enrichi (12c+) puis repli
COLUMNS_ENRICHED = """
    SELECT owner, table_name, column_id, column_name, data_type,
           data_length, char_length, char_used,
           data_precision, data_scale, nullable, data_default,
           identity_column, virtual_column, hidden_column
    FROM all_tab_columns WHERE owner = :owner
    ORDER BY table_name, column_id
"""
COLUMNS_BASIC = """
    SELECT owner, table_name, column_id, column_name, data_type,
           data_length, char_length, char_used,
           data_precision, data_scale, nullable, data_default
    FROM all_tab_columns WHERE owner = :owner
    ORDER BY table_name, column_id
"""

# Contraintes : version avec la condition CHECK en VARCHAR (12c+, = enums) puis repli.
# search_condition est de type LONG (délicat à lire) ; search_condition_vc évite le souci.
CONSTRAINTS_VC = """
    SELECT c.owner, c.table_name, c.constraint_name, c.constraint_type,
           cc.column_name, cc.position, c.status, c.search_condition_vc AS search_condition
    FROM all_constraints c
    JOIN all_cons_columns cc
      ON c.owner = cc.owner AND c.constraint_name = cc.constraint_name
    WHERE c.owner = :owner AND c.constraint_type IN ('P','U','C')
    ORDER BY c.table_name, c.constraint_name, cc.position
"""
CONSTRAINTS_BASIC = """
    SELECT c.owner, c.table_name, c.constraint_name, c.constraint_type,
           cc.column_name, cc.position, c.status
    FROM all_constraints c
    JOIN all_cons_columns cc
      ON c.owner = cc.owner AND c.constraint_name = cc.constraint_name
    WHERE c.owner = :owner AND c.constraint_type IN ('P','U','C')
    ORDER BY c.table_name, c.constraint_name, cc.position
"""


def _detect_app_schemas(pd, conn):
    """Retourne (app_owners, candidates_df) : tous les schémas applicatifs et
    leur nombre de tables (survol)."""
    candidates = pd.read_sql(
        "SELECT owner, COUNT(*) AS table_count FROM all_tables "
        "GROUP BY owner ORDER BY table_count DESC", conn)
    if not candidates.empty:
        candidates = candidates[candidates["owner"].apply(_is_application_schema)]
        candidates = candidates.reset_index(drop=True)
    app_owners = candidates["owner"].tolist() if not candidates.empty else []
    return app_owners, candidates


def _run_per_owner(pd, conn, sql: str, owners: list[str]):
    frames = []
    for owner in owners:
        try:
            frames.append(pd.read_sql(sql, conn, params={"owner": owner}))
        except Exception as e:  # noqa: BLE001
            log.warning(f"échec sur le schéma {owner}: {e}")
    return pd.concat(frames, ignore_index=True) if frames else pd.DataFrame()


def _run_with_fallback(pd, conn, primary: str, fallback: str, owners: list[str], label: str):
    df = _run_per_owner(pd, conn, primary, owners)
    if df.empty and owners:
        log.warning(f"{label}: version enrichie indisponible, repli basique.")
        df = _run_per_owner(pd, conn, fallback, owners)
    return df


def run_discovery(output: str | Path | None = None) -> Path:
    import pandas as pd  # import paresseux

    from ..database.oracle import get_engine

    engine = get_engine()
    output = Path(output) if output else REPORTS_DIR / "oracle_inventory.xlsx"
    output.parent.mkdir(parents=True, exist_ok=True)

    frames: dict[str, "pd.DataFrame"] = {}

    with engine.connect() as conn:
        # Identité de connexion
        frames["connection"] = pd.read_sql(
            """SELECT SYS_CONTEXT('USERENV','DB_NAME') AS db_name,
                      SYS_CONTEXT('USERENV','INSTANCE_NAME') AS instance_name,
                      SYS_CONTEXT('USERENV','SERVICE_NAME') AS service_name,
                      SYS_CONTEXT('USERENV','CURRENT_SCHEMA') AS current_schema,
                      SYS_CONTEXT('USERENV','SESSION_USER') AS session_user
               FROM dual""", conn)

        # --- NIVEAU 1 : SURVOL (tous les schémas applicatifs) ---
        app_owners, candidates = _detect_app_schemas(pd, conn)
        frames["schema_candidates"] = candidates
        frames["object_overview"] = _run_per_owner(pd, conn, OBJECT_OVERVIEW, app_owners)

        # --- NIVEAU 2 : APPROFONDI (schéma cible = ORACLE_SCHEMAS, sinon tous) ---
        deep = settings.oracle_schema_list or app_owners
        frames["deep_scope"] = pd.DataFrame({"deep_schemas": deep or ["(aucun)"]})
        log.info("découverte", extra={"phase": "discover",
                 "count": len(deep)})
        if not deep:
            log.warning("Aucun schéma à approfondir. Vérifie les droits ou ORACLE_SCHEMAS.")

        frames["columns"] = _run_with_fallback(
            pd, conn, COLUMNS_ENRICHED, COLUMNS_BASIC, deep, "colonnes")
        frames["constraints"] = _run_with_fallback(
            pd, conn, CONSTRAINTS_VC, CONSTRAINTS_BASIC, deep, "contraintes")

        for name, sql in DEEP_QUERIES.items():
            frames[name] = _run_per_owner(pd, conn, sql, deep)

        # Comptage réel des lignes (schéma approfondi uniquement)
        counts = []
        tbls = frames.get("tables")
        if tbls is not None and "table_name" in getattr(tbls, "columns", []):
            for _, r in tbls.iterrows():
                fq = f'"{r["owner"]}"."{r["table_name"]}"'
                try:
                    n = conn.exec_driver_sql(f"SELECT COUNT(*) FROM {fq}").scalar()
                except Exception as e:  # noqa: BLE001
                    n = f"ERREUR: {e}"
                counts.append({"owner": r["owner"], "table_name": r["table_name"],
                               "row_count": n})
        frames["row_counts"] = pd.DataFrame(counts)

    # Onglet de synthèse en tête
    summary_rows = [{"volet": k, "lignes": (0 if v is None else len(v))}
                    for k, v in frames.items()]
    frames_out = {"discovery_summary": pd.DataFrame(summary_rows)}
    frames_out.update(frames)

    with pd.ExcelWriter(output, engine="openpyxl") as writer:
        for name, df in frames_out.items():
            df.to_excel(writer, sheet_name=name[:31], index=False)

    log.info("inventaire écrit", extra={"phase": "discover"})
    return output
