# RH Migration Engine — Oracle (Amplitude) → PostgreSQL (Fluxoon)

Moteur de migration RH **modulaire, testable et livrable au client**. Développé
sur données de test, exécuté par le client sur ses données réelles.

> Cible = cluster de **8 bases PostgreSQL** (microservices Fluxoon), multi-tenant,
> clés-chaînes, peu de FK inter-bases, 377 enums `CHECK`, colonnes `jsonb`.
> Voir `docs/architecture.md`.
>
> **Nouveau au projet ?** Lis d'abord `docs/GUIDE_PARCOURS.md` : un parcours
> guidé de chaque fichier dans la chronologie réelle d'une migration.

## Démarrage rapide

```bash
python -m venv .venv
source .venv/bin/activate            # Windows : .venv\Scripts\Activate.ps1
pip install -r requirements-dev.txt
pip install -e .                     # installe la commande `rh-migration`

cp .env.example .env                 # puis renseigne les identifiants

rh-migration lint-mapping            # vérifie les mappings contre le catalogue cible
rh-migration discover                # explore Oracle -> reports/oracle_inventory.xlsx
```

Sans installation (`pip install -e .`), on peut aussi lancer :
```bash
PYTHONPATH=src python -m migration.cli lint-mapping
```

## Structure

```
config/            # settings (.env), logging JSON, ordre de chargement
catalog/           # CONTRAT cible : schema_catalog.json (+ YAML par domaine)
mappings/          # mappings déclaratifs (YAML) + enums/ (correspondances de valeurs)
sql/discovery/     # scripts SQL de découverte Oracle (SQL Developer)
sql_ddl/           # DDL des tables de contrôle (run, error, crosswalk)
src/migration/
  ├─ catalog/        # chargeur du catalogue cible
  ├─ database/       # connexions Oracle / staging / cible
  ├─ discovery/      # inventaire Oracle automatique
  ├─ extraction/     # Oracle -> staging (à compléter)
  ├─ transformation/ # converters, lookups, json_assembler, mapper
  ├─ validation/     # catalog_validator, mapping_linter, business, reconciliation
  ├─ crosswalk/      # correspondance des clés source -> cible
  ├─ loading/        # chargement PostgreSQL (à compléter)
  ├─ reporting/      # rapport de migration
  ├─ errors.py       # modèle d'erreurs structuré
  ├─ context.py      # contexte d'un run (run_id, mode, logger, erreurs)
  └─ cli.py          # point d'entrée (verbes)
tests/             # tests unitaires du cœur
docs/              # architecture + cadrage
```

## Commandes

| Commande | État | Rôle |
|----------|------|------|
| `lint-mapping` | ✅ | Vérifie les mappings contre le catalogue |
| `discover` | ✅ | Inventaire Oracle complet (structure + logique applicative + commentaires) |
| `stage` | ⏳ | Extraction Oracle → staging |
| `validate` | ⏳ | Validation d'un lot contre le contrat cible |
| `dry-run` | ⏳ | Pipeline complet sans écriture |
| `execute` | ⏳ | Migration réelle |
| `report` / `reconcile` | ⏳ | Rapport & réconciliation |

✅ = fonctionnel · ⏳ = à compléter après l'exploration Oracle (stubs balisés).

## Ce que le cœur fait déjà (testé)
- Chargement du **catalogue cible** en objets typés.
- **Validation pilotée par le catalogue** : NOT NULL, longueur `varchar`,
  précision numérique, appartenance aux **enums**.
- **Convertisseurs** de transformation (trim, casse, dates, cast…).
- **Mapper déclaratif** (dont `lookup` et `json_object`).
- **Linter de mapping** (cohérence mapping ↔ catalogue ↔ enums).

## Découverte Oracle (étape 1) — prête à l'emploi

Le `.env` est déjà renseigné (source Oracle CCA, schéma **`DELTARH`**). La découverte
se fait à **deux niveaux** : un **survol** de tous les schémas (`schema_candidates`,
`object_overview`) puis une **analyse approfondie de `DELTARH`**.

```
rh-migration discover        # -> reports/oracle_inventory.xlsx
```

L'approfondi couvre : tables, **colonnes enrichies**, contraintes (dont **conditions
CHECK = enums**), **FK colonne enfant→colonne parente**, index et colonnes d'index,
vues, séquences, triggers, procédures/packages, synonymes, dépendances, **commentaires**
de tables/colonnes, et le **comptage réel** des lignes. Chaque volet est indépendant
(un échec de droits/version n'interrompt pas les autres). Alternative sans Python :
`sql/discovery/discovery_all_in_one.sql`. Détail : `sql/discovery/README.md`.

## Tests
```bash
pytest
```

## Convention de contribution
- Un mapping = un fichier YAML ; jamais de logique métier en dur dans le moteur.
- `rh-migration lint-mapping` doit passer sans erreur avant tout commit de mapping.
- Formatage : `ruff format` / `black` ; lint : `ruff check`.
