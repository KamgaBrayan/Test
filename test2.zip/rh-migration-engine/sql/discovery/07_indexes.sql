-- Index : unicité et type (repère les index sur clés métier et colonnes de jointure).
DEFINE SCHEMA = DELTARH
SELECT owner, index_name, table_name, uniqueness, index_type, status
FROM all_indexes
WHERE owner = '&SCHEMA'
ORDER BY table_name, index_name;
