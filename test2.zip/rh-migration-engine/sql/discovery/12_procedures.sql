-- Programmes stockés : packages, procédures, fonctions. On inventorie leur existence
-- (pas leur code) pour cerner la logique applicative embarquée dans la base.
DEFINE SCHEMA = DELTARH
SELECT owner, object_name, procedure_name, object_type,
       aggregate, pipelined
FROM all_procedures
WHERE owner = '&SCHEMA'
ORDER BY object_name, procedure_name;
