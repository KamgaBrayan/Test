-- =====================================================================
--  DÉCOUVERTE ORACLE — SCRIPT CONSOLIDÉ TOUT-EN-UN
--  SIRH Amplitude -> migration vers Fluxoon
--
--  CONTEXTE : le compte de connexion ne possède aucune table ; les objets
--  applicatifs se trouvent dans D'AUTRES schémas (« Autres utilisateurs »).
--  Ce script (1) identifie les schémas candidats, puis (2) analyse TOUS les
--  schémas applicatifs à la fois — en excluant les schémas système Oracle.
--
--  COMMENT L'EXÉCUTER
--  ------------------
--  Option recommandée : SQLcl (livré avec SQL Developer), sortie CSV garantie
--      sql UTILISATEUR/MDP@HOTE:1521/SERVICE
--      @discovery_all_in_one.sql
--  Ou dans SQL Developer : ouvrir le fichier puis « Run Script » (F5).
--
--  RÉGLAGES (2 lignes à adapter ci-dessous)
--  ----------------------------------------
--   OUT   : dossier de sortie des fichiers CSV.
--   FOCUS : 'ALL' pour analyser tous les schémas applicatifs.
--           Pré-réglé sur 'DELTARH' (schéma du SIRH CCA). Mets 'ALL' pour
--           approfondir tous les schémas, ou un autre nom pour cibler ailleurs.
--
--  DROITS : ce script lit les vues ALL_* (objets visibles par ton compte).
--           Si tu disposes du rôle DBA et que certains schémas restent
--           invisibles, remplace ALL_ par DBA_ (mêmes colonnes).
-- =====================================================================

DEFINE OUT   = C:\migration\inventory
DEFINE FOCUS = DELTARH

-- Liste des schémas système Oracle à exclure (objets non applicatifs).
DEFINE SYSEXCL = "'SYS','SYSTEM','OUTLN','DBSNMP','APPQOSSYS','AUDSYS','GSMADMIN_INTERNAL','XDB','WMSYS','CTXSYS','MDSYS','ORDSYS','ORDDATA','ORDPLUGINS','OLAPSYS','SI_INFORMTN_SCHEMA','LBACSYS','DVSYS','DVF','OJVMSYS','DBSFWUSER','GGSYS','ANONYMOUS','XS$NULL','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYS$UMF','REMOTE_SCHEDULER_AGENT','DIP','ORACLE_OCM','MDDATA','SPATIAL_CSW_ADMIN_USR','SPATIAL_WFS_ADMIN_USR','GSMCATUSER','GSMUSER','PDBADMIN','FLOWS_FILES'"

SET SQLFORMAT csv
SET SERVEROUTPUT ON SIZE UNLIMITED
SET FEEDBACK OFF
SET PAGESIZE 0
SET LINESIZE 32767
SET TRIMSPOOL ON
SET VERIFY OFF

PROMPT ================= 00 : Schemas candidats (ou sont les tables ?) =================
SPOOL &OUT\00_schema_candidates.csv
-- Nombre de tables par schema (hors schemas systeme). Le SIRH ressort par son
-- volume de tables. C'est CETTE liste qui te dit quel FOCUS choisir ensuite.
SELECT owner,
       COUNT(*) AS table_count
FROM all_tables
WHERE owner NOT IN (&SYSEXCL)
  AND owner NOT LIKE 'APEX\_%' ESCAPE '\'
  AND owner NOT LIKE 'FLOWS\_%' ESCAPE '\'
GROUP BY owner
ORDER BY table_count DESC;
SPOOL OFF

PROMPT ================= 01 : Connexion =================
SPOOL &OUT\01_connection.csv
SELECT SYS_CONTEXT('USERENV','DB_NAME')        AS db_name,
       SYS_CONTEXT('USERENV','INSTANCE_NAME')  AS instance_name,
       SYS_CONTEXT('USERENV','SERVICE_NAME')   AS service_name,
       SYS_CONTEXT('USERENV','CURRENT_SCHEMA') AS current_schema,
       SYS_CONTEXT('USERENV','SESSION_USER')   AS session_user
FROM dual;
SPOOL OFF

PROMPT ================= 02 : Survol des objets par schema et type (TOUS schemas) =================
SPOOL &OUT\02_object_overview.csv
-- SURVOL : inventaire des objets par type sur TOUS les schemas applicatifs
-- (ne depend pas de FOCUS). Donne une vision d'ensemble avant l'approfondissement.
SELECT owner, object_type, COUNT(*) AS object_count
FROM all_objects
WHERE owner NOT IN (&SYSEXCL)
  AND owner NOT LIKE 'APEX\_%' ESCAPE '\'
GROUP BY owner, object_type
ORDER BY owner, object_type;
SPOOL OFF

PROMPT ================= 03 : Tables =================
SPOOL &OUT\03_tables.csv
SELECT owner, table_name, num_rows, tablespace_name,
       partitioned, temporary, last_analyzed
FROM all_tables
WHERE owner NOT IN (&SYSEXCL)
  AND ('&FOCUS' = 'ALL' OR owner = '&FOCUS')
ORDER BY owner, table_name;
SPOOL OFF

PROMPT ================= 04 : Colonnes =================
-- IDENTITY_COLUMN / VIRTUAL_COLUMN / HIDDEN_COLUMN : Oracle 12c+.
-- Sur une version anterieure, retire ces trois colonnes de la requete.
SPOOL &OUT\04_columns.csv
SELECT owner, table_name, column_id, column_name, data_type,
       data_length, char_length, char_used,
       data_precision, data_scale, nullable, data_default,
       identity_column, virtual_column, hidden_column
FROM all_tab_columns
WHERE owner NOT IN (&SYSEXCL)
  AND ('&FOCUS' = 'ALL' OR owner = '&FOCUS')
ORDER BY owner, table_name, column_id;
SPOOL OFF

PROMPT ================= 05 : Contraintes PK / UK / CHECK =================
SPOOL &OUT\05_constraints.csv
SELECT c.owner, c.table_name, c.constraint_name, c.constraint_type,
       cc.column_name, cc.position, c.status, c.search_condition_vc AS search_condition
FROM all_constraints c
JOIN all_cons_columns cc
  ON c.owner = cc.owner AND c.constraint_name = cc.constraint_name
WHERE c.owner NOT IN (&SYSEXCL)
  AND ('&FOCUS' = 'ALL' OR c.owner = '&FOCUS')
  AND c.constraint_type IN ('P','U','C')
ORDER BY c.owner, c.table_name, c.constraint_name, cc.position;
SPOOL OFF

PROMPT ================= 06 : Cles etrangeres (colonne enfant -> colonne parente) =================
SPOOL &OUT\06_foreign_keys.csv
SELECT c.owner,
       c.table_name    AS child_table,
       cc.column_name  AS child_column,
       cc.position,
       c.constraint_name,
       rc.owner        AS parent_owner,
       rc.table_name   AS parent_table,
       rcc.column_name AS parent_column,
       c.delete_rule
FROM all_constraints c
JOIN all_cons_columns cc
  ON c.owner = cc.owner AND c.constraint_name = cc.constraint_name
JOIN all_constraints rc
  ON c.r_owner = rc.owner AND c.r_constraint_name = rc.constraint_name
JOIN all_cons_columns rcc
  ON rc.owner = rcc.owner AND rc.constraint_name = rcc.constraint_name
 AND rcc.position = cc.position
WHERE c.owner NOT IN (&SYSEXCL)
  AND ('&FOCUS' = 'ALL' OR c.owner = '&FOCUS')
  AND c.constraint_type = 'R'
ORDER BY c.owner, c.table_name, c.constraint_name, cc.position;
SPOOL OFF

PROMPT ================= 07 : Index =================
SPOOL &OUT\07_indexes.csv
SELECT owner, index_name, table_name, uniqueness, index_type, status
FROM all_indexes
WHERE owner NOT IN (&SYSEXCL)
  AND ('&FOCUS' = 'ALL' OR owner = '&FOCUS')
ORDER BY owner, table_name, index_name;
SPOOL OFF

PROMPT ================= 08 : Colonnes d'index =================
SPOOL &OUT\08_index_columns.csv
SELECT index_owner, index_name, table_owner, table_name,
       column_name, column_position, descend
FROM all_ind_columns
WHERE table_owner NOT IN (&SYSEXCL)
  AND ('&FOCUS' = 'ALL' OR table_owner = '&FOCUS')
ORDER BY table_owner, table_name, index_name, column_position;
SPOOL OFF

PROMPT ================= 09 : Vues =================
SPOOL &OUT\09_views.csv
SELECT owner, view_name, text_length
FROM all_views
WHERE owner NOT IN (&SYSEXCL)
  AND ('&FOCUS' = 'ALL' OR owner = '&FOCUS')
ORDER BY owner, view_name;
SPOOL OFF

PROMPT ================= 10 : Sequences =================
SPOOL &OUT\10_sequences.csv
SELECT sequence_owner, sequence_name, min_value, max_value,
       increment_by, cycle_flag, order_flag, last_number
FROM all_sequences
WHERE sequence_owner NOT IN (&SYSEXCL)
  AND ('&FOCUS' = 'ALL' OR sequence_owner = '&FOCUS')
ORDER BY sequence_owner, sequence_name;
SPOOL OFF

PROMPT ================= 11 : Triggers =================
SPOOL &OUT\11_triggers.csv
SELECT owner, trigger_name, table_owner, table_name,
       triggering_event, trigger_type, status
FROM all_triggers
WHERE owner NOT IN (&SYSEXCL)
  AND ('&FOCUS' = 'ALL' OR owner = '&FOCUS')
ORDER BY owner, table_name, trigger_name;
SPOOL OFF

PROMPT ================= 12 : Procedures / Fonctions / Packages =================
SPOOL &OUT\12_procedures.csv
SELECT owner, object_name, procedure_name, object_type, aggregate, pipelined
FROM all_procedures
WHERE owner NOT IN (&SYSEXCL)
  AND ('&FOCUS' = 'ALL' OR owner = '&FOCUS')
ORDER BY owner, object_name, procedure_name;
SPOOL OFF

PROMPT ================= 13 : Synonymes =================
SPOOL &OUT\13_synonyms.csv
SELECT owner, synonym_name, table_owner, table_name, db_link
FROM all_synonyms
WHERE owner NOT IN (&SYSEXCL)
  AND ('&FOCUS' = 'ALL' OR owner = '&FOCUS')
ORDER BY owner, synonym_name;
SPOOL OFF

PROMPT ================= 14 : Dependances =================
SPOOL &OUT\14_dependencies.csv
SELECT owner, name, type, referenced_owner, referenced_name, referenced_type
FROM all_dependencies
WHERE owner NOT IN (&SYSEXCL)
  AND ('&FOCUS' = 'ALL' OR owner = '&FOCUS')
ORDER BY owner, name, type;
SPOOL OFF

PROMPT ================= 15 : Commentaires de tables =================
SPOOL &OUT\15_table_comments.csv
SELECT owner, table_name, comments
FROM all_tab_comments
WHERE owner NOT IN (&SYSEXCL)
  AND ('&FOCUS' = 'ALL' OR owner = '&FOCUS')
  AND comments IS NOT NULL
ORDER BY owner, table_name;
SPOOL OFF

PROMPT ================= 16 : Commentaires de colonnes =================
SPOOL &OUT\16_column_comments.csv
SELECT owner, table_name, column_name, comments
FROM all_col_comments
WHERE owner NOT IN (&SYSEXCL)
  AND ('&FOCUS' = 'ALL' OR owner = '&FOCUS')
  AND comments IS NOT NULL
ORDER BY owner, table_name, column_name;
SPOOL OFF

PROMPT ================= 17 : Comptage reel des lignes (par schema.table) =================
-- Bloc PL/SQL : COUNT(*) dynamique sur chaque table des schemas retenus.
SPOOL &OUT\17_row_counts.txt
DECLARE
  v_count NUMBER;
BEGIN
  DBMS_OUTPUT.PUT_LINE('OWNER,TABLE_NAME,ROW_COUNT');
  FOR t IN (
    SELECT owner, table_name
    FROM all_tables
    WHERE owner NOT IN (&SYSEXCL)
      AND ('&FOCUS' = 'ALL' OR owner = '&FOCUS')
    ORDER BY owner, table_name
  ) LOOP
    BEGIN
      EXECUTE IMMEDIATE
        'SELECT COUNT(*) FROM "'||t.owner||'"."'||t.table_name||'"' INTO v_count;
      DBMS_OUTPUT.PUT_LINE(t.owner||','||t.table_name||','||v_count);
    EXCEPTION WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE(t.owner||','||t.table_name||',ERREUR '||SQLERRM);
    END;
  END LOOP;
END;
/
SPOOL OFF

PROMPT ================================================================
PROMPT  Termine. Verifie d'abord 00_schema_candidates.csv :
PROMPT  identifie le schema du SIRH, puis (facultatif) renseigne DEFINE FOCUS
PROMPT  avec son nom et relance pour cibler uniquement ce schema.
PROMPT  Tous les fichiers CSV sont dans : &OUT
PROMPT ================================================================
