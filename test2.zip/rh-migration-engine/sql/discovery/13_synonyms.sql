-- Synonymes : expliquent pourquoi l'appli fait "SELECT * FROM EMPLOYE" alors que
-- l'objet réel est RH.EMPLOYE (ou un objet distant via DB link).
DEFINE SCHEMA = DELTARH
SELECT owner, synonym_name, table_owner, table_name, db_link
FROM all_synonyms
WHERE owner = '&SCHEMA'
ORDER BY synonym_name;
