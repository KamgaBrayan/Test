-- Séquences : comprendre comment sont générés les identifiants (SEQ_EMPLOYE...).
-- Utile pour décider de la stratégie de clés côté cible.
DEFINE SCHEMA = DELTARH
SELECT sequence_owner, sequence_name, min_value, max_value,
       increment_by, cycle_flag, order_flag, last_number
FROM all_sequences
WHERE sequence_owner = '&SCHEMA'
ORDER BY sequence_name;
