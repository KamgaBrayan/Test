-- Commentaires de tables : documentation métier éventuelle, précieuse pour le glossaire.
DEFINE SCHEMA = DELTARH
SELECT owner, table_name, comments
FROM all_tab_comments
WHERE owner = '&SCHEMA' AND comments IS NOT NULL
ORDER BY table_name;
