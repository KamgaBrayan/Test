-- ============================================================
--  PROFILAGE D'UNE COLONNE — RELÈVE DE L'ÉTAPE 4 (Data Profiling)
--  Fourni ici pour mémoire. Remplace &TABLE et &COL.
--  Donne : volumétrie, % NULL, cardinalité, min/max
--          -> aide à deviner clés métier et colonnes de référence.
-- ============================================================
DEFINE SCHEMA = DELTARH
SELECT COUNT(*)                                                   AS rows_total,
       COUNT(&COL)                                                AS rows_non_null,
       COUNT(*) - COUNT(&COL)                                     AS rows_null,
       ROUND(100 * (COUNT(*) - COUNT(&COL)) / NULLIF(COUNT(*),0), 2) AS pct_null,
       COUNT(DISTINCT &COL)                                       AS distinct_values,
       MIN(&COL)                                                  AS min_value,
       MAX(&COL)                                                  AS max_value
FROM "&SCHEMA"."&TABLE";
