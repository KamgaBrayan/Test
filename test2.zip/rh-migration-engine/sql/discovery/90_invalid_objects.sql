-- OPTIONNEL : objets INVALIDES (vues/packages cassés). Signale une base fragile
-- ou des dépendances manquantes — utile à savoir avant de s'appuyer sur une vue.
DEFINE SCHEMA = DELTARH
SELECT owner, object_name, object_type, status, last_ddl_time
FROM all_objects
WHERE owner = '&SCHEMA' AND status <> 'VALID'
ORDER BY object_type, object_name;
