-- OPTIONNEL : colonnes LOB (CLOB/BLOB/NCLOB). Elles demandent un traitement
-- d'extraction/chargement spécifique (volumétrie, encodage).
DEFINE SCHEMA = DELTARH
SELECT owner, table_name, column_name, data_type
FROM all_tab_columns
WHERE owner = '&SCHEMA'
  AND data_type IN ('CLOB','BLOB','NCLOB','BFILE')
ORDER BY table_name, column_name;
