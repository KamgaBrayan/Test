-- Tables accessibles (+ estimation de lignes, partitionnement, dernière analyse).
-- NUM_ROWS provient des statistiques Oracle : estimation, pas un COUNT(*) à jour.
DEFINE SCHEMA = DELTARH
SELECT owner, table_name, num_rows, tablespace_name,
       partitioned, temporary, last_analyzed
FROM all_tables
WHERE owner = '&SCHEMA'
ORDER BY owner, table_name;
