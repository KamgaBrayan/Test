-- Colonnes de chaque index, dans l'ordre : révèle les clés métier candidates.
--   IDX_EMPLOYE_NOM_PRENOM : 1->NOM, 2->PRENOM
DEFINE SCHEMA = DELTARH
SELECT index_owner, index_name, table_owner, table_name,
       column_name, column_position, descend
FROM all_ind_columns
WHERE table_owner = '&SCHEMA'
ORDER BY table_name, index_name, column_position;
