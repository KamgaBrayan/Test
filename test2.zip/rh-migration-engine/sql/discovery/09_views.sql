-- Vues : l'application peut travailler sur des vues métier (VW_SALARIES, VW_EMPLOYE_ACTIF)
-- plutôt que sur les tables brutes. Une vue peut porter une logique importante.
DEFINE SCHEMA = DELTARH
SELECT owner, view_name, text_length
FROM all_views
WHERE owner = '&SCHEMA'
ORDER BY view_name;
