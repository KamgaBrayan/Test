-- Triggers : un INSERT peut déclencher des effets de bord (historisation, cascades).
-- À connaître avant de charger/reprendre des données, pour ne pas déclencher de
-- mécanismes involontaires ou, au contraire, en manquer d'indispensables.
-- (Le corps TRIGGER_BODY est volontairement exclu ici ; voir 11b si besoin.)
DEFINE SCHEMA = DELTARH
SELECT owner, trigger_name, table_owner, table_name,
       triggering_event, trigger_type, status
FROM all_triggers
WHERE owner = '&SCHEMA'
ORDER BY table_name, trigger_name;
