"""Vérification rapide de bout en bout (hors bases de données)."""
import sys
from pathlib import Path

root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(root / "src"))
sys.path.insert(0, str(root))

from migration.catalog.loader import load_catalog
from migration.validation.mapping_linter import lint_all
from config.settings import MAPPINGS_DIR

cat = load_catalog()
print(f"Catalogue : {len(cat.databases)} bases, "
      f"{sum(len(d.tables) for d in cat.databases.values())} tables.")
issues = lint_all(MAPPINGS_DIR)
err = [i for i in issues if i.level == 'ERROR']
warn = [i for i in issues if i.level == 'WARNING']
print(f"Lint mapping : {len(err)} erreur(s), {len(warn)} avertissement(s).")
for i in issues:
    print(f"  [{i.level}] {i.mapping_file}: {i.message}")
print("SMOKE TEST OK" if not err else "SMOKE TEST : erreurs présentes")
