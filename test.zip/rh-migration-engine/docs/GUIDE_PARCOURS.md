# Parcours guidé du projet — dans la chronologie réelle d'une migration

Ce guide explique **le rôle de chaque fichier** en suivant l'ordre dans lequel les
pièces entrent en jeu au cours d'une migration. C'est la meilleure façon de
comprendre *pourquoi* chaque module existe et *quand* il sert.

## Le principe qui structure tout le code

On sépare trois choses souvent mélangées à tort :

```
STRUCTURE      → ce que la cible attend        → catalog/            (figé, régénérable)
MAPPING        → quelle source va où            → mappings/*.yaml     (déclaratif)
TRANSFORMATION → comment convertir la valeur    → src/.../transformation/ (code)
```

Conséquence : on peut changer un mapping sans toucher au moteur, et changer la
cible (régénérer le catalogue) sans réécrire les mappings.

Vue d'ensemble, dans l'ordre du pipeline :

```
config/         → fondations (chargées en premier, utilisées partout)
catalog/        → le CONTRAT de la cible
sql/discovery/  → étape 1 : explorer Oracle
src/migration/
  ├─ database/       → connexions (Oracle, staging, cible)
  ├─ discovery/      → étape 1 automatisée
  ├─ extraction/     → étape 2 : Oracle → staging
  ├─ transformation/ → étape 3 : mapping + conversions
  ├─ validation/     → étape 4 : contrôle qualité
  ├─ crosswalk/      → correspondance des clés (fil rouge)
  ├─ loading/        → étape 5 : écrire dans la cible
  ├─ reporting/      → étape 6 : rapport
  ├─ errors.py       → modèle d'erreurs (transverse)
  ├─ context.py      → contexte d'un run (transverse)
  └─ cli.py          → le chef d'orchestre
mappings/, sql_ddl/, tests/, docs/, + fichiers de packaging
```

---

## Fondations — `config/` (chargé avant tout le reste)

Tout run commence par lire la configuration. `config/settings.py` centralise **tous**
les paramètres et les lit depuis `.env` (jamais de secret dans le code) :

```python
from config.settings import settings
settings.oracle_host         # "127.0.0.1"
settings.migration_mode      # "dry-run" ou "execute"
settings.oracle_schema_list  # ["RH"]  (propriété qui découpe "RH,PAIE")
```

Ce fichier expose aussi les **chemins** standards (`SCHEMA_CATALOG_PATH`,
`MAPPINGS_DIR`, `REPORTS_DIR`…), pour que personne n'écrive de chemin en dur.

`config/logging_config.py` installe une journalisation **JSON**, une ligne = un
événement, indexée par `run_id` — filtrable pendant l'exécution :

```json
{"ts":"2026-…","level":"INFO","msg":"run started","run_id":"20260904-160000-a1b2","phase":"init"}
```

`config/load_order.yaml` décrit l'ordre de chargement des 8 bases (les « paliers ») :
l'administration d'abord, puis les domaines fonctionnels par dépendance. C'est une
donnée, pas du code — modifiable sans toucher au moteur.

---

## Le contrat de la cible — `catalog/`

Avant même de regarder Oracle, le projet sait **exactement** ce que la cible attend,
car je l'ai extrait du dump PostgreSQL. `catalog/schema_catalog.json` est le
référentiel maître (209 tables, types, PK, NOT NULL, 377 enums). Les
`catalog/*.yaml` sont la même information par domaine, versionnable dans Git.

`src/migration/catalog/loader.py` transforme ce JSON en objets Python :

```python
from migration.catalog.loader import load_catalog
cat = load_catalog()

col = cat.resolve("fluxoon_employee", "employees", "employee_id")
col.base_type    # "text"
col.max_length   # 255     ← sert à détecter les débordements varchar
col.nullable     # False   ← colonne obligatoire

cat.resolve("fluxoon_employee", "employees", "gender").enum
# ["MALE", "FEMALE"]        ← valeurs autorisées par le CHECK
```

Intérêt : la validation et le linter **lisent** ces objets au lieu de coder les
règles à la main. La cible évolue ? On régénère le catalogue et tout suit.

---

## Étape 1 — Explorer Oracle : `sql/discovery/` + `src/migration/discovery/`

C'est là que commence le travail concret côté source. Deux voies pour la même chose.

**Voie manuelle** : les scripts `01_connection.sql` … `17_row_counts.sql` interrogent
le dictionnaire de données Oracle. Le périmètre est volontairement large : au-delà des
tables, colonnes et contraintes, il couvre **la logique applicative** d'Amplitude —
vues, séquences, triggers, procédures/packages, synonymes, dépendances — et la
**documentation** (commentaires de tables et colonnes). `00_run_all.sql` enchaîne tout
et exporte chaque volet en CSV. Détail des scripts : voir `sql/discovery/README.md`.

**Voie automatique (recommandée)** : `src/migration/discovery/inventory.py` exécute
ces mêmes requêtes via le driver Python et produit directement un Excel
(`reports/oracle_inventory.xlsx`), une feuille par volet + un onglet de synthèse.
La connexion vient de `database/oracle.py`, qui importe le driver **paresseusement**
(le paquet reste utilisable hors ligne) :

```python
def get_connection():
    import oracledb                      # importé seulement au moment de l'appel
    dsn = oracledb.makedsn(settings.oracle_host, settings.oracle_port,
                           service_name=settings.oracle_service_name)
    return oracledb.connect(user=settings.oracle_user,
                            password=settings.oracle_password, dsn=dsn)
```

Deux choix de robustesse dans le moteur : chaque volet s'exécute **indépendamment**
(un échec de droits sur un volet n'interrompt pas les autres), et la requête
« colonnes » tente d'abord la version enrichie (12c+ : identité, colonne virtuelle,
sémantique BYTE/CHAR) puis **retombe** sur une version de base sur une version Oracle
plus ancienne. La sortie `reports/oracle_inventory.xlsx` est **l'inventaire à me
renvoyer** pour remplir le volet source du mapping.

Pourquoi ce périmètre élargi ? Parce que les FK donnent le squelette
(`EMPLOYE.DEPARTEMENT_ID → DEPARTEMENT.ID`, avec la **colonne parente**, pas seulement
la table), les **commentaires** décodent les noms abrégés (`MAT_EMP` → « matricule »)
et accélèrent le glossaire, et les **triggers/packages** révèlent des effets de bord à
connaître avant toute reprise de données.

---

## Étape 2 — Vers le staging : `src/migration/extraction/` + `database/staging.py`

`extraction/extractor.py` est un **stub balisé** (`NotImplementedError`), complété après
l'exploration. Rôle : copier chaque table Oracle retenue vers une table de staging
PostgreSQL, **1:1, sans transformation**, par lots. `database/staging.py` fournit la
connexion.

Pourquoi un staging persistant plutôt que tout en mémoire ? On lit Oracle **une seule
fois**, puis on itère les transformations hors ligne — précieux quand on développe sur
données de test avant de livrer. Le staging sert aussi au profilage (étape 4) et à la
reprise sur erreur.

---

## Étape 3 — Transformer : `mappings/` + `src/migration/transformation/`

Le cœur métier. Le **mapping est déclaratif** : un fichier YAML par table cible.

```yaml
- target: last_name
  source: NOM
  transform: { type: uppercase }
```

« Prends la colonne Oracle `NOM`, mets-la en majuscules, écris-la dans `last_name` ».
Les fichiers de `mappings/enums/` sont les correspondances de valeurs issues des CHECK
(ex. `gender.yaml` : `M → MALE`).

Quatre fichiers travaillent ensemble. `converters.py` contient les briques atomiques,
pures et testées (`trim`, `uppercase`, `to_date`, `to_int`…). `lookups.py` applique les
enums, avec une politique explicite en cas de valeur imprévue :

```python
vmap.apply("M")   # → "MALE"
vmap.apply("Z")   # → lève LookupError_  (si on_unmapped: reject)
```

`json_assembler.py` reconstruit les colonnes `jsonb` de Fluxoon à partir de plusieurs
colonnes Oracle plates. `mapper.py` orchestre : `TableMapping.from_file()` lit le YAML,
`map_row()` applique tout et renvoie **la ligne cible + les erreurs** :

```python
src = {"MATRICULE": " E001 ", "NOM": "dupont", "SEXE": "M", "STATUT": "A",
       "EMAIL": "j@x.cm", "TELEPHONE": "699"}
out, errors = map_row(mapping, src, value_maps, run_id="r1", source_key="E001")
# out == {"employee_id":"E001", "last_name":"DUPONT", "gender":"MALE",
#         "status":"ACTIVE", "contact":{"email":"j@x.cm","phone":"699"}, ...}
```

Ce test tourne réellement (`tests/test_mapper.py`).

---

## Étape 4 — Valider : `src/migration/validation/`

`catalog_validator.py` est la pièce maîtresse : il vérifie une ligne **contre le
catalogue**, sans règle codée en dur (NOT NULL, longueur varchar, dépassement
numérique, appartenance aux enums) :

```python
row = {"company_id":"C1", "employee_id":"", "gender":"XX", ...}
errors = validate_row(cat, "fluxoon_employee", "employees", row, run_id="r1")
# → REQUIRED_NULL sur employee_id  (NOT NULL vide)
# → ENUM_UNMAPPED sur gender       ("XX" hors ["MALE","FEMALE"])
```

`mapping_linter.py` applique la même logique **en amont**, sur le mapping lui-même,
avant toute exécution — ton garde-fou :

```
[ERROR] colonne cible inexistante: employees.colonne_qui_nexiste_pas
[ERROR] table de correspondance absente pour gender
[WARNING] colonne obligatoire non mappée: last_name
```

`business_validator.py` est le point d'extension des règles métier transverses
(date_fin ≥ date_debut, un seul contrat actif…), à remplir à l'étape 5.
`reconciliation.py` tient l'équation `source = migrés + rejetés`, table par table.

---

## Le fil rouge — `errors.py`, `context.py`, `crosswalk/`

`errors.py` définit le **modèle d'erreurs structuré**. Chaque rejet est un
enregistrement précis, exportable en CSV et en base :

```python
MigrationError(run_id, Phase.VALIDATE, Severity.BLOCKING, ErrorCode.ENUM_UNMAPPED,
               "valeur hors enum ['MALE','FEMALE']",
               target_table="employees", target_column="gender",
               source_key="E001", raw_value="XX")
```

`ErrorCollector` accumule tout et calcule le **taux de rejets bloquants** (pour
interrompre avant le LOAD si le seuil est dépassé). `context.py` porte le `RunContext` :
`run_id` unique, mode (dry-run/execute), logger, collecteur d'erreurs.

`crosswalk/crosswalk.py` est essentiel ici : comme les clés cibles sont des chaînes et
qu'il **n'y a pas de FK inter-bases**, il mémorise `clé Oracle → clé cible` :

```python
xwalk.put("employee", "E001", "emp_7f3a")   # après création de l'employé
xwalk.get("employee", "E001")                # → "emp_7f3a" plus tard, en paie
```

Cela permet (1) de résoudre les liens entre les 8 bases, (2) de rejouer sans dupliquer
(idempotence), (3) de réconcilier.

---

## Étape 5 — Charger : `src/migration/loading/` + `database/target.py`

`loading/base.py` définit l'interface (`upsert`), `loading/postgres_loader.py`
l'implémente. Le point clé est le **dry-run** : en simulation, on compte sans écrire ;
en réel, `INSERT ... ON CONFLICT` idempotent.

```python
loader = PostgresLoader(engine, dry_run=True)
loader.upsert("employees", rows, conflict_keys=["company_id","employee_id"])
# dry-run → renvoie len(rows) sans rien écrire
```

`database/target.py` gère les connexions **base par base** et lit l'ordre de
chargement :

```python
for palier in load_order():   # fluxoon_auth d'abord, puis org, employee, ...
    engine = get_engine(palier["database"])
```

Un parent en échec fait sauter ses enfants — pas d'orphelins.

---

## Étape 6 — Rendre compte : `reporting/` + `sql_ddl/control_schema.sql`

`reporting/report.py` produit le rapport lisible et exporte les erreurs en CSV :

```
========== RAPPORT DE MIGRATION RH ==========
Réconciliation
OK  employees   source=  15432 migrés=  15401 rejetés=   31
Erreurs bloquantes : 31  (taux=0.20%)
Statut : TERMINÉE AVEC ANOMALIES
```

`sql_ddl/control_schema.sql` crée les trois tables de contrôle côté staging :
`migration_run` (suivi des exécutions), `migration_error` (une ligne par rejet,
requêtable par code/table) et `id_crosswalk` (la correspondance persistée). C'est ce
qui rend une exécution **auditable**.

---

## Le chef d'orchestre — `cli.py`

`cli.py` expose les verbes et relie les modules. `lint-mapping` et `discover` sont
fonctionnels ; les autres appelleront les modules ci-dessus dans l'ordre du pipeline :

```
rh-migration lint-mapping   → validation/mapping_linter
rh-migration discover       → discovery/inventory
rh-migration stage          → extraction/extractor        (à compléter)
rh-migration dry-run        → extract→transform→validate→load(dry) + report
rh-migration execute        → idem, écriture réelle
```

---

## Ce qui verrouille la qualité — `tests/` et le packaging

`tests/` prouve que le cœur marche : convertisseurs, chargement du catalogue,
validateur (il attrape REQUIRED_NULL, ENUM_UNMAPPED, LENGTH_OVERFLOW), mapper de bout
en bout, linter. `scripts/smoke_test.py` fait une vérification rapide hors base.

Les fichiers de packaging font du dépôt un vrai projet d'équipe : `pyproject.toml`
(installe la commande `rh-migration`, configure pytest), `requirements*.txt`,
`Makefile`, `.env.example`, `.gitignore`, `README.md` et `docs/architecture.md` (qui
fige les décisions bloquantes : voie d'écriture, tenant, stratégie de clés).

---

## Comment le projet se complète, concrètement

Quand l'inventaire Oracle arrive, l'enchaînement est précis — chaque stub correspond à
une étape de la feuille de route :

1. On remplit le **volet source du classeur de mapping** et on crée un
   `mappings/<table>.yaml` par table cible (en dupliquant `employees.yaml`). On alimente
   `mappings/enums/` avec les correspondances de codes Oracle. À chaque ajout,
   `rh-migration lint-mapping` valide le respect du contrat cible.
2. On implémente les stubs dans l'ordre du pipeline : `extraction/extractor.py`
   (Oracle → staging), la `PostgresCrosswalk` persistée, puis `loading/postgres_loader.py`
   (upsert idempotent). On ajoute les règles métier dans `business_validator.py` au fil
   de l'eau.
3. La boucle `dry-run`/`execute` dans `cli.py` n'est plus que l'assemblage de pièces
   déjà écrites et testées.

Autrement dit : fondations, contrat cible, validation et mapping sont déjà solides et
prouvés ; ce qui reste à écrire, ce sont surtout les **entrées/sorties** vers les vraies
bases, qui dépendent précisément de ce que l'exploration Oracle va révéler.
