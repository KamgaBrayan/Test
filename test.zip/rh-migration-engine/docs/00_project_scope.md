# 00 — Cadrage du projet (à remplir avec le client)

## Source
- Base Oracle (Amplitude) : hôte, service, version :
- Schéma(s) applicatif(s) :
- Compte d'accès (lecture seule) :

## Cible
- Cluster PostgreSQL Fluxoon : hôte, version :
- **Voie d'écriture** : SQL direct / API Fluxoon (à trancher) :
- Bases concernées / exclues :

## Tenant
- Nombre d'entreprises dans Oracle :
- `company_id` cible imposé ou à générer :

## Périmètre
- Données concernées :
- Données exclues (audit, logs, temporaires) :

## Gouvernance
- Qui valide le mapping :
- Qui valide les règles métier :
- Qui exécute la migration finale :

## Sécurité & reprise
- Règles de sécurité / anonymisation données de test :
- Stratégie de rollback / reprise :

## Critères de succès
- Taux de migration attendu :
- Seuil de rejets bloquants acceptable :
