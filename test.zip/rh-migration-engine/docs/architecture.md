# Architecture du moteur de migration

## Cible réelle (rappel)
La cible n'est pas une base unique mais un **cluster de 8 bases PostgreSQL**
(microservices) du SIRH Fluxoon, multi-tenant, à clés primaires composites
(`company_id` + clé métier), identifiants **chaînes**, **peu de FK inter-bases**,
377 enums en `CHECK`, nombreuses colonnes `jsonb`.

## Principe fondamental : structure ≠ mapping ≠ transformation
- **Structure** : le catalogue cible (`catalog/schema_catalog.json`) — figé, régénérable.
- **Mapping** : déclaratif, dans `mappings/*.yaml` — quelle source vers quelle cible.
- **Transformation** : code réutilisable (`transformation/`) — comment convertir.

Ce découplage permet de modifier le mapping sans toucher au moteur.

## Pipeline
```
Oracle → EXTRACT → STAGING → TRANSFORM → VALIDATE → LOAD (8 bases) → REPORT
                                   │           │
                              mappings/*    catalog/*  (contrat cible)
```

## Décisions à acter à l'étape 0 (bloquantes)
1. **Voie d'écriture cible** : SQL direct dans les 8 bases *ou* API Fluxoon.
   Recommandé : API (ou procédure éditeur) pour `fluxoon_auth` (identités/secrets),
   SQL direct possible pour les gros volumes fonctionnels si on reproduit les invariants.
2. **Tenant** : une ou plusieurs entreprises dans Oracle ? `company_id` imposé ou à générer ?
   La résolution du tenant est un **prérequis** de tout chargement.
3. **Stratégie de clés** : comment dériver les clés cibles (chaînes) depuis Oracle ;
   la table `id_crosswalk` conserve la correspondance.

## Robustesse & exploitation des erreurs
- Validation **pilotée par le catalogue** (types, longueurs, NOT NULL, enums).
- **Linter de mapping** exécuté avant tout run (`rh-migration lint-mapping`).
- Modèle d'erreurs structuré (`errors.py`) + tables de contrôle (`sql_ddl/control_schema.sql`).
- Politique : on **collecte tous** les rejets d'une passe ; on **interrompt avant LOAD**
  si le taux de rejets bloquants dépasse `MIGRATION_MAX_BLOCKING_RATE`.
- Logs **JSON** indexés par `run_id`.

## Ordre de chargement
Défini dans `config/load_order.yaml` (admin d'abord, puis dépendances). Un parent
en échec fait sauter ses enfants (pas d'orphelins).

## Ce qui reste à compléter après l'exploration Oracle
`extraction/extractor.py`, `loading/postgres_loader.py`, `crosswalk` persistée,
règles métier (`validation/business_validator.py`), et les mappings `mappings/*.yaml`.
Chaque stub est balisé `NotImplementedError` / `À COMPLÉTER`.

## Ce que la découverte élargie apporte aux décisions

La découverte ne se limite pas à la structure : elle inventorie aussi la **logique
applicative** d'Amplitude (triggers, procédures/packages, vues) et la **documentation**
(commentaires). Deux impacts directs :
- les **triggers** et **packages** éclairent la décision « voie d'écriture » : écrire en
  SQL direct court-circuite ces mécanismes, ce qui peut être voulu (reprise brute) ou
  dangereux (historisation, cascades) selon les cas ;
- les **commentaires** de colonnes accélèrent le Business Glossary (étape 5) en décodant
  les noms abrégés, et les **FK avec colonne parente** alimentent directement le graphe
  d'ordre de chargement.
