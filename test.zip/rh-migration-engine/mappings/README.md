# Mappings

Un fichier YAML par table cible. Chaque fichier décrit **où** vont les données
(structure) et **comment** elles sont transformées.

- `employees.yaml` — exemple complet et valide (gabarit à dupliquer).
- `enums/` — tables de correspondance de valeurs (code Oracle → valeur cible),
  issues de la feuille `03_Enums` du classeur de mapping.

Règles :
- Le mapping est **déclaratif** : aucune logique en dur dans le moteur.
- Toujours lancer `rh-migration lint-mapping` avant d'exécuter quoi que ce soit :
  le linter vérifie chaque mapping contre le catalogue cible (`catalog/schema_catalog.json`).
- Les fichiers préfixés par `_` sont ignorés (brouillons).

Transformations disponibles : `direct, trim, uppercase, lowercase, cast_int,
cast_decimal, cast_bool, date, timestamp, constant, default, concat, lookup,
json_object`.
