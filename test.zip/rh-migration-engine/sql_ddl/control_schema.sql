-- Schéma de contrôle de la migration (à créer dans la base de STAGING PostgreSQL).
-- Trois tables : suivi des runs, erreurs détaillées, correspondance des clés.

CREATE SCHEMA IF NOT EXISTS migration;

-- 1. Suivi des exécutions (manifeste de run)
CREATE TABLE IF NOT EXISTS migration.migration_run (
    run_id          text PRIMARY KEY,
    mode            text NOT NULL,                 -- dry-run | execute
    started_at      timestamptz NOT NULL DEFAULT now(),
    ended_at        timestamptz,
    status          text,                          -- RUNNING | OK | ANOMALIES | FAILED
    rows_seen       bigint DEFAULT 0,
    rows_migrated   bigint DEFAULT 0,
    rows_rejected   bigint DEFAULT 0
);

-- 2. Erreurs détaillées (une ligne par rejet/avertissement)
CREATE TABLE IF NOT EXISTS migration.migration_error (
    id              bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    run_id          text NOT NULL REFERENCES migration.migration_run(run_id),
    created_at      timestamptz NOT NULL DEFAULT now(),
    phase           text NOT NULL,                 -- extract|stage|transform|validate|load
    severity        text NOT NULL,                 -- BLOCKING|WARNING|INFO
    code            text NOT NULL,
    message         text,
    source_table    text,
    source_key      text,
    target_db       text,
    target_table    text,
    target_column   text,
    raw_value       text
);
CREATE INDEX IF NOT EXISTS ix_error_run   ON migration.migration_error(run_id);
CREATE INDEX IF NOT EXISTS ix_error_code  ON migration.migration_error(code);

-- 3. Correspondance des clés source -> cible (idempotence + résolution des liens)
CREATE TABLE IF NOT EXISTS migration.id_crosswalk (
    entity          text NOT NULL,                 -- ex: 'employee', 'contract'
    source_key      text NOT NULL,                 -- clé métier Oracle (ex: MATRICULE)
    target_db       text NOT NULL,
    target_table    text NOT NULL,
    target_key      text NOT NULL,                 -- clé cible (chaîne)
    created_at      timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (entity, source_key)
);
CREATE INDEX IF NOT EXISTS ix_crosswalk_target ON migration.id_crosswalk(target_db, target_table, target_key);
