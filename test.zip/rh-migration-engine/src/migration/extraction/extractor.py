"""Extraction Oracle -> staging (données brutes, 1:1).

À COMPLÉTER après l'exploration : on extrait chaque table source retenue vers
une table de staging homonyme, sans transformation, par lots (chunks). Le
staging persistant permet de relire les transformations sans retaper Oracle.
"""
from __future__ import annotations

from ..context import RunContext


def extract_table(ctx: RunContext, source_table: str, chunk_size: int = 50_000) -> int:
    """Extrait une table Oracle vers le staging. Renvoie le nombre de lignes.
    STUB : à implémenter (pandas.read_sql par chunks -> to_sql staging)."""
    ctx.log("extract (stub)", phase="extract", table=source_table)
    raise NotImplementedError("À implémenter après le choix des tables sources (étape 3).")
