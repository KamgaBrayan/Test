"""Chargeur du catalogue cible (schema_catalog.json) en objets Python.

Le catalogue est LE contrat de la cible : il pilote la validation (types,
longueurs, NOT NULL, enums) sans que ces règles soient codées en dur.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from pathlib import Path

from config.settings import SCHEMA_CATALOG_PATH

_VARCHAR = re.compile(r"character varying\((\d+)\)|varchar\((\d+)\)", re.I)
_CHAR = re.compile(r"^character\((\d+)\)|^char\((\d+)\)", re.I)
_NUMERIC = re.compile(r"numeric\((\d+),\s*(\d+)\)|numeric\((\d+)\)", re.I)


@dataclass
class Column:
    name: str
    type_raw: str
    nullable: bool
    is_pk: bool = False
    enum: list[str] | None = None

    @property
    def base_type(self) -> str:
        t = self.type_raw.lower()
        if "character varying" in t or "varchar" in t or "text" in t or "character" in t:
            return "text"
        if "timestamp" in t:
            return "timestamp"
        if "date" in t:
            return "date"
        if "numeric" in t or "decimal" in t or "double" in t or "real" in t:
            return "numeric"
        if "bigint" in t or "integer" in t or "smallint" in t or t.strip() == "int":
            return "integer"
        if "boolean" in t or "bool" in t:
            return "boolean"
        if "json" in t:
            return "json"
        if "uuid" in t:
            return "uuid"
        if "bytea" in t:
            return "bytea"
        return "other"

    @property
    def max_length(self) -> int | None:
        m = _VARCHAR.search(self.type_raw) or _CHAR.search(self.type_raw)
        if m:
            return int(next(g for g in m.groups() if g))
        return None

    @property
    def numeric_precision_scale(self) -> tuple[int, int] | None:
        m = _NUMERIC.search(self.type_raw)
        if not m:
            return None
        g = m.groups()
        if g[0] and g[1]:
            return int(g[0]), int(g[1])
        if g[2]:
            return int(g[2]), 0
        return None


@dataclass
class Table:
    name: str
    pk: list[str] = field(default_factory=list)
    columns: dict[str, Column] = field(default_factory=dict)

    def column(self, name: str) -> Column | None:
        return self.columns.get(name)


@dataclass
class Database:
    name: str
    tables: dict[str, Table] = field(default_factory=dict)

    def table(self, name: str) -> Table | None:
        return self.tables.get(name)


@dataclass
class Catalog:
    databases: dict[str, Database] = field(default_factory=dict)

    def database(self, name: str) -> Database | None:
        return self.databases.get(name)

    def resolve(self, db: str, table: str, column: str | None = None):
        d = self.database(db)
        if not d:
            return None
        t = d.table(table)
        if not t or column is None:
            return t
        return t.column(column)


def load_catalog(path: str | Path = SCHEMA_CATALOG_PATH) -> Catalog:
    raw = json.loads(Path(path).read_text(encoding="utf-8"))
    cat = Catalog()
    for db_name, db in raw.items():
        database = Database(name=db_name)
        for tname, tinfo in db.get("tables", {}).items():
            pk = list(tinfo.get("pk", []))
            checks = tinfo.get("checks", {})
            table = Table(name=tname, pk=pk)
            for col in tinfo.get("columns", []):
                cname = col["name"]
                table.columns[cname] = Column(
                    name=cname,
                    type_raw=col["type"],
                    nullable=col.get("nullable", True),
                    is_pk=cname in pk,
                    enum=checks.get(cname),
                )
            database.tables[tname] = table
        cat.databases[db_name] = database
    return cat
