"""Rapport de migration : synthèse lisible + export des erreurs.

Produit un rapport texte (et pourra produire un PDF/Excel) résumant source,
transformation, cible, réconciliation et statut global.
"""
from __future__ import annotations

from pathlib import Path

from config.settings import REPORTS_DIR
from ..context import RunContext
from ..validation.reconciliation import ReconReport


def write_report(ctx: RunContext, recon: ReconReport) -> Path:
    lines = []
    lines.append("=" * 55)
    lines.append("        RAPPORT DE MIGRATION RH")
    lines.append("=" * 55)
    lines.append(f"Run        : {ctx.run_id}")
    lines.append(f"Mode       : {ctx.mode}")
    lines.append("")
    lines.append("Réconciliation")
    lines.append("-" * 30)
    for r in recon.items:
        row = r.as_row()
        flag = "OK " if row["balanced"] else "!! "
        lines.append(f"{flag}{row['entity']:<20} source={row['source']:>7} "
                     f"migrés={row['migrated']:>7} rejetés={row['rejected']:>6}")
    lines.append("")
    n_block = len(ctx.errors.blocking)
    lines.append(f"Erreurs bloquantes : {n_block}  (taux={ctx.errors.blocking_rate():.2f}%)")
    status = "TERMINÉE" if (recon.all_balanced and n_block == 0) else "TERMINÉE AVEC ANOMALIES"
    lines.append(f"Statut     : {status}")

    REPORTS_DIR.mkdir(parents=True, exist_ok=True)
    out = REPORTS_DIR / f"migration_report_{ctx.run_id}.txt"
    out.write_text("\n".join(lines), encoding="utf-8")
    # Erreurs détaillées en CSV
    ctx.errors.export_csv(REPORTS_DIR / f"migration_errors_{ctx.run_id}.csv")
    return out
