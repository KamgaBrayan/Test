"""Modèle d'erreurs de migration : codes, sévérités, enregistrement et collecteur.

C'est la pièce qui rend les erreurs *exploitables* : chaque rejet est capturé
de façon structurée (phase, table source/cible, colonne, code, valeur brute),
puis exportable en CSV et/ou en base de contrôle.
"""
from __future__ import annotations

import csv
from dataclasses import dataclass, field, asdict
from enum import Enum
from pathlib import Path


class Phase(str, Enum):
    EXTRACT = "extract"
    STAGE = "stage"
    TRANSFORM = "transform"
    VALIDATE = "validate"
    LOAD = "load"
    RECONCILE = "reconcile"


class Severity(str, Enum):
    BLOCKING = "BLOCKING"      # la ligne est rejetée
    WARNING = "WARNING"        # chargée avec réserve
    INFO = "INFO"


class ErrorCode(str, Enum):
    # Extraction / staging
    EXTRACT_FAILED = "EXTRACT_FAILED"
    ENCODING = "ENCODING"
    # Transformation
    TYPE_CAST = "TYPE_CAST"
    DATE_PARSE = "DATE_PARSE"
    JSON_MALFORMED = "JSON_MALFORMED"
    TRANSFORM_FAILED = "TRANSFORM_FAILED"
    # Validation (contrat cible)
    REQUIRED_NULL = "REQUIRED_NULL"
    LENGTH_OVERFLOW = "LENGTH_OVERFLOW"
    NUMERIC_OVERFLOW = "NUMERIC_OVERFLOW"
    ENUM_UNMAPPED = "ENUM_UNMAPPED"
    # Cohérence / métier
    DUPLICATE_KEY = "DUPLICATE_KEY"
    ORPHAN_REFERENCE = "ORPHAN_REFERENCE"
    TENANT_UNRESOLVED = "TENANT_UNRESOLVED"
    BUSINESS_RULE = "BUSINESS_RULE"
    # Chargement
    LOAD_FAILED = "LOAD_FAILED"


@dataclass
class MigrationError:
    run_id: str
    phase: Phase
    severity: Severity
    code: ErrorCode
    message: str
    source_table: str = ""
    source_key: str = ""
    target_db: str = ""
    target_table: str = ""
    target_column: str = ""
    raw_value: str = ""

    def as_row(self) -> dict:
        d = asdict(self)
        d["phase"] = self.phase.value
        d["severity"] = self.severity.value
        d["code"] = self.code.value
        return d


@dataclass
class ErrorCollector:
    """Accumule les erreurs d'un run (politique : on collecte tout, on n'arrête
    pas au premier rejet), puis calcule le taux de rejets bloquants."""
    run_id: str
    errors: list[MigrationError] = field(default_factory=list)
    _rows_seen: int = 0

    def add(self, err: MigrationError) -> None:
        self.errors.append(err)

    def mark_rows(self, n: int) -> None:
        self._rows_seen += n

    @property
    def blocking(self) -> list[MigrationError]:
        return [e for e in self.errors if e.severity == Severity.BLOCKING]

    def blocking_rate(self) -> float:
        if self._rows_seen == 0:
            return 0.0
        return 100.0 * len(self.blocking) / self._rows_seen

    def export_csv(self, path: str | Path) -> Path:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        fields = list(MigrationError(self.run_id, Phase.VALIDATE, Severity.INFO,
                                     ErrorCode.BUSINESS_RULE, "").as_row().keys())
        with path.open("w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=fields)
            w.writeheader()
            for e in self.errors:
                w.writerow(e.as_row())
        return path
