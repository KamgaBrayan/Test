"""Contexte partagé d'un run de migration : identifiant, mode, logger, erreurs."""
from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone

from config.logging_config import setup_logging
from config.settings import LOGS_DIR, settings

from .errors import ErrorCollector


@dataclass
class RunContext:
    mode: str = field(default_factory=lambda: settings.migration_mode)
    run_id: str = field(default_factory=lambda: datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S-") + uuid.uuid4().hex[:8])
    started_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    def __post_init__(self) -> None:
        LOGS_DIR.mkdir(parents=True, exist_ok=True)
        self.logger = setup_logging(logfile=str(LOGS_DIR / f"{self.run_id}.log"))
        self.errors = ErrorCollector(run_id=self.run_id)
        self.logger.info("run started", extra={"run_id": self.run_id, "phase": "init"})

    @property
    def is_execute(self) -> bool:
        return self.mode == "execute"

    def log(self, msg: str, **extra) -> None:
        extra.setdefault("run_id", self.run_id)
        self.logger.info(msg, extra=extra)
