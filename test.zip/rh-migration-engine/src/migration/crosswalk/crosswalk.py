"""Table de correspondance des clés source -> cible (« ID crosswalk »).

Indispensable ici : les clés cibles sont des chaînes et il n'existe aucune FK
inter-bases. Cette table permet (1) de résoudre les références logiques entre
les 8 bases, (2) l'idempotence (rejouer sans dupliquer), (3) la réconciliation,
(4) les rechargements incrémentaux.

Deux implémentations : en mémoire (tests/dry-run) et persistée (PostgreSQL de
staging). L'API est identique.
"""
from __future__ import annotations

from dataclasses import dataclass, field


class CrosswalkBase:
    def put(self, entity: str, source_key: str, target_key: str) -> None: ...
    def get(self, entity: str, source_key: str) -> str | None: ...
    def has(self, entity: str, source_key: str) -> bool: ...


@dataclass
class InMemoryCrosswalk(CrosswalkBase):
    _data: dict[tuple[str, str], str] = field(default_factory=dict)

    def put(self, entity: str, source_key: str, target_key: str) -> None:
        self._data[(entity, str(source_key))] = target_key

    def get(self, entity: str, source_key: str) -> str | None:
        return self._data.get((entity, str(source_key)))

    def has(self, entity: str, source_key: str) -> bool:
        return (entity, str(source_key)) in self._data


class PostgresCrosswalk(CrosswalkBase):
    """Persiste la correspondance dans la table staging `id_crosswalk`.
    À COMPLÉTER : brancher sur l'engine staging (voir sql_ddl/control_schema.sql)."""

    def __init__(self, engine) -> None:  # engine SQLAlchemy staging
        self._engine = engine

    def put(self, entity: str, source_key: str, target_key: str) -> None:
        raise NotImplementedError("À implémenter à l'étape LOAD (UPSERT id_crosswalk).")

    def get(self, entity: str, source_key: str) -> str | None:
        raise NotImplementedError("À implémenter (SELECT target_key).")

    def has(self, entity: str, source_key: str) -> bool:
        return self.get(entity, source_key) is not None
