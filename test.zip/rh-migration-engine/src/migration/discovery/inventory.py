"""Découverte automatique de la base Oracle -> classeur d'inventaire.

Exécute les requêtes de découverte (dictionnaire de données Oracle) et produit
`reports/oracle_inventory.xlsx` avec une feuille par volet :
connexion, inventaire d'objets, tables, colonnes, contraintes, clés étrangères
(colonne enfant -> colonne parente), index, colonnes d'index, vues, séquences,
triggers, procédures/packages, synonymes, dépendances, commentaires, et
comptage réel des lignes.

Principes de robustesse :
- chaque volet est exécuté INDÉPENDAMMENT : si l'un échoue (droits, version
  Oracle), on journalise et on continue (la feuille contient l'erreur) ;
- filtrage par schéma via un bind `:owner` exécuté schéma par schéma (pas de
  `= ANY(:liste)`, non portable sur Oracle) ;
- la requête "colonnes" tente d'abord la version enrichie (12c+), puis retombe
  automatiquement sur une version de base si des colonnes n'existent pas.

Utilisation (après avoir renseigné .env) :
    rh-migration discover
"""
from __future__ import annotations

import logging
from pathlib import Path

from config.settings import REPORTS_DIR, settings

log = logging.getLogger("migration.discovery")

# --- Requêtes filtrées par :owner (un schéma à la fois) --------------------
QUERIES: dict[str, str] = {
    "object_inventory": """
        SELECT owner, object_type, COUNT(*) AS object_count
        FROM all_objects WHERE owner = :owner
        GROUP BY owner, object_type ORDER BY object_type
    """,
    "tables": """
        SELECT owner, table_name, num_rows, tablespace_name,
               partitioned, temporary, last_analyzed
        FROM all_tables WHERE owner = :owner ORDER BY table_name
    """,
    "constraints": """
        SELECT c.owner, c.table_name, c.constraint_name, c.constraint_type,
               cc.column_name, cc.position, c.status, c.search_condition
        FROM all_constraints c
        JOIN all_cons_columns cc
          ON c.owner = cc.owner AND c.constraint_name = cc.constraint_name
        WHERE c.owner = :owner AND c.constraint_type IN ('P','U','C')
        ORDER BY c.table_name, c.constraint_name, cc.position
    """,
    "foreign_keys": """
        SELECT c.owner, c.table_name AS child_table, cc.column_name AS child_column,
               cc.position, c.constraint_name,
               rc.owner AS parent_owner, rc.table_name AS parent_table,
               rcc.column_name AS parent_column, c.delete_rule
        FROM all_constraints c
        JOIN all_cons_columns cc
          ON c.owner = cc.owner AND c.constraint_name = cc.constraint_name
        JOIN all_constraints rc
          ON c.r_owner = rc.owner AND c.r_constraint_name = rc.constraint_name
        JOIN all_cons_columns rcc
          ON rc.owner = rcc.owner AND rc.constraint_name = rcc.constraint_name
         AND rcc.position = cc.position
        WHERE c.owner = :owner AND c.constraint_type = 'R'
        ORDER BY c.table_name, c.constraint_name, cc.position
    """,
    "indexes": """
        SELECT owner, index_name, table_name, uniqueness, index_type, status
        FROM all_indexes WHERE owner = :owner ORDER BY table_name, index_name
    """,
    "index_columns": """
        SELECT index_owner, index_name, table_owner, table_name,
               column_name, column_position, descend
        FROM all_ind_columns WHERE table_owner = :owner
        ORDER BY table_name, index_name, column_position
    """,
    "views": """
        SELECT owner, view_name, text_length
        FROM all_views WHERE owner = :owner ORDER BY view_name
    """,
    "sequences": """
        SELECT sequence_owner, sequence_name, min_value, max_value,
               increment_by, cycle_flag, order_flag, last_number
        FROM all_sequences WHERE sequence_owner = :owner ORDER BY sequence_name
    """,
    "triggers": """
        SELECT owner, trigger_name, table_owner, table_name,
               triggering_event, trigger_type, status
        FROM all_triggers WHERE owner = :owner ORDER BY table_name, trigger_name
    """,
    "procedures": """
        SELECT owner, object_name, procedure_name, object_type, aggregate, pipelined
        FROM all_procedures WHERE owner = :owner ORDER BY object_name, procedure_name
    """,
    "synonyms": """
        SELECT owner, synonym_name, table_owner, table_name, db_link
        FROM all_synonyms WHERE owner = :owner ORDER BY synonym_name
    """,
    "dependencies": """
        SELECT owner, name, type, referenced_owner, referenced_name, referenced_type
        FROM all_dependencies WHERE owner = :owner ORDER BY name, type
    """,
    "table_comments": """
        SELECT owner, table_name, comments
        FROM all_tab_comments WHERE owner = :owner AND comments IS NOT NULL
        ORDER BY table_name
    """,
    "column_comments": """
        SELECT owner, table_name, column_name, comments
        FROM all_col_comments WHERE owner = :owner AND comments IS NOT NULL
        ORDER BY table_name, column_name
    """,
}

# Colonnes enrichie (12c+) puis repli de base si identifiants invalides
COLUMNS_ENRICHED = """
    SELECT owner, table_name, column_id, column_name, data_type,
           data_length, char_length, char_used,
           data_precision, data_scale, nullable, data_default,
           identity_column, virtual_column, hidden_column
    FROM all_tab_columns WHERE owner = :owner
    ORDER BY table_name, column_id
"""
COLUMNS_BASIC = """
    SELECT owner, table_name, column_id, column_name, data_type,
           data_length, char_length, char_used,
           data_precision, data_scale, nullable, data_default
    FROM all_tab_columns WHERE owner = :owner
    ORDER BY table_name, column_id
"""


def _resolve_schemas(conn) -> list[str]:
    schemas = settings.oracle_schema_list
    if schemas:
        return schemas
    cur = conn.exec_driver_sql(
        "SELECT SYS_CONTEXT('USERENV','CURRENT_SCHEMA') FROM dual")
    return [cur.scalar()]


def _run_per_owner(pd, conn, sql: str, owners: list[str]):
    frames = []
    for owner in owners:
        frames.append(pd.read_sql(sql, conn, params={"owner": owner}))
    return pd.concat(frames, ignore_index=True) if frames else pd.DataFrame()


def run_discovery(output: str | Path | None = None) -> Path:
    import pandas as pd  # import paresseux

    from ..database.oracle import get_engine

    engine = get_engine()
    output = Path(output) if output else REPORTS_DIR / "oracle_inventory.xlsx"
    output.parent.mkdir(parents=True, exist_ok=True)

    frames: dict[str, "pd.DataFrame"] = {}

    with engine.connect() as conn:
        # Connexion (identité)
        frames["connection"] = pd.read_sql(
            """SELECT SYS_CONTEXT('USERENV','DB_NAME') AS db_name,
                      SYS_CONTEXT('USERENV','INSTANCE_NAME') AS instance_name,
                      SYS_CONTEXT('USERENV','SERVICE_NAME') AS service_name,
                      SYS_CONTEXT('USERENV','CURRENT_SCHEMA') AS current_schema,
                      SYS_CONTEXT('USERENV','SESSION_USER') AS session_user
               FROM dual""", conn)

        owners = _resolve_schemas(conn)
        log.info("schémas explorés", extra={"phase": "discover", "count": len(owners)})

        # Colonnes : enrichi puis repli
        try:
            frames["columns"] = _run_per_owner(pd, conn, COLUMNS_ENRICHED, owners)
        except Exception as e:  # noqa: BLE001
            log.warning(f"colonnes enrichies indisponibles, repli basique: {e}")
            try:
                frames["columns"] = _run_per_owner(pd, conn, COLUMNS_BASIC, owners)
            except Exception as e2:  # noqa: BLE001
                frames["columns"] = pd.DataFrame({"erreur": [str(e2)]})

        # Tous les autres volets, indépendamment
        for name, sql in QUERIES.items():
            try:
                frames[name] = _run_per_owner(pd, conn, sql, owners)
            except Exception as e:  # noqa: BLE001
                log.warning(f"volet '{name}' en échec: {e}")
                frames[name] = pd.DataFrame({"erreur": [str(e)]})

        # Comptage réel des lignes (par table, tolérant aux erreurs)
        counts = []
        tbls = frames.get("tables")
        if tbls is not None and "table_name" in getattr(tbls, "columns", []):
            for _, r in tbls.iterrows():
                fq = f'"{r["owner"]}"."{r["table_name"]}"'
                try:
                    n = conn.exec_driver_sql(f"SELECT COUNT(*) FROM {fq}").scalar()
                except Exception as e:  # noqa: BLE001
                    n = f"ERREUR: {e}"
                counts.append({"owner": r["owner"], "table_name": r["table_name"],
                               "row_count": n})
        frames["row_counts"] = pd.DataFrame(counts)

    # Onglet de synthèse
    summary_rows = [{"volet": k, "lignes": (0 if v is None else len(v))}
                    for k, v in frames.items()]
    frames_out = {"discovery_summary": pd.DataFrame(summary_rows)}
    frames_out.update(frames)

    with pd.ExcelWriter(output, engine="openpyxl") as writer:
        for name, df in frames_out.items():
            df.to_excel(writer, sheet_name=name[:31], index=False)

    log.info("inventaire écrit", extra={"phase": "discover"})
    return output
