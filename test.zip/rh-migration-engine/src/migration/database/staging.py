"""Connexion à la base de staging PostgreSQL (données brutes + tables de contrôle)."""
from __future__ import annotations

from config.settings import settings


def get_engine():
    from sqlalchemy import create_engine

    url = (
        f"postgresql+psycopg://{settings.staging_user}:{settings.staging_password}"
        f"@{settings.staging_host}:{settings.staging_port}/{settings.staging_db}"
    )
    return create_engine(url)
