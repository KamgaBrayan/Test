"""Connexion à la source Oracle via python-oracledb (mode Thin, sans Oracle Client).

Import paresseux du driver : le paquet reste importable même si oracledb n'est
pas installé (utile pour les tests hors-ligne).
"""
from __future__ import annotations

from config.settings import settings


def get_connection():
    import oracledb  # import paresseux

    dsn = oracledb.makedsn(
        settings.oracle_host, settings.oracle_port,
        service_name=settings.oracle_service_name,
    )
    return oracledb.connect(
        user=settings.oracle_user,
        password=settings.oracle_password,
        dsn=dsn,
    )


def get_engine():
    """Engine SQLAlchemy (dialecte oracle+oracledb) pour pandas/exploration."""
    from sqlalchemy import create_engine

    url = (
        f"oracle+oracledb://{settings.oracle_user}:{settings.oracle_password}"
        f"@{settings.oracle_host}:{settings.oracle_port}"
        f"/?service_name={settings.oracle_service_name}"
    )
    return create_engine(url)
