"""Connexions au cluster cible Fluxoon : une base par domaine.

On se connecte base par base (fluxoon_auth, fluxoon_org, ...). L'ordre de
chargement est défini dans config/load_order.yaml.
"""
from __future__ import annotations

from functools import lru_cache

import yaml

from config.settings import LOAD_ORDER_PATH, settings


def target_url(database: str) -> str:
    return (
        f"postgresql+psycopg://{settings.target_user}:{settings.target_password}"
        f"@{settings.target_host}:{settings.target_port}/{database}"
    )


@lru_cache(maxsize=None)
def get_engine(database: str):
    from sqlalchemy import create_engine

    return create_engine(target_url(database))


def load_order() -> list[dict]:
    data = yaml.safe_load(LOAD_ORDER_PATH.read_text(encoding="utf-8")) or {}
    paliers = data.get("paliers", [])
    return sorted(paliers, key=lambda p: p.get("level", 99))
