"""Point d'entrée en ligne de commande du moteur de migration.

Verbes disponibles :
    discover        Explorer Oracle et générer l'inventaire (reports/oracle_inventory.xlsx)
    lint-mapping    Vérifier les mappings contre le catalogue cible
    validate        Valider un lot déjà transformé contre le contrat cible (à compléter)
    stage           Extraire Oracle -> staging (à compléter)
    dry-run         Exécuter tout le pipeline sans écrire dans la cible (à compléter)
    execute         Exécuter la migration réelle (à compléter)
    report          Générer le rapport du dernier run (à compléter)

Exemples :
    rh-migration lint-mapping
    rh-migration discover
"""
from __future__ import annotations

import argparse
import sys

from config.settings import MAPPINGS_DIR


def _cmd_lint_mapping(args: argparse.Namespace) -> int:
    from .validation.mapping_linter import lint_all

    issues = lint_all(args.dir)
    errors = [i for i in issues if i.level == "ERROR"]
    warnings = [i for i in issues if i.level == "WARNING"]
    for i in issues:
        print(f"[{i.level}] {i.mapping_file}: {i.message}")
    print(f"\n{len(errors)} erreur(s), {len(warnings)} avertissement(s).")
    return 1 if errors else 0


def _cmd_discover(args: argparse.Namespace) -> int:
    from .discovery.inventory import run_discovery

    out = run_discovery()
    print(f"Inventaire écrit : {out}")
    return 0


def _cmd_todo(name: str):
    def _run(args: argparse.Namespace) -> int:
        print(f"'{name}' sera implémenté après l'exploration Oracle "
              f"(voir docs/architecture.md).")
        return 0
    return _run


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="rh-migration",
                                description="Moteur de migration RH Oracle -> PostgreSQL (Fluxoon)")
    sub = p.add_subparsers(dest="command", required=True)

    sp = sub.add_parser("lint-mapping", help="Vérifier les mappings contre le catalogue")
    sp.add_argument("--dir", default=str(MAPPINGS_DIR), help="Répertoire des mappings")
    sp.set_defaults(func=_cmd_lint_mapping)

    sp = sub.add_parser("discover", help="Explorer Oracle et générer l'inventaire")
    sp.set_defaults(func=_cmd_discover)

    for verb in ("validate", "stage", "dry-run", "execute", "report", "reconcile"):
        sp = sub.add_parser(verb, help=f"{verb} (à compléter)")
        sp.set_defaults(func=_cmd_todo(verb))

    return p


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
