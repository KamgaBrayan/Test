"""Convertisseurs atomiques réutilisables (les briques des transformations).

Chaque fonction est pure et testable unitairement. Une exception ConvertError
est levée en cas d'échec, pour être transformée en MigrationError par le mapper.
"""
from __future__ import annotations

from datetime import date, datetime
from decimal import Decimal, InvalidOperation


class ConvertError(ValueError):
    """Erreur de conversion, portée au mapper qui la consigne."""


def as_str(v) -> str | None:
    return None if v is None else str(v)


def trim(v):
    return v.strip() if isinstance(v, str) else v


def upper(v):
    return v.upper() if isinstance(v, str) else v


def lower(v):
    return v.lower() if isinstance(v, str) else v


def to_int(v):
    if v is None or v == "":
        return None
    try:
        return int(str(v).strip())
    except (ValueError, TypeError) as e:
        raise ConvertError(f"entier invalide: {v!r}") from e


def to_decimal(v):
    if v is None or v == "":
        return None
    try:
        return Decimal(str(v).strip().replace(",", "."))
    except (InvalidOperation, ValueError) as e:
        raise ConvertError(f"décimal invalide: {v!r}") from e


def to_bool(v):
    if v is None or v == "":
        return None
    if isinstance(v, bool):
        return v
    s = str(v).strip().lower()
    if s in {"1", "t", "true", "y", "yes", "o", "oui"}:
        return True
    if s in {"0", "f", "false", "n", "no", "non"}:
        return False
    raise ConvertError(f"booléen invalide: {v!r}")


def to_date(v, fmts: list[str] | None = None):
    if v is None or v == "":
        return None
    if isinstance(v, (date, datetime)):
        return v.date() if isinstance(v, datetime) else v
    fmts = fmts or ["%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y", "%Y/%m/%d"]
    s = str(v).strip()
    for fmt in fmts:
        try:
            return datetime.strptime(s, fmt).date()
        except ValueError:
            continue
    raise ConvertError(f"date non parsable: {v!r}")


def to_timestamp(v, fmts: list[str] | None = None):
    if v is None or v == "":
        return None
    if isinstance(v, datetime):
        return v
    fmts = fmts or ["%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d"]
    s = str(v).strip()
    for fmt in fmts:
        try:
            return datetime.strptime(s, fmt)
        except ValueError:
            continue
    raise ConvertError(f"horodatage non parsable: {v!r}")


# Registre nom -> fonction, utilisé par le mapper (transform.type)
SIMPLE_CONVERTERS = {
    "direct": lambda v: v,
    "trim": trim,
    "uppercase": upper,
    "lowercase": lower,
    "cast_int": to_int,
    "cast_decimal": to_decimal,
    "cast_bool": to_bool,
    "date": to_date,
    "timestamp": to_timestamp,
}
