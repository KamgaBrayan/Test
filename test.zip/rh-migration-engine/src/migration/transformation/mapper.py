"""Application d'un mapping (colonne source -> colonne cible) à une ligne source.

Le mapping est déclaratif (YAML), jamais codé en dur : voir mappings/*.yaml.
Le mapper produit la ligne cible et consigne toute erreur de transformation.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import yaml

from ..errors import ErrorCode, MigrationError, Phase, Severity
from .converters import SIMPLE_CONVERTERS, ConvertError, to_date, to_timestamp
from .json_assembler import build_object
from .lookups import ValueMap, LookupError_


@dataclass
class ColumnMapping:
    target: str
    source: str | None = None
    transform: dict | None = None
    required: bool = False


@dataclass
class TableMapping:
    target_db: str
    target_table: str
    source_table: str | None
    columns: list[ColumnMapping]

    @staticmethod
    def from_file(path: str | Path) -> "TableMapping":
        data = yaml.safe_load(Path(path).read_text(encoding="utf-8")) or {}
        tgt = data.get("target", {})
        src = data.get("source", {})
        cols = [
            ColumnMapping(
                target=c["target"],
                source=c.get("source"),
                transform=c.get("transform"),
                required=c.get("required", False),
            )
            for c in data.get("columns", [])
        ]
        return TableMapping(
            target_db=tgt.get("database", ""),
            target_table=tgt.get("table", ""),
            source_table=src.get("table"),
            columns=cols,
        )


def apply_transform(transform: dict | None, value, source_row: dict, value_maps: dict[str, ValueMap]):
    """Applique une transformation déclarative à une valeur. Peut lever
    ConvertError / LookupError_ (capturées par map_row)."""
    if transform is None:
        return value
    ttype = transform.get("type", "direct")

    if ttype in SIMPLE_CONVERTERS:
        fn = SIMPLE_CONVERTERS[ttype]
        if ttype == "date":
            return to_date(value, transform.get("formats"))
        if ttype == "timestamp":
            return to_timestamp(value, transform.get("formats"))
        return fn(value)
    if ttype == "constant":
        return transform.get("value")
    if ttype == "default":
        return value if value not in (None, "") else transform.get("value")
    if ttype == "concat":
        parts = [str(source_row.get(c, "") or "") for c in transform.get("sources", [])]
        return transform.get("sep", " ").join(p for p in parts if p)
    if ttype == "lookup":
        vm = value_maps.get(transform.get("table", ""))
        if vm is None:
            raise LookupError_(f"table de correspondance absente: {transform.get('table')}")
        return vm.apply(value)
    if ttype == "json_object":
        return build_object(source_row, transform.get("fields", {}),
                            drop_empty=transform.get("drop_empty", True))
    raise ConvertError(f"type de transformation inconnu: {ttype}")


def map_row(
    mapping: TableMapping,
    source_row: dict,
    value_maps: dict[str, ValueMap],
    run_id: str,
    source_key: str = "",
) -> tuple[dict, list[MigrationError]]:
    """Transforme une ligne source en ligne cible. Renvoie (ligne_cible, erreurs)."""
    out: dict = {}
    errors: list[MigrationError] = []
    for cm in mapping.columns:
        raw = source_row.get(cm.source) if cm.source else None
        try:
            out[cm.target] = apply_transform(cm.transform, raw, source_row, value_maps)
        except (ConvertError, LookupError_) as e:
            code = ErrorCode.ENUM_UNMAPPED if isinstance(e, LookupError_) else ErrorCode.TRANSFORM_FAILED
            errors.append(MigrationError(
                run_id, Phase.TRANSFORM, Severity.BLOCKING, code, str(e),
                source_table=mapping.source_table or "", source_key=source_key,
                target_db=mapping.target_db, target_table=mapping.target_table,
                target_column=cm.target, raw_value="" if raw is None else str(raw)[:200]))
    return out, errors
