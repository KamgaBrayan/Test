"""Assemblage d'objets JSON cibles à partir de plusieurs colonnes source.

La cible Fluxoon comporte de nombreuses colonnes jsonb (contact, bank_account,
personal_address, emergency_contacts, identity_ids...). Les données Oracle étant
généralement plates, on reconstruit l'objet JSON ici.
"""
from __future__ import annotations


def build_object(source_row: dict, field_map: dict[str, str], drop_empty: bool = True) -> dict | None:
    """field_map : {clé_json_cible: colonne_source}. Renvoie un dict (ou None si vide)."""
    obj = {}
    for json_key, src_col in field_map.items():
        val = source_row.get(src_col)
        if drop_empty and (val is None or val == ""):
            continue
        obj[json_key] = val
    return obj or None
