"""Tables de correspondance de valeurs (enums) : code source -> valeur cible.

Alimentées par les fichiers mappings/enums/*.yaml (issus de la feuille 03_Enums).
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import yaml

from config.settings import ENUMS_DIR


class LookupError_(Exception):
    pass


@dataclass
class ValueMap:
    name: str
    values: dict[str, str]
    on_unmapped: str = "reject"   # reject | default | passthrough
    default: str | None = None

    def apply(self, v):
        if v is None:
            return None
        key = str(v).strip()
        if key in self.values:
            return self.values[key]
        if self.on_unmapped == "passthrough":
            return v
        if self.on_unmapped == "default":
            return self.default
        raise LookupError_(f"valeur non mappée pour '{self.name}': {v!r}")


def load_value_maps(directory: str | Path = ENUMS_DIR) -> dict[str, ValueMap]:
    directory = Path(directory)
    maps: dict[str, ValueMap] = {}
    if not directory.exists():
        return maps
    for f in sorted(directory.glob("*.yaml")):
        if f.name.startswith("_"):
            continue  # fichiers d'exemple ignorés
        data = yaml.safe_load(f.read_text(encoding="utf-8")) or {}
        name = f.stem
        maps[name] = ValueMap(
            name=name,
            values={str(k): str(v) for k, v in (data.get("values") or {}).items()},
            on_unmapped=data.get("on_unmapped", "reject"),
            default=data.get("default"),
        )
    return maps
