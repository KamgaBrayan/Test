"""Validation d'une ligne cible contre le contrat du catalogue.

Vérifie, colonne par colonne et sans règle codée en dur :
- NOT NULL (colonne obligatoire vide) ;
- longueur varchar/char (débordement) ;
- précision/échelle numérique ;
- appartenance aux valeurs d'enum (CHECK) ;
- cohérence de type de base (entier, booléen, date...).

Renvoie une liste de MigrationError (vide si la ligne est conforme).
"""
from __future__ import annotations

from datetime import date, datetime
from decimal import Decimal

from ..catalog.loader import Catalog, Table
from ..errors import ErrorCode, MigrationError, Phase, Severity


def _is_empty(v) -> bool:
    return v is None or (isinstance(v, str) and v.strip() == "")


def validate_row(
    catalog: Catalog,
    db: str,
    table: str,
    row: dict,
    run_id: str,
    source_key: str = "",
) -> list[MigrationError]:
    tbl: Table | None = catalog.resolve(db, table)  # type: ignore[assignment]
    errors: list[MigrationError] = []
    if tbl is None:
        errors.append(MigrationError(
            run_id, Phase.VALIDATE, Severity.BLOCKING, ErrorCode.BUSINESS_RULE,
            f"table cible inconnue: {db}.{table}", target_db=db, target_table=table,
            source_key=source_key))
        return errors

    def err(code: ErrorCode, msg: str, col: str, val) -> None:
        errors.append(MigrationError(
            run_id, Phase.VALIDATE, Severity.BLOCKING, code, msg,
            target_db=db, target_table=table, target_column=col,
            source_key=source_key, raw_value="" if val is None else str(val)[:200]))

    for cname, col in tbl.columns.items():
        val = row.get(cname)

        if _is_empty(val):
            if not col.nullable:
                err(ErrorCode.REQUIRED_NULL, "valeur obligatoire manquante", cname, val)
            continue

        # Enum (CHECK)
        if col.enum is not None and str(val) not in col.enum:
            err(ErrorCode.ENUM_UNMAPPED,
                f"valeur hors enum {col.enum}", cname, val)
            continue

        bt = col.base_type
        # Longueur texte
        if bt == "text" and col.max_length is not None:
            if len(str(val)) > col.max_length:
                err(ErrorCode.LENGTH_OVERFLOW,
                    f"longueur {len(str(val))} > max {col.max_length}", cname, val)
        # Numérique
        elif bt == "numeric":
            try:
                dec = Decimal(str(val).replace(",", "."))
            except Exception:
                err(ErrorCode.TYPE_CAST, "décimal invalide", cname, val)
            else:
                ps = col.numeric_precision_scale
                if ps:
                    precision, scale = ps
                    digits = dec.as_tuple()
                    int_digits = len(digits.digits) + digits.exponent
                    if int_digits > (precision - scale):
                        err(ErrorCode.NUMERIC_OVERFLOW,
                            f"dépassement numeric({precision},{scale})", cname, val)
        elif bt == "integer":
            if not isinstance(val, int):
                try:
                    int(str(val))
                except (ValueError, TypeError):
                    err(ErrorCode.TYPE_CAST, "entier invalide", cname, val)
        elif bt == "boolean":
            if not isinstance(val, bool) and str(val).lower() not in {
                "t", "f", "true", "false", "0", "1"}:
                err(ErrorCode.TYPE_CAST, "booléen invalide", cname, val)
        elif bt in ("date", "timestamp"):
            if not isinstance(val, (date, datetime, str)):
                err(ErrorCode.DATE_PARSE, "date/horodatage invalide", cname, val)

    return errors
