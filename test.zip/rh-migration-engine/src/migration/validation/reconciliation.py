"""Réconciliation source -> cible : comptages et équation de contrôle.

    source = migrés + rejetés   (doit toujours être vérifié)
"""
from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class Recon:
    entity: str
    source_count: int = 0
    migrated_count: int = 0
    rejected_count: int = 0
    warnings: int = 0

    @property
    def balanced(self) -> bool:
        return self.source_count == self.migrated_count + self.rejected_count

    def as_row(self) -> dict:
        return {
            "entity": self.entity,
            "source": self.source_count,
            "migrated": self.migrated_count,
            "rejected": self.rejected_count,
            "warnings": self.warnings,
            "balanced": self.balanced,
        }


@dataclass
class ReconReport:
    items: list[Recon] = field(default_factory=list)

    def add(self, r: Recon) -> None:
        self.items.append(r)

    @property
    def all_balanced(self) -> bool:
        return all(r.balanced for r in self.items)
