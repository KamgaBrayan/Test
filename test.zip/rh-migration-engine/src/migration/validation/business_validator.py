"""Règles métier transverses (inter-champs, cohérence), écrites à la main.

À COMPLÉTER après l'exploration Oracle et la définition des règles métier
(étape 5). Exemples typiques : date_fin >= date_debut, un seul contrat actif,
cohérence entre statut et date de sortie, etc.
"""
from __future__ import annotations

from collections.abc import Callable

from ..errors import MigrationError

# Un validateur métier prend (ligne_cible, run_id, source_key) et renvoie des erreurs.
BusinessRule = Callable[[dict, str, str], list[MigrationError]]

# Enregistrer ici les règles par table cible : {"employees": [rule1, rule2], ...}
RULES_BY_TABLE: dict[str, list[BusinessRule]] = {}


def validate_business(table: str, row: dict, run_id: str, source_key: str = "") -> list[MigrationError]:
    errors: list[MigrationError] = []
    for rule in RULES_BY_TABLE.get(table, []):
        errors.extend(rule(row, run_id, source_key))
    return errors
