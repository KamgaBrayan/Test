"""Linter de mapping : vérifie un fichier de mapping CONTRE le catalogue cible.

Attrape avant toute exécution : tables/colonnes cibles inexistantes, colonnes
obligatoires non couvertes, transformations inconnues, et valeurs d'enum
produites par un lookup qui ne respecteraient pas le CHECK de la cible.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from ..catalog.loader import Catalog, load_catalog
from ..transformation.lookups import ValueMap, load_value_maps
from ..transformation.mapper import TableMapping

_KNOWN_TRANSFORMS = {
    "direct", "trim", "uppercase", "lowercase", "cast_int", "cast_decimal",
    "cast_bool", "date", "timestamp", "constant", "default", "concat",
    "lookup", "json_object",
}


@dataclass
class LintIssue:
    level: str            # ERROR | WARNING
    mapping_file: str
    message: str


def lint_mapping_file(
    path: str | Path,
    catalog: Catalog,
    value_maps: dict[str, ValueMap],
) -> list[LintIssue]:
    path = Path(path)
    issues: list[LintIssue] = []
    fname = path.name
    try:
        m = TableMapping.from_file(path)
    except Exception as e:  # noqa: BLE001
        return [LintIssue("ERROR", fname, f"fichier illisible: {e}")]

    tbl = catalog.resolve(m.target_db, m.target_table)
    if tbl is None:
        return [LintIssue("ERROR", fname,
                          f"table cible inconnue: {m.target_db}.{m.target_table}")]

    target_cols = set(tbl.columns.keys())
    mapped_targets = set()

    for cm in m.columns:
        mapped_targets.add(cm.target)
        col = tbl.column(cm.target)
        if col is None:
            issues.append(LintIssue("ERROR", fname,
                f"colonne cible inexistante: {m.target_table}.{cm.target}"))
            continue
        ttype = (cm.transform or {}).get("type", "direct")
        if ttype not in _KNOWN_TRANSFORMS:
            issues.append(LintIssue("ERROR", fname,
                f"transformation inconnue '{ttype}' sur {cm.target}"))
        # Un lookup alimentant une colonne enum : ses sorties doivent être un
        # sous-ensemble des valeurs autorisées par le CHECK cible.
        if ttype == "lookup" and col.enum is not None:
            vm = value_maps.get((cm.transform or {}).get("table", ""))
            if vm is None:
                issues.append(LintIssue("ERROR", fname,
                    f"table de correspondance absente pour {cm.target}"))
            else:
                bad = sorted(set(vm.values.values()) - set(col.enum))
                if bad:
                    issues.append(LintIssue("ERROR", fname,
                        f"{cm.target}: valeurs produites hors enum {bad} (autorisé: {col.enum})"))

    # Colonnes cibles obligatoires non couvertes par le mapping
    for cname in target_cols - mapped_targets:
        col = tbl.column(cname)
        if col and not col.nullable:
            issues.append(LintIssue("WARNING", fname,
                f"colonne obligatoire non mappée: {cname} (prévoir source, défaut ou constante)"))

    return issues


def lint_all(
    mappings_dir: str | Path,
    catalog: Catalog | None = None,
    value_maps: dict[str, ValueMap] | None = None,
) -> list[LintIssue]:
    catalog = catalog or load_catalog()
    value_maps = value_maps if value_maps is not None else load_value_maps()
    issues: list[LintIssue] = []
    for f in sorted(Path(mappings_dir).glob("*.yaml")):
        if f.name.startswith("_"):
            continue
        issues.extend(lint_mapping_file(f, catalog, value_maps))
    return issues
