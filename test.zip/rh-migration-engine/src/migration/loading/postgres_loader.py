"""Chargement vers une base PostgreSQL cible (UPSERT idempotent).

À COMPLÉTER : en dry-run, ne rien écrire (compter seulement) ; en execute,
INSERT ... ON CONFLICT (clés) DO UPDATE, par lots et en transaction, avec
savepoints pour isoler les échecs de lot.
"""
from __future__ import annotations

from .base import Loader


class PostgresLoader(Loader):
    def __init__(self, engine, dry_run: bool = True) -> None:
        self._engine = engine
        self._dry_run = dry_run

    def upsert(self, table: str, rows: list[dict], conflict_keys: list[str]) -> int:
        if self._dry_run:
            return len(rows)  # dry-run : on compte, on n'écrit pas
        raise NotImplementedError("À implémenter à l'étape LOAD (INSERT ... ON CONFLICT).")
