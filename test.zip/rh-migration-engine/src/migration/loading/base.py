"""Interface de chargement (un adaptateur par base cible)."""
from __future__ import annotations

from abc import ABC, abstractmethod


class Loader(ABC):
    @abstractmethod
    def upsert(self, table: str, rows: list[dict], conflict_keys: list[str]) -> int:
        """Insère/actualise des lignes (idempotent sur conflict_keys). Renvoie le
        nombre de lignes affectées."""
