-- Comptage RÉEL des lignes par table (les stats NUM_ROWS peuvent être périmées).
-- Bloc PL/SQL : boucle sur les tables, COUNT(*) dynamique, sortie propre.
-- => évite le problème du "UNION ALL" en trop d'un générateur naïf.
-- Prérequis SQL Developer/SQLcl : SET SERVEROUTPUT ON (déjà fait dans 00_run_all).
-- Le moteur Python (rh-migration discover) fait la même chose automatiquement.
DEFINE SCHEMA = RH
SET SERVEROUTPUT ON SIZE UNLIMITED
DECLARE
  v_count   NUMBER;
  v_sql     VARCHAR2(400);
BEGIN
  DBMS_OUTPUT.PUT_LINE(RPAD('TABLE_NAME', 40) || 'ROW_COUNT');
  DBMS_OUTPUT.PUT_LINE(RPAD('-', 49, '-'));
  FOR t IN (
    SELECT table_name
    FROM all_tables
    WHERE owner = '&SCHEMA'
    ORDER BY table_name
  ) LOOP
    v_sql := 'SELECT COUNT(*) FROM "&SCHEMA"."' || t.table_name || '"';
    BEGIN
      EXECUTE IMMEDIATE v_sql INTO v_count;
      DBMS_OUTPUT.PUT_LINE(RPAD(t.table_name, 40) || v_count);
    EXCEPTION WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE(RPAD(t.table_name, 40) || 'ERREUR: ' || SQLERRM);
    END;
  END LOOP;
END;
/
