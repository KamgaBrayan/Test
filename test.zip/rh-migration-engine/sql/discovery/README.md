# Scripts de découverte Oracle (SQL Developer / SQLcl)

Objectif : recueillir **tout** ce dont la migration a besoin sur la base source
Amplitude — structure, relations, logique applicative et documentation.

## Deux façons de les utiliser

### A. Automatique (recommandé) — via le moteur
Une fois `.env` renseigné :
```
rh-migration discover
```
=> `reports/oracle_inventory.xlsx`, une feuille par volet + un onglet de synthèse.
Le moteur fait aussi le **comptage réel** des lignes, avec gestion des erreurs par table.

### B. Manuel — dans SQL Developer
1. Ouvre `00_run_all.sql`, ajuste `DEFINE SCHEMA = RH` et `DEFINE OUT = ...`.
2. Exécute en **Run Script (F5)**. Chaque volet est spoolé en CSV.
3. Ou lance un `NN_*.sql` isolément (il contient son propre `DEFINE SCHEMA`),
   puis exporte la grille (clic droit → Export → CSV/Excel).

## Périmètre couvert

| # | Script | Vue Oracle | Rôle |
|---|--------|-----------|------|
| 01 | connection | `SYS_CONTEXT` | Identité de la connexion (base, schéma, user) |
| 02 | object_inventory | `ALL_OBJECTS` | Objets par type (tables, vues, séquences, triggers, packages…) |
| 03 | tables | `ALL_TABLES` | Tables + partitionnement + dernière analyse |
| 04 | columns | `ALL_TAB_COLUMNS` | Colonnes + sémantique BYTE/CHAR, identité, virtuelle, cachée |
| 05 | constraints | `ALL_CONSTRAINTS` / `ALL_CONS_COLUMNS` | PK / UK / CHECK (+ enums applicatifs) |
| 06 | foreign_keys | `ALL_CONSTRAINTS` ×2 | FK **colonne enfant → colonne parente** (graphe de charge) |
| 07 | indexes | `ALL_INDEXES` | Index (unicité, type, statut) |
| 08 | index_columns | `ALL_IND_COLUMNS` | Colonnes des index (clés métier candidates) |
| 09 | views | `ALL_VIEWS` | Vues métier (logique applicative) |
| 10 | sequences | `ALL_SEQUENCES` | Génération des identifiants |
| 11 | triggers | `ALL_TRIGGERS` | Effets de bord à l'écriture (11b = corps, optionnel) |
| 12 | procedures | `ALL_PROCEDURES` | Packages / procédures / fonctions |
| 13 | synonyms | `ALL_SYNONYMS` | Alias d'objets (dont DB links) |
| 14 | dependencies | `ALL_DEPENDENCIES` | Cartographie de la logique (VIEW→TABLE…) |
| 15 | table_comments | `ALL_TAB_COMMENTS` | Documentation métier des tables |
| 16 | column_comments | `ALL_COL_COMMENTS` | Documentation métier des colonnes (glossaire) |
| 17 | row_counts | PL/SQL | **Comptage réel** des lignes (sans `UNION ALL` en trop) |
| 18 | profiling_template | — | Gabarit de profilage (relève de l'**étape 4**) |
| 90 | invalid_objects | `ALL_OBJECTS` | (Optionnel) objets invalides |
| 91 | lob_columns | `ALL_TAB_COLUMNS` | (Optionnel) colonnes LOB |

## Notes importantes
- Les vues `ALL_*` montrent ce que **le compte courant a le droit de voir**
  (principe du moindre privilège), pas nécessairement toute la base.
- `NUM_ROWS` (script 03) est une **estimation** ; le comptage réel est le script 17.
- Colonnes `IDENTITY_COLUMN` / `HIDDEN_COLUMN` : Oracle **12c+**. Sur une version
  antérieure, retire-les du script 04 (le moteur Python les ignore automatiquement si absentes).
- Le **profilage** (18) n'est pas de la découverte de structure : il appartient à
  l'étape 4 (Data Profiling), une fois le modèle source compris.
