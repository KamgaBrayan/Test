-- OPTIONNEL : corps complet des triggers (peut être volumineux et multi-lignes).
-- À n'exécuter que si l'analyse d'un trigger précis est nécessaire.
DEFINE SCHEMA = RH
SELECT owner, trigger_name, triggering_event, trigger_type, trigger_body
FROM all_triggers
WHERE owner = '&SCHEMA'
ORDER BY table_name, trigger_name;
