-- Colonnes : type, taille, précision, nullabilité, valeur par défaut + sémantique.
-- CHAR_USED (B/C) distingue VARCHAR2(50 BYTE) de VARCHAR2(50 CHAR) : crucial en migration.
-- IDENTITY_COLUMN / VIRTUAL_COLUMN / HIDDEN_COLUMN : Oracle 12c+ (sinon retirer ces colonnes).
DEFINE SCHEMA = RH
SELECT owner, table_name, column_id, column_name, data_type,
       data_length, char_length, char_used,
       data_precision, data_scale, nullable, data_default,
       identity_column, virtual_column, hidden_column
FROM all_tab_columns
WHERE owner = '&SCHEMA'
ORDER BY owner, table_name, column_id;
