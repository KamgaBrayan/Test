-- Dépendances entre objets : VIEW->TABLE, PACKAGE->TABLE, TRIGGER->TABLE...
-- NB : les relations structurelles entre tables viennent des FK (script 06),
-- pas d'ici. ALL_DEPENDENCIES sert surtout à cartographier la logique applicative.
DEFINE SCHEMA = RH
SELECT owner, name, type, referenced_owner, referenced_name, referenced_type
FROM all_dependencies
WHERE owner = '&SCHEMA'
ORDER BY name, type;
