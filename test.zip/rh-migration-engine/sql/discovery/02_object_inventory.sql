-- Inventaire des objets par schéma ET par type (vision structurante d'Amplitude).
-- Remplace le simple comptage de schémas : montre tables, vues, séquences,
-- triggers, packages, procédures... d'un coup d'oeil.
DEFINE SCHEMA = RH
SELECT owner, object_type, COUNT(*) AS object_count
FROM all_objects
WHERE owner = '&SCHEMA'
GROUP BY owner, object_type
ORDER BY owner, object_type;
