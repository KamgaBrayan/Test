-- Clés primaires (P), uniques (U) et contraintes CHECK (C) + colonnes impliquées.
-- Les CHECK peuvent encoder des "enums" applicatifs (ex: STATUT IN ('A','I','S')).
DEFINE SCHEMA = RH
SELECT c.owner, c.table_name, c.constraint_name, c.constraint_type,
       cc.column_name, cc.position, c.status, c.search_condition
FROM all_constraints c
JOIN all_cons_columns cc
  ON c.owner = cc.owner AND c.constraint_name = cc.constraint_name
WHERE c.owner = '&SCHEMA'
  AND c.constraint_type IN ('P','U','C')
ORDER BY c.table_name, c.constraint_name, cc.position;
