-- Commentaires de colonnes : souvent la meilleure source pour décoder des noms
-- abrégés (MAT_EMP -> "Matricule de l'agent"). Accélère le Business Glossary (étape 5).
DEFINE SCHEMA = RH
SELECT owner, table_name, column_name, comments
FROM all_col_comments
WHERE owner = '&SCHEMA' AND comments IS NOT NULL
ORDER BY table_name, column_name;
