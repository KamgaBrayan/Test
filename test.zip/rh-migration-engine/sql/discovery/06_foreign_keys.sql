-- Clés étrangères : colonne ENFANT -> colonne PARENTE (alignées par position).
-- Correction vs version initiale : on récupère AUSSI la colonne parente,
-- pas seulement la table parente. Indispensable pour le mapping et le graphe de charge.
--   RH.EMPLOYE.DEPARTEMENT_ID  ->  RH.DEPARTEMENT.ID
DEFINE SCHEMA = RH
SELECT c.owner,
       c.table_name        AS child_table,
       cc.column_name      AS child_column,
       cc.position,
       c.constraint_name,
       rc.owner            AS parent_owner,
       rc.table_name       AS parent_table,
       rcc.column_name     AS parent_column,
       c.delete_rule
FROM all_constraints c
JOIN all_cons_columns cc
  ON c.owner = cc.owner AND c.constraint_name = cc.constraint_name
JOIN all_constraints rc
  ON c.r_owner = rc.owner AND c.r_constraint_name = rc.constraint_name
JOIN all_cons_columns rcc
  ON rc.owner = rcc.owner AND rc.constraint_name = rcc.constraint_name
 AND rcc.position = cc.position
WHERE c.owner = '&SCHEMA'
  AND c.constraint_type = 'R'
ORDER BY c.table_name, c.constraint_name, cc.position;
