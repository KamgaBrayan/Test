-- ============================================================
--  DÉCOUVERTE ORACLE — exécuteur global (SQL Developer / SQLcl)
--  Lancer en "Run Script" (F5).
--  1) Adapter SCHEMA ci-dessous.  2) Adapter le dossier de sortie &OUT.
-- ============================================================
DEFINE SCHEMA = RH
DEFINE OUT = C:\migration\inventory

SET SQLFORMAT csv
SET SERVEROUTPUT ON SIZE UNLIMITED
SET FEEDBACK OFF
SET PAGESIZE 0
SET LINESIZE 32767
SET TRIMSPOOL ON

PROMPT === 01 Connexion ===
SPOOL &OUT\01_connection.csv
@01_connection.sql
SPOOL OFF

PROMPT === 02 Inventaire des objets ===
SPOOL &OUT\02_object_inventory.csv
@02_object_inventory.sql
SPOOL OFF

PROMPT === 03 Tables ===
SPOOL &OUT\03_tables.csv
@03_tables.sql
SPOOL OFF

PROMPT === 04 Colonnes ===
SPOOL &OUT\04_columns.csv
@04_columns.sql
SPOOL OFF

PROMPT === 05 Contraintes PK/UK/CHECK ===
SPOOL &OUT\05_constraints.csv
@05_constraints.sql
SPOOL OFF

PROMPT === 06 Cles etrangeres ===
SPOOL &OUT\06_foreign_keys.csv
@06_foreign_keys.sql
SPOOL OFF

PROMPT === 07 Index ===
SPOOL &OUT\07_indexes.csv
@07_indexes.sql
SPOOL OFF

PROMPT === 08 Colonnes d'index ===
SPOOL &OUT\08_index_columns.csv
@08_index_columns.sql
SPOOL OFF

PROMPT === 09 Vues ===
SPOOL &OUT\09_views.csv
@09_views.sql
SPOOL OFF

PROMPT === 10 Sequences ===
SPOOL &OUT\10_sequences.csv
@10_sequences.sql
SPOOL OFF

PROMPT === 11 Triggers ===
SPOOL &OUT\11_triggers.csv
@11_triggers.sql
SPOOL OFF

PROMPT === 12 Procedures/Fonctions/Packages ===
SPOOL &OUT\12_procedures.csv
@12_procedures.sql
SPOOL OFF

PROMPT === 13 Synonymes ===
SPOOL &OUT\13_synonyms.csv
@13_synonyms.sql
SPOOL OFF

PROMPT === 14 Dependances ===
SPOOL &OUT\14_dependencies.csv
@14_dependencies.sql
SPOOL OFF

PROMPT === 15 Commentaires de tables ===
SPOOL &OUT\15_table_comments.csv
@15_table_comments.sql
SPOOL OFF

PROMPT === 16 Commentaires de colonnes ===
SPOOL &OUT\16_column_comments.csv
@16_column_comments.sql
SPOOL OFF

PROMPT === 17 Comptage reel des lignes ===
SPOOL &OUT\17_row_counts.txt
@17_row_counts.sql
SPOOL OFF

PROMPT Termine. Fichiers generes dans &OUT
