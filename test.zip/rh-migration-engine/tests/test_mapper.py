from migration.transformation.mapper import TableMapping, map_row
from migration.transformation.lookups import load_value_maps
from config.settings import MAPPINGS_DIR


def test_map_employees_example():
    m = TableMapping.from_file(MAPPINGS_DIR / "employees.yaml")
    vmaps = load_value_maps()
    src = {"MATRICULE": " E001 ", "PRENOM": " Jean ", "NOM": "dupont",
           "SEXE": "M", "STATUT": "A", "DATE_NAISS": "31/12/1990",
           "EMAIL": "j@x.cm", "TELEPHONE": "699"}
    out, errs = map_row(m, src, vmaps, run_id="t", source_key="E001")
    assert errs == []
    assert out["employee_id"] == "E001"
    assert out["last_name"] == "DUPONT"
    assert out["gender"] == "MALE"
    assert out["status"] == "ACTIVE"
    assert out["contact"] == {"email": "j@x.cm", "phone": "699"}
