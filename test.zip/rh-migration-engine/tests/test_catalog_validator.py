from migration.validation.catalog_validator import validate_row
from migration.errors import ErrorCode


def _codes(errors):
    return {e.code for e in errors}


def test_required_null_detected(catalog):
    # employee_id est NOT NULL -> vide doit être rejeté
    row = {"company_id": "C1", "employee_id": "", "first_name": "A",
           "last_name": "B", "nationality": "X"}
    errs = validate_row(catalog, "fluxoon_employee", "employees", row, run_id="t")
    assert ErrorCode.REQUIRED_NULL in _codes(errs)


def test_enum_violation_detected(catalog):
    row = {"company_id": "C1", "employee_id": "E1", "first_name": "A",
           "last_name": "B", "nationality": "X", "gender": "XX"}
    errs = validate_row(catalog, "fluxoon_employee", "employees", row, run_id="t")
    assert ErrorCode.ENUM_UNMAPPED in _codes(errs)


def test_length_overflow_detected(catalog):
    row = {"company_id": "C1", "employee_id": "E" * 300, "first_name": "A",
           "last_name": "B", "nationality": "X"}
    errs = validate_row(catalog, "fluxoon_employee", "employees", row, run_id="t")
    assert ErrorCode.LENGTH_OVERFLOW in _codes(errs)


def test_valid_row_passes(catalog):
    row = {"company_id": "C1", "employee_id": "E1", "first_name": "A",
           "last_name": "B", "nationality": "X", "gender": "MALE"}
    errs = validate_row(catalog, "fluxoon_employee", "employees", row, run_id="t")
    # on n'exige pas 0 (d'autres colonnes NOT NULL peuvent manquer),
    # mais aucune de ces trois erreurs ne doit porter sur les colonnes fournies
    codes = _codes(errs)
    assert ErrorCode.ENUM_UNMAPPED not in codes
    assert ErrorCode.LENGTH_OVERFLOW not in codes
