from datetime import date
from decimal import Decimal

import pytest

from migration.transformation.converters import (
    ConvertError, to_bool, to_date, to_decimal, to_int, trim, upper,
)


def test_trim_and_upper():
    assert trim("  x ") == "x"
    assert upper("ab") == "AB"
    assert upper(None) is None


def test_to_int():
    assert to_int(" 42 ") == 42
    assert to_int("") is None
    with pytest.raises(ConvertError):
        to_int("abc")


def test_to_decimal_accepts_comma():
    assert to_decimal("3,14") == Decimal("3.14")


def test_to_bool():
    assert to_bool("Oui") is True
    assert to_bool("0") is False
    with pytest.raises(ConvertError):
        to_bool("peut-être")


def test_to_date_formats():
    assert to_date("31/12/2024") == date(2024, 12, 31)
    assert to_date("2024-01-05") == date(2024, 1, 5)
    with pytest.raises(ConvertError):
        to_date("pas une date")
