"""Fixtures partagées. pythonpath=src est configuré dans pyproject.toml."""
import pytest

from migration.catalog.loader import load_catalog


@pytest.fixture(scope="session")
def catalog():
    return load_catalog()
