from migration.validation.mapping_linter import lint_all
from config.settings import MAPPINGS_DIR


def test_example_mapping_has_no_errors():
    issues = lint_all(MAPPINGS_DIR)
    errors = [i for i in issues if i.level == "ERROR"]
    assert errors == [], f"Le mapping d'exemple ne doit pas avoir d'erreur: {errors}"
