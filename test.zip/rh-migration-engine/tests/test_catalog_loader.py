def test_catalog_loads_eight_databases(catalog):
    # 8 bases fonctionnelles attendues
    assert "fluxoon_employee" in catalog.databases
    assert "fluxoon_auth" in catalog.databases
    assert len(catalog.databases) >= 8


def test_employees_table_has_pk_and_enum(catalog):
    t = catalog.resolve("fluxoon_employee", "employees")
    assert t is not None
    assert "company_id" in t.pk
    gender = t.column("gender")
    assert gender is not None and gender.enum, "gender doit porter un enum (CHECK)"


def test_varchar_length_parsing(catalog):
    col = catalog.resolve("fluxoon_employee", "employees", "employee_id")
    assert col is not None
    assert col.base_type == "text"
    assert col.max_length == 255
