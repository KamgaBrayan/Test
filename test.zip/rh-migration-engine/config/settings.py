"""Configuration centrale, chargée depuis les variables d'environnement (.env).

Aucune valeur secrète n'est codée en dur : tout vient de l'environnement.
Voir .env.example pour la liste des variables attendues.
"""
from __future__ import annotations

from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict

# Racine du projet (deux niveaux au-dessus de ce fichier : config/ -> projet/)
PROJECT_ROOT = Path(__file__).resolve().parents[1]


class Settings(BaseSettings):
    # --- Source Oracle ---
    oracle_user: str = "migration_readonly"
    oracle_password: str = ""
    oracle_host: str = "127.0.0.1"
    oracle_port: int = 1521
    oracle_service_name: str = "ORCLPDB1"
    oracle_schemas: str = ""  # liste séparée par des virgules ; vide = schéma courant

    # --- Staging PostgreSQL ---
    staging_host: str = "127.0.0.1"
    staging_port: int = 5432
    staging_db: str = "migration_staging"
    staging_user: str = "migration"
    staging_password: str = ""

    # --- Cible (cluster Fluxoon) ---
    target_host: str = "127.0.0.1"
    target_port: int = 5432
    target_user: str = "migration"
    target_password: str = ""

    # --- Exécution ---
    migration_mode: str = "dry-run"  # dry-run | execute
    migration_max_blocking_rate: float = 5.0
    target_company_id: str = ""

    model_config = SettingsConfigDict(
        env_file=PROJECT_ROOT / ".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    @property
    def oracle_schema_list(self) -> list[str]:
        return [s.strip().upper() for s in self.oracle_schemas.split(",") if s.strip()]


# Instance unique importable partout : `from config.settings import settings`
settings = Settings()

# Chemins standards du projet
CATALOG_DIR = PROJECT_ROOT / "catalog"
MAPPINGS_DIR = PROJECT_ROOT / "mappings"
ENUMS_DIR = MAPPINGS_DIR / "enums"
SQL_DIR = PROJECT_ROOT / "sql"
REPORTS_DIR = PROJECT_ROOT / "reports"
LOGS_DIR = PROJECT_ROOT / "logs"
STAGING_EXPORTS_DIR = PROJECT_ROOT / "staging_exports"
SCHEMA_CATALOG_PATH = CATALOG_DIR / "schema_catalog.json"
LOAD_ORDER_PATH = PROJECT_ROOT / "config" / "load_order.yaml"
