"""Journalisation structurée en JSON, indexée par run_id.

Chaque ligne de log est un objet JSON : facile à filtrer (grep/jq) pendant
l'exécution, ce qui répond à l'objectif « identifier facilement les erreurs ».
"""
from __future__ import annotations

import json
import logging
import sys
from datetime import datetime, timezone


class JsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        payload = {
            "ts": datetime.now(timezone.utc).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "msg": record.getMessage(),
        }
        # Contexte additionnel passé via logger.info(..., extra={"run_id": ...})
        for key in ("run_id", "phase", "table", "count", "code"):
            val = getattr(record, key, None)
            if val is not None:
                payload[key] = val
        if record.exc_info:
            payload["exc"] = self.formatException(record.exc_info)
        return json.dumps(payload, ensure_ascii=False)


def setup_logging(level: str = "INFO", logfile: str | None = None) -> logging.Logger:
    root = logging.getLogger("migration")
    root.setLevel(level)
    root.handlers.clear()

    stream = logging.StreamHandler(sys.stdout)
    stream.setFormatter(JsonFormatter())
    root.addHandler(stream)

    if logfile:
        fh = logging.FileHandler(logfile, encoding="utf-8")
        fh.setFormatter(JsonFormatter())
        root.addHandler(fh)

    root.propagate = False
    return root
