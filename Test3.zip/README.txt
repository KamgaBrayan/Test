FICHIERS DELIMITES (séparateur ';', encodage UTF-8-BOM)
=========================================================
00_contexte_prerequis.csv : valeurs à obtenir après la config manuelle Auth/Org
                            (ORG_ID, COMPANY_ID, LEGAL_ENTITY_ID, CONVENTION...).
crosswalk_employee.csv    : écrit par l'ETL (source cdos|nmat -> employee_id UUID).
crosswalk_generic.csv     : autres entités (engagement, contrat...).
map_*.csv                 : correspondances de valeurs (enums) -> Lookup tMap, option reject.
completion_*.csv          : VIDES au départ. À remplir quand CCA fournit l'organigramme
                            et les infos employés fiables ; réinjectés en Lookup pour
                            compléter les colonnes laissées nulles (sites, unités, e-mails...).

Regle : tant qu'un completion_*.csv est vide, la colonne cible correspondante reste NULL,
sans bloquer la migration.
