-- =====================================================================
--  EXTRACTION DES NOMENCLATURES & PROFILAGE DES CODES — schéma DELTARH
--  SIRH Amplitude -> préparation du mapping des référentiels vers Fluxoon
--
--  POURQUOI CE SCRIPT
--  ------------------
--  Amplitude stocke ses référentiels (catégories 1..12, échelons, grades,
--  motifs, nationalités, couleurs, etc.) dans un magasin GÉNÉRIQUE clé-valeur :
--    - RHTNOM : registre des "tables générales" (CTAB = n° de table, LIBE = nom)
--    - RHFNOM : les VALEURS (CTAB + CACC=code + VALL=libellé + VALM/VALT)
--  La découverte (structure) et le dictionnaire (structure) ne donnent PAS ces
--  valeurs saisies par CCA. Ce script les extrait, + profile les codes réellement
--  utilisés sur la table pivot RHPAGENT (ceux qu'il faudra faire correspondre
--  aux enums fermés de Fluxoon : contract_type, gender, marital_status, ...).
--
--  EXÉCUTION (SQLcl recommandé pour le CSV) :
--    sql user_dhi/'Cc4Rh#di2026'@100.0.0.176:1521/testrh
--    @extract_nomenclatures.sql
--  (ou "Run Script" / F5 dans SQL Developer)
-- =====================================================================

DEFINE SCHEMA = DELTARH
DEFINE OUT = C:\migration\inventory

SET SQLFORMAT csv
SET FEEDBACK OFF
SET PAGESIZE 0
SET LINESIZE 32767
SET TRIMSPOOL ON
SET VERIFY OFF

-- ---------------------------------------------------------------------
--  1) REGISTRE DES NOMENCLATURES  (à quoi correspond chaque CTAB ?)
-- ---------------------------------------------------------------------
PROMPT === 1. Registre des nomenclatures (RHTNOM) ===
SPOOL &OUT\nomen_01_registre.csv
SELECT cdos, ctab, libe AS nom_nomenclature, nccl AS taille_cle, typc AS type_cle
FROM &SCHEMA.rhtnom
ORDER BY cdos, ctab;
SPOOL OFF

-- ---------------------------------------------------------------------
--  2) VALEURS DES NOMENCLATURES  (code -> libellé), enrichies du nom de table
--     C'est LE fichier pour construire les tables de correspondance.
-- ---------------------------------------------------------------------
PROMPT === 2. Valeurs des nomenclatures (RHFNOM + libellé RHTNOM) ===
SPOOL &OUT\nomen_02_valeurs.csv
SELECT f.cdos,
       f.ctab,
       n.libe AS nom_nomenclature,
       f.cacc AS code,
       f.nume AS ordre,
       f.vall AS libelle,
       f.valm AS montant,
       f.valt AS taux
FROM &SCHEMA.rhfnom f
LEFT JOIN &SCHEMA.rhtnom n
  ON n.cdos = f.cdos AND n.ctab = f.ctab
ORDER BY f.cdos, f.ctab, f.nume, f.cacc;
SPOOL OFF

-- ---------------------------------------------------------------------
--  3) STRUCTURE DES LIGNES DE NOMENCLATURE (RHLNOM) — utile si multi-colonnes
-- ---------------------------------------------------------------------
PROMPT === 3. Structure des nomenclatures (RHLNOM) ===
SPOOL &OUT\nomen_03_structure.csv
SELECT cdos, ctab, ctyp, nume, libe, obligatoire
FROM &SCHEMA.rhlnom
ORDER BY cdos, ctab, nume;
SPOOL OFF

-- ---------------------------------------------------------------------
--  4) PROFILAGE DES CODES RÉELLEMENT UTILISÉS SUR RHPAGENT (salariés)
--     Chaque bloc liste les valeurs distinctes + leur fréquence : c'est ce
--     qui doit être mappé vers les enums fermés de Fluxoon.
--     (On ignore les valeurs NULL pour la lisibilité.)
-- ---------------------------------------------------------------------
PROMPT === 4. Profilage des codes de RHPAGENT ===
SPOOL &OUT\nomen_04_profil_rhpagent.csv

PROMPT --- SEXE (-> Fluxoon gender: MALE/FEMALE) ---
SELECT 'SEXE' AS colonne, sexe AS code, COUNT(*) AS nb
FROM &SCHEMA.rhpagent WHERE sexe IS NOT NULL GROUP BY sexe ORDER BY nb DESC;

PROMPT --- SITF : situation familiale (-> marital_status) ---
SELECT 'SITF' AS colonne, sitf AS code, COUNT(*) AS nb
FROM &SCHEMA.rhpagent WHERE sitf IS NOT NULL GROUP BY sitf ORDER BY nb DESC;

PROMPT --- TYPC : type de contrat (-> contract_type: CDI/CDD/...) ---
SELECT 'TYPC' AS colonne, typc AS code, COUNT(*) AS nb
FROM &SCHEMA.rhpagent WHERE typc IS NOT NULL GROUP BY typc ORDER BY nb DESC;

PROMPT --- REGI : statut / régime ---
SELECT 'REGI' AS colonne, regi AS code, COUNT(*) AS nb
FROM &SCHEMA.rhpagent WHERE regi IS NOT NULL GROUP BY regi ORDER BY nb DESC;

PROMPT --- CAT : categorie (les fameuses categories 1..12) ---
SELECT 'CAT' AS colonne, cat AS code, COUNT(*) AS nb
FROM &SCHEMA.rhpagent WHERE cat IS NOT NULL GROUP BY cat ORDER BY nb DESC;

PROMPT --- ECH : echelon ---
SELECT 'ECH' AS colonne, ech AS code, COUNT(*) AS nb
FROM &SCHEMA.rhpagent WHERE ech IS NOT NULL GROUP BY ech ORDER BY nb DESC;

PROMPT --- GRAD : grade ---
SELECT 'GRAD' AS colonne, grad AS code, COUNT(*) AS nb
FROM &SCHEMA.rhpagent WHERE grad IS NOT NULL GROUP BY grad ORDER BY nb DESC;

PROMPT --- FONC : fonction ---
SELECT 'FONC' AS colonne, fonc AS code, COUNT(*) AS nb
FROM &SCHEMA.rhpagent WHERE fonc IS NOT NULL GROUP BY fonc ORDER BY nb DESC;

PROMPT --- NATO : nationalite ---
SELECT 'NATO' AS colonne, nato AS code, COUNT(*) AS nb
FROM &SCHEMA.rhpagent WHERE nato IS NOT NULL GROUP BY nato ORDER BY nb DESC;

PROMPT --- CODS : code salaire (horaire/mensuel/...) ---
SELECT 'CODS' AS colonne, cods AS code, COUNT(*) AS nb
FROM &SCHEMA.rhpagent WHERE cods IS NOT NULL GROUP BY cods ORDER BY nb DESC;

PROMPT --- MODP : mode de paiement ---
SELECT 'MODP' AS colonne, modp AS code, COUNT(*) AS nb
FROM &SCHEMA.rhpagent WHERE modp IS NOT NULL GROUP BY modp ORDER BY nb DESC;

PROMPT --- MRRX : radie/mute/repris ---
SELECT 'MRRX' AS colonne, mrrx AS code, COUNT(*) AS nb
FROM &SCHEMA.rhpagent WHERE mrrx IS NOT NULL GROUP BY mrrx ORDER BY nb DESC;

PROMPT --- NIV1 / NIV2 / NIV3 : niveaux organisationnels ---
SELECT 'NIV1' AS colonne, niv1 AS code, COUNT(*) AS nb
FROM &SCHEMA.rhpagent WHERE niv1 IS NOT NULL GROUP BY niv1 ORDER BY nb DESC;
SELECT 'NIV2' AS colonne, niv2 AS code, COUNT(*) AS nb
FROM &SCHEMA.rhpagent WHERE niv2 IS NOT NULL GROUP BY niv2 ORDER BY nb DESC;

SPOOL OFF

-- ---------------------------------------------------------------------
--  5) (Optionnel) Les 2 dossiers et leurs libellés de niveaux (RHPDOS)
--     Donne le sens des NIV1..NIV4 par dossier (organisation).
-- ---------------------------------------------------------------------
PROMPT === 5. Dossiers et libelles de niveaux (RHPDOS) ===
SPOOL &OUT\nomen_05_dossiers.csv
SELECT cdos, dniv1, dniv2, dniv3, dniv4
FROM &SCHEMA.rhpdos
ORDER BY cdos;
SPOOL OFF

PROMPT ================================================================
PROMPT  Termine. Fichiers generes dans &OUT :
PROMPT   nomen_01_registre.csv       (a quoi sert chaque CTAB)
PROMPT   nomen_02_valeurs.csv        (code -> libelle : LE fichier de mapping)
PROMPT   nomen_03_structure.csv
PROMPT   nomen_04_profil_rhpagent.csv (codes reellement utilises)
PROMPT   nomen_05_dossiers.csv
PROMPT  A renvoyer pour construire les tables de correspondance vers Fluxoon.
PROMPT ================================================================
