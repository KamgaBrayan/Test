-- L'ajustement d'un salarie se fait dans la preparation, a cote des valeurs collectees : une
-- remuneration saisie s'ajoute aux droits de Compensation, ou remplace ceux du meme code, et la
-- revision preparee la fige avec l'origine MANUAL. L'ajustement de participant de campagne disparait.
--
-- Comme une valeur collectee, une saisie est versionnee : une correction cree une version et
-- supersede la precedente.

CREATE TABLE IF NOT EXISTS manual_remunerations (
    version integer NOT NULL,
    captured_at timestamp(6) with time zone NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    lock_version bigint,
    updated_at timestamp(6) with time zone NOT NULL,
    captured_by character varying(255) NOT NULL,
    category character varying(255) NOT NULL,
    code character varying(255) NOT NULL,
    country_code character varying(255) NOT NULL,
    display_name character varying(255) NOT NULL,
    employee_id character varying(255) NOT NULL,
    id character varying(255) NOT NULL,
    legal_entity_id character varying(255) NOT NULL,
    nature character varying(255) NOT NULL,
    occurrence character varying(255) NOT NULL,
    org_id character varying(255) NOT NULL,
    override_strategy character varying(255) NOT NULL,
    period_id character varying(255) NOT NULL,
    previous_version_id character varying(255),
    status character varying(255) NOT NULL,
    calculation text NOT NULL,
    source_label text,
    CONSTRAINT manual_remunerations_pkey PRIMARY KEY (id),
    CONSTRAINT manual_remunerations_status_check CHECK (status IN ('DRAFT', 'VALIDATED', 'SUPERSEDED', 'CANCELLED')),
    CONSTRAINT manual_remunerations_override_check CHECK (override_strategy IN ('KEEP', 'OVERRIDE'))
);

CREATE INDEX IF NOT EXISTS idx_manual_remuneration_lookup
    ON manual_remunerations USING btree (org_id, period_id, employee_id, code, occurrence);

-- Une seule version courante par remuneration logique.
CREATE UNIQUE INDEX IF NOT EXISTS uq_manual_remuneration_current
    ON manual_remunerations (org_id, period_id, employee_id, code, occurrence)
    WHERE status IN ('DRAFT', 'VALIDATED');

-- Les ajustements de participant ne sont plus lus : la remuneration saisie les remplace.
DROP TABLE IF EXISTS payroll_campaign_adjustments;

ALTER TABLE payroll_campaign_participants DROP COLUMN IF EXISTS adjustments;
ALTER TABLE payroll_campaign_participants DROP COLUMN IF EXISTS adjusted;
