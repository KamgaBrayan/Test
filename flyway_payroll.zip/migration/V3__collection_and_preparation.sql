-- Collecte et preparation.
--
-- Ce que la paie a lu avant de calculer.
--
-- Une valeur collectee est versionnee et ne s'ecrase pas : une correction cree une version et
-- supersede la precedente, de sorte qu'un bulletin deja emis continue de s'expliquer avec la valeur
-- qu'il a lue. La revision preparee fige l'ensemble -- faits du salarie, remunerations, valeurs,
-- avantages, presence -- et c'est elle que l'enrolement recopie.
--
-- Le gel de configuration porte l'empreinte de ce qui a determine qui est paye et avec quelles regles :
-- si elle change, l'approbation ne vaut plus.
--
-- Cette migration fait partie de l'aplatissement du schema. Les anciennes V2..V16 patchaient
-- un schema que seul `ddl-auto` savait creer : sur une base neuve, elles echouaient. Le schema
-- est desormais pilote par ces cinq migrations, et `ddl-auto: validate` echoue au demarrage si
-- le modele d'entites et elles divergent -- un ecart se voit au boot plutot qu'a la premiere
-- requete qui touche la colonne manquante.

-- ------------------------------------------------------------------------
-- employee_engine_inputs
-- ------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS employee_engine_inputs (
    version integer NOT NULL,
    captured_at timestamp(6) with time zone NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    lock_version bigint,
    updated_at timestamp(6) with time zone NOT NULL,
    captured_by character varying(255),
    code character varying(255) NOT NULL,
    display_name character varying(255),
    employee_id character varying(255) NOT NULL,
    id character varying(255) NOT NULL,
    legal_entity_id character varying(255) NOT NULL,
    occurrence character varying(255) NOT NULL,
    org_id character varying(255) NOT NULL,
    period_id character varying(255) NOT NULL,
    previous_version_id character varying(255),
    source character varying(255) NOT NULL,
    source_aggregate_id character varying(255),
    source_domain character varying(255),
    source_event_id character varying(255),
    source_label character varying(255),
    status character varying(255) NOT NULL,
    value text NOT NULL,
    value_type character varying(255) NOT NULL,
    CONSTRAINT employee_engine_inputs_source_check CHECK (((source)::text = ANY ((ARRAY['MANUAL'::character varying, 'IMPORT'::character varying, 'SYSTEM'::character varying, 'INTEGRATION'::character varying])::text[]))),
    CONSTRAINT employee_engine_inputs_status_check CHECK (((status)::text = ANY ((ARRAY['DRAFT'::character varying, 'VALIDATED'::character varying, 'SUPERSEDED'::character varying, 'CANCELLED'::character varying])::text[]))),
    CONSTRAINT employee_engine_inputs_value_type_check CHECK (((value_type)::text = ANY ((ARRAY['MONEY'::character varying, 'DECIMAL'::character varying, 'RATE'::character varying, 'QUANTITY'::character varying, 'BOOLEAN'::character varying, 'DATE'::character varying, 'TEXT'::character varying])::text[])))
);

ALTER TABLE employee_engine_inputs
    ADD CONSTRAINT employee_engine_inputs_pkey PRIMARY KEY (id);

CREATE INDEX IF NOT EXISTS idx_employee_payroll_input_lookup ON employee_engine_inputs USING btree (org_id, period_id, employee_id, code, occurrence);

CREATE INDEX IF NOT EXISTS idx_employee_payroll_input_previous ON employee_engine_inputs USING btree (previous_version_id);

-- ------------------------------------------------------------------------
-- prepared_employee_payroll
-- ------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS prepared_employee_payroll (
    prepared_at timestamp(6) with time zone NOT NULL,
    revision bigint NOT NULL,
    company_id character varying(255) NOT NULL,
    content text NOT NULL,
    content_hash character varying(255) NOT NULL,
    employee_id character varying(255) NOT NULL,
    id character varying(255) NOT NULL,
    period_id character varying(255) NOT NULL
);

ALTER TABLE prepared_employee_payroll
    ADD CONSTRAINT prepared_employee_payroll_company_id_period_id_employee_id__key UNIQUE (company_id, period_id, employee_id, revision);

ALTER TABLE prepared_employee_payroll
    ADD CONSTRAINT prepared_employee_payroll_pkey PRIMARY KEY (id);

-- ------------------------------------------------------------------------
-- payroll_run_configurations
-- ------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS payroll_run_configurations (
    version integer NOT NULL,
    frozen_at timestamp(6) with time zone NOT NULL,
    hash character varying(64) NOT NULL,
    company_id character varying(255) NOT NULL,
    engine_id character varying(255) NOT NULL,
    engine_version character varying(255) NOT NULL,
    id character varying(255) NOT NULL,
    period_id character varying(255) NOT NULL,
    run_id character varying(255) NOT NULL,
    content jsonb NOT NULL
);

ALTER TABLE payroll_run_configurations
    ADD CONSTRAINT payroll_run_configurations_pkey PRIMARY KEY (id);

ALTER TABLE payroll_run_configurations
    ADD CONSTRAINT uc_run_configuration_version UNIQUE (company_id, run_id, version);

CREATE INDEX IF NOT EXISTS idx_run_configuration_run ON payroll_run_configurations USING btree (company_id, run_id, version);
