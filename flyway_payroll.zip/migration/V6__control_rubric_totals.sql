-- ------------------------------------------------------------------------
-- Contrôle du run, rubrique par rubrique (docs/04 §F)
-- ------------------------------------------------------------------------
--
-- Les totaux d'un run disent que la masse a bougé ; ils ne disent pas pourquoi. La raison est
-- presque toujours dans une rubrique — une prime exceptionnelle, un rappel, une indemnité qui a
-- cessé — et le rapport de contrôle la porte désormais.
--
-- Les deux colonnes sont nullables : les rapports produits avant ce contrôle n'en ont pas, et ils
-- doivent rester lisibles. Un rapport sans run de référence n'a pas de rubriques de référence.

ALTER TABLE payroll_run_control_reports
    ADD COLUMN IF NOT EXISTS rubric_totals jsonb;

ALTER TABLE payroll_run_control_reports
    ADD COLUMN IF NOT EXISTS reference_rubric_totals jsonb;
