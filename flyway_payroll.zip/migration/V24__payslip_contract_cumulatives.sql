-- Un bulletin affiche des cumuls — le brut imposable de l'année, les cotisations depuis janvier — et
-- c'est le contrat de bulletin de la release qui dit lesquels, sous quel libellé, comme il le fait
-- déjà des lignes et des totaux. Le pays définit l'accumulateur, la release le branche, le contrat
-- l'affiche.
-- Aucune reprise : les contrats déjà écrits n'en affichent aucun.

ALTER TABLE engine_payslip_contracts
    ADD COLUMN cumulatives JSONB NOT NULL DEFAULT '[]'
        CHECK (jsonb_typeof(cumulatives) = 'array');
