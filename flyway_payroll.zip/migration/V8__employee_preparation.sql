-- Dossier de préparation d'un salarié pour une période : état, attentes et dernière révision préparée.
CREATE TABLE employee_payroll_preparation (
    id                          varchar(255) PRIMARY KEY,
    company_id                  varchar(255) NOT NULL,
    legal_entity_id             varchar(255) NOT NULL,
    period_id                   varchar(255) NOT NULL,
    employee_id                 varchar(255) NOT NULL,
    status                      varchar(32)  NOT NULL,
    generation                  bigint       NOT NULL DEFAULT 0,
    lock_version                bigint       NOT NULL DEFAULT 0,
    last_attempt_at             timestamptz,
    last_successful_refresh_at  timestamptz,
    compensation_snapshot_id    varchar(255),
    prepared_revision_id        varchar(255),
    issues                      jsonb        NOT NULL DEFAULT '[]'::jsonb,
    requirements                jsonb        NOT NULL DEFAULT '[]'::jsonb,
    invalidated_at              timestamptz,
    invalidation_reasons        jsonb,
    excluded_by                 varchar(255),
    excluded_at                 timestamptz,
    exclusion_reason            text,
    CONSTRAINT employee_preparation_key UNIQUE (company_id, legal_entity_id, period_id, employee_id),
    CONSTRAINT employee_preparation_exclusion CHECK (
        (excluded_at IS NULL AND excluded_by IS NULL AND exclusion_reason IS NULL)
        OR (excluded_at IS NOT NULL AND excluded_by IS NOT NULL AND exclusion_reason IS NOT NULL))
);

CREATE INDEX employee_preparation_dashboard ON employee_payroll_preparation (company_id, period_id, status);

-- Réponses Compensation observées ; immuables, un contenu différent fait un nouveau snapshot.
CREATE TABLE payroll_compensation_snapshot (
    id           varchar(255) PRIMARY KEY,
    dossier_id   varchar(255) NOT NULL REFERENCES employee_payroll_preparation (id),
    fingerprint  varchar(64)  NOT NULL,
    content      jsonb        NOT NULL,
    received_at  timestamptz  NOT NULL
);

CREATE INDEX compensation_snapshot_dossier ON payroll_compensation_snapshot (dossier_id, received_at);
