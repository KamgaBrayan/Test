-- La paie ne garde plus la reponse brute de Compensation : les droits dus sont enregistres comme
-- valeurs collectees (remuneration_inputs, source INTEGRATION) et la revision preparee fige le reste.
-- Les snapshots observes et leur reference sur le dossier disparaissent.

ALTER TABLE employee_payroll_preparation DROP COLUMN IF EXISTS compensation_snapshot_id;

DROP INDEX IF EXISTS compensation_snapshot_dossier;
DROP TABLE IF EXISTS payroll_compensation_snapshot;
