-- Un accumulateur ne dépend pas d'une release : le brut imposable annuel existe parce que le pays
-- l'impose. Il devient donc une entité du pays, avec son identité, son statut et ses dates, et chaque
-- moteur déclare par un branchement lequel de ses résultats l'alimente. Deux releases d'un même pays
-- alimentent ainsi le même accumulateur, et le registre reste lisible d'une release à l'autre.
--
-- Deux champs disparaissent au passage :
--   * `enabled`, que le statut dit mieux (DRAFT, ACTIVE, ARCHIVED) ;
--   * `contribution_source` (BASE, CAPPED_BASE, RATE, AMOUNT), que rien ne lisait — ce qui décide de
--     la valeur est le résultat branché, et lui seul.

CREATE TABLE IF NOT EXISTS cumulative_rules
(
    id                         VARCHAR(255) NOT NULL,
    country_code               VARCHAR(255) NOT NULL,
    accumulator_code           VARCHAR(255) NOT NULL,
    label                      VARCHAR(255) NOT NULL,
    status                     VARCHAR(32)  NOT NULL,
    scope                      VARCHAR(255) NOT NULL,
    start_month                INTEGER,
    end_month                  INTEGER,
    rolling_months_window      INTEGER,
    include_current_pay_period BOOLEAN      NOT NULL,
    aggregation                VARCHAR(255) NOT NULL,
    created_at                 TIMESTAMPTZ  NOT NULL,
    updated_at                 TIMESTAMPTZ  NOT NULL,
    activated_at               TIMESTAMPTZ,
    archived_at                TIMESTAMPTZ,
    CONSTRAINT cumulative_rules_pkey PRIMARY KEY (id),
    CONSTRAINT uc_cumulative_rule_country_code UNIQUE (country_code, accumulator_code),
    CONSTRAINT cumulative_rules_status_check
        CHECK (status IN ('DRAFT', 'ACTIVE', 'ARCHIVED')),
    CONSTRAINT cumulative_rules_scope_check
        CHECK (scope IN ('CALENDAR_YEAR', 'FISCAL_YEAR', 'ROLLING_WINDOW')),
    CONSTRAINT cumulative_rules_aggregation_check
        CHECK (aggregation IN ('SUM', 'AVERAGE', 'LAST_VALUE')),
    -- Un statut porte sa date : en vigueur sans mise en vigueur, ou archivé sans retrait, ne veut
    -- rien dire.
    CONSTRAINT cumulative_rules_status_dates_check
        CHECK ((status <> 'ACTIVE' OR activated_at IS NOT NULL)
            AND (status <> 'ARCHIVED' OR archived_at IS NOT NULL))
);

CREATE TABLE IF NOT EXISTS engine_cumulative_bindings
(
    engine_id        VARCHAR(255) NOT NULL REFERENCES engines (id),
    accumulator_code VARCHAR(255) NOT NULL,
    source_code      VARCHAR(255) NOT NULL,
    created_at       TIMESTAMPTZ  NOT NULL,
    updated_at       TIMESTAMPTZ  NOT NULL,
    CONSTRAINT engine_cumulative_bindings_pkey PRIMARY KEY (engine_id, accumulator_code)
);

CREATE INDEX IF NOT EXISTS idx_engine_cumulative_binding_accumulator
    ON engine_cumulative_bindings (accumulator_code);

-- La règle part du pays du moteur qui la portait. Quand plusieurs releases d'un pays définissaient le
-- même accumulateur avec des fenêtres différentes, on garde celle de la release la plus récente :
-- c'est la dernière qui a été tenue pour juste. Un accumulateur actif reprend en vigueur, les autres
-- en préparation.
INSERT INTO cumulative_rules (id, country_code, accumulator_code, label, status, scope, start_month, end_month,
                              rolling_months_window, include_current_pay_period, aggregation,
                              created_at, updated_at, activated_at)
SELECT DISTINCT ON (e.country_code, r.accumulator_code) gen_random_uuid()::text,
                                                        e.country_code,
                                                        r.accumulator_code,
                                                        r.accumulator_code,
                                                        CASE WHEN r.enabled THEN 'ACTIVE' ELSE 'DRAFT' END,
                                                        COALESCE(r.scope, 'CALENDAR_YEAR'),
                                                        r.start_month,
                                                        r.end_month,
                                                        r.rolling_months_window,
                                                        r.include_current_pay_period,
                                                        COALESCE(r.aggregation, 'SUM'),
                                                        now(),
                                                        now(),
                                                        CASE WHEN r.enabled THEN now() END
FROM engine_cumulative_rules r
         JOIN engines e ON e.id = r.engine_id
ORDER BY e.country_code, r.accumulator_code, e.published_at DESC NULLS LAST, e.version DESC
ON CONFLICT DO NOTHING;

-- Chaque release garde son branchement : sans lui elle ne lirait plus le registre et n'y porterait
-- rien.
INSERT INTO engine_cumulative_bindings (engine_id, accumulator_code, source_code, created_at, updated_at)
SELECT r.engine_id, r.accumulator_code, r.source_code, now(), now()
FROM engine_cumulative_rules r
         JOIN engines e ON e.id = r.engine_id
ON CONFLICT DO NOTHING;

DROP TABLE engine_cumulative_rules;
