-- Le modèle de bulletin se fige au lancement de la génération des bulletins, et non plus au démarrage du run : un
-- gel par lancement, le plus récent fait foi. Les runs démarrés avant gardent le modèle de leur gel de configuration.
CREATE TABLE IF NOT EXISTS payroll_payslip_template_freezes (
    id character varying(255) NOT NULL,
    company_id character varying(255) NOT NULL,
    run_id character varying(255) NOT NULL,
    sequence integer NOT NULL,
    template_version_id character varying(255),
    frozen_at timestamp(6) with time zone NOT NULL,
    frozen_by character varying(255) NOT NULL,
    reason character varying(255),
    CONSTRAINT payroll_payslip_template_freezes_pkey PRIMARY KEY (id),
    CONSTRAINT uc_payslip_template_freeze_sequence UNIQUE (company_id, run_id, sequence)
);

CREATE INDEX IF NOT EXISTS idx_payslip_template_freeze_run ON payroll_payslip_template_freezes USING btree (company_id, run_id, sequence);
