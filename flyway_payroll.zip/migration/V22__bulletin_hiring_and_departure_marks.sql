-- Un bulletin porte désormais ce qu'il dit du contrat : le premier bulletin d'un salarié et le
-- dernier. Les marques se lisent des bornes du contrat sur la période payée, elles ne se déduisent
-- pas d'une ligne de calcul. Une colonne par marque, pour que « les départs du mois » soit une
-- requête et pas un parcours du JSON du bulletin.
-- Aucune reprise : les bulletins déjà écrits n'en portent aucune.

ALTER TABLE payroll_campaign_participant_bulletins
    ADD COLUMN hiring    BOOLEAN NOT NULL DEFAULT FALSE,
    ADD COLUMN departure BOOLEAN NOT NULL DEFAULT FALSE;
