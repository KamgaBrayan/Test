-- Une simulation peut n'appartenir à aucune société : l'admin éprouve un moteur sur des salariés
-- fictifs. Son identifiant suffit à la retrouver ; la société devient facultative.

ALTER TABLE payroll_simulations
    DROP CONSTRAINT IF EXISTS payroll_simulations_pkey;

ALTER TABLE payroll_simulations
    ALTER COLUMN company_id DROP NOT NULL;

ALTER TABLE payroll_simulations
    ADD CONSTRAINT payroll_simulations_pkey PRIMARY KEY (simulation_id);

-- La grille de rémunération de la simulation (cases catégorie × échelon), lue par gridAmount, gridMin, gridMax.
ALTER TABLE payroll_simulations
    ADD COLUMN IF NOT EXISTS grid jsonb;

-- L'entité de la société qui porte la simulation : le front n'affiche que celles de l'entité choisie.
ALTER TABLE payroll_simulations
    ADD COLUMN IF NOT EXISTS legal_entity_id varchar(255);

CREATE INDEX IF NOT EXISTS idx_payroll_simulation_legal_entity
    ON payroll_simulations (company_id, legal_entity_id);
