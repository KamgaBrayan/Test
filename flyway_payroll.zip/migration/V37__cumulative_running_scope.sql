-- Un accumulateur peut tenir un solde courant (RUNNING) : jamais remis à zéro, il se reporte d'un exercice à
-- l'autre (droits à congé acquis et consommés). Chaque accumulateur lit désormais sa propre fenêtre.

ALTER TABLE cumulative_rules DROP CONSTRAINT cumulative_rules_scope_check;
ALTER TABLE cumulative_rules ADD CONSTRAINT cumulative_rules_scope_check
    CHECK (scope IN ('CALENDAR_YEAR', 'FISCAL_YEAR', 'ROLLING_WINDOW', 'RUNNING'));
