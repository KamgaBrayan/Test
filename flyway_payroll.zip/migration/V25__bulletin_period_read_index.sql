-- La consolidation d'une période se lit sur les bulletins, toutes campagnes confondues : la paie
-- principale remplacée par sa régularisation, plus les paiements additifs. La lecture se fait par
-- société et période ; l'index la porte.

CREATE INDEX IF NOT EXISTS idx_payrollbulletin_company_period
    ON payroll_campaign_participant_bulletins (company_id, period);
