-- Condition de versement d'une rubrique du moteur : une expression qui dit, chaque mois, si la rubrique est due
-- (l'indemnité de logement CCA n'est pas versée quand la maternité couvre le mois). Absente, la rubrique l'est toujours.
ALTER TABLE engine_remuneration_rules ADD COLUMN payment_condition TEXT;
