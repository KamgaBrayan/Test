-- Une rémunération saisie à la main peut être négative (reprise, régularisation à la baisse) : le contrôle du
-- run la bloque jusqu'à ce qu'un gestionnaire l'accepte avec un message. L'acceptation est portée par la saisie.

ALTER TABLE remuneration_inputs ADD COLUMN negative_accepted_message text;
ALTER TABLE remuneration_inputs ADD COLUMN negative_accepted_by varchar(255);
ALTER TABLE remuneration_inputs ADD COLUMN negative_accepted_at timestamp(6) with time zone;
