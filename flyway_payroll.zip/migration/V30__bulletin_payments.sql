-- Le net restant à payer d'un bulletin émis, tenu sur les événements de payment-service (docs/17 §3).
-- Un suivi par bulletin, retrouvé par la référence du bulletin que payment-service cite comme document
-- source ; le rang du dernier événement lu rend la livraison « au moins une fois » sans effet en double.

CREATE TABLE IF NOT EXISTS payroll_bulletin_payments (
    company_id               character varying(255) NOT NULL,
    legal_entity_id          character varying(255),
    campaign_id              character varying(255) NOT NULL,
    participant_id           character varying(255) NOT NULL,
    employee_id              character varying(255) NOT NULL,
    reference                character varying(255) NOT NULL,
    obligation_id            character varying(255) NOT NULL,
    currency                 character varying(3)   NOT NULL,
    amount_due               numeric(19, 4)         NOT NULL,
    total_paid               numeric(19, 4)         NOT NULL,
    remaining                numeric(19, 4)         NOT NULL,
    status                   character varying(32)  NOT NULL,
    last_sequence            bigint                 NOT NULL,
    last_event_id            character varying(255),
    last_event_at            timestamp(6) with time zone,
    last_execution_reference character varying(255),
    failure_reason           text,
    updated_at               timestamp(6) with time zone NOT NULL,
    CONSTRAINT payroll_bulletin_payments_pkey PRIMARY KEY (company_id, reference),
    CONSTRAINT payroll_bulletin_payments_status_check CHECK (((status)::text = ANY ((ARRAY[
        'AWAITING'::character varying, 'PARTIALLY_PAID'::character varying, 'PAID'::character varying,
        'FAILED'::character varying, 'CANCELLED'::character varying])::text[])))
);

CREATE INDEX IF NOT EXISTS idx_bulletin_payments_campaign ON payroll_bulletin_payments USING btree (company_id, campaign_id);
