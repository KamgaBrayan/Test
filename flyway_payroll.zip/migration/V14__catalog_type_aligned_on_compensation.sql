-- Compensation a retiré PREMIUM et COMMISSION de ses types d'élément : ce sont des BONUS (compensation V9).
-- catalog_type garde la trace du type de l'élément catalogue dont la rubrique est issue : il suit.

UPDATE engine_remuneration_rules
SET catalog_type = 'BONUS'
WHERE catalog_type IN ('PREMIUM', 'COMMISSION');
