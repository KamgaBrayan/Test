-- Lecture des cumuls par salarie.
--
-- Le registre et sa projection n'etaient lus que par cle complete, au calcul et a l'emission. Leur
-- consultation (soldes d'un salarie, ecritures d'un accumulateur, soldes d'une periode) filtre par
-- societe et par salarie : sans index, chaque lecture parcourt la table entiere.

CREATE INDEX IF NOT EXISTS idx_cumulative_balance_employee
    ON cumulative_balances USING btree (company_id, employee_id);

CREATE INDEX IF NOT EXISTS idx_cumulative_entry_employee
    ON cumulative_entries USING btree (company_id, employee_id, accumulator_code);
