-- Compensation publie l'input standard BUSINESS_DISTANCE_KM en KILOMETER. Sans cette unité,
-- l'import du catalogue echouait et aucun moteur ne pouvait etre cree pour le pays.
ALTER TABLE engine_inputs DROP CONSTRAINT engine_inputs_unit_check;
ALTER TABLE engine_inputs ADD CONSTRAINT engine_inputs_unit_check
    CHECK (unit IN ('HOURS', 'DAYS', 'MONTHS', 'YEARS', 'UNITS', 'KILOMETERS'));
