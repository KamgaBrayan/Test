-- Le type de run n'est pas une option : une campagne est une paie principale, un paiement hors
-- cycle, un solde de tout compte ou une régularisation. La colonne était nullable et le domaine
-- lisait l'absence comme MAIN ; une lecture filtrée en base écartait alors ces campagnes.
-- On écrit la valeur que le domaine leur donnait déjà, puis on exige la colonne.

UPDATE payroll_campaigns
SET run_type = 'MAIN'
WHERE run_type IS NULL;

ALTER TABLE payroll_campaigns
    ALTER COLUMN run_type SET NOT NULL;
