-- Les remunerations dues par Compensation s'enregistrent comme les saisies, et comme les valeurs
-- collectees : une version par revision Compensation, la precedente remplacee. La revision preparee
-- les fige ; la reponse brute de Compensation n'a plus a etre conservee a part.

ALTER TABLE manual_remunerations RENAME TO remuneration_inputs;
ALTER TABLE remuneration_inputs RENAME CONSTRAINT manual_remunerations_pkey TO remuneration_inputs_pkey;
ALTER TABLE remuneration_inputs RENAME CONSTRAINT manual_remunerations_status_check TO remuneration_inputs_status_check;
ALTER TABLE remuneration_inputs RENAME CONSTRAINT manual_remunerations_override_check TO remuneration_inputs_override_check;
ALTER INDEX idx_manual_remuneration_lookup RENAME TO idx_remuneration_input_lookup;
ALTER INDEX uq_manual_remuneration_current RENAME TO uq_remuneration_input_current;

-- Les lignes existantes sont toutes des saisies.
ALTER TABLE remuneration_inputs ADD COLUMN source character varying(255) NOT NULL DEFAULT 'MANUAL';
ALTER TABLE remuneration_inputs ALTER COLUMN source DROP DEFAULT;
ALTER TABLE remuneration_inputs ADD CONSTRAINT remuneration_inputs_source_check CHECK (source IN ('MANUAL', 'INTEGRATION'));

ALTER TABLE remuneration_inputs ADD COLUMN contractual boolean NOT NULL DEFAULT false;

-- D'ou vient un droit de Compensation : objet source et revision.
ALTER TABLE remuneration_inputs ADD COLUMN source_domain character varying(255);
ALTER TABLE remuneration_inputs ADD COLUMN source_aggregate_id character varying(255);
ALTER TABLE remuneration_inputs ADD COLUMN source_event_id character varying(255);

-- Les jours de la periode ou le droit est du ; absents, il court sur toute la periode.
ALTER TABLE remuneration_inputs ADD COLUMN earned_from date;
ALTER TABLE remuneration_inputs ADD COLUMN earned_to date;

-- Le versement ponctuel chez Compensation, paye une seule fois.
ALTER TABLE remuneration_inputs ADD COLUMN one_time_payment_reference character varying(255);
