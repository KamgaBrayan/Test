-- Une simulation garde le calcul de chacun de ses salariés (totaux et lignes du moteur), pas
-- seulement les totaux de l'ensemble : c'est ce qu'on lit pour chiffrer une embauche.

ALTER TABLE payroll_simulations
    ADD COLUMN IF NOT EXISTS results jsonb NOT NULL DEFAULT '[]'::jsonb;
