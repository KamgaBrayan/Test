-- Les avantages d'une release : un type du catalogue de Compensation, avec le contrat importé (modalités
-- de fourniture, caractéristiques) et la manière dont la release le valorise (portée, agrégats préparés,
-- formules). Même identité que les entrées et les rubriques : (code, engine_id), de sorte qu'une montée
-- de version emporte ses propres avantages. Aucune reprise : un moteur existant n'en porte pas tant qu'il
-- n'est pas resynchronisé avec le catalogue.

CREATE TABLE engine_benefits
(
    code                 VARCHAR(255) NOT NULL,
    engine_id            VARCHAR(255) NOT NULL REFERENCES engines (id),
    country_code         VARCHAR(255) NOT NULL,
    catalog_number       VARCHAR(255) NOT NULL,
    catalog_version      BIGINT       NOT NULL CHECK (catalog_version > 0),
    catalog_valid_from   DATE,
    catalog_valid_to     DATE,
    display_name         VARCHAR(255) NOT NULL,
    legal_ref            VARCHAR(255),
    allowed_supply_modes VARCHAR(255) NOT NULL,
    characteristics      JSONB        NOT NULL DEFAULT '[]' CHECK (jsonb_typeof(characteristics) = 'array'),
    status               VARCHAR(20)  NOT NULL CHECK (status IN ('TO_CONFIGURE', 'VALUED', 'NOT_VALUED')),
    justification        TEXT,
    valuation_scope      VARCHAR(20) CHECK (valuation_scope IN ('GROUPED', 'INDIVIDUAL')),
    aggregates           JSONB        NOT NULL DEFAULT '[]' CHECK (jsonb_typeof(aggregates) = 'array'),
    in_kind_formula      TEXT,
    cash_formula         TEXT,
    rounding_rule        VARCHAR(20)  NOT NULL
        CHECK (rounding_rule IN ('NONE', 'UP', 'DOWN', 'HALF_UP', 'HALF_DOWN')),
    created_at           TIMESTAMPTZ  NOT NULL,
    updated_at           TIMESTAMPTZ  NOT NULL,
    PRIMARY KEY (code, engine_id)
);

-- Une attribution résolue désigne son type par son numéro de catalogue.
CREATE UNIQUE INDEX engine_benefit_catalog_number ON engine_benefits (engine_id, catalog_number);
CREATE INDEX idx_engine_benefit_engine ON engine_benefits (engine_id);
