-- Les sorties nommées d'une rubrique (output_bindings) et le drapeau contractuel des rémunérations
-- collectées (contractual) ne sont plus lus ni écrits : une rubrique publie d'office ses parts sous son
-- code préfixé (TAXABLE_<CODE>…), et l'origine de la rémunération dit déjà si elle vient du contrat.
--
-- Les colonnes restent le temps de la validation, pour qu'une version antérieure puisse encore tourner
-- sur la même base ; elles reçoivent seulement une valeur par défaut, puisque le code ne les renseigne
-- plus. Leur suppression viendra dans une migration suivante.

ALTER TABLE engine_remuneration_rules ALTER COLUMN output_bindings SET DEFAULT '[]'::jsonb;
ALTER TABLE remuneration_inputs ALTER COLUMN contractual SET DEFAULT false;
