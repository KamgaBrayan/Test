-- Alertes de préparation : un problème qui attend une action, par dossier, code et objet concerné.
CREATE TABLE preparation_alert (
    id                varchar(255) PRIMARY KEY,
    company_id        varchar(255) NOT NULL,
    legal_entity_id   varchar(255) NOT NULL,
    period_id         varchar(255) NOT NULL,
    employee_id       varchar(255) NOT NULL,
    dossier_id        varchar(255) NOT NULL REFERENCES employee_payroll_preparation (id),
    code              varchar(64)  NOT NULL,
    reference         varchar(512) NOT NULL,
    severity          varchar(16)  NOT NULL,
    message           text,
    opened_at         timestamptz  NOT NULL,
    last_seen_at      timestamptz  NOT NULL,
    last_reminded_at  timestamptz,
    reminder_count    integer      NOT NULL DEFAULT 0,
    resolved_at       timestamptz,
    lock_version      bigint       NOT NULL DEFAULT 0,
    CONSTRAINT preparation_alert_severity CHECK (severity IN ('WAITING', 'BLOCKING'))
);

-- Au plus une alerte ouverte par problème ; un problème qui revient après résolution en ouvre une autre.
CREATE UNIQUE INDEX preparation_alert_open_key ON preparation_alert (dossier_id, code, reference)
    WHERE resolved_at IS NULL;

CREATE INDEX preparation_alert_period ON preparation_alert (company_id, period_id, resolved_at);
