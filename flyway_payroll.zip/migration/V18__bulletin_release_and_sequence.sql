-- Un bulletin garde ce avec quoi il se relit : la release qui l'a calculé et son pays, son rang
-- d'émission dans le run, sa nature, son mois de rattachement, et qui l'a calculé quand. Le modèle du
-- domaine les exigeait déjà ; la table ne les portait pas, si bien qu'aucun bulletin ne pouvait être
-- ni écrit ni relu. Aucune reprise : la table est vide.

ALTER TABLE payroll_campaign_participant_bulletins
    ADD COLUMN legal_entity_id VARCHAR(255),
    ADD COLUMN engine_id       VARCHAR(255) NOT NULL REFERENCES engines (id),
    ADD COLUMN engine_version  VARCHAR(255) NOT NULL,
    ADD COLUMN country_code    VARCHAR(255) NOT NULL,
    ADD COLUMN sequence        INTEGER      NOT NULL CHECK (sequence > 0),
    ADD COLUMN kind            VARCHAR(20)  NOT NULL CHECK (kind IN ('NORMAL', 'FICTIVE', 'CORRECTIVE')),
    ADD COLUMN period          VARCHAR(255) NOT NULL,
    ADD COLUMN calculated_by   VARCHAR(255),
    ADD COLUMN calculated_at   TIMESTAMPTZ,
    ADD COLUMN validated_at    TIMESTAMPTZ;
