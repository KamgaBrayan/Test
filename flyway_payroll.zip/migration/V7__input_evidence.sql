-- ------------------------------------------------------------------------
-- Pièces justificatives des valeurs collectées (docs/04 §C)
-- ------------------------------------------------------------------------
--
-- Une saisie manuelle sans pièce n'est qu'une affirmation. La pièce s'attache à une **version** de
-- valeur, pas à un code : corriger une valeur crée une version, et la pièce qui justifiait
-- l'ancienne ne justifie pas la nouvelle.
--
-- Le fichier n'est pas stocké ici : la ligne porte de quoi le retrouver (storage_ref) et de quoi
-- constater qu'il n'a pas changé (sha256). C'est cette empreinte que le bulletin fige à l'émission.

CREATE TABLE IF NOT EXISTS payroll_input_evidences (
    id character varying(255) NOT NULL,
    company_id character varying(255) NOT NULL,
    period_id character varying(255) NOT NULL,
    employee_id character varying(255) NOT NULL,
    input_id character varying(255) NOT NULL,
    kind character varying(32) NOT NULL,
    file_name character varying(255) NOT NULL,
    content_type character varying(255),
    size_bytes bigint NOT NULL,
    sha256 character varying(64) NOT NULL,
    storage_ref character varying(1024) NOT NULL,
    note character varying(1000),
    attached_by character varying(255) NOT NULL,
    attached_at timestamp(6) with time zone NOT NULL
);

ALTER TABLE payroll_input_evidences
    ADD CONSTRAINT payroll_input_evidences_pkey PRIMARY KEY (id);

-- Une taille négative n'existe pas, et une empreinte SHA-256 fait 64 caractères hexadécimaux.
ALTER TABLE payroll_input_evidences
    ADD CONSTRAINT ck_input_evidence_size CHECK (size_bytes >= 0);

ALTER TABLE payroll_input_evidences
    ADD CONSTRAINT ck_input_evidence_sha256 CHECK (sha256 ~ '^[0-9a-f]{64}$');

-- La même pièce ne justifie pas deux fois la même valeur : deux lignes pour un même fichier
-- feraient croire à deux justifications et fausseraient tout décompte de preuves.
CREATE UNIQUE INDEX IF NOT EXISTS uq_input_evidence_content
    ON payroll_input_evidences USING btree (company_id, input_id, sha256);

CREATE INDEX IF NOT EXISTS idx_input_evidence_input
    ON payroll_input_evidences USING btree (company_id, input_id);

CREATE INDEX IF NOT EXISTS idx_input_evidence_employee
    ON payroll_input_evidences USING btree (company_id, period_id, employee_id);
