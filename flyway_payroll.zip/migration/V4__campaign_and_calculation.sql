-- Campagnes, calcul et paiement.
--
-- Le deroulement d'une paie : enroler, calculer, controler, emettre, payer.
--
-- La tentative de calcul porte sa cle d'idempotence : meme gel, memes entrees, meme resultat -- le
-- calcul n'est pas refait. Le rapport de controle et l'emission gardent leur trace parce qu'une paie
-- doit pouvoir dire ce qu'elle a verifie et ce qu'elle a produit, longtemps apres.
--
-- Cette migration fait partie de l'aplatissement du schema. Les anciennes V2..V16 patchaient
-- un schema que seul `ddl-auto` savait creer : sur une base neuve, elles echouaient. Le schema
-- est desormais pilote par ces cinq migrations, et `ddl-auto: validate` echoue au demarrage si
-- le modele d'entites et elles divergent -- un ecart se voit au boot plutot qu'a la premiere
-- requete qui touche la colonne manquante.

-- ------------------------------------------------------------------------
-- payroll_campaigns
-- ------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS payroll_campaigns (
    calculation_count integer,
    load_count integer,
    payslip_generation_count integer,
    bulletins_generated_at timestamp(6) with time zone,
    closed_at timestamp(6) with time zone,
    computed_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone NOT NULL,
    employees_loaded_at timestamp(6) with time zone,
    end_date timestamp(6) with time zone NOT NULL,
    payment_completed_at timestamp(6) with time zone,
    payment_started_at timestamp(6) with time zone,
    start_date timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    validated_at timestamp(6) with time zone,
    company_id character varying(255) NOT NULL,
    country character varying(255) NOT NULL,
    engine_id character varying(255) NOT NULL,
    legal_entity_id character varying(255),
    payment_status character varying(255),
    payroll_id character varying(255) NOT NULL,
    period character varying(255) NOT NULL,
    period_id character varying(255),
    reference character varying(255) NOT NULL,
    run_type character varying(255),
    scope jsonb,
    status character varying(255) NOT NULL,
    summary jsonb,
    CONSTRAINT payroll_campaigns_payment_status_check CHECK (((payment_status)::text = ANY ((ARRAY['NOT_STARTED'::character varying, 'STARTING'::character varying, 'STARTED_ERROR'::character varying, 'PENDING'::character varying, 'PAID'::character varying])::text[]))),
    CONSTRAINT payroll_campaigns_run_type_check CHECK (((run_type)::text = ANY ((ARRAY['MAIN'::character varying, 'OFF_CYCLE'::character varying, 'TERMINATION'::character varying, 'ADJUSTMENT'::character varying])::text[]))),
    CONSTRAINT payroll_campaigns_status_check CHECK (((status)::text = ANY ((ARRAY['DRAFT'::character varying, 'READY_FOR_LOADING'::character varying, 'LOADING_IN_PROGRESS'::character varying, 'EMPLOYEES_LOADED'::character varying, 'LOADING_FAILED'::character varying, 'READY_FOR_COMPUTATION'::character varying, 'COMPUTING'::character varying, 'COMPUTED'::character varying, 'COMPUTATION_FAILED'::character varying, 'VALIDATED'::character varying, 'READY_FOR_BULLETINS'::character varying, 'GENERATING_BULLETINS'::character varying, 'BULLETINS_GENERATED'::character varying, 'BULLETINS_FAILED'::character varying, 'CLOSED'::character varying, 'ARCHIVED'::character varying])::text[])))
);

ALTER TABLE payroll_campaigns
    ADD CONSTRAINT payroll_campaigns_pkey PRIMARY KEY (company_id, payroll_id);

CREATE INDEX IF NOT EXISTS idx_payroll_campaign_company ON payroll_campaigns USING btree (company_id);

-- ------------------------------------------------------------------------
-- payroll_campaign_participants
-- ------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS payroll_campaign_participants (
    adjusted boolean,
    dirty boolean,
    expected_amount numeric(38,2),
    payment_count integer,
    total_paid numeric(38,2),
    total_pending numeric(38,2),
    calculated_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone NOT NULL,
    enrolled_at timestamp(6) with time zone,
    last_payment_at timestamp(6) with time zone,
    pay_slip_generated_at timestamp(6) with time zone,
    preparation_revision bigint,
    updated_at timestamp(6) with time zone NOT NULL,
    validated_at timestamp(6) with time zone,
    absences jsonb,
    activity_snapshot jsonb,
    adjustments jsonb,
    benefits jsonb,
    campaign_id character varying(255) NOT NULL,
    company_id character varying(255) NOT NULL,
    employee_id character varying(255) NOT NULL,
    employee_snapshot jsonb NOT NULL,
    exclusion_reason text,
    last_payment_method character varying(255),
    participant_id character varying(255) NOT NULL,
    payment_status character varying(255),
    period character varying(255),
    period_id character varying(255) NOT NULL,
    preparation_id character varying(255),
    prepared_inputs jsonb,
    presence_segments jsonb,
    remunerations jsonb,
    status character varying(255) NOT NULL,
    CONSTRAINT payroll_campaign_participants_last_payment_method_check CHECK (((last_payment_method)::text = ANY ((ARRAY['MOBILE_MONEY'::character varying, 'MASTER'::character varying, 'VISA'::character varying, 'CASH'::character varying, 'DIGITAL_WALLET'::character varying, 'CHECK'::character varying, 'BANK_TRANSFERT'::character varying])::text[]))),
    CONSTRAINT payroll_campaign_participants_payment_status_check CHECK (((payment_status)::text = ANY ((ARRAY['UNPAID'::character varying, 'PARTIALLY_PAID'::character varying, 'FULLY_PAID'::character varying])::text[]))),
    CONSTRAINT payroll_campaign_participants_status_check CHECK (((status)::text = ANY ((ARRAY['ENROLLED'::character varying, 'VALIDATED'::character varying, 'CALCULATED'::character varying, 'BULLETIN_GENERATED'::character varying, 'LOADING_ERROR'::character varying, 'COMPUTATION_ERROR'::character varying, 'GENERATION_ERROR'::character varying, 'EXCLUDED'::character varying])::text[])))
);

ALTER TABLE payroll_campaign_participants
    ADD CONSTRAINT payroll_campaign_participants_pkey PRIMARY KEY (campaign_id, company_id, participant_id);

ALTER TABLE payroll_campaign_participants
    ADD CONSTRAINT uc_payroll_campaign_participant_empl UNIQUE (company_id, campaign_id, participant_id, employee_id);

CREATE INDEX IF NOT EXISTS idx_payroll_campaign_participant_company ON payroll_campaign_participants USING btree (company_id);

-- ------------------------------------------------------------------------
-- payroll_campaign_participant_bulletins
-- ------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS payroll_campaign_participant_bulletins (
    gross_salary numeric(38,2) NOT NULL,
    net_salary numeric(38,2) NOT NULL,
    employee_deductions numeric(38, 2),
    employer_deductions numeric(38, 2),
    net_to_pay numeric(38, 2),
    campaign_end_date timestamp(6) with time zone,
    campaign_start_date timestamp(6) with time zone,
    created_at timestamp(6) with time zone NOT NULL,
    payment_date timestamp(6) with time zone,
    updated_at timestamp(6) with time zone,
    campaign_id character varying(255) NOT NULL,
    company_id character varying(255) NOT NULL,
    content jsonb,
    document jsonb,
    employee_id character varying(255),
    participant_id character varying(255) NOT NULL,
    period_id character varying(255) NOT NULL,
    reference character varying(255) NOT NULL,
    status character varying(255),
    CONSTRAINT payroll_campaign_participant_bulletins_status_check CHECK (((status)::text = ANY ((ARRAY['DRAFT'::character varying, 'INVALIDATED'::character varying, 'VALIDATED'::character varying, 'CANCELLED'::character varying, 'CALCULATED'::character varying, 'PUBLISHED'::character varying])::text[])))
);

ALTER TABLE payroll_campaign_participant_bulletins
    ADD CONSTRAINT payroll_campaign_participant_bulletins_pkey PRIMARY KEY (campaign_id, company_id, participant_id, reference);

CREATE INDEX IF NOT EXISTS idx_payrollbulletin_campaign ON payroll_campaign_participant_bulletins USING btree (company_id, campaign_id);

CREATE INDEX IF NOT EXISTS idx_payrollbulletin_company ON payroll_campaign_participant_bulletins USING btree (company_id);

CREATE INDEX IF NOT EXISTS idx_payrollbulletin_employee ON payroll_campaign_participant_bulletins USING btree (company_id, employee_id);

-- ------------------------------------------------------------------------
-- payroll_campaign_adjustments
-- ------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS payroll_campaign_adjustments (
    applied_at timestamp(6) with time zone NOT NULL,
    activity_snapshot jsonb,
    adjustment_id character varying(255) NOT NULL,
    applied_by_id character varying(255) NOT NULL,
    applied_by_name character varying(255) NOT NULL,
    campaign_id character varying(255) NOT NULL,
    company_id character varying(255) NOT NULL,
    employee_snapshot jsonb NOT NULL,
    participant_id character varying(255) NOT NULL,
    reason text,
    remunerations jsonb
);

ALTER TABLE payroll_campaign_adjustments
    ADD CONSTRAINT payroll_campaign_adjustments_pkey PRIMARY KEY (adjustment_id, campaign_id, company_id, participant_id);

ALTER TABLE payroll_campaign_adjustments
    ADD CONSTRAINT uc_payroll_campaign_adjustment_participant UNIQUE (company_id, campaign_id, participant_id);

CREATE INDEX IF NOT EXISTS idx_payroll_campaign_adjustment_company ON payroll_campaign_adjustments USING btree (company_id);

-- ------------------------------------------------------------------------
-- payroll_campaign_errors
-- ------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS payroll_campaign_errors (
    resolved boolean NOT NULL,
    occurred_at timestamp(6) with time zone,
    resolved_at timestamp(6) with time zone,
    campaign_id character varying(255) NOT NULL,
    company_id character varying(255) NOT NULL,
    error_code character varying(255) NOT NULL,
    error_id character varying(255) NOT NULL,
    message text,
    participant_id character varying(255),
    phase character varying(255) NOT NULL,
    resolution_note text,
    severity character varying(255) NOT NULL,
    technical_details text,
    type character varying(255) NOT NULL,
    context jsonb,
    CONSTRAINT payroll_campaign_errors_phase_check CHECK (((phase)::text = ANY ((ARRAY['LOADING'::character varying, 'COMPUTATION'::character varying, 'GENERATION'::character varying])::text[]))),
    CONSTRAINT payroll_campaign_errors_severity_check CHECK (((severity)::text = ANY ((ARRAY['INFO'::character varying, 'WARNING'::character varying, 'ERROR'::character varying, 'CRITICAL'::character varying])::text[]))),
    CONSTRAINT payroll_campaign_errors_type_check CHECK (((type)::text = ANY ((ARRAY['DATA_NOT_FOUND'::character varying, 'DATA_INCOMPLETE'::character varying, 'DATA_INVALID'::character varying, 'TIME_SHEET_NOT_FOUND'::character varying, 'EMPLOYEE_NOT_FOUND'::character varying, 'REMUNERATION_NOT_FOUND'::character varying, 'CALCULATION_ERROR'::character varying, 'SYSTEM_ERROR'::character varying, 'TIMEOUT'::character varying, 'UNKNOWN'::character varying])::text[])))
);

ALTER TABLE payroll_campaign_errors
    ADD CONSTRAINT payroll_campaign_errors_pkey PRIMARY KEY (campaign_id, company_id, error_id);

CREATE INDEX IF NOT EXISTS idx_payrollcampaignerror_participant ON payroll_campaign_errors USING btree (company_id, campaign_id, participant_id);

-- ------------------------------------------------------------------------
-- payroll_campaign_ledgers
-- ------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS payroll_campaign_ledgers (
    participant_count integer NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    campaign_id character varying(255) NOT NULL,
    company_id character varying(255) NOT NULL,
    document jsonb NOT NULL,
    id character varying(255) NOT NULL,
    reference character varying(255) NOT NULL
);

ALTER TABLE payroll_campaign_ledgers
    ADD CONSTRAINT payroll_campaign_ledgers_pkey PRIMARY KEY (id);

CREATE INDEX IF NOT EXISTS idx_payrollledger_campaign ON payroll_campaign_ledgers USING btree (company_id, campaign_id);

CREATE INDEX IF NOT EXISTS idx_payrollledger_company ON payroll_campaign_ledgers USING btree (company_id);

-- ------------------------------------------------------------------------
-- payroll_campaign_financial_summary_chunk_entity
-- ------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS payroll_campaign_financial_summary_chunk_entity (
    campaign_id character varying(255) NOT NULL,
    chunk_id character varying(255) NOT NULL,
    company_id character varying(255) NOT NULL,
    financial_summary jsonb NOT NULL
);

ALTER TABLE payroll_campaign_financial_summary_chunk_entity
    ADD CONSTRAINT payroll_campaign_financial_summary_chunk_entity_pkey PRIMARY KEY (campaign_id, chunk_id, company_id);

CREATE INDEX IF NOT EXISTS idx_payrollcampaignfinancialsummarychunkentity ON payroll_campaign_financial_summary_chunk_entity USING btree (company_id, campaign_id);

-- ------------------------------------------------------------------------
-- payroll_calculation_results: one immutable outcome per execution
-- ------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS payroll_calculation_results (
    id varchar(255) PRIMARY KEY,
    sequence bigint GENERATED ALWAYS AS IDENTITY UNIQUE,
    company_id varchar(255) NOT NULL,
    campaign_id varchar(255) NOT NULL,
    participant_id varchar(255) NOT NULL,
    employee_id varchar(255) NOT NULL,
    preparation_id varchar(255) NOT NULL,
    preparation_revision bigint NOT NULL CHECK (preparation_revision > 0),
    configuration_version integer NOT NULL,
    configuration_hash varchar(64) NOT NULL,
    engine_id varchar(255) NOT NULL,
    engine_version varchar(255) NOT NULL,
    input_hash varchar(64) NOT NULL,
    status varchar(255) NOT NULL CHECK (status IN ('SUCCEEDED', 'FAILED')),
    result_hash varchar(64),
    error_code varchar(255),
    error_message text,
    started_at timestamp(6) with time zone NOT NULL,
    completed_at timestamp(6) with time zone NOT NULL CHECK (completed_at >= started_at),
    engine_status smallint CHECK (engine_status IN (0, 1)),
    duration bigint,
    context jsonb,
    constant_resolutions jsonb,
    step_results jsonb,
    CONSTRAINT calculation_outcome_check CHECK (
        (status = 'SUCCEEDED' AND result_hash IS NOT NULL AND engine_status IS NOT NULL
            AND engine_status = 0 AND error_code IS NULL AND error_message IS NULL)
        OR (status = 'FAILED' AND error_code IS NOT NULL AND result_hash IS NULL
            AND (engine_status IS NULL OR engine_status = 1))
    ),
    CONSTRAINT calculation_output_check CHECK (
        engine_status IS NULL OR (duration IS NOT NULL AND context IS NOT NULL AND step_results IS NOT NULL)
    )
);

CREATE INDEX idx_calculation_result_participant
    ON payroll_calculation_results (company_id, campaign_id, participant_id, completed_at DESC, sequence DESC);
CREATE INDEX idx_calculation_result_key
    ON payroll_calculation_results (participant_id, configuration_hash, input_hash);

-- ------------------------------------------------------------------------
-- payroll_one_time_element_payments
-- ------------------------------------------------------------------------

CREATE TABLE payroll_one_time_element_payments (
    id varchar(255) PRIMARY KEY,
    company_id varchar(255) NOT NULL,
    employee_id varchar(255) NOT NULL,
    reference varchar(255) NOT NULL,
    campaign_id varchar(255) NOT NULL,
    participant_id varchar(255) NOT NULL,
    bulletin_sequence integer NOT NULL CHECK (bulletin_sequence > 0),
    amount numeric(38,10) NOT NULL CHECK (amount > 0),
    issued_at timestamp(6) with time zone NOT NULL,
    CONSTRAINT uk_one_time_element_payment UNIQUE (company_id, employee_id, reference)
);

CREATE INDEX idx_one_time_payment_bulletin
    ON payroll_one_time_element_payments (company_id, campaign_id, participant_id, bulletin_sequence);

-- ------------------------------------------------------------------------
-- payroll_payments
-- ------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS payroll_payments (
    amount numeric(19,4) NOT NULL,
    cancelled_at timestamp(6) with time zone,
    confirmed_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone NOT NULL,
    paid_at timestamp(6) with time zone,
    updated_at timestamp(6) with time zone NOT NULL,
    method_type character varying(30) NOT NULL,
    status character varying(30) NOT NULL,
    campaign_id character varying(255) NOT NULL,
    company_id character varying(255) NOT NULL,
    employee_id character varying(255) NOT NULL,
    employee_name character varying(255),
    note text,
    participant_id character varying(255) NOT NULL,
    payment_id character varying(255) NOT NULL,
    CONSTRAINT payroll_payments_method_type_check CHECK (((method_type)::text = ANY ((ARRAY['MOBILE_MONEY'::character varying, 'MASTER'::character varying, 'VISA'::character varying, 'CASH'::character varying, 'DIGITAL_WALLET'::character varying, 'CHECK'::character varying, 'BANK_TRANSFERT'::character varying])::text[]))),
    CONSTRAINT payroll_payments_status_check CHECK (((status)::text = ANY ((ARRAY['PENDING'::character varying, 'CONFIRMED'::character varying, 'CANCELLED'::character varying])::text[])))
);

ALTER TABLE payroll_payments
    ADD CONSTRAINT payroll_payments_pkey PRIMARY KEY (campaign_id, company_id, payment_id);

CREATE INDEX IF NOT EXISTS idx_payroll_payment_campaign ON payroll_payments USING btree (company_id, campaign_id);

CREATE INDEX IF NOT EXISTS idx_payroll_payment_company ON payroll_payments USING btree (company_id);

CREATE INDEX IF NOT EXISTS idx_payroll_payment_employee ON payroll_payments USING btree (company_id, employee_id);

CREATE INDEX IF NOT EXISTS idx_payroll_payment_participant ON payroll_payments USING btree (company_id, campaign_id, participant_id);

CREATE INDEX IF NOT EXISTS idx_payroll_payment_status ON payroll_payments USING btree (status);

-- ------------------------------------------------------------------------
-- campaign_payment_exports
-- ------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS campaign_payment_exports (
    cancelled_amount numeric(38,2),
    confirmed_amount numeric(38,2),
    pending_amount numeric(38,2),
    total_amount numeric(38,2),
    cancelled_payments bigint NOT NULL,
    confirmed_payments bigint NOT NULL,
    exported_at timestamp(6) with time zone,
    pending_payments bigint NOT NULL,
    total_payments bigint NOT NULL,
    campaign_id character varying(255) NOT NULL,
    campaign_reference character varying(255),
    company_id character varying(255) NOT NULL,
    export_format character varying(255),
    file text,
    CONSTRAINT campaign_payment_exports_export_format_check CHECK (((export_format)::text = ANY ((ARRAY['EXCEL'::character varying, 'CSV'::character varying])::text[])))
);

ALTER TABLE campaign_payment_exports
    ADD CONSTRAINT campaign_payment_exports_pkey PRIMARY KEY (campaign_id, company_id);

-- ------------------------------------------------------------------------
-- payroll_simulations
-- ------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS payroll_simulations (
    run_count integer NOT NULL,
    completed_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone,
    started_at timestamp(6) with time zone,
    updated_at timestamp(6) with time zone,
    company_id character varying(255) NOT NULL,
    employees jsonb NOT NULL,
    engine_id character varying(255),
    errors jsonb NOT NULL,
    name character varying(255),
    simulation_id character varying(255) NOT NULL,
    status character varying(255),
    summary jsonb NOT NULL,
    CONSTRAINT payroll_simulations_status_check CHECK (((status)::text = ANY ((ARRAY['DRAFT'::character varying, 'RUNNING'::character varying, 'COMPLETED'::character varying, 'FAILED'::character varying])::text[])))
);

ALTER TABLE payroll_simulations
    ADD CONSTRAINT payroll_simulations_pkey PRIMARY KEY (company_id, simulation_id);

CREATE INDEX IF NOT EXISTS idx_payroll_simulation_company ON payroll_simulations USING btree (company_id);

-- ------------------------------------------------------------------------
-- payroll_run_control_reports
-- ------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS payroll_run_control_reports (
    blocking_count integer NOT NULL,
    employer_cost numeric(19,4),
    gross numeric(19,4),
    net numeric(19,4),
    patronal_deductions numeric(19,4),
    salarial_deductions numeric(19,4),
    headcount bigint NOT NULL,
    produced_at timestamp(6) with time zone NOT NULL,
    calculation_hash character varying(255),
    company_id character varying(255) NOT NULL,
    configuration_hash character varying(255),
    findings jsonb NOT NULL,
    id character varying(255) NOT NULL,
    reference_run_id character varying(255),
    reference_totals jsonb,
    run_id character varying(255) NOT NULL
);

ALTER TABLE payroll_run_control_reports
    ADD CONSTRAINT payroll_run_control_reports_pkey PRIMARY KEY (id);

CREATE INDEX IF NOT EXISTS idx_run_control_report_run ON payroll_run_control_reports USING btree (company_id, run_id, produced_at);

-- ------------------------------------------------------------------------
-- payroll_bulletin_issuances
-- ------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS payroll_bulletin_issuances (
    issue_sequence integer NOT NULL,
    issued_at timestamp(6) with time zone,
    started_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    company_id character varying(255) NOT NULL,
    effects jsonb NOT NULL,
    employee_id character varying(255) NOT NULL,
    failure_code character varying(255),
    id character varying(255) NOT NULL,
    idempotency_key character varying(255) NOT NULL,
    participant_id character varying(255) NOT NULL,
    payload_hash character varying(255),
    run_id character varying(255) NOT NULL,
    status character varying(255) NOT NULL,
    CONSTRAINT payroll_bulletin_issuances_status_check CHECK (((status)::text = ANY ((ARRAY['IN_PROGRESS'::character varying, 'ISSUED'::character varying, 'FAILED'::character varying])::text[])))
);

ALTER TABLE payroll_bulletin_issuances
    ADD CONSTRAINT payroll_bulletin_issuances_pkey PRIMARY KEY (id);

ALTER TABLE payroll_bulletin_issuances
    ADD CONSTRAINT uq_bulletin_issuance_key UNIQUE (company_id, idempotency_key);

CREATE INDEX IF NOT EXISTS idx_bulletin_issuance_run ON payroll_bulletin_issuances USING btree (company_id, run_id, status);
