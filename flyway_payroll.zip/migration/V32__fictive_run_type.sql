-- La paie fictive devient un type de run : calculée comme une paie de la période, sur les vrais
-- salariés, ses bulletins (de nature FICTIVE, déjà admise) s'affichent sans se valider.

ALTER TABLE payroll_campaigns
    DROP CONSTRAINT IF EXISTS payroll_campaigns_run_type_check;

ALTER TABLE payroll_campaigns
    ADD CONSTRAINT payroll_campaigns_run_type_check
        CHECK (run_type IN ('MAIN', 'OFF_CYCLE', 'TERMINATION', 'ADJUSTMENT', 'FICTIVE'));
