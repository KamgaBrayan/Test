-- Le contrat de bulletin d'une release : ce que son bulletin contient — lignes et totaux — avec les
-- valeurs de démonstration sur lesquelles un modèle de bulletin s'écrit. Un par moteur, sous l'identité
-- du moteur ; il part avec lui quand un brouillon est supprimé.

CREATE TABLE engine_payslip_contracts
(
    engine_id      VARCHAR(255) NOT NULL PRIMARY KEY REFERENCES engines (id) ON DELETE CASCADE,
    country_code   VARCHAR(255) NOT NULL,
    engine_version VARCHAR(255) NOT NULL,
    lines          JSONB        NOT NULL DEFAULT '[]' CHECK (jsonb_typeof(lines) = 'array'),
    totals         JSONB        NOT NULL DEFAULT '[]' CHECK (jsonb_typeof(totals) = 'array'),
    created_at     TIMESTAMPTZ  NOT NULL,
    updated_at     TIMESTAMPTZ  NOT NULL
);

-- Un modèle de bulletin est écrit pour une release du moteur de paie, et chaque version publiée garde
-- la release pour laquelle elle l'a été. Un modèle ne s'attache qu'à une release publiée, qui ne se
-- supprime plus : la référence ne casse pas. Aucune reprise : les deux tables sont vides.

ALTER TABLE payslip_templates
    ADD COLUMN payroll_engine_id VARCHAR(255) NOT NULL REFERENCES engines (id);

ALTER TABLE payslip_template_versions
    ADD COLUMN payroll_engine_id VARCHAR(255) NOT NULL REFERENCES engines (id);

CREATE INDEX idx_payslip_template_engine ON payslip_templates (company_id, payroll_engine_id);
