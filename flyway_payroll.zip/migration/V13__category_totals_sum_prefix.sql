-- Les totaux par catégorie sont désormais publiés sous SUM_<catégorie> : SUM_BASE_SALARY, SUM_OVERTIMES,
-- SUM_ALLOWANCES, SUM_BONUS, SUM_BENEFITS, SUM_DEDUCTIONS. Sans préfixe, le total de la catégorie
-- BASE_SALARY portait le même code que la rubrique BASE_SALARY : l'un écrasait l'autre dans le contexte.
--
-- Dans les formules déjà enregistrées, un code de catégorie nu désignait le total de la catégorie : il
-- est réécrit en SUM_<code>, sur des mots entiers (\m…\M). Les agrégats déjà préfixés
-- (TAXABLE_ALLOWANCES, NON_CONTRIBUTORY_BONUS…) et les autres codes (SALARIAL_DEDUCTIONS,
-- NON_MONETARY_BENEFITS…) ne sont pas touchés, le tiret bas faisant partie du mot.

UPDATE engine_bases
SET formular = jsonb_set(formular, '{expression}', to_jsonb(regexp_replace(
        formular ->> 'expression',
        '\m(BASE_SALARY|OVERTIMES|ALLOWANCES|BONUS|BENEFITS|DEDUCTIONS)\M', 'SUM_\1', 'g')))
WHERE formular ->> 'expression' ~ '\m(BASE_SALARY|OVERTIMES|ALLOWANCES|BONUS|BENEFITS|DEDUCTIONS)\M';

UPDATE engine_remuneration_rules
SET tax_treatment_formula = regexp_replace(tax_treatment_formula,
        '\m(BASE_SALARY|OVERTIMES|ALLOWANCES|BONUS|BENEFITS|DEDUCTIONS)\M', 'SUM_\1', 'g')
WHERE tax_treatment_formula ~ '\m(BASE_SALARY|OVERTIMES|ALLOWANCES|BONUS|BENEFITS|DEDUCTIONS)\M';

UPDATE engine_remuneration_rules
SET contribution_treatment_formula = regexp_replace(contribution_treatment_formula,
        '\m(BASE_SALARY|OVERTIMES|ALLOWANCES|BONUS|BENEFITS|DEDUCTIONS)\M', 'SUM_\1', 'g')
WHERE contribution_treatment_formula ~ '\m(BASE_SALARY|OVERTIMES|ALLOWANCES|BONUS|BENEFITS|DEDUCTIONS)\M';
