-- Une référence de valeur du contrat de bulletin s'écrit désormais {code, value} — un code moteur ou un
-- littéral — et non plus {stepCode, inputKey}. Les contrats enregistrés avant ce changement devenaient
-- illisibles (vérification d'activation en 500). inputKey n'a jamais été renseigné : la conversion est
-- sans perte, stepCode devient code.
CREATE OR REPLACE FUNCTION pg_temp.value_reference(ref jsonb) RETURNS jsonb AS $$
    SELECT CASE
               WHEN ref IS NULL OR jsonb_typeof(ref) <> 'object' OR NOT (ref ? 'stepCode') THEN ref
               ELSE jsonb_build_object('code', ref -> 'stepCode', 'value', ref -> 'value')
           END;
$$ LANGUAGE sql IMMUTABLE;

UPDATE engine_payslip_contracts c
SET lines = (SELECT coalesce(jsonb_agg(
                     line || jsonb_strip_nulls(jsonb_build_object(
                             'calculatedBase', pg_temp.value_reference(line -> 'calculatedBase'),
                             'cappedBase', pg_temp.value_reference(line -> 'cappedBase'),
                             'rate', pg_temp.value_reference(line -> 'rate')))
                     ORDER BY ordinality), '[]'::jsonb)
             FROM jsonb_array_elements(c.lines) WITH ORDINALITY AS l(line, ordinality)),
    totals = (SELECT coalesce(jsonb_agg(
                      total || jsonb_strip_nulls(jsonb_build_object('value', pg_temp.value_reference(total -> 'value')))
                      ORDER BY ordinality), '[]'::jsonb)
              FROM jsonb_array_elements(c.totals) WITH ORDINALITY AS t(total, ordinality))
WHERE c.lines::text LIKE '%"stepCode"%' OR c.totals::text LIKE '%"stepCode"%';
