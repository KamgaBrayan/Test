-- Cumuls et documents.
--
-- Ce qui survit a la periode.
--
-- Un cumul n'est pas un total recalcule : c'est un registre de mouvements, ou une annulation
-- contre-passe au lieu d'effacer. Les modeles de bulletin et les documents emis ferment la chaine :
-- ce que le salarie recoit, et sous quelle forme.
--
-- Cette migration fait partie de l'aplatissement du schema. Les anciennes V2..V16 patchaient
-- un schema que seul `ddl-auto` savait creer : sur une base neuve, elles echouaient. Le schema
-- est desormais pilote par ces cinq migrations, et `ddl-auto: validate` echoue au demarrage si
-- le modele d'entites et elles divergent -- un ecart se voit au boot plutot qu'a la premiere
-- requete qui touche la colonne manquante.

-- ------------------------------------------------------------------------
-- cumulative_entries
-- ------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS cumulative_entries (
    amount numeric(24,6) NOT NULL,
    fiscal_window_end date NOT NULL,
    fiscal_window_start date NOT NULL,
    source_bulletin_version integer NOT NULL,
    entry_sequence bigint NOT NULL,
    occurred_at timestamp(6) with time zone NOT NULL,
    accumulator_code character varying(255) NOT NULL,
    company_id character varying(255) NOT NULL,
    employee_id character varying(255) NOT NULL,
    id character varying(255) NOT NULL,
    idempotency_key character varying(255) NOT NULL,
    jurisdiction character varying(255) NOT NULL,
    legal_entity_id character varying(255) NOT NULL,
    operation character varying(255) NOT NULL,
    payroll_period_id character varying(255) NOT NULL,
    reason character varying(255),
    reverted_entry_id character varying(255),
    source_bulletin_id character varying(255) NOT NULL,
    CONSTRAINT cumulative_entries_operation_check CHECK (((operation)::text = ANY ((ARRAY['APPLY'::character varying, 'REVERT'::character varying, 'ADJUST'::character varying])::text[])))
);

ALTER TABLE cumulative_entries
    ADD CONSTRAINT cumulative_entries_pkey PRIMARY KEY (id);

ALTER TABLE cumulative_entries
    ADD CONSTRAINT uk_cumulative_entry_idempotency UNIQUE (idempotency_key);

ALTER TABLE cumulative_entries
    ADD CONSTRAINT uk_cumulative_entry_sequence UNIQUE (entry_sequence);

-- ------------------------------------------------------------------------
-- cumulative_balances
-- ------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS cumulative_balances (
    fiscal_window_end date NOT NULL,
    fiscal_window_start date NOT NULL,
    total numeric(24,6) NOT NULL,
    last_entry_sequence bigint NOT NULL,
    lock_version bigint NOT NULL,
    updated_at timestamp(6) with time zone,
    accumulator_code character varying(255) NOT NULL,
    company_id character varying(255) NOT NULL,
    employee_id character varying(255) NOT NULL,
    jurisdiction character varying(255) NOT NULL,
    legal_entity_id character varying(255) NOT NULL
);

ALTER TABLE cumulative_balances
    ADD CONSTRAINT cumulative_balances_pkey PRIMARY KEY (fiscal_window_end, fiscal_window_start, accumulator_code, company_id, employee_id, jurisdiction, legal_entity_id);

-- ------------------------------------------------------------------------
-- payslip_templates
-- ------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS payslip_templates (
    latest_published_version integer NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    published_at timestamp(6) with time zone,
    updated_at timestamp(6) with time zone,
    company_id character varying(255) NOT NULL,
    content_type character varying(255) NOT NULL,
    created_by character varying(255),
    description text,
    engine character varying(255) NOT NULL,
    html_template text NOT NULL,
    id character varying(255) NOT NULL,
    language character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    status character varying(255) NOT NULL,
    updated_by character varying(255),
    CONSTRAINT payslip_templates_status_check CHECK (((status)::text = ANY ((ARRAY['DRAFT'::character varying, 'PUBLISHED'::character varying, 'ARCHIVED'::character varying])::text[])))
);

ALTER TABLE payslip_templates
    ADD CONSTRAINT payslip_templates_pkey PRIMARY KEY (id);

CREATE INDEX IF NOT EXISTS idx_payslip_template_company ON payslip_templates USING btree (company_id);

-- ------------------------------------------------------------------------
-- payslip_template_versions
-- ------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS payslip_template_versions (
    version integer NOT NULL,
    published_at timestamp(6) with time zone NOT NULL,
    company_id character varying(255) NOT NULL,
    html_template text NOT NULL,
    id character varying(255) NOT NULL,
    published_by character varying(255),
    template_id character varying(255) NOT NULL
);

ALTER TABLE payslip_template_versions
    ADD CONSTRAINT payslip_template_versions_pkey PRIMARY KEY (id);

CREATE INDEX IF NOT EXISTS idx_payslip_template_version_company ON payslip_template_versions USING btree (company_id);

CREATE INDEX IF NOT EXISTS idx_payslip_template_version_template ON payslip_template_versions USING btree (company_id, template_id);

-- ------------------------------------------------------------------------
-- documents
-- ------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS documents (
    "timestamp" timestamp(6) without time zone NOT NULL,
    format character varying(255) NOT NULL,
    id character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    data oid NOT NULL,
    CONSTRAINT documents_format_check CHECK (((format)::text = ANY ((ARRAY['PNG'::character varying, 'JPEG'::character varying, 'CSV'::character varying, 'XLS'::character varying, 'PDF'::character varying])::text[])))
);

ALTER TABLE documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);
