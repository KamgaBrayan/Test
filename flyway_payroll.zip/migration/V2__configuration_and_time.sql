-- Configuration et decoupage du temps.
--
-- Ou tombent les periodes, et qui elles paient.
--
-- Le cycle porte le rythme, l'ancrage et le fuseau ; il ne se versionne pas. Le calendrier porte ce
-- qui arrive a l'interieur d'une periode -- ouverture de la saisie, coupe, paiement -- et se versionne,
-- parce que ces regles changent souvent quand le decoupage ne change presque jamais. La periode
-- materialise les deux, et fige ses dates : une revision posterieure ne doit pas lui faire changer
-- d'heures.
--
-- Cette migration fait partie de l'aplatissement du schema. Les anciennes V2..V16 patchaient
-- un schema que seul `ddl-auto` savait creer : sur une base neuve, elles echouaient. Le schema
-- est desormais pilote par ces cinq migrations, et `ddl-auto: validate` echoue au demarrage si
-- le modele d'entites et elles divergent -- un ecart se voit au boot plutot qu'a la premiere
-- requete qui touche la colonne manquante.

-- ------------------------------------------------------------------------
-- legal_entity_payroll_configs
-- ------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS legal_entity_payroll_configs (
    effective_from date NOT NULL,
    effective_to date,
    created_at timestamp(6) with time zone NOT NULL,
    lock_version bigint NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    company_id character varying(255) NOT NULL,
    country_code character varying(255) NOT NULL,
    default_cycle_id character varying(255),
    id character varying(255) NOT NULL,
    legal_entity_id character varying(255) NOT NULL,
    payroll_currency character varying(255) NOT NULL,
    status character varying(255) NOT NULL,
    time_zone character varying(255) NOT NULL,
    CONSTRAINT legal_entity_payroll_configs_status_check CHECK (((status)::text = ANY ((ARRAY['DRAFT'::character varying, 'ACTIVE'::character varying, 'SUSPENDED'::character varying, 'CLOSED'::character varying])::text[])))
);

ALTER TABLE legal_entity_payroll_configs
    ADD CONSTRAINT legal_entity_payroll_configs_pkey PRIMARY KEY (id);

ALTER TABLE legal_entity_payroll_configs
    ADD CONSTRAINT uc_legal_entity_payroll_config UNIQUE (company_id, legal_entity_id);

CREATE INDEX IF NOT EXISTS idx_legal_entity_payroll_config_company ON legal_entity_payroll_configs USING btree (company_id, status);

-- ------------------------------------------------------------------------
-- payroll_cycles
-- ------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS payroll_cycles (
    anchor_date date NOT NULL,
    effective_from date NOT NULL,
    effective_to date,
    created_at timestamp(6) with time zone NOT NULL,
    lock_version bigint NOT NULL,
    published_at timestamp(6) with time zone,
    updated_at timestamp(6) with time zone NOT NULL,
    company_id character varying(255) NOT NULL,
    frequency character varying(255) NOT NULL,
    id character varying(255) NOT NULL,
    label character varying(255) NOT NULL,
    legal_entity_id character varying(255) NOT NULL,
    status character varying(255) NOT NULL,
    timezone character varying(255) NOT NULL,
    CONSTRAINT payroll_cycles_frequency_check CHECK (((frequency)::text = ANY ((ARRAY['WEEKLY'::character varying, 'BIWEEKLY'::character varying, 'SEMI_MONTHLY'::character varying, 'MONTHLY'::character varying, 'QUARTERLY'::character varying, 'SEMI_ANNUAL'::character varying, 'ANNUAL'::character varying])::text[]))),
    CONSTRAINT payroll_cycles_status_check CHECK (((status)::text = ANY ((ARRAY['DRAFT'::character varying, 'PUBLISHED'::character varying, 'ARCHIVED'::character varying])::text[])))
);

ALTER TABLE payroll_cycles
    ADD CONSTRAINT payroll_cycles_pkey PRIMARY KEY (id);

ALTER TABLE payroll_cycles
    ADD CONSTRAINT uc_payroll_cycle_label UNIQUE (company_id, legal_entity_id, label);

CREATE INDEX IF NOT EXISTS idx_payroll_cycle_governing ON payroll_cycles USING btree (company_id, status, effective_from);

CREATE INDEX IF NOT EXISTS idx_payroll_cycle_legal_entity ON payroll_cycles USING btree (company_id, legal_entity_id);

-- ------------------------------------------------------------------------
-- payroll_calendars
-- ------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS payroll_calendars (
    effective_from date NOT NULL,
    effective_to date,
    opens_automatically boolean NOT NULL,
    version integer NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    lock_version bigint NOT NULL,
    published_at timestamp(6) with time zone,
    updated_at timestamp(6) with time zone NOT NULL,
    company_id character varying(255) NOT NULL,
    cut_off_rule character varying(255) NOT NULL,
    cycle_id character varying(255) NOT NULL,
    id character varying(255) NOT NULL,
    opening_rule character varying(255) NOT NULL,
    payment_rule character varying(255) NOT NULL,
    previous_version_id character varying(255),
    status character varying(255) NOT NULL,
    CONSTRAINT payroll_calendars_status_check CHECK (((status)::text = ANY ((ARRAY['DRAFT'::character varying, 'PUBLISHED'::character varying, 'ARCHIVED'::character varying])::text[])))
);

ALTER TABLE payroll_calendars
    ADD CONSTRAINT payroll_calendars_pkey PRIMARY KEY (id);

ALTER TABLE payroll_calendars
    ADD CONSTRAINT uc_payroll_calendar_cycle_version UNIQUE (cycle_id, version);

CREATE INDEX IF NOT EXISTS idx_payroll_calendar_governing ON payroll_calendars USING btree (company_id, cycle_id, status, effective_from);

-- ------------------------------------------------------------------------
-- payroll_periods
-- ------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS payroll_periods (
    end_date date NOT NULL,
    payment_date date NOT NULL,
    start_date date NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    cut_off_at timestamp(6) with time zone NOT NULL,
    lock_version bigint NOT NULL,
    opening_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    attachment_month character varying(255) NOT NULL,
    calendar_version_id character varying(255) NOT NULL,
    company_id character varying(255) NOT NULL,
    cycle_id character varying(255) NOT NULL,
    id character varying(255) NOT NULL,
    label character varying(255) NOT NULL,
    legal_entity_id character varying(255) NOT NULL,
    status character varying(255) NOT NULL,
    timezone character varying(255) NOT NULL,
    population_snapshot jsonb NOT NULL,
    CONSTRAINT payroll_periods_status_check CHECK (((status)::text = ANY ((ARRAY['SCHEDULED'::character varying, 'IN_PROGRESS'::character varying, 'CLOSED'::character varying])::text[])))
);

ALTER TABLE payroll_periods
    ADD CONSTRAINT payroll_periods_pkey PRIMARY KEY (id);

ALTER TABLE payroll_periods
    ADD CONSTRAINT uc_payroll_period_cycle_start UNIQUE (company_id, cycle_id, start_date);

CREATE INDEX IF NOT EXISTS idx_payroll_period_attachment ON payroll_periods USING btree (company_id, attachment_month);

CREATE INDEX IF NOT EXISTS idx_payroll_period_range ON payroll_periods USING btree (company_id, cycle_id, start_date, end_date);

-- ------------------------------------------------------------------------
-- payroll_populations
-- ------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS payroll_populations (
    created_at timestamp(6) with time zone NOT NULL,
    lock_version bigint NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    company_id character varying(255) NOT NULL,
    definition jsonb NOT NULL,
    id character varying(255) NOT NULL,
    label character varying(255) NOT NULL,
    legal_entity_id character varying(255) NOT NULL,
    parent_id character varying(255)
);

ALTER TABLE payroll_populations
    ADD CONSTRAINT payroll_populations_pkey PRIMARY KEY (id);

CREATE INDEX IF NOT EXISTS idx_payroll_population_company ON payroll_populations USING btree (company_id, legal_entity_id);

CREATE INDEX IF NOT EXISTS idx_payroll_population_parent ON payroll_populations USING btree (parent_id);

-- ------------------------------------------------------------------------
-- payroll_population_assignments
-- ------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS payroll_population_assignments (
    effective_from date NOT NULL,
    effective_to date,
    created_at timestamp(6) with time zone NOT NULL,
    lock_version bigint NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    company_id character varying(255) NOT NULL,
    cycle_id character varying(255) NOT NULL,
    id character varying(255) NOT NULL,
    legal_entity_id character varying(255) NOT NULL,
    population_id character varying(255) NOT NULL
);

ALTER TABLE payroll_population_assignments
    ADD CONSTRAINT payroll_population_assignments_pkey PRIMARY KEY (id);

CREATE INDEX IF NOT EXISTS idx_population_assignment_cycle ON payroll_population_assignments USING btree (company_id, cycle_id, effective_from);

CREATE INDEX IF NOT EXISTS idx_population_assignment_population ON payroll_population_assignments USING btree (company_id, population_id);

-- ------------------------------------------------------------------------
-- input_windows
-- ------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS input_windows (
    opens_automatically boolean DEFAULT true NOT NULL,
    closed_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone NOT NULL,
    cut_off_at timestamp(6) with time zone NOT NULL,
    extended_until timestamp(6) with time zone,
    lock_version bigint NOT NULL,
    opened_at timestamp(6) with time zone,
    opens_at timestamp(6) with time zone NOT NULL,
    population_prepared_at timestamp(6) with time zone,
    updated_at timestamp(6) with time zone NOT NULL,
    calendar_version_id character varying(255) NOT NULL,
    closed_by character varying(255),
    company_id character varying(255) NOT NULL,
    id character varying(255) NOT NULL,
    legal_entity_id character varying(255) NOT NULL,
    opened_by character varying(255),
    period_id character varying(255) NOT NULL,
    reason text,
    status character varying(255) NOT NULL,
    CONSTRAINT input_windows_status_check CHECK (((status)::text = ANY ((ARRAY['SCHEDULED'::character varying, 'OPEN'::character varying, 'REOPENED'::character varying, 'CLOSED'::character varying])::text[])))
);

ALTER TABLE input_windows
    ADD CONSTRAINT input_windows_pkey PRIMARY KEY (id);

ALTER TABLE input_windows
    ADD CONSTRAINT uc_input_window_period UNIQUE (period_id);

CREATE INDEX IF NOT EXISTS idx_input_window_company ON input_windows USING btree (company_id, period_id);

-- ------------------------------------------------------------------------
-- input_window_audit
-- ------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS input_window_audit (
    cut_off_after timestamp(6) with time zone,
    cut_off_before timestamp(6) with time zone,
    occurred_at timestamp(6) with time zone NOT NULL,
    action character varying(255) NOT NULL,
    actor character varying(255) NOT NULL,
    company_id character varying(255) NOT NULL,
    id character varying(255) NOT NULL,
    period_id character varying(255) NOT NULL,
    reason text,
    status_after character varying(255) NOT NULL,
    status_before character varying(255) NOT NULL,
    window_id character varying(255) NOT NULL,
    CONSTRAINT input_window_audit_action_check CHECK (((action)::text = ANY ((ARRAY['OPENED'::character varying, 'OPENED_ON_SCHEDULE'::character varying, 'EXTENDED'::character varying, 'REOPENED'::character varying, 'CLOSED'::character varying, 'CLOSED_AT_CUT_OFF'::character varying])::text[]))),
    CONSTRAINT input_window_audit_status_after_check CHECK (((status_after)::text = ANY ((ARRAY['SCHEDULED'::character varying, 'OPEN'::character varying, 'REOPENED'::character varying, 'CLOSED'::character varying])::text[]))),
    CONSTRAINT input_window_audit_status_before_check CHECK (((status_before)::text = ANY ((ARRAY['SCHEDULED'::character varying, 'OPEN'::character varying, 'REOPENED'::character varying, 'CLOSED'::character varying])::text[])))
);

ALTER TABLE input_window_audit
    ADD CONSTRAINT input_window_audit_pkey PRIMARY KEY (id);

CREATE INDEX IF NOT EXISTS idx_input_window_audit_window ON input_window_audit USING btree (company_id, window_id, occurred_at);

