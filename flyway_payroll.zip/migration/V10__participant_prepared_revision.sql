-- Migration des participants d'une campagne, les snapshot sont maintenant portés par la preparation
ALTER TABLE payroll_campaign_participants ADD COLUMN net_salary numeric(38,10);

ALTER TABLE payroll_campaign_participants
    DROP COLUMN employee_snapshot,
    DROP COLUMN remunerations,
    DROP COLUMN activity_snapshot,
    DROP COLUMN presence_segments,
    DROP COLUMN prepared_inputs,
    DROP COLUMN benefits,
    DROP COLUMN absences;

CREATE INDEX idx_participant_preparation ON payroll_campaign_participants (preparation_id);

-- Keep any previously published configuration versions for historical calculations.
-- From now on a campaign can receive only its initial configuration.
CREATE FUNCTION prevent_campaign_configuration_refreeze() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
    PERFORM 1 FROM payroll_campaigns
      WHERE company_id = NEW.company_id AND payroll_id = NEW.run_id FOR UPDATE;
    IF EXISTS (SELECT 1 FROM payroll_run_configurations WHERE company_id = NEW.company_id AND run_id = NEW.run_id) THEN
        RAISE EXCEPTION 'Campaign configuration is immutable after startup';
    END IF;
    RETURN NEW;
END $$;

CREATE TRIGGER immutable_campaign_configuration
BEFORE INSERT ON payroll_run_configurations
FOR EACH ROW EXECUTE FUNCTION prevent_campaign_configuration_refreeze();
