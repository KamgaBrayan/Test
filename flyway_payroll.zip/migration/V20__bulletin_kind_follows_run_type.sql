-- La nature d'un bulletin suit le type du run qui l'émet. La contrainte posée par V18 ne connaissait
-- que NORMAL, FICTIVE et CORRECTIVE : un run hors cycle ou un solde de tout compte n'avait aucune
-- valeur à écrire. Aucune reprise de données : les bulletins déjà écrits sont tous NORMAL, qui reste
-- la nature de la paie principale.

-- La contrainte de V18 est née sans nom dans un ADD COLUMN ; on la retrouve par la colonne qu'elle
-- garde plutôt que par un nom supposé.
DO $$
DECLARE constraint_name text;
BEGIN
    FOR constraint_name IN
        SELECT con.conname
        FROM pg_constraint con
                 JOIN pg_class rel ON rel.oid = con.conrelid
                 JOIN pg_attribute att ON att.attrelid = rel.oid AND att.attnum = ANY (con.conkey)
        WHERE rel.relname = 'payroll_campaign_participant_bulletins'
          AND con.contype = 'c'
          AND att.attname = 'kind'
        LOOP
            EXECUTE format('ALTER TABLE payroll_campaign_participant_bulletins DROP CONSTRAINT %I', constraint_name);
        END LOOP;
END $$;

ALTER TABLE payroll_campaign_participant_bulletins
    ADD CONSTRAINT payroll_campaign_participant_bulletins_kind_check
        CHECK (kind IN ('NORMAL', 'OFF_CYCLE', 'TERMINATION', 'CORRECTIVE', 'FICTIVE'));
