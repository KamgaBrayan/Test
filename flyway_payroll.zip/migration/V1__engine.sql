-- Le moteur de paie.
--
-- Ce qui calcule : une release, ses rubriques, ses bases, ses constantes, ses fonctions, et les
-- liaisons de saisie qui disent quelles valeurs elle sait lire. Une release est immuable une fois
-- publiee, et c'est ce qui permet a une paie ancienne de se rejouer a l'identique.
--
-- L'affectation d'une release a une societe vit ici aussi : c'est elle qui dit avec quel moteur une
-- entreprise calcule, et elle a le droit de rester sur une version.
--
-- Cette migration fait partie de l'aplatissement du schema. Les anciennes V2..V16 patchaient
-- un schema que seul `ddl-auto` savait creer : sur une base neuve, elles echouaient. Le schema
-- est desormais pilote par ces cinq migrations, et `ddl-auto: validate` echoue au demarrage si
-- le modele d'entites et elles divergent -- un ecart se voit au boot plutot qu'a la premiere
-- requete qui touche la colonne manquante.

-- ------------------------------------------------------------------------
-- engines
-- ------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS engines (
    deprecated boolean,
    retroactive_from date,
    valid_from date,
    valid_to date,
    created_at timestamp(6) with time zone,
    published_at timestamp(6) with time zone,
    updated_at timestamp(6) with time zone,
    country_code character varying(255) NOT NULL,
    description character varying(255),
    display_name character varying(255) NOT NULL,
    id character varying(255) NOT NULL,
    legal_reference jsonb NOT NULL,
    localized_descriptions jsonb,
    localized_display_names jsonb,
    status character varying(255),
    version character varying(255) NOT NULL,
    CONSTRAINT engines_status_check CHECK (((status)::text = ANY ((ARRAY['DRAFT'::character varying, 'ENABLED'::character varying, 'DISABLED'::character varying, 'ARCHIVED'::character varying])::text[])))
);

ALTER TABLE engines
    ADD CONSTRAINT engines_pkey PRIMARY KEY (id);

ALTER TABLE engines
    ADD CONSTRAINT uc_engineentity_version UNIQUE (version, country_code);

-- ------------------------------------------------------------------------
-- engine_bases
-- ------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS engine_bases (
    optional boolean,
    code character varying(255) NOT NULL,
    description text NOT NULL,
    display_name character varying(255) NOT NULL,
    engine_id character varying(255) NOT NULL,
    formular jsonb NOT NULL,
    rounding_rule character varying(255) NOT NULL,
    type character varying(255) NOT NULL,
    CONSTRAINT engine_bases_rounding_rule_check CHECK (((rounding_rule)::text = ANY ((ARRAY['NONE'::character varying, 'UP'::character varying, 'DOWN'::character varying, 'HALF_UP'::character varying, 'HALF_DOWN'::character varying])::text[]))),
    CONSTRAINT engine_bases_type_check CHECK (((type)::text = ANY ((ARRAY['REMUNERATION'::character varying, 'INTERMEDIATE'::character varying, 'SUMMARY'::character varying])::text[])))
);

ALTER TABLE engine_bases
    ADD CONSTRAINT engine_bases_pkey PRIMARY KEY (code, engine_id);

ALTER TABLE engine_bases
    ADD CONSTRAINT fkn9ct8w1txd32qxw24c0ojopkt FOREIGN KEY (engine_id) REFERENCES public.engines(id);

-- ------------------------------------------------------------------------
-- engine_constants
-- ------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS engine_constants (
    value numeric(19,6) NOT NULL,
    code character varying(255) NOT NULL,
    description character varying(255) NOT NULL,
    engine_id character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    override_input_code character varying(255),
    resolution_policy character varying(255) NOT NULL,
    value_type character varying(255) NOT NULL,
    CONSTRAINT engine_constants_resolution_policy_check CHECK (((resolution_policy)::text = ANY ((ARRAY['REJECT_OVERRIDE'::character varying, 'ENGINE_ONLY'::character varying, 'INPUT_OVERRIDE'::character varying, 'MAXIMUM'::character varying, 'MINIMUM'::character varying])::text[]))),
    CONSTRAINT engine_constants_value_type_check CHECK (((value_type)::text = ANY ((ARRAY['HOURS'::character varying, 'DAYS'::character varying, 'YEARS'::character varying, 'MONTHS'::character varying, 'AMOUNT'::character varying, 'COUNT'::character varying, 'PERCENT'::character varying, 'NUMBER'::character varying, 'RATE'::character varying, 'PERCENTAGE'::character varying, 'QUANTITY'::character varying, 'BOOLEAN'::character varying, 'ENUM'::character varying, 'STRING'::character varying])::text[])))
);

ALTER TABLE engine_constants
    ADD CONSTRAINT engine_constants_pkey PRIMARY KEY (code, engine_id);

ALTER TABLE engine_constants
    ADD CONSTRAINT fk37v3a0tdvc6bi692f9ue8bnmw FOREIGN KEY (engine_id) REFERENCES public.engines(id);

-- ------------------------------------------------------------------------
-- engine_cumulative_rules
-- ------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS engine_cumulative_rules (
    enabled boolean NOT NULL,
    end_month integer,
    include_current_pay_period boolean NOT NULL,
    rolling_months_window integer,
    start_month integer,
    accumulator_code character varying(255) NOT NULL,
    aggregation character varying(255),
    contribution_source character varying(255),
    engine_id character varying(255) NOT NULL,
    scope character varying(255),
    source_code character varying(255) NOT NULL,
    CONSTRAINT engine_cumulative_rules_aggregation_check CHECK (((aggregation)::text = ANY ((ARRAY['SUM'::character varying, 'AVERAGE'::character varying, 'LAST_VALUE'::character varying])::text[]))),
    CONSTRAINT engine_cumulative_rules_contribution_source_check CHECK (((contribution_source)::text = ANY ((ARRAY['BASE'::character varying, 'CAPPED_BASE'::character varying, 'RATE'::character varying, 'AMOUNT'::character varying])::text[]))),
    CONSTRAINT engine_cumulative_rules_scope_check CHECK (((scope)::text = ANY ((ARRAY['CALENDAR_YEAR'::character varying, 'FISCAL_YEAR'::character varying, 'ROLLING_WINDOW'::character varying])::text[])))
);

ALTER TABLE engine_cumulative_rules
    ADD CONSTRAINT engine_cumulative_rules_pkey PRIMARY KEY (accumulator_code, engine_id);

-- ------------------------------------------------------------------------
-- engine_functions
-- ------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS engine_functions (
    description character varying(255) NOT NULL,
    engine_id character varying(255) NOT NULL,
    fnc jsonb NOT NULL,
    name character varying(255) NOT NULL
);

ALTER TABLE engine_functions
    ADD CONSTRAINT engine_functions_pkey PRIMARY KEY (engine_id, name);

ALTER TABLE engine_functions
    ADD CONSTRAINT fk9wtjj3jeetmvbpuuhakwi51gw FOREIGN KEY (engine_id) REFERENCES public.engines(id);

-- ------------------------------------------------------------------------
-- engine_inputs
-- ------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS engine_inputs (
    catalog_valid_from date,
    catalog_valid_to date,
    integral boolean NOT NULL,
    maximum numeric(38,2),
    minimum numeric(38,2),
    overridable boolean NOT NULL,
    required boolean NOT NULL,
    system_defined boolean NOT NULL,
    catalog_version bigint,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    aggregation character varying(255),
    allowed_sources character varying(255) NOT NULL,
    code character varying(255) NOT NULL,
    color character varying(255),
    country_code character varying(255) NOT NULL,
    currency character varying(255),
    display_name character varying(255) NOT NULL,
    engine_id character varying(255) NOT NULL,
    frequency character varying(255) NOT NULL,
    icon character varying(255),
    input_value_type character varying(255),
    legal_ref character varying(255),
    localized_display_names jsonb,
    possible_values character varying(255),
    reference_value character varying(255),
    resolution_policy character varying(255),
    unit character varying(255),
    value_type character varying(255) NOT NULL,
    CONSTRAINT engine_inputs_aggregation_check CHECK (((aggregation)::text = ANY ((ARRAY['SINGLE'::character varying, 'SUM'::character varying])::text[]))),
    CONSTRAINT engine_inputs_frequency_check CHECK (((frequency)::text = ANY ((ARRAY['PERMANENT'::character varying, 'CAMPAIGN'::character varying])::text[]))),
    CONSTRAINT engine_inputs_input_value_type_check CHECK (((input_value_type)::text = ANY ((ARRAY['MONEY'::character varying, 'DECIMAL'::character varying, 'RATE'::character varying, 'QUANTITY'::character varying, 'BOOLEAN'::character varying, 'DATE'::character varying, 'TEXT'::character varying])::text[]))),
    CONSTRAINT engine_inputs_resolution_policy_check CHECK (((resolution_policy)::text = ANY ((ARRAY['REFERENCE_ONLY'::character varying, 'EXTERNAL_OVERRIDE'::character varying, 'MAXIMUM'::character varying, 'MINIMUM'::character varying])::text[]))),
    CONSTRAINT engine_inputs_unit_check CHECK (((unit)::text = ANY ((ARRAY['HOURS'::character varying, 'DAYS'::character varying, 'MONTHS'::character varying, 'YEARS'::character varying, 'UNITS'::character varying])::text[]))),
    CONSTRAINT engine_inputs_value_type_check CHECK (((value_type)::text = ANY ((ARRAY['HOURS'::character varying, 'DAYS'::character varying, 'YEARS'::character varying, 'MONTHS'::character varying, 'AMOUNT'::character varying, 'COUNT'::character varying, 'PERCENT'::character varying, 'NUMBER'::character varying, 'RATE'::character varying, 'PERCENTAGE'::character varying, 'QUANTITY'::character varying, 'BOOLEAN'::character varying, 'ENUM'::character varying, 'STRING'::character varying])::text[])))
);

ALTER TABLE engine_inputs
    ADD CONSTRAINT engine_inputs_pkey PRIMARY KEY (code, engine_id);

CREATE INDEX IF NOT EXISTS idx_engine_input_country ON engine_inputs USING btree (country_code);

CREATE INDEX IF NOT EXISTS idx_engine_input_engine ON engine_inputs USING btree (engine_id);

-- ------------------------------------------------------------------------
-- engine_remuneration_rules
-- ------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS engine_remuneration_rules (
    catalog_valid_from date,
    catalog_valid_to date,
    contributive boolean NOT NULL,
    overridable boolean NOT NULL,
    taxable boolean NOT NULL,
    catalog_version bigint,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    calculation jsonb,
    catalog_number varchar(16),
    catalog_type character varying(255),
    catalog_value_type character varying(255),
    category character varying(255),
    code character varying(255) NOT NULL,
    color character varying(255),
    contribution_treatment_display jsonb,
    contribution_treatment_explanation text,
    contribution_treatment_formula text,
    contribution_treatment_mode character varying(255),
    contribution_treatment_visibility character varying(255),
    country_code character varying(255) NOT NULL,
    display_name character varying(255) NOT NULL,
    engine_id character varying(255) NOT NULL,
    icon character varying(255),
    legal_ref character varying(255),
    localized_display_names jsonb,
    nature character varying(255),
    output_bindings jsonb NOT NULL,
    proration_policy jsonb,
    resolution_policy character varying(255),
    tax_treatment_display jsonb,
    tax_treatment_explanation text,
    tax_treatment_formula text,
    tax_treatment_mode character varying(255),
    tax_treatment_visibility character varying(255),
    CONSTRAINT engine_remuneration_rules_category_check CHECK (((category)::text = ANY ((ARRAY['BASE_SALARY'::character varying, 'OVERTIME'::character varying, 'ALLOWANCE'::character varying, 'BONUS'::character varying, 'BENEFIT'::character varying, 'DEDUCTION'::character varying])::text[]))),
    CONSTRAINT engine_remuneration_rules_contribution_treatment_mode_check CHECK (((contribution_treatment_mode)::text = ANY ((ARRAY['EXCLUDED'::character varying, 'INCLUDED'::character varying, 'FORMULA'::character varying])::text[]))),
    CONSTRAINT engine_remuneration_rules_contribution_treatment_visibili_check CHECK (((contribution_treatment_visibility)::text = ANY ((ARRAY['PAYSLIP'::character varying, 'DETAIL_ONLY'::character varying, 'INTERNAL'::character varying])::text[]))),
    CONSTRAINT engine_remuneration_rules_nature_check CHECK (((nature)::text = ANY ((ARRAY['FINAL'::character varying, 'INTERMEDIATE'::character varying])::text[]))),
    CONSTRAINT engine_remuneration_rules_resolution_policy_check CHECK (((resolution_policy)::text = ANY ((ARRAY['ENGINE_ONLY'::character varying, 'ACCEPT_AMOUNT'::character varying, 'ACCEPT_CALCULATION'::character varying])::text[]))),
    CONSTRAINT engine_remuneration_rules_tax_treatment_mode_check CHECK (((tax_treatment_mode)::text = ANY ((ARRAY['EXCLUDED'::character varying, 'INCLUDED'::character varying, 'FORMULA'::character varying])::text[]))),
    CONSTRAINT engine_remuneration_rules_tax_treatment_visibility_check CHECK (((tax_treatment_visibility)::text = ANY ((ARRAY['PAYSLIP'::character varying, 'DETAIL_ONLY'::character varying, 'INTERNAL'::character varying])::text[])))
);

CREATE UNIQUE INDEX engine_remuneration_catalog_number
    ON engine_remuneration_rules (engine_id, catalog_number)
    WHERE catalog_number IS NOT NULL;

ALTER TABLE engine_remuneration_rules
    ADD CONSTRAINT engine_remuneration_rules_pkey PRIMARY KEY (code, engine_id);

CREATE INDEX IF NOT EXISTS idx_engine_remuneration_rule_country ON engine_remuneration_rules USING btree (country_code);

CREATE INDEX IF NOT EXISTS idx_engine_remuneration_rule_engine ON engine_remuneration_rules USING btree (engine_id);

-- ------------------------------------------------------------------------
-- payroll_engine_assignments
-- ------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS payroll_engine_assignments (
    effective_from date NOT NULL,
    effective_to date,
    assigned_at timestamp(6) with time zone NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    lock_version bigint NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    assigned_by character varying(255),
    company_id character varying(255) NOT NULL,
    engine_id character varying(255) NOT NULL,
    id character varying(255) NOT NULL,
    legal_entity_id character varying(255) NOT NULL,
    status character varying(255) NOT NULL,
    CONSTRAINT payroll_engine_assignments_status_check CHECK (((status)::text = ANY ((ARRAY['PLANNED'::character varying, 'ACTIVE'::character varying, 'ENDED'::character varying])::text[])))
);

ALTER TABLE payroll_engine_assignments
    ADD CONSTRAINT payroll_engine_assignments_pkey PRIMARY KEY (id);

CREATE INDEX IF NOT EXISTS idx_engine_assignment_engine ON payroll_engine_assignments USING btree (company_id, engine_id);

CREATE INDEX IF NOT EXISTS idx_engine_assignment_legal_entity ON payroll_engine_assignments USING btree (company_id, legal_entity_id, effective_from);
