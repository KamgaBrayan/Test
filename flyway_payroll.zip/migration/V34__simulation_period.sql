-- Une simulation porte son mois : il borne la période des avantages simulés et situe l'embauche.
-- Les simulations déjà écrites le prennent de leur création.

ALTER TABLE payroll_simulations
    ADD COLUMN IF NOT EXISTS period varchar(7);

UPDATE payroll_simulations
SET period = to_char(created_at, 'YYYY-MM')
WHERE period IS NULL AND created_at IS NOT NULL;
