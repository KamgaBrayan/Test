-- La sequence qui numerote les ecritures de cumul (CumulativeEntryEntityRepository.nextSequence).
-- Aucune migration ne la creait : l'emission d'un bulletin echouait des la premiere ecriture de cumul
-- ("relation cumulative_entry_sequence does not exist").
CREATE SEQUENCE IF NOT EXISTS cumulative_entry_sequence START WITH 1 INCREMENT BY 1;

-- Une base qui porterait deja des ecritures repart au-dela de la plus grande sequence connue.
SELECT setval('cumulative_entry_sequence', GREATEST((SELECT COALESCE(MAX(entry_sequence), 0) FROM cumulative_entries), 1),
              (SELECT COUNT(*) > 0 FROM cumulative_entries));
