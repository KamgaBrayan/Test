-- Les types d'élément de Compensation sont désormais les catégories de rubrique (BASE_SALARY, OVERTIME,
-- ALLOWANCE, BONUS) : l'import remplit la catégorie depuis le type. Les rubriques déjà importées sans
-- catégorie la reçoivent ici ; une catégorie déjà saisie n'est jamais écrasée.

UPDATE engine_remuneration_rules
SET category = catalog_type
WHERE category IS NULL
  AND catalog_type IN ('BASE_SALARY', 'OVERTIME', 'ALLOWANCE', 'BONUS');
