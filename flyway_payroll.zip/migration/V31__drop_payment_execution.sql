-- Le paiement sort vers payment-service (docs/17). L'exécution n'a plus de code dans la paie ; ses
-- tables, orphelines depuis, disparaissent. La paie garde le net restant à payer de chaque bulletin
-- (payroll_bulletin_payments), alimenté par les événements de payment-service.

DROP TABLE IF EXISTS campaign_payment_exports CASCADE;
DROP TABLE IF EXISTS payroll_payments CASCADE;
